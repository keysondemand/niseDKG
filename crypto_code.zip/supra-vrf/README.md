
# supra-vrf

This is the “mono-repo” for Supra's <abbr title="Veriafiable random function">VRF</abbr> service. in this repository you can find:

- the smart contracts for the VRF for different technologies (EVM, Aptos, Sui, etc.) in the `smart-contracts/` directory.
- the code for the “back-end” Rust code of the VRF service, in the `nodes/` directory
- example contracts, such as the user contract demonstrating how to integrate our Supra VRF, in the `sdk/` directory.

## git-related prerequisite

To make git dependencies in cargo work with ssh keys, you need to set following configuration variable  `CARGO_NET_GIT_FETCH_WITH_CLI=true`

To use the commit hooks, you need to set up the git config for that project so that it fetches the hooks in the right place:

```
git config core.hooksPath .githooks
```

## Recent Changes

[CHANGELOG.md](./CHANGELOG.md)

## Overview

The VRF service relies on 4 different parts to work:
- smart contracts, deployed on the target chains.
- the [`free-node`](nodes/free-node/), that listen to the events sent by the smart contract on chain, and publish the final transaction.
- a VRF committee, which is a cluster of [`vrf-node`](nodes/vrf-node/) responsible for the random number generation using a [BLS threshold signature](https://en.wikipedia.org/wiki/BLS_digital_signature)
- the <abbr title="State machine replication">SMR</abbr> cluster, which is used for the distributed key generation (DKG) of the BLS public key.

The first three parts can be found in this repository, but the SMR is located [in its own repository](https://github.com/Entropy-Foundation/smr-hotstuff/).

## How to test it

There are several ways to run the code, depending on what exactly you're trying to test.

- end to end testing: requirest to run a blockchain RPC node on which you set up the smart contracts, the free node, a VRF comittee and an SMR committee.
- free node + smart contracts: there's a feature in the free-node that allows to mock the VRF committee entirely, removing the need for spawning an SMR cluster and a VRF committee to test the free node.
- free node + VRF committee + SMR: respectively, there's a feature in the free-node to mock the blockchain side while using an actual VRF committee.
- free node alone: unsurprisingly, the free node supports mocking both sides.
- the VRF committee + SMR: the VRF node can also be tested independently from the free node and the blockchain (but it still needs and SMR cluster up and running)

Below, you'll find the instructions to run each and every one of these tests (but in a slightly different order)

Note: in all of this check, you should see the following warning appearing in the logs

> [XXXX-XX-XXTXX:XX:XXZ WARN  influx_metrics] INFLUXDB_HOST not set! using using mock metrics implmentation

It just mean that the metrics won't be sent to influxdb and will be displayed in the logs instead (at the `debug` level).
### Preamble, free node configuration

The configuration of the free node comes from a configuration file called `config.toml` that must be located in the repository you're running the free node in.

There's an example configuration file in the `nodes/free-node` directory called `config.toml.example`. If you want to test the free-node locally on ` anvil`, you'll need to use copy the `[eth.anvil]` section of the example file in a config file.

The configuration file must contain a list of configuration, one per chain that the free-node should listen on. The configurations are grouped into chain technologies. Currently, the following technologies are supported:
- `eth`, for EVM chains
- `sui`, for the Sui blockchain
- `aptos`, for the Aptos blockchain

For the `eth` familly, the configuration options are the following:

- `chain_secret_keys_hex`: an array of secret keys that will be used to submit callback transactions. These private key must have their public keys whitelisted on the smart-contract before they can be used.
- `sc_address`: the address of the supra smart contract
- `deposit_sc_address`: the address of the deposit smart contract
- `sc_client_url`: the URL of the HTTP RPC endpoint
- `sc_client_callback_url`: *OPTIONAL* the URL of the HTTP RPC endpoint to use for callbacks (default: same as `sc_client_url`)
- `sc_wss_url`: the URL of the WebSocket RPC endpoint
- `block_span`: *OPTIONAL* the number of blocks that will be fetched at a single time during the catchup process (default: 10000). If the free-node has to catchup-up from block *#42* to block *#666* and the block span is `100`, then the free node will perform 7 requests during the catch-up (42->141, 142->242, …, 542-641 and 641->666).
- `polling_interval_secs`: *OPTIONAL* the interval between two consecutive HTTP polls, acting as a websocket backup (default= 10)
- `gas_limit`: *OPTIONAL* the maximum amount of gas that the free node is allowed to spend in a single transaction (default 18_000_000)
- `sc_whitelist`: *OPTIONAL* a list of whitelisted smart contract addresses (default: empty)
- `sc_blacklist`: *OPTIONAL* a list of blacklisted smart contract addresses (default: empty)
- `gas_provider`: *OPTIONAL* gas provider configuration, to get a better estimation of the gas cost for certain chains (like Polygon). Example: `gas_provider = { gas_station_api = https://gasstation.polygon.technology/v2 }`. (default: None, no gas provider will be used)
- `is_backup_node`: *OPTIONAL* a boolean determining if the free-node will be performing the catch-up on start-up or not (default: false, meaning that by default the free-node will perform the catch-up)

For `aptos`, the configuration options are the following:

- `sc_client_url`: the URL of the HTTP RPC endpoint
- `sc_address`: the address of the supra (generator) smart contract
- `creation_num`: Creation number for the generator smart contract
- `request_interval`: *OPTIONAL* Polling interval for aptos event stream (default= 1000)
- `sc_whitelist`: *OPTIONAL* a list of whitelisted smart contract addresses (default: empty)
- `sc_blacklist`: *OPTIONAL* a list of blacklisted smart contract addresses (default: empty)

And for `sui`, the configuration options are:

- `sc_address`: the address of the supra (generator) smart contract
- `sc_client_url`: the URL of the HTTP RPC endpoint
- `sc_wss_url`: the URL of the WebSocket RPC endpoint
- `dkg_resource_id`: *OPTIONAL* Dkg Resource ID to be used for smart contract callbacks (default, empty string `""`)
- `sc_whitelist`: *OPTIONAL* a list of whitelisted smart contract addresses (default: empty)
- `sc_blacklist`: *OPTIONAL* a list of blacklisted smart contract addresses (default: empty)

### Testing the free node alone

```
RUST_LOG=trace cargo run --no-default-features --features "test"
```

You can cutomize the level of logs you see, with the `RUST_LOG` environment variable, see [the documentation](https://docs.rs/env_logger/latest/env_logger/).

### Testing the free node with the smart contracts, without the VRF committee

The smart contract deployment procedure is going to depend on the specific chain technology you're targetting (EVM, Sui or Aptos are supported at the moment). In the following, I'll talk about testing the EVM smart contract on a local EVM chain (for other chain technologies, see the README.md for [Sui](nodes/blockchains/sui-connector/README.md) and [Aptos](nodes/blockchains/aptos-connector/README.md)).

First of all, you'll need a local development blockchain and sdk: at supra we're using [foundry](https://getfoundry.sh/), and all the following instructions assume you have foundry installed.

Once it's installed, the first step is to start `anvil`, the local test chain.

```
anvil -b 5
```

The `-b` parameters tells `anvil` to mine new blocks every 5 seconds at worse even if there is no transaction. This is important, because otherwise testing seems not to work because the free node is waiting for a certain number of confirmation before picking-up an event.

Then you need to publish the contracts to the local blockchain. There's a simple script to do so: `smart-contracts/eth/deploy_local.sh`. But before you can run the script, you need to get a few dependencies that are located in a git submodule.

```
$ git submodule init
$ git submodule update --remote
$ cd smart-contract/eth/
$ ./deploy_local.sh
```

Then you need to start the free-node, with the VRF-committee replaced by a mock committee:

```
$ cd nodes/free-node
$ RUST_LOG=info SMART_CONTRACT_ABI_PATH="../../smart-contracts/eth/out/SupraGeneratorContract.sol/SupraGeneratorContract.json" DEPOSIT_CONTRACT_ABI_PATH="../../smart-contracts/eth/out/DepositContract.sol/DepositContract.json" cargo run --no-default-features --features "eth mock_vrf"
```

Once the free-node is up and running, you can send RNG requests by running the script in `smart-contracts/eth/call_rng. sh`. The scripts take zero, one or two arguments
- with zero argument, it simply requires 1 random number
- with one (numeric) argument, it requires n random number in a single transaction
- with two arguments, one numeric and the other being a name (string), it requires n random number for user named “name”.

These three alternatives don't change much except what's shown in the logs.

#### Testing multiple free nodes simultaneously

Multiple free nodes can be run simultaneously as a way to ensure high availability. When running multiple free-node, they must have a **different set of private keys**, and those keys must be whitelisted on the smartcontract. In the existing deployment script, the whitelisted keys are `0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6` (public key = `0x90F79bf6EB2c4f870365E785982E1f101E93b906`) and `0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d` (public key = `0x70997970C51812dc3A010C7d01b50e0d17dc79C8`), but if you want more keys, you can add your public key of choice to the whitelist like it is done in [this commit](https://github.com/Entropy-Foundation/supra-vrf/pull/269/commits/1b82e44066cc1b6e7bd04f8a4db635ca2f7a70ad).

### Testing the Free node with a VRF committee without blockchain nor smart contracts


To be able to run a VRF committee, you must have a local SMR cluster running, so that the VRF committee can run their Distributed Key Generation (DKG) procedure in order to generate the committee's BLS public key.

To run the SMR, you need to clone the [smr-hotstuff](https://github.com/Entropy-Foundation/smr-hotstuff/) repository, then go to the `demo_smr`` subdirectory and you can run it with:

```bash
# cd demo_smr
RUSTFLAGS="--cfg tokio_unstable" RUST_BACKTRACE=1 RUST_LOG=info cargo run --release --bin nodes
```

It is recommanded to run the SMR on release mode to make sure that it's fast enough, for the DKG to complete in less than a minute (it is not mandatory though, otherwise you can just wait for the DKG to complete).

When you start the SMR, the SMR cluster needs to initialize itself: you'll have logs of the communication between the SMR nodes showing up in the logs, and you'll know the initialization is done when all you see in the logs is an endless line of:

> [2023-07-11T07:41:41Z INFO  bftconsensus::core] Timeout reached for round [X] in round [X+1]
> [2023-07-11T07:41:41Z INFO  bftconsensus::core] Timeout reached for round [X] in round [X+1]

Where X is an integer > 80.

After the SMR is initialized, it's time to start the VRF committee, in supra-vrf directory, you should go to `nodes/vrf-node` and run:

```bash
# cd nodes/vrf-nodes
RUST_LOG=info RUST_BACKTRACE=1 SMR_NODE_ADDR=127.0.0.1:25000 SIMULATED_FULL_NODE_RESPONSE_TIME=500 cargo run --no-default-features --features "mock_connector" --bin start_committee
```

There will be warning appearing in the logs for both the VRF commmittee and the SMR, but you should let it run until the end of the DKG process, which happens when the VRF committee's log show:

> [2023-07-11T07:23:08Z INFO  vrf_node::run_loop] DKG committee done from SMR.
> [2023-07-11T07:23:08Z INFO  vrf_node::run_loop] DKG committee done from SMR.
> [2023-07-11T07:23:08Z INFO  vrf_node::run_loop] DKG committee done from SMR.
> [2023-07-11T07:23:08Z INFO  vrf_node::run_loop] DKG committee done from SMR.
> [2023-07-11T07:23:08Z INFO  vrf_node::run_loop] DKG committee done from SMR.

Now you can start the free-node, with the blockchain side being stubbed, fake events will then be generated automatically by the stub:

```bash
# cd nodes/free-node
RUST_LOG=info VRF_ENDPOINT=127.0.0.1:26000 BACKUP_VRF_ENDPOINT=127.0.0.1:26001 cargo run --no-default-features --features "mock_connector"
```

### Testing the Free node with a VRF committee with a blockchain and the smart contracts

First, you need to start the SMR and the VRF committee as described in the section above (but not the free node).

Once this is done, you need to get the the BLS public key that came from this DKG process, and put it in the smart-contract (:warning: at this point, you don't need to have `anvil` started, and you definitely need **not to have published the smart contracts**)

To get the BLS key, you need to start the free-node, which diplays the BLS public key on start-up, like this (obviously, on your computer, the actual key is going to be different):

```bash
# cd nodes/free-node
RUST_LOG=info SMART_CONTRACT_ABI_PATH="../../smart-contracts/eth/out/SupraGeneratorContract.sol/SupraGeneratorContract.json" DEPOSIT_CONTRACT_ABI_PATH="../../smart-contracts/eth/out/DepositContract.sol/DepositContract.json" VRF_ENDPOINT=127.0.0.1:26000 BACKUP_VRF_ENDPOINT=127.0.0.1:26001 cargo run --no-default-features --features "eth"
```

> [2023-07-11T08:00:58Z INFO  free_node] VRF COMMITTEE PUBLIC KEY
> [2023-07-11T08:00:58Z INFO  free_node] x1: 20696523853751479153309709989082770212871165085044170723602419586418681490503
> [2023-07-11T08:00:58Z INFO  free_node] x2: 16861442974754167706658859434925803312029776446951671077572974321033904583826
> [2023-07-11T08:00:58Z INFO  free_node] y1: 15379200050861090505974762740370370237903336375567596352363554277241179107830
> [2023-07-11T08:00:58Z INFO  free_node] y2: 18510020575815941708006518619803715137741693642484834276428449580191160321870

------------

Note: if `anvil` isn't started, you'll see errors in the free-node's logs:

> [2023-07-11T08:03:35Z ERROR free_node] anvil: error in blockchain_listener: Web3 client error: failed to send request: error sending request for url (http://127.0.0.1:8545/): error trying to connect: tcp connect error: Connection refused (os error 111)
> [2023-07-11T08:03:35Z ERROR free_node] anvil: blockchain connector stopped running, restarting

It's not an issue, and the error message will disapear as soon as you'll start anvil.

------------

Once you have the BLS public key, you need to update the `smart-contract/eth/deploy_local.sh` script, to set your BLS public key there following what's written as a comment in this file (the BLS_PUBLIC_KEY environment variable should contain the `x1`, `x2`, `y1` and `y2` coming from the free-node, in that exact order).

Your `deploy_local.sh` will now look like something like this:

```bash
BLS_PUBLIC_KEY="20696523853751479153309709989082770212871165085044170723602419586418681490503,16861442974754167706658859434925803312029776446951671077572974321033904583826,15379200050861090505974762740370370237903336375567596352363554277241179107830,18510020575815941708006518619803715137741693642484834276428449580191160321870" forge script LocalTestSetup --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --rpc-url http://127.0.0.1:8545 --broadcast --via-ir
```

Then you can start `anvil`, and run `deploy_local.sh` to deploy the smart contract with the BLS private key from the DKG.

And finally, once the smart contract is deployed, you can start generating random numbers with the `smart-contract/eth/call_rg.sh` script.

### Testing the VRF committee without a free node nor a blockchain

TODO
