# Changelog

All notable changes to this project will be documented in this file.

## [0.2.4] - Unreleased

### Added

- influx-metrics - add time elapsed between vrf event pick event to callback
- Create auto deploy script for evm sc
- Implement multiple private key concurrent callback processing
- enforce documentation in all VRF crates
- `rangemap` library implement to handle recovery point for evm, aptos and sui chain

### Changed

- Audit suggested changes for EVM Smart contract
- Use a different configuration structure for the VRF node and the Free node one
- Restructure how the recovery point and recovery point writer works prior to enabling concurrent callbacks
- Make the gas limit configurable instead of hardcoded
- Sui SC framework and SDK version upgrade (v0.25.0 to v0.27.0)

### Removed

- Remove unused structs
- eliminate dead code
- Remove `futures-core` library uses

### Fixed

- RngRequestEvent: add nonce to event log
- VerifyCallbackMsg and Event fixes
- fix DeferredDrain iterator ending early

## [0.2.3] - 2023-02-14

### Added

- Initial block confirmation check for websocket stream
- VRF-node verify request transaction block confirmation
- Implement a pausable stream for base_ws_stream
- Implement num_confirmations for polling stream
- Automatically retry with higher gas price when we encounter gas price errors form the RPC node
- Add initial cosmwasm smart contract
- Logging failed request at free node in influxd-metrics

### Changed

- Lint check
- Abstract deferring logic away to separate module
- Rebase rework recovery points
- Sui SC framework and SDK version upgrade (v0.19.0 to v0.22.0) and then (v0.22.0 to v0.25.0)
- Always fetch block hash from rpc
- Upgrade the Smart contract of EVM

### Fixed

- Defer events without pausing the entire websocket stream
- Fix race in deferred events implementation for http events
- Aptos - catchup recovery point correct + update start_listing
- Fix/web3 error handling
- Fix/one-hour lag
- Recovery point issue fix for SUI and Aptos


## [0.2.2] - 2023-01-06

### Added

- Add release notes URL to template
- Add binary for sending specific txns to VRF Node
- Add binary to allow processing txn hashes
- Add new EVM chains KCC ,Watr ,HashGraph ,Aurora ,Fantom ,Oasis ,TOMOChain ,DogeChain ,Celo ,Telos ,Cronos ,Gnosis ,Metis ,EVMOS ,Algorand ,Boba ,Sardis ,Ziliqa ,Harmony ,Filecoin ,Zksync
- Introduce Aptos SC Decentralise version
- Sui free-node integration as decentralise version

### Changed

- Update commenting as per Natspec format for EVM smart contract
- Update recovery point on catchup

### Fixed

- Retry if gas price is less than block base fee
- Handle nonce collision error for okex
- Write recovery point when catchup is complete
- Fix signature verification part for Aptos and Sui chain
- Sui VRF bug fixes


## [0.2.1] - 2022-12-16

### Added

- Add github actions for cargo compile checks (#57)
- Blockchain: eth: add ezsocket transport for event listener
- Use ezsockets transport
- Add Release Action
- Add Asset Upload action
- Parameterize polling interval
- Build: add clipp build flag
- Add cargo clippy and fmt
- Retry vrf calls
- Stop processing streams if we encounter a Websocket error
- Implement a fallback mechanism in case the VRF RPC endpoint is down for some reason
- Eth connector: run http catchup stream in conjunction with websocket stream
- Add unit test cases for VRF node
- Add Okex, Dfk, Klaytn network in evm
- Add Sui VRF Smart Contract
- Implement multiple blockchains listening in a single free node
- Introduce try_or_skip! macro to simplify yield Err and continue pattern


### Changed

- Websocket stream: switch from combinator to stream! macro
- Utilize ? in get_past_logs stream
- Cargo fmt and lint check
- Submit_response_transaction: add comment specifying the workaround
- Update Smart Contracts of EVM
- Update unit tests for recovery points
- Handle the situation where we have an empty recovery point file
- Changes to the recovery point format + stability improvements

### Removed
- Remove unused import
- Remove comments related to nidkg lib

### Fixed

- Enable tls for ezsockets
- Ezsocket_transfer: OPN-70 address review
- Change tag variable
- Upload asset action
- Polling listener: minor fix
- Switch back to stream from try_stream
- Move websocket stream initialization to stream! macro
- replace buffer.extend with buffer.extend_with_slice and avoid a few extra allocations
- Reduce allocations and clones
- address review
- Fix format check
- Retry if txn is underpriced
- Fix updating of options.nonce derp
- Submit_response_transaction: sleep 4 seconds before retry
- Submit_response_transaction: attempt to handle rate limiting
- Fix clippy warnings

### Removed

- Remove bn254 G2 checks because hash_to_point bug
- eth-connector: disable web3_ezsocket
- Remove ref