// To run it autonomously, with both the chain and the VRF cluster stubbed, run:
// RUST_LOG=free_node=info cargo run --no-default-features --features "test"

// To test it against anvil, with a mock VRF cluster, run:
// RUST_LOG=info SMART_CONTRACT_ABI_PATH="../../smart-contracts/eth/out/SupraGeneratorContract.sol/SupraGeneratorContract.json" DEPOSIT_CONTRACT_ABI_PATH="../../smart-contracts/eth/out/DepositContract.sol/DepositContract.json" cargo run --no-default-features --features "eth mock_vrf disable_influx_metrics"

//! The VRF Free Node. Responsible for listening to blockchain events and posting them to the VRF Node

#![warn(missing_docs)]

pub mod config;
mod load_balancing_channel;
mod runner;
pub mod secrets;
mod vrf_interface;

#[allow(unused_imports)]
use common::chains::ChainId;
use common::influx_metrics;
use config::Config;
#[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
use secrets::SecretsConfig;

#[allow(unused_imports)]
use connectors::Init;

#[cfg(feature = "mock_connector")]
use test_connector::TestConfig;

#[allow(unused_imports)]
use log::{error, info};
#[allow(unused_imports)]
use runner::blockchain_listener;
use std::net::SocketAddr;
use std::time::Duration;

use vrf_interface::{get_vrf_init_data, VrfInitData};

#[allow(dead_code)]
const RESTART_TIME_INTERVAL: Duration = Duration::from_secs(2);

#[tokio::main]
async fn main() {
    env_logger::init();
    info!("Starting");

    influx_metrics::Metrics::env_init(); // Influxdb configuration

    let config = Config::load().unwrap();
    info!("{:?}", config);

    #[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
    let secrets_config = SecretsConfig::load().unwrap();

    #[cfg(not(feature = "mock_vrf"))]
    let (vrf_rpc_addr, vrf_backup_rpc_addr) = {
        let vrf_rpc = &dotenv::var("VRF_ENDPOINT").expect("VRF_ENDPOINT not set");
        let vrf_rpc_addr = vrf_rpc
            .parse::<SocketAddr>()
            .expect("VRF_ENDPOINT not a valid <ip>:<port>");

        let vrf_backup_rpc =
            &dotenv::var("BACKUP_VRF_ENDPOINT").expect("BACKUP_VRF_ENDPOINT not set");
        let vrf_backup_rpc_addr = vrf_backup_rpc
            .parse::<SocketAddr>()
            .expect("BACKUP_VRF_ENDPOINT not a valid <ip>:<port>");
        (vrf_rpc_addr, vrf_backup_rpc_addr)
    };

    #[cfg(feature = "mock_vrf")]
    let (vrf_rpc_addr, vrf_backup_rpc_addr) = {
        use std::net::{IpAddr, Ipv4Addr};
        let placeholder_addr = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(0, 0, 0, 0)), 0);
        (placeholder_addr, placeholder_addr)
    };

    let VrfInitData {
        threshold,
        x1,
        x2,
        y1,
        y2,
    } = get_vrf_init_data(vrf_rpc_addr, vrf_backup_rpc_addr).await;

    info!("VRF COMMITTEE PUBLIC KEY");
    info!("x1: {x1:?}");
    info!("x2: {x2:?}");
    info!("y1: {y1:?}");
    info!("y2: {y2:?}");

    info!("VRF threshold");
    info!("t: {:?}", threshold);

    #[cfg(feature = "eth")]
    for (chain_id, eth_config) in config.eth.into_iter() {
        spawn_connector(
            eth_config,
            &secrets_config,
            chain_id,
            vrf_rpc_addr,
            vrf_backup_rpc_addr,
        );
    }

    #[cfg(feature = "aptos")]
    for (chain_id, aptos_config) in config.aptos.into_iter() {
        spawn_connector(
            aptos_config,
            &secrets_config,
            chain_id,
            vrf_rpc_addr,
            vrf_backup_rpc_addr,
        );
    }

    #[cfg(feature = "sui")]
    for (chain_id, sui_config) in config.sui.into_iter() {
        spawn_connector(
            sui_config,
            &secrets_config,
            chain_id,
            vrf_rpc_addr,
            vrf_backup_rpc_addr,
        );
    }

    #[cfg(feature = "mock_connector")]
    spawn_mock_connector(TestConfig, vrf_rpc_addr, vrf_backup_rpc_addr);

    // just wait forever so the spawned tasks can keep running
    std::future::pending::<()>().await;
}

#[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
fn spawn_connector<T: Init>(
    config: T,
    secrets_config: &SecretsConfig,
    chain_id: ChainId,
    vrf_rpc_addr: SocketAddr,
    vrf_backup_rpc_addr: SocketAddr,
) {
    info!("{chain_id}: chain config {:?}", config);
    let secrets = secrets_config
        .get_chain_secret_keys(chain_id)
        .unwrap_or_else(|| panic!("no secrets for chain {chain_id}"));

    let blacklist = config.blacklist().expect("invalid blacklist");
    let whitelist = config.whitelist().transpose().expect("invalid whitelist");

    tokio::spawn(async move {
        loop {
            let (recovery_point_writer, connector) = match config
                .initialize_connector(chain_id, secrets.clone())
                .await
            {
                Ok(connector) => connector,
                Err(err) => {
                    error!("{chain_id}: Initialization error {err}");
                    panic!("Failed to initialize the blockchain connector for {chain_id}: {err}");
                }
            };
            if let Err(err) = blockchain_listener(
                connector,
                blacklist.clone(),
                whitelist.clone(),
                vrf_rpc_addr,
                vrf_backup_rpc_addr,
                chain_id,
                recovery_point_writer,
            )
            .await
            {
                error!("{chain_id}: error in blockchain_listener: {err}");
            }
            error!("{chain_id}: blockchain connector stopped running, restarting");
            tokio::time::sleep(RESTART_TIME_INTERVAL).await;
        }
    });
}

#[cfg(feature = "mock_connector")]
fn spawn_mock_connector(
    config: impl Init,
    vrf_rpc_addr: SocketAddr,
    vrf_backup_rpc_addr: SocketAddr,
) {
    tokio::spawn(async move {
        let chain_id = ChainId::DevMockChain;
        let blacklist = config.blacklist().expect("invalid blacklist");
        let whitelist = config.whitelist().transpose().expect("invalid whitelist");

        let secrets = Vec::new();

        let (recovery_point_writer, connector) = config
            .initialize_connector(chain_id, secrets)
            .await
            .unwrap();

        if let Err(err) = blockchain_listener(
            connector,
            blacklist,
            whitelist,
            vrf_rpc_addr,
            vrf_backup_rpc_addr,
            chain_id,
            recovery_point_writer,
        )
        .await
        {
            error!("{chain_id}: error in blockchain_listener: {err}");
        }
        info!("Job done, no more events, the process will now go idle.");
        println!("Press ctrl-C to quit");
    });
}
