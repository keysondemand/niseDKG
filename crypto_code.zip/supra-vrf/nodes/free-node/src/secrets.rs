//! Secrets Configurations for the blockchain connectors

#[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
use std::collections::BTreeMap;
use std::env::current_dir;

#[cfg(feature = "aptos")]
use aptos_connector::AptosSecretConfig;

#[cfg(feature = "eth")]
use eth_connector::EthSecretConfig;

#[cfg(feature = "sui")]
use sui_connector::SuiSecretConfig;

use common::chains::ChainId;
use common::errors::ConfigError;
use serde::{Deserialize, Serialize};
use std::fmt::Debug;

#[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
use std::fs;

#[cfg(all(
    any(feature = "eth", feature = "aptos", feature = "sui"),
    feature = "encrypted-secrets"
))]
use chacha20poly1305::{
    aead::{Aead, AeadCore, KeyInit, OsRng},
    XChaCha20Poly1305, XNonce,
};

/// Global free node Configuration
/// see `config.toml.example` for an example config
#[derive(Serialize, Deserialize, Debug, Default)]
pub struct SecretsConfig {
    /// Aptos Configurations
    #[cfg(feature = "aptos")]
    pub aptos: BTreeMap<ChainId, AptosSecretConfig>,
    /// Ethereum Configurations
    #[cfg(feature = "eth")]
    pub eth: BTreeMap<ChainId, EthSecretConfig>,
    /// Sui Configurations
    #[cfg(feature = "sui")]
    pub sui: BTreeMap<ChainId, SuiSecretConfig>,
}

#[cfg(feature = "encrypted-secrets")]
const ENCRYPTED_CONFIG: &str = "./secrets.toml.enc";

impl SecretsConfig {
    /// Loads secrets from an existing plaintext config
    pub fn load_plaintext() -> Result<Self, ConfigError> {
        #[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
        let current_dir = current_dir().expect("Current directory must be known");

        let path = current_dir
            .join("./config.toml")
            .canonicalize()
            .map_err(|_| ConfigError::ReadFile {
                location: format!("{current_dir:?}/config.toml"),
            })?;

        let config = toml_edit::easy::from_str(&fs::read_to_string(&path).map_err(|_| {
            ConfigError::ReadFile {
                location: format!("{path:?}"),
            }
        })?)?;
        #[cfg(not(any(feature = "eth", feature = "aptos", feature = "sui")))]
        let config = SecretsConfig {};
        Ok(config)
    }

    /// Loads secrets from an existing config
    pub fn load() -> Result<Self, ConfigError> {
        #[cfg(feature = "encrypted-secrets")]
        return Self::load_encrypted();

        #[cfg(not(feature = "encrypted-secrets"))]
        return Self::load_plaintext();
    }

    #[cfg(feature = "encrypted-secrets")]
    /// Loads secrets from an existing config
    pub fn load_encrypted() -> Result<Self, ConfigError> {
        #[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
        {
            let enc_conf = fs::read(ENCRYPTED_CONFIG)?;
            let nonce = XNonce::from_slice(&enc_conf[..24]);
            let key = rpassword::prompt_password("Enter secret password(hex): ")?;

            let cipher = XChaCha20Poly1305::new_from_slice(
                &hex::decode(key).map_err(|_| ConfigError::InvalidKey)?,
            )
            .map_err(|_| ConfigError::InvalidKey)?;

            cipher
                .decrypt(nonce, &enc_conf[24..])
                .map_err(|_| ConfigError::InvalidKey)
                .and_then(|dec_conf| Ok(toml_edit::easy::from_slice(&dec_conf)?))
        }
    }

    #[cfg(feature = "encrypted-secrets")]
    /// Save the secrets to an encrypted config
    /// returns the key used to encrypt the config
    pub fn save_encrypted(self) -> Result<[u8; 32], ConfigError> {
        let key = XChaCha20Poly1305::generate_key(&mut OsRng);
        let cipher = XChaCha20Poly1305::new(&key);
        let nonce = XChaCha20Poly1305::generate_nonce(&mut OsRng);
        let raw_conf = toml_edit::easy::to_vec(&self)?;

        let mut enc_conf = nonce.to_vec();
        enc_conf.extend_from_slice(
            &cipher
                .encrypt(&nonce, raw_conf.as_ref())
                .expect("AEAD encryption failed?!"),
        );

        fs::write(ENCRYPTED_CONFIG, enc_conf)?;

        Ok(key.into())
    }

    /// Get the secret keys for a given chain
    #[allow(unused_variables)]
    pub fn get_chain_secret_keys(&self, chain_id: ChainId) -> Option<Vec<String>> {
        #[cfg(feature = "aptos")]
        if let Some(aptos) = self.aptos.get(&chain_id) {
            return Some(vec![aptos.chain_secret_key_hex.clone()]);
        }

        #[cfg(feature = "sui")]
        if let Some(sui) = self.sui.get(&chain_id) {
            return Some(sui.chain_secret_keys_hex.clone());
        }

        #[cfg(feature = "eth")]
        if let Some(eth) = self.eth.get(&chain_id) {
            // the combinator soup below just takes either the `chain_secret_keys_hex` vector in config,
            // or the `chain_secret_key_hex` (mind the lack of “s” in “key”) single key string
            // and get a unified `Vec<String>` out of it.
            return eth.chain_secret_keys_hex
            .clone()
            .and_then(|keys| {
                if keys.is_empty() {
                    None
                } else {
                    Some(keys)
                }
            }).or_else(|| {
                log::warn!("Use of deprecated `chain_secret_key_hex` in config. Prefer `chain_secret_keys_hex` instead (mind the “s”)");
                eth.chain_secret_key_hex.clone().map(|key| vec![key])
            });
        }

        None
    }
}
