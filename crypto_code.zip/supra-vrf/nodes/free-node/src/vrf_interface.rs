use web3::types::U256;

#[cfg(not(feature = "mock_vrf"))]
pub use actual_impl::{get_vrf_init_data, VrfConnector};

#[cfg(feature = "mock_vrf")]
pub use mock_impl::{get_vrf_init_data, VrfConnector};

pub struct VrfInitData {
    pub threshold: usize,
    pub x1: U256,
    pub x2: U256,
    pub y1: U256,
    pub y2: U256,
}

#[cfg(not(feature = "mock_vrf"))]
mod actual_impl {

    use common::VrfClient;
    use log::info;
    use std::net::SocketAddr;
    use std::str::FromStr;
    use web3::types::U256;

    use super::VrfInitData;

    pub use vrf_connector::VrfConnector;

    pub async fn get_vrf_init_data(
        vrf_rpc_addr: SocketAddr,
        vrf_backup_rpc_addr: SocketAddr,
    ) -> VrfInitData {
        let vrf_conn = VrfClient::new(vrf_rpc_addr, vrf_backup_rpc_addr);
        let committe_data = vrf_conn
            .get_committee_data()
            .await
            .expect("couldn't get committee data from VRF");
        let threshold = committe_data.threshold_f;

        info!(
            "committee_pubkey: {:?}",
            hex::encode(committe_data.committee_pubkey.into_bytes())
        );

        let public_key = committe_data.committee_pubkey.bn254.pub_key_g2;

        let x1 = U256::from_str(&public_key.getx().geta().tostring()).unwrap();
        let x2 = U256::from_str(&public_key.getx().getb().tostring()).unwrap();
        let y1 = U256::from_str(&public_key.gety().geta().tostring()).unwrap();
        let y2 = U256::from_str(&public_key.gety().getb().tostring()).unwrap();

        VrfInitData {
            threshold,
            x1,
            x2,
            y1,
            y2,
        }
    }
}

#[cfg(feature = "mock_vrf")]
mod mock_impl {

    use common::errors::VRFError;
    use common::VrfRequest;
    use connectors::VrfTx;
    use std::net::SocketAddr;
    use std::str::FromStr;
    use web3::types::U256;

    use super::VrfInitData;

    use nidkg_helper::nidkg::BlsPrivateKey;

    #[derive(Clone)]
    pub struct VrfConnector {
        priv_key: BlsPrivateKey,
    }

    impl VrfConnector {
        pub async fn connect(
            _vrf_rpc_addr: SocketAddr,
            _backup_vrf_rpc_addr: SocketAddr,
        ) -> VrfConnector {
            let priv_key = [42u8; 80].as_slice().try_into().unwrap();

            VrfConnector { priv_key }
        }

        pub async fn send_request(&self, request: &VrfRequest) -> Result<VrfTx, VRFError> {
            let sig = self.priv_key.sign_chain(&request.message);

            Ok(VrfTx { bls_signature: sig })
        }
    }

    pub async fn get_vrf_init_data(
        _vrf_rpc_addr: SocketAddr,
        _vrf_backup_rpc_addr: SocketAddr,
    ) -> VrfInitData {
        let priv_key: BlsPrivateKey = [42u8; 80].as_slice().try_into().unwrap();
        let public_key = priv_key.public_key().bn254.pub_key_g2;

        let x1 = U256::from_str(&public_key.getx().geta().tostring()).unwrap();
        let x2 = U256::from_str(&public_key.getx().getb().tostring()).unwrap();
        let y1 = U256::from_str(&public_key.gety().geta().tostring()).unwrap();
        let y2 = U256::from_str(&public_key.gety().getb().tostring()).unwrap();

        VrfInitData {
            threshold: 0,
            x1,
            x2,
            y1,
            y2,
        }
    }
}
