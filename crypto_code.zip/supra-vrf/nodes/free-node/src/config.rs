//! Configurations for the blockchain connectors

#[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
use std::collections::BTreeMap;
use std::env::current_dir;

#[cfg(feature = "aptos")]
use aptos_connector::AptosConfig;

#[cfg(feature = "eth")]
use eth_connector::EthConfig;

#[cfg(feature = "sui")]
use sui_connector::SuiConfig;

#[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
use common::chains::ChainId;
use common::errors::ConfigError;
use serde::{Deserialize, Serialize};
use std::fmt::Debug;

#[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
use std::fs;

/// Global free node Configuration
/// see `config.toml.example` for an example config
#[derive(Serialize, Deserialize, Debug, Default)]
pub struct Config {
    /// Aptos Configurations
    #[cfg(feature = "aptos")]
    pub aptos: BTreeMap<ChainId, AptosConfig>,
    /// Ethereum Configurations
    #[cfg(feature = "eth")]
    pub eth: BTreeMap<ChainId, EthConfig>,
    /// Sui Configurations
    #[cfg(feature = "sui")]
    pub sui: BTreeMap<ChainId, SuiConfig>,
}

impl Config {
    /// Loads an existing config
    pub fn load() -> Result<Self, ConfigError> {
        #[cfg(any(feature = "eth", feature = "aptos", feature = "sui"))]
        let current_dir = current_dir().expect("Current directory must known");

        let path = current_dir
            .join("./config.toml")
            .canonicalize()
            .map_err(|_| ConfigError::ReadFile {
                location: format!("{current_dir:?}/config.toml"),
            })?;

        let config = toml_edit::easy::from_str(&fs::read_to_string(&path).map_err(|_| {
            ConfigError::ReadFile {
                location: format!("{path:?}"),
            }
        })?)?;
        #[cfg(not(any(feature = "eth", feature = "aptos", feature = "sui")))]
        let config = Config {};
        Ok(config)
    }
}
