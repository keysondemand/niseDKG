use std::{env, net::SocketAddr, str::FromStr};

use common::{chains::ChainId, with_retries};
use connectors::{BcConnector, Init, RequestEvent};
use eth_connector::MaybeRequestEvent;
use free_node::{secrets::SecretsConfig, Config};
use vrf_connector::VrfConnector;
use web3::types::H256;

#[tokio::main]
async fn main() {
    env_logger::init();

    let mut config = Config::load().unwrap();
    log::info!("{:?}", config);
    let secrets_config = SecretsConfig::load().unwrap();

    let vrf_rpc = &dotenv::var("VRF_ENDPOINT").expect("VRF_ENDPOINT not set");
    let vrf_rpc_addr = vrf_rpc
        .parse::<SocketAddr>()
        .expect("VRF_ENDPOINT is not a valid <ip>:<port>");

    let vrf_backup_rpc = &dotenv::var("BACKUP_VRF_ENDPOINT").expect("BACKUP_VRF_ENDPOINT not set");
    let vrf_backup_rpc_addr = vrf_backup_rpc
        .parse::<SocketAddr>()
        .expect("BACKUP_VRF_ENDPOINT not a valid <ip>:<port>");

    let chain_id = &dotenv::var("CHAIN_ID").expect("CHAIN_ID not set");
    let chain_id = ChainId::from_str(chain_id).expect("Invalid CHAIN_ID");

    let chain_conf = config
        .eth
        .get_mut(&chain_id)
        .expect("CHAIN_ID not configured!");

    let (rpw, eth_connector) = chain_conf
        .initialize_connector(
            chain_id,
            secrets_config.get_chain_secret_keys(chain_id).unwrap(),
        )
        .await
        .expect("failed to initialize EthConnector!");

    let tx_hash_raw = env::args().nth(1).expect("txn hash not passed");
    let tx_hash = H256::from_str(&tx_hash_raw).expect("invalid txn hash");

    let vrf_conn = VrfConnector::connect(vrf_rpc_addr, vrf_backup_rpc_addr).await;

    for event in eth_connector.get_logs_for_txn(tx_hash).await.unwrap() {
        log::info!("found an event {event:#?}");

        let vrf_req = event
            .to_vrf_request()
            .unwrap()
            .expect("vrf request should exist");

        log::info!(
            "{chain_id}: Sending an event to VRF with message {:?}",
            vrf_req.message
        );

        let vrf_tx = with_retries(2, || vrf_conn.send_request(&vrf_req))
            .await
            .unwrap();
        let send_future = eth_connector.send_callback_tx(
            0,
            Some(vrf_tx),
            MaybeRequestEvent::RequestEvent(event),
            rpw.clone(),
        );
        if let Err(e) = send_future.await {
            log::error!("{chain_id}: Error while sending callback {e}");
            break;
        }
        log::info!("Processed log..");
    }
}
