use crate::load_balancing_channel::load_balancing_channel;
use crate::vrf_interface::VrfConnector;

use common::chains::ChainId;
use common::{influx_metrics::Metrics, with_retries};
use connectors::recovery_point::RecoveryPointWriter;
use connectors::RequestEvent;
use connectors::StreamError;
use connectors::{BcConnector, InferCallIdent};
use log::{debug, error, info, warn};
use std::collections::HashSet;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Instant;
use tokio_stream::wrappers::UnboundedReceiverStream;
use tokio_stream::StreamExt;

// This function processes the events coming from the blockain, ask sends a request to VRF nodes, and then send the callback to the blockchain.
//
//
//     Event  Event  Event
// ──────┬─────┬──────┬────────────────────────────────────────────────►     blockchain events are processed
//       │     │      │                                                      sequentially in a dedicated task
//       │     │      │
//       │     │      │
//       ▼     │      │
//   ┌─────────┼──────┼──┐
//   │         │      │  ├───────────┐
//   │         │      │  │           │
//   └─────────┼──────┼──┘           │
//             │      │              │    VRF transactions are processed concurrently,
//          ┌──┴──┐   │              │    by spawning a task for every event,
//          │     │   │              │
//          │     ├─┐ │              │
//          └─────┘ │ ▼              │
//                  ├────────────┐   │
//                  │            │   │
//                  │            ├─┐ │
//                  ├────────────┘ │ │
//                  │              │ │
//                  │              │ │
//                  │              │ │    and sending the response to a channel.
//                  │              │ │
//                  │              │ │
//                  │              │ │
//                  │              │ │
//                  ▼              ▼ ▼
//  ───────────────────────────────────────────────────────────────────►       Callbacks are processed sequentially
//                                                                             in another dedicated task, listening to the channel
#[allow(dead_code, clippy::too_many_arguments)]
pub async fn blockchain_listener<B: BcConnector>(
    bc_connector: B,
    blacklist: HashSet<InferCallIdent<B>>,
    whitelist: Option<HashSet<InferCallIdent<B>>>,
    vrf_rpc_addr: SocketAddr,
    backup_vrf_rpc_addr: SocketAddr,
    chain_id: ChainId,
    recovery_point_writer: RecoveryPointWriter<B::Nonce, B::BlockNumber>,
) -> Result<(), B::Error> {
    let vrf_connector = VrfConnector::connect(vrf_rpc_addr, backup_vrf_rpc_addr).await;

    let catchup_stream = Box::into_pin(bc_connector.catchup().await?);

    let listening_stream = Box::into_pin(bc_connector.start_listening().await?); // Note: if the catchup succeeds but this fail, we could let the catchup go on and retry listening only later on,
                                                                                 // but we currently stop the process immediately (so it can be restarted entirely by the main function)

    let concurrency_limit = bc_connector.concurrency_limit();

    let (sender, receivers) = load_balancing_channel(concurrency_limit);

    // spawn the “blockchain event” task
    tokio::spawn(async move {
        tokio::pin!(catchup_stream);
        let mut merged_streams = listening_stream.merge(catchup_stream);

        while let Some(request_event) = merged_streams.next().await {
            let re = match request_event {
                Ok(re) => re,
                Err(err) => {
                    error!("{chain_id}: error event received: {:?}", err);
                    // If the error is a websocket error (coming from the listening stream), then we stop processing the merge stream even if there's still events coming from the catchup stream
                    if err.is_wss_error() {
                        Metrics::websocket_break(&chain_id);
                        break;
                    } else {
                        continue;
                    }
                }
            };

            info!("{chain_id}: Received an event {}", re.short_log());
            debug!("full event: {re:?}");

            let caller = re.get_caller();
            if blacklist.contains(&caller) {
                warn!(
                    "{chain_id}: Ignoring event because the caller is blacklisted: {}",
                    re.short_log()
                );
                continue;
            }

            if let Some(false) = whitelist.as_ref().map(|w| w.contains(&caller)) {
                warn!(
                    "{chain_id}: Ignoring event because the caller is not whitelisted: {}",
                    re.short_log()
                );
                continue;
            }

            let vrf_request = match re.to_vrf_request() {
                Ok(vrf_request) => vrf_request,
                Err(e) => {
                    error!("{chain_id}: unable to convert request_event to vrf_request, {:?} with error {}",re, e);
                    continue;
                }
            };

            let vrf_connector = vrf_connector.clone();

            let sender = sender.clone();
            let tx_hash = re.get_tx_hash();

            // spawn a task for each event
            tokio::spawn(async move {
                // if vrf_request isn't None, we send the vrf request to the VRF node, otherwise the vrf_transaction will be None as well
                let vrf_transaction = if let Some(vrf_request) = vrf_request {
                    info!(
                        "{chain_id}: IMPORTANT Sending an event to the VRF. Event: {}",
                        re.short_log(),
                    );
                    debug!("VRF message: {:?}", vrf_request.message);

                    Metrics::pick_event_time(
                        &chain_id,
                        re.get_vrf_nonce(),
                        re.get_reception_time(),
                    );

                    // HACK: this retry is merely here to accomodate the fact that we don't wait for block confirmation before sending an event. TODO: implement some actual logic to wait for block confirmation before sending the event to the VRF node.
                    let vrf_transaction = match with_retries(2, || {
                        vrf_connector.send_request(&vrf_request)
                    })
                    .await
                    {
                        Err(error) => {
                            error!(
                                "{chain_id}: IMPORTANT error during vrf request, {:?} with error {error}",
                                re
                            );
                            Metrics::vrf_request_break(&chain_id, error, vrf_request, tx_hash);
                            return;
                        }
                        Ok(vrf_transaction) => vrf_transaction,
                    };
                    info!(
                        "\
                        {chain_id}: IMPORTANT Received response from the VRF for event: {}",
                        re.short_log()
                    );
                    debug!("{vrf_transaction:?}");
                    Some(vrf_transaction)
                } else {
                    None
                };

                let queue_start = Instant::now();
                // The channel index is calculated from the nonce, which enables a fair load-balancing between all concurrent tasks
                let channel_index = re.get_vrf_nonce() as usize % concurrency_limit;

                if let Err(err) = sender.send((vrf_transaction, re, queue_start), channel_index) {
                    error!("{chain_id}: Failed to send transaction to the callback-processing task because the channel was closed. Error: {err}");
                }
            });
        }
    });

    let mut callback_processing_handles = Vec::with_capacity(concurrency_limit);

    // We use a reference-counted pointer to allow sharing the blockchain connectors betwee the different tasks (as Read only)
    let arc_connector = Arc::new(bc_connector);

    // spawn the callback-handling tasks, one per receiving channel and as many as the concurrency limit defines.
    for (receiver_index, receiver) in receivers.into_iter().enumerate() {
        let mut receiver_stream = UnboundedReceiverStream::new(receiver);
        let arc_connector = arc_connector.clone();

        let recovery_point_writer = recovery_point_writer.clone();

        let handle = tokio::spawn(async move {
            while let Some((vrf_transaction, request_event, queue_start)) =
                receiver_stream.next().await
            {
                Metrics::vrf_res_queue_time(&chain_id, request_event.get_vrf_nonce(), queue_start);

                // Note: The temporary future variable is needed because the borrow checker struggles with callback_connector's lifetime
                // TODO: forwarding the request event to the send_callback is a temporary hack to make things work more easily,
                // but is must be removed and replaced by sending the info we need to the VRF and getting it back from there because:
                // 1. as such, it breaks aptos at the moment.
                // 2. we cannot catch-up from a disconnection from the VRF with such a pattern.
                info!(
                    "{chain_id}: IMPORTANT getting {} from the channel",
                    request_event.short_log()
                );

                debug! {"{request_event:?}"}
                let start = Instant::now();
                let send_future = arc_connector.send_callback_tx(
                    receiver_index,
                    vrf_transaction,
                    request_event.clone(),
                    recovery_point_writer.clone(),
                );
                if let Err(error) = send_future.await {
                    error!("{chain_id}: Error while sending callback {error}");
                    continue;
                }
                info!(
                    "{chain_id}: IMPORTANT Callback sent for {}",
                    request_event.short_log()
                );
                debug! {"{request_event:?}"}
                Metrics::queued_cb_complete_time(&chain_id, request_event.get_vrf_nonce(), start);
                let instant = request_event.get_reception_time();
                Metrics::vrf_pick_cb_time(&chain_id, request_event.get_vrf_nonce(), instant);
            }
        });
        callback_processing_handles.push(handle);
    }

    // We wait for the callback processing handles to finish, because if the blockchain event processing task
    // ends, the sender of the communication channel between this and the callback processing tasks will be
    // closed, then the callback processing handles will eventually ends when it has finished processing
    // previous messages.
    futures::future::join_all(callback_processing_handles)
        .await
        .iter()
        .for_each(|result| {
            result
                .as_ref()
                .expect("An error occured when waiting on the JoinHandle");
        });
    Ok(())
}
