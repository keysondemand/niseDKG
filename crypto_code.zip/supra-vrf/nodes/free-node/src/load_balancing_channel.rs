//!
//! This is an implementation of a “multiple sender multiple consummer” channel with a fixed number of consumers
//!

use tokio::sync::mpsc::{error::SendError, unbounded_channel, UnboundedReceiver, UnboundedSender};
// UnboundedReceiver<T>

pub struct Sender<T>(Vec<UnboundedSender<T>>);

impl<T> Clone for Sender<T> {
    fn clone(&self) -> Self {
        Sender(self.0.clone())
    }
}

impl<T> Sender<T> {
    /// Calling the `send` method on the sender with a specific index `i` will send the message to the `i`th channel.
    pub fn send(&self, payload: T, index: usize) -> Result<(), SendError<T>> {
        self.0[index].send(payload)
    }
}

/// Create a “multiple sender multiple consummer” Sender with a vector of receivers
pub fn load_balancing_channel<T>(poll_size: usize) -> (Sender<T>, Vec<UnboundedReceiver<T>>) {
    let mut senders = Vec::with_capacity(poll_size);
    let mut receivers = Vec::with_capacity(poll_size);

    for _ in 0..poll_size {
        let (sender, receiver) = unbounded_channel();
        senders.push(sender);
        receivers.push(receiver);
    }
    (Sender(senders), receivers)
}
