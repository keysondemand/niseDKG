## Aptos Free Node

A node run by anybody that get event from a BC and call VRF node and get data from VRF Node and post them as transaction to Supra/developer SC.

Aptos free node are listen the event from the Supra SC and send to VRF node. So listen the event via using the rest_url.
URL should like this `{rest_url}/accounts/{account_address}/events/{creation_num}?start=0&limit=2`, Example `http://127.0.0.1:8080/v1/accounts/0x36b67d62112127f2125f2f2820ccaed685242ea3f7f50bc12ab66c980da69288/events/4?start=0&limit=2`.

- When a request event is notified from the BC
- Then The free node read the request
- And The free node wait for a request Tx finalized. Parameter in the Tx event (nb blocks). Set a max of number of block.
- And the free node send the BC event data to a VRF node
- And the VRF node verify the data by querying the BC to verify the Tx and event are valid : success and finalized,
- And the VRF node verify that the data come from the Supra SC: depend on the BC, Use event or Tx data. VRF node need to know the Supra Sc address.
- And get the Tx data: nonce, callback (dev Sc, function, parameters), chain id, number of block to wait, block hash ...
- And generate the partial sign [ nonce, the chain id, callback,number of block to wait, block hash] using VRF node's key share.
- And create a partial signature message with the partial signature and Tx data.
- And send the message to all Committee node.


### Dependencies and installation

```
Rust/Cargo : 1.64.0
Aptos for Rust rev: 971c160079263a8d3e1d2503a570b01ecaaf10ba
```

- Install rust follow this command in terminal `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh` or go to this link  `https://www.rust-lang.org/tools/install`.

To be able to compile the code, you'll need the following dependencies installed on your computer:
- libssl-dev
- g++
- pkg-config

### Start Aptos Free node

Before starting the Aptos free node, make sure the config.toml file is configured correctly path [nodes/free-node/config.toml](./free-node/config.toml) with below variables.
```toml
[aptos]
rest_url = "rest_url"
account_address = "account_address"
secret_key = "secret_key"
creation_num = "4"
event_limit = 2
request_interval = 5
```

`rest_url` and `faucet_url` are one of them based on aptos server.
```toml
[local] 
rest_url = "http://127.0.0.1:8080"
faucet_url = "http://127.0.0.1:8081"

[devnet] 
rest_url = "https://fullnode.devnet.aptoslabs.com/v1"
faucet_url = "https://faucet.devnet.aptoslabs.com"

[testnet]
rest_url = "https://fullnode.testnet.aptoslabs.com/v1"
faucet_url = "https://faucet.testnet.aptoslabs.com"
```

`account_address` is Aptos SC account address and  `secret_key` is private key of the account.

`creation_num` is the aptos new event number, mostly `4` is the value of the variable. `event_limit` is the event listing parameter at a time.

- Use `RUSTFLAGS="--cfg tokio_unstable" cargo build` command inside [nodes/free-node](./free-node) directory to build a rust script, and start script using `./target/debug/free-node`.

- Or just run rust script using the `RUSTFLAGS="--cfg tokio_unstable" cargo run` command.

- You can find here, how to deploy supra SC here [smart-contracts/aptos/README.md](./../smart-contracts/aptos/README.md). For developer SC here [sdk/README.md](./../sdk/README.md).

### Encrypted Secrets Configuration for free-node

Private Keys by default are stored in plain-text (i.e in `config.toml`). This is fine for dev environments, but in a production environment, its may be 
more appropriate to store the private keys behind an encrypted keystore.
The free-node uses a toml file encrypted with AEAD for this.

You can encrypt secrets (i.e private keys) in an existing plain-text configuration (i.e `config.toml`) in free-node with:

```bash
cargo run --bin encrypt-secrets
```
The free node will use these encrypted secrets when the `encrypted-secrets` feature is enabled

##VRF Node
See the [Readme file](vrf-node/README.md)