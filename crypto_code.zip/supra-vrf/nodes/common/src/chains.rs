//! Chains supported by supra-vrf
use num_enum::{IntoPrimitive, TryFromPrimitive};
use serde::{Deserialize, Serialize};
use std::{
    fmt::{self, Display, Formatter},
    str::FromStr,
};

/// Smart contract platform
#[derive(Eq, PartialEq, Ord, PartialOrd, Copy, Clone, Hash, Debug, Serialize, Deserialize)]
pub enum ChainType {
    /// Ethereum Virtual Machine
    Evm,
    /// Aptos flavoured Move
    Aptos,
    /// Sui flavoured Move
    Sui,
    /// Mock chain for free node testing purpose
    #[cfg(feature = "mock_connector")]
    DevMockChain,
}

/// The BLS Domain for the EVM Smart Contract
/// "b2b5ca56968e81bf5845ee0e6c6888aff023d02790943f6947a389b2e2892ea5"
pub const ETH_DOMAIN: [u8; 32] = [
    178, 181, 202, 86, 150, 142, 129, 191, 88, 69, 238, 14, 108, 104, 136, 175, 240, 35, 208, 39,
    144, 148, 63, 105, 71, 163, 137, 178, 226, 137, 46, 165,
];

/// Supported Chains
#[allow(missing_docs)]
#[derive(
    Eq,
    PartialEq,
    Ord,
    PartialOrd,
    Copy,
    Clone,
    Hash,
    Debug,
    Serialize,
    Deserialize,
    IntoPrimitive,
    TryFromPrimitive,
)]
#[serde(rename_all = "lowercase")]
#[repr(u8)]
pub enum ChainId {
    Anvil = 1,
    Eth = 2,
    Avax = 3,
    Arbitrum = 4,
    Optimism = 5,
    Bsc = 6,
    Matic = 7,
    Iotex = 8,
    Okex = 9,
    Dfk = 10,
    Klaytn = 11,
    Aptos = 12,
    Sui = 13,
    Godwoken = 14,
    Fx = 15,
    Astar = 16,
    KCC = 17,
    Watr = 18,
    HashGraph = 19,
    Aurora = 20,
    Fantom = 21,
    Oasis = 22,
    TOMOChain = 23,
    DogeChain = 24,
    Celo = 25,
    Telos = 26,
    Cronos = 27,
    Gnosis = 28,
    Metis = 29,
    EVMOS = 30,
    Algorand = 31,
    Boba = 32,
    Sardis = 33,
    Ziliqa = 34,
    Harmony = 35,
    Filecoin = 36,
    Zksync = 37,
    Mantle = 38,
    Syscoin = 39,
    #[cfg(feature = "mock_connector")]
    DevMockChain = 42,
}

impl ChainId {
    /// Returns the chain type
    pub fn get_chain_type(self) -> ChainType {
        match self {
            ChainId::Aptos => ChainType::Aptos,
            ChainId::Sui => ChainType::Sui,
            ChainId::Anvil
            | ChainId::Eth
            | ChainId::Avax
            | ChainId::Arbitrum
            | ChainId::Optimism
            | ChainId::Bsc
            | ChainId::Matic
            | ChainId::Iotex
            | ChainId::Okex
            | ChainId::Dfk
            | ChainId::Klaytn
            | ChainId::Godwoken
            | ChainId::Astar
            | ChainId::Fx
            | ChainId::KCC
            | ChainId::Watr
            | ChainId::HashGraph
            | ChainId::Aurora
            | ChainId::Fantom
            | ChainId::Oasis
            | ChainId::TOMOChain
            | ChainId::DogeChain
            | ChainId::Celo
            | ChainId::Telos
            | ChainId::Cronos
            | ChainId::Gnosis
            | ChainId::Metis
            | ChainId::EVMOS
            | ChainId::Algorand
            | ChainId::Boba
            | ChainId::Sardis
            | ChainId::Ziliqa
            | ChainId::Harmony
            | ChainId::Filecoin
            | ChainId::Zksync
            | ChainId::Mantle
            | ChainId::Syscoin => ChainType::Evm,
            #[cfg(feature = "mock_connector")]
            ChainId::DevMockChain => ChainType::DevMockChain,
        }
    }
}

impl FromStr for ChainId {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "anvil" => Ok(ChainId::Anvil),
            "eth" => Ok(ChainId::Eth),
            "avax" => Ok(ChainId::Avax),
            "arbitrum" => Ok(ChainId::Arbitrum),
            "optimism" => Ok(ChainId::Optimism),
            "bsc" => Ok(ChainId::Bsc),
            "matic" => Ok(ChainId::Matic),
            "iotex" => Ok(ChainId::Iotex),
            "okex" => Ok(ChainId::Okex),
            "dfk" => Ok(ChainId::Dfk),
            "klaytn" => Ok(ChainId::Klaytn),
            "aptos" => Ok(ChainId::Aptos),
            "sui" => Ok(ChainId::Sui),
            "godwoken" => Ok(ChainId::Godwoken),
            "fx" => Ok(ChainId::Fx),
            "astar" => Ok(ChainId::Astar),
            "kcc" => Ok(ChainId::KCC),
            "watr" => Ok(ChainId::Watr),
            "hashgraph" => Ok(ChainId::HashGraph),
            "aurora" => Ok(ChainId::Aurora),
            "fantom" => Ok(ChainId::Fantom),
            "oasis" => Ok(ChainId::Oasis),
            "tomochain" => Ok(ChainId::TOMOChain),
            "dogechain" => Ok(ChainId::DogeChain),
            "celo" => Ok(ChainId::Celo),
            "telos" => Ok(ChainId::Telos),
            "cronos" => Ok(ChainId::Cronos),
            "gnosis" => Ok(ChainId::Gnosis),
            "metis" => Ok(ChainId::Metis),
            "evmos" => Ok(ChainId::EVMOS),
            "algorand" => Ok(ChainId::Algorand),
            "boba" => Ok(ChainId::Boba),
            "sardis" => Ok(ChainId::Sardis),
            "ziliqa" => Ok(ChainId::Ziliqa),
            "harmony" => Ok(ChainId::Harmony),
            "filecoin" => Ok(ChainId::Filecoin),
            "zksync" => Ok(ChainId::Zksync),
            "mantle" => Ok(ChainId::Mantle),
            "syscoin" => Ok(ChainId::Syscoin),
            #[cfg(feature = "mock_connector")]
            "mock_chain" => Ok(ChainId::DevMockChain),
            _ => Err("unsupported blockchain name".to_string()),
        }
    }
}

impl Display for ChainId {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        match self {
            ChainId::Anvil => write!(f, "anvil"),
            ChainId::Eth => write!(f, "eth"),
            ChainId::Avax => write!(f, "avax"),
            ChainId::Arbitrum => write!(f, "arbitrum"),
            ChainId::Optimism => write!(f, "optimism"),
            ChainId::Okex => write!(f, "okex"),
            ChainId::Dfk => write!(f, "dfk"),
            ChainId::Klaytn => write!(f, "klaytn"),
            ChainId::Bsc => write!(f, "bsc"),
            ChainId::Matic => write!(f, "matic"),
            ChainId::Iotex => write!(f, "iotex"),
            ChainId::Aptos => write!(f, "aptos"),
            ChainId::Sui => write!(f, "sui"),
            ChainId::Godwoken => write!(f, "godwoken"),
            ChainId::Fx => write!(f, "fx"),
            ChainId::Astar => write!(f, "astar"),
            ChainId::KCC => write!(f, "kcc"),
            ChainId::Watr => write!(f, "watr"),
            ChainId::HashGraph => write!(f, "hashGraph"),
            ChainId::Aurora => write!(f, "aurora"),
            ChainId::Fantom => write!(f, "fantom"),
            ChainId::Oasis => write!(f, "oasis"),
            ChainId::TOMOChain => write!(f, "tomochain"),
            ChainId::DogeChain => write!(f, "dogechain"),
            ChainId::Celo => write!(f, "celo"),
            ChainId::Telos => write!(f, "telos"),
            ChainId::Cronos => write!(f, "cronos"),
            ChainId::Gnosis => write!(f, "gnosis"),
            ChainId::Metis => write!(f, "metis"),
            ChainId::EVMOS => write!(f, "evmos"),
            ChainId::Algorand => write!(f, "algorand"),
            ChainId::Boba => write!(f, "boba"),
            ChainId::Sardis => write!(f, "sardis"),
            ChainId::Ziliqa => write!(f, "ziliqa"),
            ChainId::Harmony => write!(f, "harmony"),
            ChainId::Filecoin => write!(f, "filecoin"),
            ChainId::Zksync => write!(f, "zksync"),
            ChainId::Mantle => write!(f, "mantle"),
            ChainId::Syscoin => write!(f, "syscoin"),
            #[cfg(feature = "mock_connector")]
            ChainId::DevMockChain => write!(f, "mock_chain"),
        }
    }
}

#[cfg(test)]
pub mod common_chain_id_test {
    use crate::chains::ChainId;

    #[test]
    fn check_chain_id() {
        let anvil_u8: u8 = ChainId::Anvil.into();
        assert_eq!(anvil_u8, 1u8);
        let anvil_chain: ChainId = ChainId::try_from(anvil_u8).unwrap();
        assert_eq!(anvil_chain, ChainId::Anvil);

        let iotex_u8: u8 = ChainId::Iotex.into();
        assert_eq!(iotex_u8, 8u8);
        let iotex_chain: ChainId = ChainId::try_from(iotex_u8).unwrap();
        assert_eq!(iotex_chain, ChainId::Iotex);

        let godwoken_u8: u8 = ChainId::Godwoken.into();
        assert_eq!(godwoken_u8, 15u8);
        let godwoken_chain: ChainId = ChainId::try_from(godwoken_u8).unwrap();
        assert_eq!(godwoken_chain, ChainId::Godwoken);

        let oasis_u8: u8 = ChainId::Oasis.into();
        assert_eq!(oasis_u8, 22u8);
        let oasis_chain: ChainId = ChainId::try_from(oasis_u8).unwrap();
        assert_eq!(oasis_chain, ChainId::Oasis);

        let metis_u8: u8 = ChainId::Metis.into();
        assert_eq!(metis_u8, 29u8);
        let metis_chain: ChainId = ChainId::try_from(metis_u8).unwrap();
        assert_eq!(metis_chain, ChainId::Metis);

        let zksync_u8: u8 = ChainId::Zksync.into();
        assert_eq!(zksync_u8, 37u8);
        let zksync_chain: ChainId = ChainId::try_from(zksync_u8).unwrap();
        assert_eq!(zksync_chain, ChainId::Zksync);
    }
}
