use crate::VRFError;
use crate::VrfCallback;
use crate::VrfRequest;
use log::error;
use std::fmt;

use reqwest::StatusCode;
use serde::{Deserialize, Serialize};
use sodkg::BlsPublicKey;
use std::net::SocketAddr;
use std::str::FromStr;
use web3::types::U256;

//TODO do serialisation by hand
/// Committee data Serialization helper struct
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SerdeCommitteeData {
    /// Public key of the committee
    pub committee_pubkey: Vec<u8>,
    /// f+1 value
    pub threshold_f: usize,
    /// Min number of node to start the DKG >= f+1
    pub min_number_of_node: usize,
    /// number_of_dealer >= g+1
    pub nb_dealer: usize,
    /// dealer threshold g+1
    pub dealer_threshold_g: usize,
}

impl SerdeCommitteeData {
    /// Serializes the Comittee data
    pub fn into_bytes(&self) -> Result<Vec<u8>, Box<bincode::ErrorKind>> {
        bincode::serialize(self)
    }
}

impl TryFrom<&[u8]> for SerdeCommitteeData {
    type Error = Box<bincode::ErrorKind>;

    fn try_from(bytes: &[u8]) -> Result<Self, Self::Error> {
        bincode::deserialize::<SerdeCommitteeData>(bytes)
    }
}

/// VRF Committee Data
#[derive(Clone, Debug)]
pub struct CommitteeData {
    /// Public key of the committee
    pub committee_pubkey: BlsPublicKey,
    /// f+1 value
    pub threshold_f: usize,
    /// Min number of node to start the DKG >= f+1
    pub min_number_of_node: usize,
    /// number_of_dealer >= g+1
    pub nb_dealer: usize,
    /// dealer threshold g+1
    pub dealer_threshold_g: usize,
}

impl fmt::Display for CommitteeData {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let threshold = self.threshold_f;

        let public_key = &self.committee_pubkey.bn254.pub_key_g2;

        let x1 =
            U256::from_str(&public_key.getx().geta().tostring()).unwrap_or_else(|_| U256::from(0));
        let x2 =
            U256::from_str(&public_key.getx().getb().tostring()).unwrap_or_else(|_| U256::from(0));
        let y1 =
            U256::from_str(&public_key.gety().geta().tostring()).unwrap_or_else(|_| U256::from(0));
        let y2 =
            U256::from_str(&public_key.gety().getb().tostring()).unwrap_or_else(|_| U256::from(0));

        write!(
            f,
            "x1: {x1:?}
x2: {x2:?}
y1: {y1:?}
y2: {y2:?}
threshold: {threshold:?}"
        )
    }
}

impl TryFrom<SerdeCommitteeData> for CommitteeData {
    type Error = VRFError;

    fn try_from(data: SerdeCommitteeData) -> Result<Self, Self::Error> {
        let b: &[u8] = &data.committee_pubkey;
        Ok(CommitteeData {
            committee_pubkey: BlsPublicKey::try_from(b).map_err(|err| {
                VRFError::BlsSign(format!("Fail to read from byte signature:{err}"))
            })?,
            threshold_f: data.threshold_f,
            min_number_of_node: data.min_number_of_node,
            nb_dealer: data.nb_dealer,
            dealer_threshold_g: data.dealer_threshold_g,
        })
    }
}

/// Helper struct for interacting with the VRF rpc
pub struct VrfClient {
    client: reqwest::Client,
    server_addr: SocketAddr,
    backup_server_addr: SocketAddr,
}

impl VrfClient {
    /// Creates a new VRF Client
    pub fn new(server_addr: SocketAddr, backup_server_addr: SocketAddr) -> Self {
        let client = reqwest::Client::new();
        VrfClient {
            client,
            server_addr,
            backup_server_addr,
        }
    }

    async fn send_rpc_request(
        &self,
        request: Option<&VrfRequest>,
        rpc_path: &str,
    ) -> Result<Vec<u8>, VRFError> {
        let res = send_rpc_request_inner(&self.client, self.server_addr, request, rpc_path).await;

        if let Err(err) = res {
            error!("{err}");
            send_rpc_request_inner(&self.client, self.backup_server_addr, request, rpc_path).await
        } else {
            res
        }
    }

    /// Sends a VRF Request for generating a random number
    pub async fn send_request(&self, request: &VrfRequest) -> Result<VrfCallback, VRFError> {
        let bytes: &[u8] = &self
            .send_rpc_request(Some(request), "/rpc/v1/generate_rn")
            .await?;
        let callback = VrfCallback::try_from(bytes).unwrap();
        Ok(callback)
    }

    /// Fetches comittee data from the VRF Node
    pub async fn get_committee_data(&self) -> Result<CommitteeData, VRFError> {
        let bytes: &[u8] = &self
            .send_rpc_request(None, "/rpc/v1/committee_sign")
            .await?;

        println!("{:?}", &bytes);
        let serdecommittee = SerdeCommitteeData::try_from(bytes)
            .map_err(|err| VRFError::BlsSign(format!("Fail to read from byte signature:{err}")))?;
        let committee = CommitteeData::try_from(serdecommittee)?;
        Ok(committee)
    }
}

async fn send_rpc_request_inner(
    client: &reqwest::Client,
    addr: SocketAddr,
    request: Option<&VrfRequest>,
    rpc_path: &str,
) -> Result<Vec<u8>, VRFError> {
    let request_builder = if let Some(request) = request {
        let bytes = request.to_bytes();
        client.post(format!("http://{addr}{rpc_path}")).body(bytes)
    } else {
        client.get(format!("http://{addr}{rpc_path}"))
    };

    let resp = request_builder.send().await?;
    if resp.status() == StatusCode::OK {
        let response = resp.bytes().await.unwrap().to_vec();
        Ok(response)
    } else {
        Err(VRFError::VrfRpc(resp.status().to_string()))
    }
}
