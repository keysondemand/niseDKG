//! Common utils for the supra-vrf project
#![warn(missing_docs)]

use crate::chains::ChainId;
use crate::errors::VRFError;
use log::warn;
use serde::{Deserialize, Serialize};
use sha3::{Digest as Sha3Digest, Keccak256};
use socrypto::Hash as SoHash;
use socrypto::PublicKey;
use sodkg::BlsPrivateKey;
use sodkg::BlsSignature;
use sodkg::DleqProofGLOW;
use std::cmp::Ordering;
use std::fmt::Display;
use std::future::Future;
use std::hash::Hash;
use std::hash::Hasher;
use std::time::Duration;

pub mod chains;
pub mod errors;
pub mod influx_metrics;
mod vrfclient;

pub use vrfclient::{CommitteeData, SerdeCommitteeData, VrfClient};

/// Commonized format for a VRF Request
/// Target Blockchains must implement conversion of their native
/// request to this type
#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct VrfRequest {
    /// Unique Nonce
    pub nonce: [u64; 4],
    /// Transaction Hash
    pub txhash: Vec<u8>,
    /// Encoded message to be signed (used by the callback)
    pub message: Vec<u8>,
    /// Hash of the block which contains the request
    pub block_hash: Vec<u8>,
    /// Chain where the VRF request originated
    pub chain_id: ChainId,
}

impl VrfRequest {
    /// generte a partial bls signature for the vrf request's message
    pub fn sign_partial_bls(
        &self,
        _domain: &[u8],
        bls_privkey: &BlsPrivateKey,
    ) -> (BlsSignature, DleqProofGLOW) {
        let sig = bls_privkey.sign_chain(&self.message);
        let dl_eq_glow = bls_privkey.dl_eq_proof(&self.message.to_vec());
        //        log::trace!("sign_partial_bls publickey:{:?}", bls_privkey.public_key());
        (sig, dl_eq_glow)
    }

    /// Hash of the request's message
    pub fn get_id(&self) -> SoHash {
        //hash the whole message to be sure that Id don't collid with other request.
        // The message lengh is bounded by the RPC access that don't accept request with more than 512k
        let mut block_hasher = Keccak256::new();
        block_hasher.update(&self.message);
        socrypto::Hash(<[u8; 32]>::from(block_hasher.finalize()))
    }

    /// Serialize the VRF Request
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut buffer = Vec::with_capacity(
            self.message.len() + self.block_hash.len() + self.txhash.len() + 4 * 4 + 1 + 3 * 4,
        );
        buffer.push(self.chain_id.into());
        //nonce
        buffer.extend_from_slice(&self.nonce[0].to_le_bytes());
        buffer.extend_from_slice(&self.nonce[1].to_le_bytes());
        buffer.extend_from_slice(&self.nonce[2].to_le_bytes());
        buffer.extend_from_slice(&self.nonce[3].to_le_bytes());
        //txhash
        let len_bytes = (self.txhash.len() as u32).to_le_bytes();
        buffer.extend_from_slice(&len_bytes);
        buffer.extend_from_slice(&self.txhash);
        //message
        let len_bytes = (self.message.len() as u32).to_le_bytes();
        buffer.extend_from_slice(&len_bytes);
        buffer.extend_from_slice(&self.message);
        //block_hash
        let len_bytes = (self.block_hash.len() as u32).to_le_bytes();
        buffer.extend_from_slice(&len_bytes);
        buffer.extend_from_slice(&self.block_hash);
        buffer
    }
}

impl PartialOrd for VrfRequest {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.txhash.cmp(&other.txhash))
    }
}
impl PartialEq for VrfRequest {
    fn eq(&self, other: &Self) -> bool {
        self.txhash == other.txhash
    }
}

impl Ord for VrfRequest {
    fn cmp(&self, other: &Self) -> Ordering {
        self.txhash.cmp(&other.txhash)
    }
}

impl Eq for VrfRequest {}

impl Hash for VrfRequest {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.txhash.hash(state);
    }
}

impl TryFrom<&[u8]> for VrfRequest {
    type Error = VRFError;

    fn try_from(bytes: &[u8]) -> Result<Self, Self::Error> {
        if bytes.len() < 1 + 8 * 4 + 4 {
            return Err(VRFError::General(
                "could not extract chain_id slice too small".to_string(),
            ));
        }

        let chain_id = ChainId::try_from(bytes[0]).map_err(|err| {
            VRFError::General(format!(
                "VrfRequest could not extract chain_id,Nonce from slice: {err:?}"
            ))
        })?;
        let mut start = 1;
        let mut nonce = [0_u64; 4];
        for nonce_c in &mut nonce {
            let nonce_bytes: [u8; 8] = (&bytes[start..start + 8]).try_into().map_err(|err| {
                VRFError::General(format!("could not extract nonce from slice: {err:?}"))
            })?;
            *nonce_c = u64::from_le_bytes(nonce_bytes);
            start += 8;
        }
        let hash_len = u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
        start += 4;
        if bytes.len() < start + hash_len + 4 {
            return Err(VRFError::General(
                "VrfRequest could not extract TxHash slice too small".to_string(),
            ));
        }
        let txhash: Vec<u8> = (&bytes[start..start + hash_len]).into();
        start += hash_len;
        let message_len = u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
        start += 4;
        if bytes.len() < start + message_len + 4 {
            return Err(VRFError::General(
                "VrfRequest could not extract message slice too small".to_string(),
            ));
        }
        let message: Vec<u8> = (&bytes[start..start + message_len]).into();
        start += message_len;
        let block_hash_len =
            u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
        start += 4;
        if bytes.len() < start + block_hash_len {
            return Err(VRFError::General(
                "VrfRequest could not extract block_hash slice too small".to_string(),
            ));
        }
        let block_hash: Vec<u8> = (&bytes[start..start + block_hash_len]).into();

        Ok(VrfRequest {
            nonce,
            txhash,
            message,
            block_hash,
            chain_id,
        })
    }
}

impl TryFrom<Vec<u8>> for VrfRequest {
    type Error = VRFError;

    fn try_from(vec: Vec<u8>) -> Result<Self, Self::Error> {
        let bytes = &vec[..];
        VrfRequest::try_from(bytes)
    }
}

/// Commonized format for a VRF Callback
#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct VrfCallback {
    /// Unique Nonce corresponding to a VRF Request
    pub nonce: [u64; 4],
    /// Proof of idenity & integrity
    /// (publickey, sodkg::BlsSignature, sodkg::DleqProofGLOW)
    pub signs: Vec<(u64, PublicKey, Vec<u8>, Vec<u8>)>,
    /// Block hash where the VRF Request corresponding to this callback was created
    pub block_hash: Vec<u8>,
    /// Transaction Hash of the VRF Request corresponding to this callback
    pub txhash: Vec<u8>,
    /// Chain Id of the VRF Request
    pub chain_id: ChainId,
}

impl VrfCallback {
    /// Creates a VrfCallback
    pub fn new(
        txhash: Vec<u8>,
        block_hash: Vec<u8>,
        nonce: [u64; 4],
        chain_id: ChainId,
        signs: Vec<(u64, PublicKey, BlsSignature, DleqProofGLOW)>,
    ) -> VrfCallback {
        let signs = signs
            .into_iter()
            .map(|(n, pk, s, p)| (n, pk, s.into_bytes(), p.into_bytes()))
            .collect();
        VrfCallback {
            txhash,
            signs,
            block_hash,
            nonce,
            chain_id,
        }
    }

    /// Serializes the VRF Request
    pub fn into_bytes(&self) -> Result<Vec<u8>, Box<bincode::ErrorKind>> {
        bincode::serialize(self)
    }

    /// Extracts Partial Signatures from the VRF Callback
    pub fn get_partial_signatures(
        &self,
    ) -> Result<Vec<(u64, PublicKey, BlsSignature, DleqProofGLOW)>, VRFError> {
        self.signs
            .iter()
            .map(|(n, pk, s, p)| {
                let s: &[u8] = s;
                let p: &[u8] = p;
                BlsSignature::try_from(s)
                    .map_err(|err| VRFError::BlsSign(err.to_string()))
                    .and_then(|s| {
                        DleqProofGLOW::try_from(p)
                            .map(|p| (*n, *pk, s, p))
                            .map_err(|err| VRFError::BlsSign(err.to_string()))
                    })
            })
            .collect()
    }
}

impl TryFrom<&[u8]> for VrfCallback {
    type Error = Box<bincode::ErrorKind>;

    fn try_from(bytes: &[u8]) -> Result<Self, Self::Error> {
        bincode::deserialize::<VrfCallback>(bytes)
    }
}

impl PartialOrd for VrfCallback {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.txhash.cmp(&other.txhash))
    }
}
impl PartialEq for VrfCallback {
    fn eq(&self, other: &Self) -> bool {
        self.txhash == other.txhash
    }
}

impl Ord for VrfCallback {
    fn cmp(&self, other: &Self) -> Ordering {
        self.txhash.cmp(&other.txhash)
    }
}

impl Eq for VrfCallback {}

impl Hash for VrfCallback {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.txhash.hash(state);
    }
}

const RETRY_TIME_INTERVAL_U64: u64 = 3;
const RETRY_TIME_INTERVAL: Duration = Duration::from_secs(RETRY_TIME_INTERVAL_U64);

/// A helper to make retrying an asynchronous process easy:
/// This function takes a closure returning a future in input
/// and executes its until it succeeds of until the number of retries has elapsed
/// Between each retries, there is a sleep time of 3 seconds,
/// it is set by the `RETRY_TIME_INTERVAL` constant
///
/// ```ignore
/// let x : Result<(), ()> = Ok(());
///
/// with_retries(3, || async {
///     future::ready(x).await // <- the process you want to retry goes there
/// })
/// ```
///
/// Or even just
///
/// ```ignore
/// let x : Result<(), ()> = Ok(());
///
/// with_retries(3, || future::ready(x) /* <- the future you want to retry goes there */)
///
/// ```
pub async fn with_retries<E: Display, U, T: FnMut() -> V, V: Future<Output = Result<U, E>>>(
    number_of_retries: usize,
    mut op: T,
) -> Result<U, E> {
    let mut last_error = match op().await {
        Ok(return_value) => return Ok(return_value),
        Err(err) => err,
    };

    for _ in 0..number_of_retries {
        warn!(
            "Error {last_error} in `with_retries`, retrying in {RETRY_TIME_INTERVAL_U64} seconds"
        );
        tokio::time::sleep(RETRY_TIME_INTERVAL).await;
        match op().await {
            Ok(return_value) => return Ok(return_value),
            Err(err) => last_error = err,
        }
    }

    Err(last_error)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_vrfrequest_serialization() {
        let vrf_request = VrfRequest {
            message: [
                35, 205, 30, 200, 104, 232, 9, 138, 171, 138, 142, 129, 101, 120, 149, 38, 165,
                127, 77, 78, 190, 20, 116, 171, 126, 193, 98, 185, 127, 62, 79, 223,
            ]
            .to_vec(),
            block_hash: bincode::serialize(
                "37e4cc3af781f26a67efff82b9e6f837c4c2cd908e82af77151990d28351d2dc",
            )
            .unwrap(),
            txhash: bincode::serialize(
                "e2b3ec186c3886b707fe4844f7577d87bfe5f7a6058f54530319595599d29098",
            )
            .unwrap(),
            nonce: [1, 2, 3, 4],
            chain_id: ChainId::Anvil,
        };

        let tx_bytes = vrf_request.to_bytes();
        let new_request = VrfRequest::try_from(tx_bytes).unwrap();

        assert_eq!(vrf_request.message, new_request.message);
        assert_eq!(vrf_request.block_hash, new_request.block_hash);
        assert_eq!(vrf_request.txhash, new_request.txhash);
        assert_eq!(vrf_request.nonce, new_request.nonce);
        assert_eq!(vrf_request.chain_id, new_request.chain_id);
    }
}
