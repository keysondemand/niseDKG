//! common VRF Errors

use thiserror::Error;

#[allow(missing_docs)]
#[derive(Error, Debug)]
pub enum VRFError {
    #[error("General err:{0}")]
    General(String),

    #[error("Error during BC notification: {0}")]
    NotificationBcConnector(String),

    #[error("Error while fetching data on a blockchain connector: {0}")]
    BcConnectorFetch(String),

    #[error("Error during a connection to a VRF Node: {0}")]
    VrfNodeConnector(String),

    #[error("Error while serialzing: {0}")]
    JsonSerialize(#[from] serde_json::Error),

    #[error("Error while parsing to int: {0}")]
    ParseInt(#[from] std::num::ParseIntError),

    #[error("Error while parsing to float: {0}")]
    ParseFloat(#[from] std::num::ParseFloatError),

    #[error("Unable to convert to string")]
    ParseString,

    #[error("From hex error: {0}")]
    ParseFromHex(#[from] hex::FromHexError),

    #[error("Error while requesting data: {0}")]
    Request(#[from] reqwest::Error),

    #[error("Error with RwLock: {0}")]
    RwPoison(String),

    #[error("Recovery point logic failure err:{0}")]
    RecoveryPoint(String),

    #[error("BCS error: {0}")]
    Bcs(#[from] bcs::Error),

    #[error("From hex error: {0}")]
    Ed25519(#[from] ed25519_dalek::ed25519::Error),

    #[error("Unable to get current block")]
    GetCurrentBlock,

    #[error("Error while handling config: {0}")]
    Config(#[from] ConfigError),

    #[error("Error with Aptos: {0}")]
    Aptos(String),

    #[error("Invalid Secret Key: {0}")]
    EthereumSecretKey(#[from] secp256k1::Error),

    #[error("Error with Ethereum: {0}")]
    Ethereum(String),

    #[error("Error with Sui: {0}")]
    SuiError(String),

    #[error("Error with bls sign verification: {0}")]
    BlsSign(String),

    #[error("Error with failed to build web3 client:{0}")]
    Web3Transport(#[from] web3::Error),

    #[error("Error with failed to serialize or deseralize:{0}")]
    BincodeErrorKind(#[from] bincode::Error),

    #[error("Error with hash array length: {0}")]
    HashArrayLength(usize),

    #[error("Error during VRF Node RPC call: {0}")]
    VrfRpc(String),

    // #[error("Serailisation error : {0}")]
    // SerilisationError(#[from] bincode::Error),
    #[error("Unable to parse Sui Event: {0}")]
    SuiEventParseError(String),

    #[error("Failed to connect to sui client")]
    SuiClient,

    #[error("Request not compatible with chainId: {0}")]
    MismatchedChainId(String),

    #[error("Error with failed anyhow err :{0}")]
    Anyhow(#[from] anyhow::Error),

    #[error("RPC Request timeout")]
    Timeout,
}

#[allow(missing_docs)]
#[derive(Error, Debug)]
pub enum ConfigError {
    #[error("Could not find Aptos config")]
    AptosConfigNotFound,

    #[error("Could not read config file at {location}")]
    ReadFile { location: String },

    #[error("Could not parse config file")]
    ParseFile(#[from] toml_edit::de::Error),

    #[error("Could not serialize config struct")]
    SerializeStruct(#[from] toml_edit::ser::Error),

    #[error("Invalid key")]
    InvalidKey,
}
