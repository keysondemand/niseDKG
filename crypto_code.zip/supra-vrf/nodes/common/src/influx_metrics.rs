//! InfluxDB Metrics Helpers

use crate::chains::ChainId;
use crate::errors::VRFError;
use crate::VrfRequest;
use influx_metrics::{env_init, MetricsBuilder};
use std::time::Instant;
use web3::ethabi::{Token, Uint};

/// Helper struct for InfluxDB Metrics
pub struct Metrics {}

impl Metrics {
    /// Initialize InfluxDB Metrics
    pub fn env_init() {
        env_init();
    }

    fn common_failed_log(
        chain_id: &ChainId,
        op: String,
        error: String,
        nonce: String,
        tx_hash: String,
    ) {
        let chain_id = chain_id.to_string();
        tokio::spawn(
            MetricsBuilder::new()
                .log_failed_req(chain_id, op, Some(error), Some(nonce), Some(tx_hash))
                .send_metrics(),
        );
    }

    /// log failed request for "Websocket break"
    /// Once Websocket is break or due to some reason websocket not work
    pub fn websocket_break(chain_id: &ChainId) {
        let op = "websocket_break".to_string();
        tokio::spawn(
            MetricsBuilder::new()
                .log_failed_req(chain_id.to_string(), op, None, None, None)
                .send_metrics(),
        );
    }

    /// log failed request for "VRF request break"
    /// While Sending request to VRF-node and it response and error
    pub fn vrf_request_break(
        chain_id: &ChainId,
        error: VRFError,
        vrf_request: VrfRequest,
        tx_hash: String,
    ) {
        let op = "vrf_request_break".to_string();
        let nonce = vrf_request.nonce[0].to_string();
        Metrics::common_failed_log(chain_id, op, error.to_string(), nonce, tx_hash);
    }

    /// log failed request for "Running out of compute"
    /// If the transaction gas is more than we defined then this error is occur
    pub fn out_of_compute(
        chain_id: &ChainId,
        error: impl ToString,
        nonce: impl Nonce,
        tx_hash: impl ToString,
    ) {
        let op = "running_out_of_compute".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error.to_string(), nonce, tx_hash.to_string());
    }

    /// log failed request for "Running out of gas"
    /// If wallet don't have enough faucet to process the transaction
    pub fn out_of_gas(
        chain_id: &ChainId,
        error: impl ToString,
        nonce: impl Nonce,
        tx_hash: impl ToString,
    ) {
        let op = "running_out_of_gas".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error.to_string(), nonce, tx_hash.to_string());
    }

    /// log failed request for "RPC connectivity break"
    /// While perform callback transaction and it failed and give rpc error
    pub fn rpc_break(chain_id: &ChainId, error: String, nonce: impl Nonce, tx_hash: impl ToString) {
        let op = "rpc_connectivity_break".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error, nonce, tx_hash.to_string());
    }

    /// log failed request for "nonce error"
    /// "Nonce to low error" to process the callback transaction
    pub fn nonce_err(
        chain_id: &ChainId,
        error: impl ToString,
        nonce: impl Nonce,
        tx_hash: impl ToString,
    ) {
        let op = "nonce_error".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error.to_string(), nonce, tx_hash.to_string());
    }

    /// log failed request for "Callback break"
    /// While perform callback transaction and it failed and no other errors as I mentioned above
    pub fn cb_break(
        chain_id: &ChainId,
        error: impl ToString,
        nonce: impl Nonce,
        tx_hash: impl ToString,
    ) {
        let op = "callback_break".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error.to_string(), nonce, tx_hash.to_string());
    }

    /// log failed request for "transaction underpriced"
    /// While perform callback transaction and it failed and give "transaction underpriced error"
    pub fn tx_underpriced(
        chain_id: &ChainId,
        error: String,
        nonce: impl Nonce,
        tx_hash: impl ToString,
    ) {
        let op = "transaction_underpriced".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error, nonce, tx_hash.to_string());
    }

    /// log failed request for "gas estimation error"
    pub fn failed_gas_estimation(
        chain_id: &ChainId,
        error: String,
        nonce: impl Nonce,
        tx_hash: impl ToString,
    ) {
        let op = "gas_estimation".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error, nonce, tx_hash.to_string());
    }

    /// log failed request for "client wallet balance is less the transaction fee"
    pub fn failed_check_client_deposit_balance(
        chain_id: &ChainId,
        error: String,
        nonce: impl Nonce,
        tx_hash: impl ToString,
    ) {
        let op = "check_client_deposit_balance".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error, nonce, tx_hash.to_string());
    }

    /// log failed request for "client wallet balance is less the transaction fee"
    pub fn client_balance_low(
        chain_id: &ChainId,
        error: String,
        nonce: impl Nonce,
        tx_hash: impl ToString,
    ) {
        let op = "client_balance_low".to_string();
        let nonce = nonce.to_u64().to_string();
        Metrics::common_failed_log(chain_id, op, error, nonce, tx_hash.to_string());
    }

    /// Logs the time elapsed with respect to some instant
    pub fn common_log_elapsed_time(
        data_point: &str,
        chain_id: &ChainId,
        nonce: impl Nonce,
        instant: Instant,
    ) {
        let duration = instant.elapsed().as_millis();
        tokio::spawn(
            MetricsBuilder::new()
                .log_elapsed_time(
                    data_point.to_string(),
                    chain_id.to_string(),
                    nonce.to_u64().to_string(),
                    duration as i64,
                )
                .send_metrics(),
        );
    }

    /// log picked events
    pub fn pick_event_log(chain_id: &ChainId, nonce: impl Nonce, caller: String, transport: &str) {
        tokio::spawn(
            MetricsBuilder::new()
                .log_pick_event(
                    chain_id.to_string(),
                    nonce.to_u64().to_string(),
                    caller,
                    transport.to_string(),
                )
                .send_metrics(),
        );
    }

    /// log time elapsed between "pick event after num confirmation" to "vrf"
    pub fn pick_event_time(chain_id: &ChainId, nonce: impl Nonce, instant: Instant) {
        Metrics::common_log_elapsed_time("picked_up_to_vrf_time", chain_id, nonce, instant);
    }

    /// log time elapsed between "vrf request" to "vrf response"
    pub fn vrf_req_res_time(chain_id: &ChainId, nonce: impl Nonce, instant: Instant) {
        Metrics::common_log_elapsed_time("vrf_req_to_res_time", chain_id, nonce, instant);
    }

    /// log time elapsed between "vrf response received" to "queued into the callback"
    pub fn vrf_res_queue_time(chain_id: &ChainId, nonce: impl Nonce, instant: Instant) {
        Metrics::common_log_elapsed_time("vrf_res_to_queued_cb_time", chain_id, nonce, instant);
    }

    /// log time elapsed between "queued into the callback" to "callback completed"
    pub fn queued_cb_complete_time(chain_id: &ChainId, nonce: impl Nonce, instant: Instant) {
        Metrics::common_log_elapsed_time("queued_cb_to_cb_time", chain_id, nonce, instant);
    }

    /// log time elapsed between "pick event" to "callback completed"
    pub fn vrf_pick_cb_time(chain_id: &ChainId, nonce: impl Nonce, instant: Instant) {
        Metrics::common_log_elapsed_time("vrf_req_pick_to_cb_time", chain_id, nonce, instant);
    }
}

/// Trait to convert nonce to u64
// TODO: should be replaced by Into<u64>
pub trait Nonce {
    /// Convert to u64
    fn to_u64(self) -> u64;
}

impl Nonce for Token {
    fn to_u64(self) -> u64 {
        self.into_uint().unwrap_or_else(|| Uint::from(0)).0[0]
    }
}

impl Nonce for u64 {
    fn to_u64(self) -> u64 {
        self
    }
}
