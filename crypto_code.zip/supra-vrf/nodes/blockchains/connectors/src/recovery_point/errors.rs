//! Recovery Point Errors
use std::array::TryFromSliceError;
use std::fmt::Debug;
use std::io;

use common::chains::ChainId;
use serde_json::error::Error as SerdeJsonError;
use thiserror::Error;

/// Error during deserialization of the recovery point
#[allow(missing_docs)]
#[derive(Debug, Error)]
pub enum DeserializationError {
    #[error(transparent)]
    SerdeError(#[from] SerdeJsonError),
    #[error(transparent)]
    FromByteError(#[from] TryFromSliceError),
}

/// Error during processing a recovery point
#[allow(missing_docs)]
#[derive(Debug, Error)]
pub enum RecoveryPointError {
    #[error("{chain_id} an IO error occured: {source}")]
    IOError {
        chain_id: ChainId,
        source: io::Error,
    },

    #[error("{chain_id} failed to create the recovery point file {source}")]
    FailedToCreateFileError {
        chain_id: ChainId,
        source: io::Error,
    },

    #[error("{chain_id} deserialization error: {source}")]
    DeserializationError {
        chain_id: ChainId,
        source: DeserializationError,
    },
}
