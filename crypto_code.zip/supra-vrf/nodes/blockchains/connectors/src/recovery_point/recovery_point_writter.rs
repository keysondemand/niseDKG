//! Utils for saving a [`RecoveryPoint`]
use std::fmt::Debug;
use std::fs::{File, OpenOptions};
use std::io::{self, ErrorKind, Read, Seek, Write};
use std::ops::{Add, Sub};
use std::path::PathBuf;
use std::sync::mpsc::{channel, Sender};

use std::thread::spawn;

use common::chains::ChainId;
use log::{error, warn};

use super::errors::DeserializationError;
use super::{RecoveryPoint, RecoveryPointError, StorableRecoveryPoint};

/// A wrapper on top of a background thread manipulating the `RecoveryPointWriter` directly
/// This is done so the add_point method is never blocking the tokio threads
#[derive(Clone)]
pub struct SyncRecoveryPointWriter<N, B> {
    sender: Sender<(N, B)>,
}

impl<N, B> SyncRecoveryPointWriter<N, B>
where
    N: Send
        + Debug
        + Copy
        + Clone
        + From<u64>
        + Add<Output = N>
        + PartialEq
        + Sub<Output = N>
        + PartialOrd
        + Ord,
    B: Send + Debug + Clone + Ord + Default + Copy,
    RecoveryPoint<N, B>: StorableRecoveryPoint + Send,
{
    /// When a event has been processed, we add the nonce and the the block number to the recovery point
    pub fn add_point(&self, nonce: N, block_number: B) {
        self.sender
            .send((nonce, block_number))
            .expect("Cannot send to the recovery writer thread, it has probably died");
    }

    /// Spin up a new thread that will write the recovery point to a file without blocking the executor
    pub fn init(chain_id: ChainId) -> Result<(Self, RecoveryPoint<N, B>), RecoveryPointError> {
        let (mut recovery_point_writer, recovery_point) = RecoveryPointWriter::init(chain_id)?;

        let (sender, receiver) = channel();

        spawn(move || loop {
            let receive_result = receiver.recv();

            let Ok((nonce, block_number)) = receive_result else{
                    warn!("{chain_id}: recovery point channel sender closed");
                    break;
                };
            if let Err(err) = recovery_point_writer.add_point(nonce, block_number) {
                error!("{chain_id}: error adding a point to the recovery file: {err}");
            }
        });

        Ok((SyncRecoveryPointWriter { sender }, recovery_point))
    }
}

/// Helper for writing recovery point to a local file
/// The structure implements clone, which means we can clone it whenever we want
/// but there's only one underlying instance of the open file
struct RecoveryPointWriter<N: Clone + Ord, B: Clone + Ord> {
    file_writer: File,
    chain_id: ChainId,
    recovery_point: RecoveryPoint<N, B>,
}

impl<N, B> RecoveryPointWriter<N, B>
where
    RecoveryPoint<N, B>: StorableRecoveryPoint + Send,
    B: Clone + Ord + Debug + Default + Copy,
    N: Copy
        + Clone
        + From<u64>
        + Add<Output = N>
        + PartialEq
        + Sub<Output = N>
        + PartialOrd
        + Ord
        + Debug,
{
    /// Create a new RecoveryPointWriter, and returns the previously recorded recovery point
    pub fn init(chain_id: ChainId) -> Result<(Self, RecoveryPoint<N, B>), RecoveryPointError> {
        let file_path = PathBuf::from(format!("{chain_id}.recovery_point"));

        let (file, recovery_point) =
            match OpenOptions::new().read(true).write(true).open(&file_path) {
                Ok(mut file) => {
                    let mut bytes = Vec::new();
                    let length = file.read_to_end(&mut bytes).map_err(|error| {
                        RecoveryPointError::IOError {
                            chain_id,
                            source: error,
                        }
                    })?;

                    if length == 0 {
                        (file, RecoveryPoint::empty())
                    } else {
                        match StorableRecoveryPoint::from_slice(&bytes) {
                            Ok(recovery_point) => (file, recovery_point),
                            Err(err) => {
                                return Err(RecoveryPointError::DeserializationError {
                                    chain_id,
                                    source: DeserializationError::from(err),
                                })
                            }
                        }
                    }
                }
                Err(error) => {
                    // if we could not open the file because it did not exist, create a new one, otherwise, return an error.
                    if let ErrorKind::NotFound = error.kind() {
                        let file = File::create(&file_path).map_err(|err| {
                            RecoveryPointError::FailedToCreateFileError {
                                chain_id,
                                source: err,
                            }
                        })?;

                        (file, RecoveryPoint::empty())
                    } else {
                        return Err(RecoveryPointError::IOError {
                            chain_id,
                            source: error,
                        });
                    }
                }
            };

        Ok((
            RecoveryPointWriter {
                file_writer: file,
                chain_id,
                recovery_point: recovery_point.clone(),
            },
            recovery_point,
        ))
    }

    /// Saves the recovery point to a file
    fn write_recovery_point(&mut self) -> Result<(), RecoveryPointError> {
        let chain_id = self.chain_id;

        // the two following expects are things that:
        // - should never happen (the serialization issue)
        // - should propagate the panic if it happens (the `lock()`error, which would be caused
        // by poisoning of the Mutex due to a panic in another thread)
        let bytes = self
            .recovery_point
            .to_vec()
            .expect("Failed to serialize the recovery point");
        let file = &mut self.file_writer;
        // move the cursor back to the begining of the file
        file.rewind().map_err(Self::io_error_mapper(chain_id))?;
        // we truncate the file to the size of the new value, to make sure the file only contains the new value and not fragments of the previous ones.
        file.set_len(bytes.len() as u64)
            .map_err(Self::io_error_mapper(chain_id))?;
        file.write_all(&bytes)
            .map_err(Self::io_error_mapper(chain_id))?;
        file.sync_data().map_err(Self::io_error_mapper(chain_id))?;
        Ok(())
    }

    fn add_point(&mut self, nonce: N, block_number: B) -> Result<(), RecoveryPointError> {
        self.recovery_point.add_point(nonce, block_number);
        self.write_recovery_point()
    }

    // a convenience function to convert io::Errors to RecoveryPointError::IOError easily
    fn io_error_mapper(chain_id: ChainId) -> impl Fn(io::Error) -> RecoveryPointError {
        move |err| RecoveryPointError::IOError {
            chain_id,
            source: err,
        }
    }
}

#[cfg(test)]
mod test {
    use std::fs::remove_file;

    use super::RecoveryPointWriter;
    use crate::recovery_point::RecoveryPoint;
    use common::chains::ChainId;

    #[test]
    fn test_recovery_point() {
        let empty: RecoveryPoint<u64, u64> = RecoveryPoint::empty();
        // Use a different chain for every test, to avoid race conditions when running tests in parallel
        let chain_id = ChainId::Eth;

        // remove the file if it already exists form a previous test
        let _ = remove_file(format!("{chain_id}.recovery_point"));

        let (mut rpw, rp) = RecoveryPointWriter::<u64, u64>::init(chain_id).unwrap();
        assert_eq!(rp, empty);

        rpw.add_point(0, 42).unwrap();
        drop(rpw);

        let (_rpw, rp) = RecoveryPointWriter::<u64, u64>::init(chain_id).unwrap();

        let mut expected_recovery_point = empty;
        expected_recovery_point.add_point(0, 42);
        assert_eq!(rp, expected_recovery_point);
    }

    #[test]
    fn test_with_empty_recovery_point() {
        let empty: RecoveryPoint<u64, u64> = RecoveryPoint::empty();
        // Use a different chain for every test, to avoid race conditions when running tests in parallel
        let chain_id = ChainId::Anvil;

        // remove the file if it already exists form a previous test
        let _ = remove_file(format!("{chain_id}.recovery_point"));

        let (rpw, rp) = RecoveryPointWriter::<u64, u64>::init(chain_id).unwrap();
        assert_eq!(rp, empty);

        drop(rpw);

        let (_rpw, rp) = RecoveryPointWriter::<u64, u64>::init(chain_id).unwrap();
        assert_eq!(rp, empty);
    }
}
