//! Helper do deal with errors in streams.
//! It comes in two flavors, depending on whether you are using the `stream!` macro or channels, to build your streams

pub mod stream {
    //! Helper for [`async_stream::stream`] and [`async_stream::try_stream`]

    /// Checks if the passed value is Err, if so, yield it and continues, else it will return the Ok value \
    /// The second argument is expected be `yield`  \
    ///
    /// ```ignore
    /// try_or_skip!(v, yield)
    /// ```
    /// roughly expands to:
    ///
    /// ```ignore
    /// match v {
    ///     Ok(v) => v,
    ///     Err(e) => {
    ///         yield e;
    ///         continue;
    ///     }
    /// }
    /// ```
    #[macro_export]
    macro_rules! try_or_skip {
        // `yield` expands to __yield_tx.send(()).await
        // `$inj` & `$inj2` are just tt munchers for `__yield_tx` & `send`
        ($val:expr, $inj:tt. $inj2:tt(()).await) => {
            match $val {
                Ok(v) => v,
                Err(err) => {
                    $inj.$inj2(Err(err.into())).await;
                    continue;
                }
            }
        };
    }
}

pub mod channel {
    //! Helpers for channel-based streams

    /// Checks if the passed value is Err, if so, sends it and continues, else it will gives the Ok value
    /// The second argument is expected to be the channel's sender side
    ///
    /// ```ignore
    /// try_or_continue!(v, sender)
    /// ```
    /// roughly expands to:
    ///
    /// ```ignore
    /// match v {
    ///     Ok(v) => v,
    ///     Err(e) => {
    ///         sender.send(e);
    ///         continue;
    ///     }
    /// }
    /// ```
    #[macro_export]
    macro_rules! try_or_continue {
        ($val:expr, $sender:expr) => {
            match $val {
                Ok(v) => v,
                Err(err) => {
                    let _ = $sender.send(Err(err.into()));
                    continue;
                }
            }
        };
    }

    /// Checks if the passed value is Err, if so, sends it and `return`, else it will gives the Ok value.
    /// The second argument is expected to be the channel's sender side
    ///
    /// ```ignore
    /// try_or_return!(v, sender)
    /// ```
    /// roughly expands to:
    ///
    /// ```ignore
    /// match v {
    ///     Ok(v) => v,
    ///     Err(e) => {
    ///         sender.send(e);
    ///         return;
    ///     }
    /// }
    /// ```
    #[macro_export]
    macro_rules! try_or_return {
        ($val:expr, $sender:expr) => {
            match $val {
                Ok(v) => v,
                Err(err) => {
                    let _ = $sender.send(Err(err.into()));
                    return;
                }
            }
        };
    }
}
