//! Vrf Configurations

use std::collections::BTreeMap;

use common::chains::ChainId;
use common::errors::ConfigError;
use serde::{Deserialize, Serialize};
use std::fmt::Debug;
use std::fs;
use std::path::PathBuf;

const fn eth_req_timeout() -> u64 {
    3
}

/// Ethereum Vrf Config
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct EthVrfConfig {
    /// Address of the Ethereum Smart Contract
    pub sc_address: String,
    /// Ethereum RPC client url
    pub sc_client_url: String,
    /// Backup Ehtereum RPC client url
    pub backup_sc_client_url: Option<String>,
    /// Seconds to wait for RPC response before timing out
    /// (default: 5s)
    #[serde(default = "eth_req_timeout")]
    pub request_timeout_secs: u64,
}

/// Aptos Vrf Config
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct AptosVrfConfig {
    /// Aptos RPC client url
    pub sc_client_url: String,
    /// Aptos VRF Smart Contract
    pub sc_address: String,
    /// Aptos VRF SC creation number
    pub creation_num: String,
}

/// Sui Vrf Config
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct SuiVrfConfig {
    /// Sui VRF Smart Contract
    pub sc_address: String,
    /// Sui RPC client url
    pub sc_client_url: String,
    /// Sui DKG Resource Id
    #[serde(default)]
    pub dkg_resource_id: String,
}

/// VRF Config
#[derive(Serialize, Debug, Default)]
pub struct VrfConfig {
    /// Path of the configuration
    #[serde(skip_serializing)]
    pub path: PathBuf,
    /// Aptos Configs
    pub aptos: BTreeMap<ChainId, AptosVrfConfig>,
    /// Eth Configs
    pub eth: BTreeMap<ChainId, EthVrfConfig>,
    /// Sui Configs
    pub sui: BTreeMap<ChainId, SuiVrfConfig>,
}

/// Vrf Config for serde
#[derive(Serialize, Deserialize)]
pub struct FileVrfConfig {
    #[serde(default = "BTreeMap::new")]
    aptos: BTreeMap<ChainId, AptosVrfConfig>,
    #[serde(default = "BTreeMap::new")]
    eth: BTreeMap<ChainId, EthVrfConfig>,
    #[serde(default = "BTreeMap::new")]
    sui: BTreeMap<ChainId, SuiVrfConfig>,
}

impl VrfConfig {
    /// Init a VrfConfig ready for loading
    /// default path is `./config.toml`
    pub fn new(path: Option<&str>) -> Self {
        VrfConfig {
            path: PathBuf::from(path.unwrap_or("./config.toml").to_string()),
            ..Default::default()
        }
    }

    /// Actually load the VrfConfig
    pub fn load(&self) -> Result<Self, ConfigError> {
        let file_config = toml_edit::easy::from_str::<FileVrfConfig>(
            &fs::read_to_string(&self.path).map_err(|_| ConfigError::ReadFile {
                location: format!("{:?}", self.path),
            })?,
        )?;
        let config = VrfConfig {
            path: self.path.clone(),
            aptos: file_config.aptos,
            eth: file_config.eth,
            sui: file_config.sui,
        };
        Ok(config)
    }

    #[cfg(test)]
    fn save(&self) -> Result<(), ConfigError> {
        let fc = FileVrfConfig {
            aptos: self.aptos.clone(),
            eth: self.eth.clone(),
            sui: self.sui.clone(),
        };

        fs::write(&self.path, toml_edit::easy::to_string(&fc)?).map_err(|_| ConfigError::ReadFile {
            location: format!("{:?}", self.path),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn save_and_load_config() {
        let mut eth_config = BTreeMap::new();

        eth_config.insert(
            ChainId::Anvil,
            EthVrfConfig {
                sc_address: "e7f1725E7734CE288F8367e1Bb143E90bb3F0512".to_string(),
                sc_client_url: "http://127.0.0.1:8545".to_string(),
                backup_sc_client_url: None,
                request_timeout_secs: 10,
            },
        );

        eth_config.insert(
            ChainId::Eth,
            EthVrfConfig {
                sc_address: "e7f1725E7734CE288F8367e1Bb143E90bb3F0512".to_string(),
                sc_client_url: "http://127.0.0.1:8545".to_string(),
                backup_sc_client_url: Some("http://127.0.0.1:8546".to_string()),
                request_timeout_secs: 5,
            },
        );

        eth_config.insert(
            ChainId::Matic,
            EthVrfConfig {
                sc_address: "e7f1725E7734CE288F8367e1Bb143E90bb3F0512".to_string(),
                sc_client_url: "http://127.0.0.1:8545".to_string(),
                backup_sc_client_url: Some("http://127.0.0.1:8546".to_string()),
                request_timeout_secs: 5,
            },
        );

        let test_path = "test_config.toml";

        let config = VrfConfig {
            path: PathBuf::from(test_path),
            aptos: BTreeMap::new(),
            eth: eth_config,
            sui: BTreeMap::new(),
        };

        config.save().unwrap();

        let config = VrfConfig::new(Some(test_path)).load().unwrap();

        assert_eq!(config.aptos.len(), 0);
        assert_eq!(config.eth.len(), 3);
    }
}
