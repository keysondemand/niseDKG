//! Helpers for Recovery Point (i.e catchup) mechanism
mod errors;
mod recovery_point_writter;

pub use errors::RecoveryPointError;
pub use recovery_point_writter::SyncRecoveryPointWriter as RecoveryPointWriter;

use rangemap::RangeSet;
use serde::{de::DeserializeOwned, Deserialize, Serialize};
use serde_json::error::Error as SerdeJsonError;
use std::cmp::Ordering;
use std::fmt::Debug;
use std::ops::{Add, Range, Sub};

/// implemented by struct that indicate a state of the blockchain mostly the block number.
/// Use to identify when a request has been read and do some recovery of missed request during a stop for example.
pub trait StorableRecoveryPoint: Send + 'static + Sized {
    /// Deserialize the recovery point
    /// The Send and 'static bounds are here because we need the RecoveryPointWriter to be Send and 'static
    fn from_slice(bytes: &[u8]) -> Result<Self, SerdeJsonError>;
    /// Serialize the recovery point
    fn to_vec(&self) -> Result<Vec<u8>, SerdeJsonError>;
    /// Constructs an Empty recovery point
    fn empty() -> Self;
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RecoveryNonce<N, B>(N, B);

impl<N: PartialEq, B> PartialEq for RecoveryNonce<N, B> {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

impl<N: PartialOrd, B> PartialOrd for RecoveryNonce<N, B> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.0.partial_cmp(&other.0)
    }
}

impl<N: Eq, B> Eq for RecoveryNonce<N, B> {}

impl<N: Ord, B> Ord for RecoveryNonce<N, B> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.0.cmp(&other.0)
    }
}

/// The recovery point stores an ordered vector of encountered Milestones,
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct RecoveryPoint<N: Ord + Clone, B: Ord + Clone>(RangeSet<RecoveryNonce<N, B>>);

impl<N: Ord + Clone, B: Ord + Clone> RecoveryPoint<N, B> {
    /// Constructs an empty recovery point store
    pub fn empty() -> Self {
        Self(RangeSet::<RecoveryNonce<N, B>>::new())
    }
}

impl<N: Ord + Clone + Add + Debug, B: Ord + Clone + Debug + Default> RecoveryPoint<N, B>
where
    N: Copy + Clone + From<u64> + Add<Output = N> + PartialEq + Add<Output = N> + PartialOrd,
    B: Copy,
{
    /// When a event has been processed, we add the nonce and the the block number to the recovery point
    pub fn add_point(&mut self, nonce: N, block_number: B) {
        let range = Range {
            start: RecoveryNonce(nonce, block_number),
            end: RecoveryNonce(nonce + 1.into(), block_number),
        };
        self.0.insert(range)
    }

    /// get a vector of (start_blocks, end_block) to request to the chain
    pub fn get_recovery_ranges(&self) -> Vec<(B, B)> {
        // if there's either no event, or a single one, then the recovery range list is empty
        if self.0.len() <= 1 {
            return Vec::new();
        }
        let outer_range = self.get_first_range().unwrap()..self.get_last_range().unwrap(); // these indexing are guaranteed
                                                                                           // not to panic since we used length condition at first
        let mut ranges = vec![];
        let recovery_range = self.0.gaps(&outer_range);
        for range in recovery_range {
            ranges.push((range.start.1, range.end.1));
        }
        ranges
    }

    /// get a vector of (start_nonce, end_nonce) to request to the chain
    pub fn get_recovery_nonce_ranges(&self) -> Vec<(N, N)> {
        // if there's either no event, or a single one, then the recovery range list is empty
        if self.0.len() <= 1 {
            return Vec::new();
        }
        let outer_range = self.get_first_range().unwrap()..self.get_last_range().unwrap(); // these indexing are guaranteed
                                                                                           // not to panic since we used length condition at first
        let mut ranges = vec![];
        let recovery_range = self.0.gaps(&outer_range);
        for range in recovery_range {
            ranges.push((range.start.0, range.end.0));
        }
        ranges
    }

    /// get first index pf the processed nonce/block
    fn get_first_range(&self) -> Option<RecoveryNonce<N, B>> {
        self.0.iter().next().map(|range| range.start.clone())
    }

    /// get the last index of the processed nonce/block
    fn get_last_range(&self) -> Option<RecoveryNonce<N, B>> {
        self.0.iter().last().map(|range| range.end.clone())
    }

    /// get the index of the latest processed block, this way the catchup mechanism can fetch all the blocks that are more recent than this one (including this one, because we may have missed an event in the same block)
    pub fn get_latest_processed_block(&self) -> Option<B> {
        self.get_last_range().map(|range| range.1)
    }

    /// get the index of the latest processed nonce
    pub fn get_latest_processed_nonce(&self) -> Option<N> {
        self.get_last_range().map(|range| range.0)
    }

    /// check if an event with a given nonce has already been processed or not
    pub fn has_nonce_been_processed(&self, nonce: N) -> bool {
        self.0.contains(&RecoveryNonce(nonce, Default::default()))
    }
}

impl<N: Ord + Clone, B: Ord + Clone> StorableRecoveryPoint for RecoveryPoint<N, B>
where
    N: Add<Output = N>
        + Sub<Output = N>
        + PartialOrd
        + PartialEq
        + Send
        + 'static
        + Copy
        + Clone
        + From<u64>
        + Serialize
        + DeserializeOwned,
    B: Send + 'static + Clone + Serialize + DeserializeOwned,
{
    fn empty() -> Self {
        Self(RangeSet::new())
    }

    fn from_slice(bytes: &[u8]) -> Result<Self, SerdeJsonError> {
        serde_json::from_slice(bytes)
    }

    fn to_vec(&self) -> Result<Vec<u8>, SerdeJsonError> {
        serde_json::to_vec(&self)
    }
}

/// This function is here to remove duplicates in the block ranges returned by `get_recovery_range`
/// It needs to be a separate function because the full list of ranges also includes the range between
/// the latest processed block and the current block, in addition to the list we get from `get_recovery_range`
pub fn optimize_block_ranges<B: PartialEq>(block_ranges: Vec<(B, B)>) -> Vec<(B, B)> {
    let mut optimized_block_ranges = Vec::with_capacity(block_ranges.len());

    // we iterate the list of blakc ranges, and if we find a range of block that starts with the same block as the pervious range's end, we merge them by updating the end.
    for (index, (start, end)) in block_ranges.into_iter().enumerate() {
        if index == 0 {
            optimized_block_ranges.push((start, end));
        } else {
            let end_of_last_in_optimized = &mut optimized_block_ranges
                .last_mut()
                .expect("the vector is not empty")
                .1;

            if *end_of_last_in_optimized == start {
                *end_of_last_in_optimized = end;
            } else {
                optimized_block_ranges.push((start, end));
            }
        }
    }
    optimized_block_ranges
}

#[cfg(test)]
mod test_recovery_point {
    use crate::recovery_point::RecoveryNonce;
    use rangemap::RangeSet;

    type RecoveryPoint = super::RecoveryPoint<u64, u64>;

    #[test]
    fn single_point() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);

        assert_eq!(1, rec.0.len());
        assert_eq!(RecoveryNonce(10, 55), rec.get_first_range().unwrap());

        let ranges = rec.get_recovery_ranges();
        assert_eq!(0, ranges.len());

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(55, latest_block);
    }

    #[test]
    fn multiple_consecutive_points_in_the_same_block() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        rec.add_point(11, 55);

        assert_eq!(1, rec.0.len());

        let mut range_set = RangeSet::new();
        range_set.insert(RecoveryNonce(10, 55)..RecoveryNonce(12, 55));
        assert_eq!(rec.0, range_set);

        let ranges = rec.get_recovery_ranges();
        assert_eq!(0, ranges.len());

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(55, latest_block);
    }

    #[test]
    fn multiple_consecutive_points_different_blocks() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        rec.add_point(11, 58);
        rec.add_point(12, 65);

        assert_eq!(1, rec.0.len());

        let mut range_set = RangeSet::new();
        range_set.insert(RecoveryNonce(10, 55)..RecoveryNonce(13, 65));
        assert_eq!(rec.0, range_set);

        let ranges = rec.get_recovery_ranges();
        assert_eq!(0, ranges.len());

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(65, latest_block);
    }

    #[test]
    fn multiple_points_with_one_miss_in_the_same_block() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        // missing event with nonce=11
        rec.add_point(12, 55);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(12, 55)),
            Some(&(RecoveryNonce(12, 55)..RecoveryNonce(13, 55)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((55, 55), ranges[0]); // TODO: this is the naive approach, this way we would download block 55 two times !

        let latest_block = rec.get_latest_processed_block().unwrap();

        assert_eq!(55, latest_block);

        assert!(!rec.has_nonce_been_processed(9));
        assert!(rec.has_nonce_been_processed(10));
        assert!(!rec.has_nonce_been_processed(11));
        assert!(rec.has_nonce_been_processed(12));
    }

    #[test]
    fn multiple_points_with_one_miss_in_different_blocks() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        // missing event with nonce=11
        rec.add_point(12, 58);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(12, 58)),
            Some(&(RecoveryNonce(12, 58)..RecoveryNonce(13, 58)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((55, 58), ranges[0]); // TODO: this is the naive approach, this way we would download block 55 two times !

        let latest_block = rec.get_latest_processed_block().unwrap();

        assert_eq!(58, latest_block);

        assert!(!rec.has_nonce_been_processed(9));
        assert!(rec.has_nonce_been_processed(10));
        assert!(!rec.has_nonce_been_processed(11));
        assert!(rec.has_nonce_been_processed(12));
    }

    #[test]
    fn multiple_points_with_multiple_misses_in_the_same_block() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        // missing event with nonce=11
        rec.add_point(12, 55);
        // missing event with nonce=13
        rec.add_point(14, 55);

        assert_eq!(3, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(12, 55)),
            Some(&(RecoveryNonce(12, 55)..RecoveryNonce(13, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(14, 55)),
            Some(&(RecoveryNonce(14, 55)..RecoveryNonce(15, 55)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(2, ranges.len());
        assert_eq!((55, 55), ranges[0]);
        assert_eq!((55, 55), ranges[1]); // TODO: this is the naive approach, this way we would download block 55 three times !

        let latest_block = rec.get_latest_processed_block().unwrap();

        assert_eq!(55, latest_block);

        assert!(!rec.has_nonce_been_processed(9));
        assert!(rec.has_nonce_been_processed(10));
        assert!(!rec.has_nonce_been_processed(11));
        assert!(rec.has_nonce_been_processed(12));
        assert!(!rec.has_nonce_been_processed(13));
        assert!(rec.has_nonce_been_processed(14));
    }

    #[test]
    fn adding_one_event_in_a_series_of_missed_ones() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        // missing event with nonce=11
        // missing event with nonce=12
        // missing event with nonce=13
        // missing event with nonce=14
        rec.add_point(15, 58);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(15, 58)),
            Some(&(RecoveryNonce(15, 58)..RecoveryNonce(16, 58)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((55, 58), ranges[0]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(58, latest_block);

        assert!(!rec.has_nonce_been_processed(9));
        assert!(rec.has_nonce_been_processed(10));
        assert!(!rec.has_nonce_been_processed(11));
        assert!(!rec.has_nonce_been_processed(12));
        assert!(rec.has_nonce_been_processed(15));

        rec.add_point(12, 57);

        assert_eq!(3, rec.0.len());

        let ranges = rec.get_recovery_ranges();
        assert_eq!(2, ranges.len());
        assert_eq!((55, 57), ranges[0]);
        assert_eq!((57, 58), ranges[1]); // TODO: il faudrait vraiment faire en sorte de ne pas télécharger deux fois le bloc 57
    }

    #[test]
    fn adding_multiple_nonconsecutive_events_in_a_series_of_missed_ones() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        // missing event with nonce=11
        // missing event with nonce=12
        // missing event with nonce=13
        // missing event with nonce=14
        // missing event with nonce=15
        rec.add_point(16, 70);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(16, 70)),
            Some(&(RecoveryNonce(16, 70)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((55, 70), ranges[0]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);

        rec.add_point(12, 57);
        rec.add_point(14, 60);

        assert_eq!(4, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(12, 57)),
            Some(&(RecoveryNonce(12, 57)..RecoveryNonce(13, 57)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(14, 60)),
            Some(&(RecoveryNonce(14, 60)..RecoveryNonce(15, 60)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(16, 70)),
            Some(&(RecoveryNonce(16, 70)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(3, ranges.len());
        assert_eq!((55, 57), ranges[0]); // TODO: il faudrait vraiment faire en sorte de ne pas télécharger deux fois le bloc 57 (idem pour le block 60 en dessous)
        assert_eq!((57, 60), ranges[1]);
        assert_eq!((60, 70), ranges[2]);
    }

    #[test]
    fn adding_multiple_consecutive_events_in_a_series_of_missed_ones() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        // missing event with nonce=11
        // missing event with nonce=12
        // missing event with nonce=13
        // missing event with nonce=14
        // missing event with nonce=15
        rec.add_point(16, 70);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(16, 70)),
            Some(&(RecoveryNonce(16, 70)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((55, 70), ranges[0]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);

        rec.add_point(12, 57);
        rec.add_point(13, 57);
        rec.add_point(14, 60);

        assert_eq!(3, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(12, 57)),
            Some(&(RecoveryNonce(12, 57)..RecoveryNonce(15, 60)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(16, 70)),
            Some(&(RecoveryNonce(16, 70)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(2, ranges.len());
        assert_eq!((55, 57), ranges[0]); // TODO: il faudrait vraiment faire en sorte de ne pas télécharger deux fois le bloc 57
        assert_eq!((60, 70), ranges[1]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);
    }

    #[test]
    fn adding_an_event_narrowing_a_range_from_the_bottom() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        // missing event with nonce=11 <- that's the one we'll add
        // missing event with nonce=12
        // missing event with nonce=13
        // missing event with nonce=14
        // missing event with nonce=15
        rec.add_point(16, 70);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(16, 70)),
            Some(&(RecoveryNonce(16, 70)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((55, 70), ranges[0]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);

        rec.add_point(11, 57);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(12, 57)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(16, 70)),
            Some(&(RecoveryNonce(16, 70)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((57, 70), ranges[0]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);
    }

    #[test]
    fn adding_an_event_narrowing_a_range_from_the_top() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        // missing event with nonce=11
        // missing event with nonce=12
        // missing event with nonce=13
        // missing event with nonce=14
        // missing event with nonce=15 <- that's the one we'll add
        rec.add_point(16, 70);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(16, 70)),
            Some(&(RecoveryNonce(16, 70)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((55, 70), ranges[0]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);

        rec.add_point(15, 60);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(11, 55)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(15, 60)),
            Some(&(RecoveryNonce(15, 60)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((55, 60), ranges[0]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);
    }

    #[test]
    fn adding_an_event_closing_a_gap() {
        let mut rec = RecoveryPoint::empty();
        rec.add_point(10, 55);
        rec.add_point(11, 58);
        rec.add_point(12, 58);
        // missing event with nonce=13
        rec.add_point(14, 67);
        rec.add_point(15, 68);
        rec.add_point(16, 70);

        assert_eq!(2, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(13, 58)))
        );
        assert_eq!(
            rec.0.get(&RecoveryNonce(14, 67)),
            Some(&(RecoveryNonce(14, 67)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(1, ranges.len());
        assert_eq!((58, 67), ranges[0]);

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);

        rec.add_point(13, 61);

        assert_eq!(1, rec.0.len());
        assert_eq!(
            rec.0.get(&RecoveryNonce(10, 55)),
            Some(&(RecoveryNonce(10, 55)..RecoveryNonce(17, 70)))
        );

        let ranges = rec.get_recovery_ranges();
        assert_eq!(0, ranges.len());

        let latest_block = rec.get_latest_processed_block().unwrap();
        assert_eq!(70, latest_block);
    }
}
