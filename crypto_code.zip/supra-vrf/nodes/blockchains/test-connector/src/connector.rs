use async_stream::stream;
use async_trait::async_trait;
use common::chains::ChainId;
use common::{VrfCallback, VrfRequest};
use connectors::Init;
use connectors::{recovery_point::RecoveryPointWriter, RecoveryPointError};
use connectors::{BcConnector, RequestEvent, StreamError, VrfTx};
use log::debug;
use std::collections::HashSet;
use std::fmt::Debug;
use std::time::{Duration, Instant};
use thiserror::Error;
use tokio::time::sleep;
use tokio_stream::Stream;

const TEST_CHAIN_ID: ChainId = ChainId::DevMockChain;

#[derive(Debug, Error)]
pub enum TestError {
    #[error("todo")]
    Todo,
    #[error("Failed to initialize recovery point: {0}")]
    RecoveryPoint(#[from] RecoveryPointError),
}

impl StreamError for TestError {
    /// Whether this error is a websocket stream related error
    fn is_wss_error(&self) -> bool {
        false
    }
}

type Nonce = u64;

type BlockNumber = u64;

#[derive(Debug, Clone)]
pub struct TestRequestEvent {
    nonce: Nonce,
}

impl RequestEvent for TestRequestEvent {
    type CallerIdentifier = ();
    type Error = TestError;

    fn to_vrf_request(&self) -> Result<Option<VrfRequest>, Self::Error> {
        let nonce = [self.nonce, 0, 0, 0];

        Ok(Some(VrfRequest {
            nonce,
            txhash: vec![self.nonce as u8],
            message: vec![self.nonce as u8],
            block_hash: vec![self.nonce as u8],
            chain_id: TEST_CHAIN_ID,
        }))
    }

    fn get_tx_hash(&self) -> String {
        let index = self.nonce;
        format!("Transaction for Nonce {index}")
    }

    fn short_log(&self) -> String {
        let index = self.nonce;
        format!("Short log for Nonce {index}")
    }

    fn get_vrf_nonce(&self) -> u64 {
        self.nonce
    }

    fn get_reception_time(&self) -> Instant {
        Instant::now()
    }

    fn get_caller(&self) -> Self::CallerIdentifier {}
}

/// Test Connector
pub struct TestConnector;

#[async_trait]
impl BcConnector for TestConnector {
    type RequestEvent = TestRequestEvent;
    type Error = TestError;
    type Nonce = Nonce;
    type BlockNumber = BlockNumber;

    /// Wait for 100 ms then returns the events with nonce 1, 2 and 3.
    async fn catchup(
        &self,
    ) -> Result<Box<dyn Stream<Item = Result<Self::RequestEvent, Self::Error>> + Send>, Self::Error>
    {
        sleep(Duration::from_millis(100)).await;
        let request_events = [1u64, 2, 3].map(|nonce| Ok(TestRequestEvent { nonce }));

        Ok(Box::new(tokio_stream::iter(request_events)))
    }

    // returns a stream of events starting from nonce 4 up to nonce 10
    // note: the first event is being returned instantly
    async fn start_listening(
        &self,
    ) -> Result<Box<dyn Stream<Item = Result<Self::RequestEvent, Self::Error>> + Send>, Self::Error>
    {
        let stream = stream! {
            for nonce in 4..=10 {
                yield Ok(TestRequestEvent{nonce});
                sleep(Duration::from_millis(100)).await;
            }
        };
        Ok(Box::new(stream))
    }

    async fn close_connector(&mut self) {
        todo!()
    }

    async fn verify_callback_nonce(
        &mut self,
        _event: Self::RequestEvent,
        _callback: &VrfCallback,
    ) -> Result<bool, Self::Error> {
        todo!()
    }

    async fn send_callback_tx(
        &self,
        concurrency_index: usize,
        callback: Option<VrfTx>,
        event: Self::RequestEvent,
        _rpw: RecoveryPointWriter<Nonce, BlockNumber>,
    ) -> Result<(), Self::Error> {
        let nonce = event.nonce;
        debug!("Sending callback for nonce {nonce}, concurrency index: {concurrency_index}, {callback:?}");
        Ok(())
    }

    fn concurrency_limit(&self) -> usize {
        4 // Arbitrary number
    }
}

#[derive(Debug, Clone, Default)]
pub struct TestConfig;

#[async_trait]
impl Init for TestConfig {
    type InitializationError = TestError;
    type Connector = TestConnector;

    async fn initialize_connector(
        &self,
        _chain_id: ChainId,
        _secrets: Vec<String>,
    ) -> Result<(RecoveryPointWriter<Nonce, BlockNumber>, TestConnector), Self::InitializationError>
    {
        let (rpw, _) = RecoveryPointWriter::init(TEST_CHAIN_ID).unwrap();

        Ok((rpw, TestConnector))
    }

    fn whitelist(
        &self,
    ) -> Option<
        Result<
            HashSet<
                <<Self::Connector as BcConnector>::RequestEvent as RequestEvent>::CallerIdentifier,
            >,
            Self::InitializationError,
        >,
    > {
        None
    }

    fn blacklist(
        &self,
    ) -> Result<
        HashSet<<<Self::Connector as BcConnector>::RequestEvent as RequestEvent>::CallerIdentifier>,
        Self::InitializationError,
    > {
        Ok(HashSet::new())
    }
}
