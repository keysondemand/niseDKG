# Test Connector

A mock connector for testing purpose.

The catchup waits for 100 ms then returns the events with nonce 1, 2 and 3.

The listening process returns a stream of events starting from nonce 4 up to nonce 10, every 100ms (note: the first event is being returned instantly)