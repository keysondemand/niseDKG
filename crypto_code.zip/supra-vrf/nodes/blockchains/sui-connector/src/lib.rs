//! The Connector for the Sui blockchain

#![warn(missing_docs)]

mod callback;
mod config;
pub mod errors;
mod request;
mod request_event;
mod verify_request;

use crate::callback::SupraSuiClient;
use crate::errors::SuiConnectorError;
use crate::request::{get_filter_for_event, handle_event};
use async_stream::stream;
use async_trait::async_trait;
use common::chains::ChainId;
use common::influx_metrics::Metrics;
use common::{with_retries, CommitteeData, VrfCallback};
pub use config::{SuiConfig, SuiSecretConfig};
use connectors::recovery_point::RecoveryPoint;
use connectors::recovery_point::RecoveryPointWriter;
use connectors::try_or_skip;
use connectors::{BcConnector, VrfTx};
use futures::StreamExt;
use log::info;
pub use request_event::SuiRequestEvent;
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;
use std::time::Duration;
use sui_keys::keystore::AccountKeystore;
use sui_sdk::apis::EventApi;
use sui_sdk::rpc_types::{EventFilter, SuiEvent};
use sui_types::base_types::{ObjectID, TransactionDigest};
use sui_types::event::EventID;
use tokio_stream::Stream;
pub use verify_request::verify_request;

const POLLING_CHUNK_SIZE: usize = 100;
const POLLING_INTERVAL: Duration = Duration::from_secs(8);

/// Sui History Point
#[derive(Copy, Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Default, Serialize, Deserialize)]
pub struct SuiHistoryPoint {
    /// Event Sequence
    pub event_seq: u64,
    /// Transaction hash
    pub tx_digest: [u8; 32],
}

type SuiRecoveryPoint = RecoveryPoint<u64, SuiHistoryPoint>;

/// The Sui connector
pub struct SuiConnector {
    sui_client: SupraSuiClient,
    smart_contract_address: ObjectID,
    /// The config being used by this container
    pub config: SuiConfig,
    recovery_point: SuiRecoveryPoint,
    chain_id: ChainId,
}

impl SuiConnector {
    async fn get_latest_cursor(
        event_api: &EventApi,
        query: &EventFilter,
    ) -> Result<Option<EventID>, SuiConnectorError> {
        Ok(event_api
            .query_events(query.clone(), None, Some(1), true)
            .await?
            .data
            .pop()
            .map(|e| e.id))
    }

    async fn polling_evstream(
        &self,
    ) -> Result<
        impl Stream<Item = Result<SuiRequestEvent, SuiConnectorError>> + 'static,
        SuiConnectorError,
    > {
        let event_api = self.sui_client.client.event_api().clone();
        let ev_query = get_filter_for_event(&self.smart_contract_address)?;

        let mut cursor = Self::get_latest_cursor(&event_api, &ev_query).await?;
        let mut skip = 1;
        Ok(stream! {

            loop {
                let latest_events = event_api.query_events(
                    ev_query.clone(),
                    cursor.clone(),
                    Some(POLLING_CHUNK_SIZE),
                    false
                ).await?;

                if !latest_events.data.is_empty() {
                    for ev in &latest_events.data[skip..] {
                        let e = try_or_skip!(handle_event(ev), yield);
                        yield Ok(e);
                    }
                    let last_cursor = cursor;
                    cursor = latest_events.next_cursor;
                    while cursor.is_none() || cursor == last_cursor {
                        cursor = try_or_skip!(Self::get_latest_cursor(&event_api, &ev_query).await, yield);
                        tokio::time::sleep(POLLING_INTERVAL).await;
                    }
                }
                skip = 0;
            }
        })
    }

    async fn websocket_evstream(
        &self,
        chain_id: ChainId,
    ) -> Result<impl Stream<Item = Result<SuiRequestEvent, SuiConnectorError>>, SuiConnectorError>
    {
        let ws_transport = self.sui_client.client.clone();
        let smart_contract_address = self.smart_contract_address;

        let filtered = stream! {

            let mut sub = with_retries(3, || async {
                let filter = get_filter_for_event(&smart_contract_address).unwrap(); // TODO : unwrap()
                ws_transport.event_api().subscribe_event(filter).await
            }).await?;

            while let Some(log_res) = sub.next().await {
                match log_res {
                    Ok(ev) => {
                        let e = try_or_skip!(handle_event(&ev), yield);
                        Metrics::pick_event_log(&ChainId::Sui, e.clone().nonce, e.clone().caller_contract, "ws");
                        yield Ok(e);
                    },
                    Err(e) => log::warn!("{chain_id}: Websocket stream received error {e}")
                }
            }
            yield Err(SuiConnectorError::WssConnectionLost);
        };

        Ok(filtered)
    }

    /// Updates the BLS Committee key
    pub async fn add_public_key(
        config: &SuiConfig,
        secret: String,
        committee_data: CommitteeData,
    ) -> Result<(), SuiConnectorError> {
        let client = SupraSuiClient::new(config, &[secret]).await?;
        client.add_public_key(config, committee_data).await
    }
}

#[async_trait]
impl BcConnector for SuiConnector {
    type RequestEvent = SuiRequestEvent;
    type Error = SuiConnectorError;
    type Nonce = u64;
    type BlockNumber = SuiHistoryPoint;

    async fn catchup(
        &self,
    ) -> Result<Box<dyn Stream<Item = Result<Self::RequestEvent, Self::Error>> + Send>, Self::Error>
    {
        let Some(SuiHistoryPoint { event_seq, tx_digest })= self.recovery_point.get_latest_processed_block() else {
            return Ok(Box::new(tokio_stream::empty()));
        };

        let event_api = self.sui_client.client.event_api().clone();
        let ev_query = get_filter_for_event(&self.smart_contract_address)?;
        let cursor = Some(EventID {
            event_seq,
            tx_digest: TransactionDigest::new(tx_digest),
        });

        Ok(Box::new(stream! {
            let latest_events = event_api.query_events(
                ev_query.clone(),
                cursor.clone(),
                None,
                false
            ).await;

            match latest_events {
                Ok(event) => {
                    for ev in event.data {
                        let e = try_or_skip!(handle_event(&ev), yield);
                        Metrics::pick_event_log(&ChainId::Sui, e.clone().nonce, e.clone().caller_contract, "http");
                        yield Ok(e);
                    }
                },
                Err(err) => {
                    log::error!("Sui catchup error {:?}", err);
                }
            }

        }))
    }

    async fn start_listening(
        &self,
    ) -> Result<Box<dyn Stream<Item = Result<Self::RequestEvent, Self::Error>> + Send>, Self::Error>
    {
        let chain_id = self.chain_id;
        let ws_stream = self.websocket_evstream(chain_id).await?;
        let polling_stream = self.polling_evstream().await?;

        let ev_stream = stream! {
            tokio::pin!(ws_stream);
            tokio::pin!(polling_stream);

            let mut ev_cache = BTreeSet::new();
            loop {
                let transport;
                let ev = tokio::select! {
                    Some(ev) = polling_stream.next() => {
                        transport = "http";
                        ev
                    },
                    maybe_ev = ws_stream.next() => {
                        transport = "ws";
                        match maybe_ev {
                            Some(ev) => ev,
                            None => {
                                log::warn!("{chain_id}: webscoket transport stopped streaming, stopping early");
                                break;
                            }
                        }
                    }
                };

                let ev = try_or_skip!(ev, yield);
                let ev_id = try_or_skip!(ev.event_id(), yield);

                if !ev_cache.remove(&ev_id) {
                    log::info!("{chain_id}: received event, transport: {transport}");
                    ev_cache.insert(ev_id);
                    yield Ok(ev);
                }
            }
        };
        Ok(Box::new(ev_stream))
    }

    async fn verify_callback_nonce(
        &mut self,
        _request_event: Self::RequestEvent,
        _vrf_callback: &VrfCallback,
    ) -> Result<bool, SuiConnectorError> {
        Ok(true)
    }

    async fn send_callback_tx(
        &self,
        concurrency_index: usize,
        callback: Option<VrfTx>,
        request_event: Self::RequestEvent,
        recovery_point_writer: RecoveryPointWriter<u64, SuiHistoryPoint>,
    ) -> Result<(), Self::Error> {
        let nonce = request_event.nonce;
        let chain_point = request_event.chain_point;

        let callback = callback.expect("empty vrf transaction"); // the VRF transaction can never be None for Aptos

        // if, for some reason, the nonce as already been processed by this free node, don't call the callback
        // it can happen because during catchup we re-fetch the block surrounding a missing nonce,
        // because the missing nonce could be in the same block as an already processed nonce.
        if self.recovery_point.has_nonce_been_processed(nonce) {
            info!(
                "{}: Nonce {nonce} has already been processed, skipping",
                self.chain_id
            );
            return Ok(());
        }

        self.sui_client
            .generate_callback(
                callback.bls_signature,
                request_event,
                self.config.clone(),
                concurrency_index,
            )
            .await?;

        recovery_point_writer.add_point(nonce, chain_point);

        Ok(())
    }

    async fn close_connector(&mut self) {
        // TODO: this should be implemented, right ?
        todo!()
    }

    fn concurrency_limit(&self) -> usize {
        self.sui_client.key_store.keys().len()
    }
}
