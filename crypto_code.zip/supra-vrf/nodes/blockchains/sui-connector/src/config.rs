//! Configurations for the sui blockchain connector

use async_trait::async_trait;
use common::chains::ChainId;
use connectors::{recovery_point::RecoveryPointWriter, Init, RecoveryPointError};
use log::info;
use serde::{Deserialize, Serialize};
use std::{collections::HashSet, fmt::Debug};
use sui_types::base_types::{ObjectID, ObjectIDParseError};
use thiserror::Error;

use crate::{callback::SupraSuiClient, errors::SuiConnectorError, SuiConnector, SuiHistoryPoint};

/// Configuration for the Sui Connector
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct SuiConfig {
    /// Address of the Generator Smart Contract
    pub(crate) sc_address: String,
    /// Sui Client URL
    pub(crate) sc_client_url: String,
    /// Sui Websocket Client URL
    pub(crate) sc_wss_url: String,
    /// Dkg Resource ID to be used for smart contract callbacks
    #[serde(default)]
    pub(crate) dkg_resource_id: String,
    pub(crate) sc_whitelist: Option<HashSet<String>>,
    #[serde(default)]
    pub(crate) sc_blacklist: HashSet<String>,
}

/// Secrets configuration for Sui Connector
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct SuiSecretConfig {
    /// Private key to send transactions (in hex format)
    pub chain_secret_keys_hex: Vec<String>,
}

/// The Init trait, responsible for the initialization of the connector
#[async_trait]
impl Init for SuiConfig {
    type InitializationError = InitializationError;
    type Connector = SuiConnector;

    /// Perform the initialization of a blockchain connector
    async fn initialize_connector(
        &self,
        chain_id: ChainId,
        secrets: Vec<String>,
    ) -> Result<(RecoveryPointWriter<u64, SuiHistoryPoint>, SuiConnector), Self::InitializationError>
    {
        let (recovery_point_writer, recovery_point) = RecoveryPointWriter::init(chain_id)?;
        info!("{chain_id}: starting point= {:?}", recovery_point);

        Ok((
            recovery_point_writer,
            SuiConnector {
                sui_client: SupraSuiClient::new(self, &secrets).await?,
                smart_contract_address: ObjectID::from_hex_literal(&self.sc_address)?,
                config: self.clone(),
                recovery_point,
                chain_id,
            },
        ))
    }

    fn whitelist(&self) -> Option<Result<HashSet<String>, InitializationError>> {
        self.sc_whitelist.clone().map(Ok)
    }

    fn blacklist(&self) -> Result<HashSet<String>, InitializationError> {
        Ok(self.sc_blacklist.clone())
    }
}

/// Errors encountered during the initialization of the Sui connector
#[allow(missing_docs)]
#[allow(clippy::enum_variant_names)]
#[derive(Error, Debug)]
pub enum InitializationError {
    #[error("Invalid smart contract address: {0}")]
    SmartContractAddressError(#[from] ObjectIDParseError),

    #[error("Cannot get the smart contract instance, with error: {0}")]
    GetContractInstanceError(#[from] SuiConnectorError),

    #[error(transparent)]
    RecoveryPointError(#[from] RecoveryPointError),
}

impl InitializationError {
    /// check sui initial configuration is correct, if not then return "true"
    pub fn is_config_error(&self) -> bool {
        match &self {
            InitializationError::GetContractInstanceError(err) => match err {
                SuiConnectorError::SuiKeyPair(_err) => true,
                SuiConnectorError::Anyhow(error) => {
                    let nt_err = ["Networking or low-level protocol error: empty string".to_string(),
                    "Networking or low-level protocol error: Invalid Url: Invalid URL: empty string".to_string()];
                    nt_err.contains(&error.to_string())
                }
                _ => false,
            },
            _ => false,
        }
    }
}
