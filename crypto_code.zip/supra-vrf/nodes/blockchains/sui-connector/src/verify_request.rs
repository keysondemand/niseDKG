use common::{errors::VRFError, VrfRequest};
use connectors::vrf_config::VrfConfig;
use sui_sdk::SuiClientBuilder;
use sui_types::base_types::TransactionDigest;

use crate::{request::handle_event, SuiRequestEvent};

/// Verifies if a VRF Request is valid for Sui
pub async fn verify_request(config: &VrfConfig, request: &VrfRequest) -> Result<bool, VRFError> {
    let mut response = false;
    let chain_id = request.chain_id;

    let sui_config = config.sui.get(&chain_id).ok_or_else(|| {
        VRFError::SuiError(format!(
            "verify_request no config found for request chain id:{chain_id:?}"
        ))
    })?;

    let client = SuiClientBuilder::default()
        .build(&sui_config.sc_client_url)
        .await
        .map_err(|_e| VRFError::SuiError(format!("Unable Initialize SuiClient :{chain_id:?}")))?;

    let digest = TransactionDigest::new(request.txhash.clone().try_into().map_err(|_e| {
        VRFError::SuiError(format!(
            "Unable to converse Vec<u8> to Array chain id:{chain_id:?}"
        ))
    })?);

    let transaction = client.event_api().get_events(digest).await;

    if let Ok(event) = transaction {
        for ev in event {
            let request_event = handle_event(&ev);
            if let Ok(SuiRequestEvent { message, .. }) = request_event {
                if message == request.message {
                    response = true;
                }
            }
        }
    }
    Ok(response)
}

#[cfg(test)]
mod tests {

    // cargo test -- test_sui_vrf_request --exact --nocapture
    #[tokio::test]
    #[cfg(ignore = "it's local vrf_request data")]
    async fn test_sui_vrf_request() {
        let chain_id = common::chains::ChainId::Sui;
        let vrf_request = VrfRequest {
            message: vec![
                49, 58, 49, 58, 49, 58, 48, 120, 53, 100, 49, 98, 54, 49, 97, 100, 97, 51, 102, 99,
                55, 98, 102, 97, 97, 98, 49, 100, 48, 97, 101, 99, 100, 100, 101, 49, 55, 102, 55,
                55, 97, 101, 51, 52, 56, 50, 102, 101, 58, 84, 101, 101, 110, 80, 97, 116, 116,
                105, 58, 58, 100, 105, 115, 116, 114, 105, 98, 117, 116, 101, 58, 53,
            ],
            block_hash: vec![],
            txhash: TransactionDigest::from_str("FfQh4PQyfHojNAWhoxDoL5XUaQNZEt2D2g7NwLvwWWTi")
                .unwrap()
                .to_bytes()
                .to_vec(),
            nonce: [1, 0, 0, 0],
            chain_id: chain_id,
        };
        let config = Config::new(Some("../../free-node/config.toml"))
            .load()
            .unwrap();

        let data = verify_request(&config, &vrf_request).await;
        assert!(data.is_ok());
        assert!(data.unwrap());
    }
}
