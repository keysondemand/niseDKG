use crate::errors::SuiConnectorError;
use crate::SuiHistoryPoint;
use crate::{SuiEvent, SuiRequestEvent};
use common::chains::ChainId;
use move_core_types::account_address::AccountAddress;
use move_core_types::identifier::Identifier;
use move_core_types::language_storage::StructTag;
use serde_json::Value;
use std::str::FromStr;
use std::time::Instant;
use sui_sdk::rpc_types::EventFilter::{self, MoveEventType};
use sui_types::base_types::ObjectID;

pub const CONTRACT_MODULE: &str = "SupraContract";
pub const CONTRACT_EVENT: &str = "SupraEvent";

pub fn get_filter_for_event(sc_address: &ObjectID) -> Result<EventFilter, SuiConnectorError> {
    Ok(MoveEventType(StructTag {
        address: AccountAddress::from(*sc_address),
        module: Identifier::from_str(CONTRACT_MODULE)?,
        name: Identifier::from_str(CONTRACT_EVENT)?,
        type_params: vec![],
    }))
}

pub fn handle_event(event: &SuiEvent) -> Result<SuiRequestEvent, SuiConnectorError> {
    let event = event.clone();
    match event.parsed_json {
        Value::Object(obj) => {
            let nonce = obj
                .get("nonce")
                .ok_or_else(|| SuiConnectorError::SuiEventParse("nonce".to_string()))?
                .as_str()
                .ok_or_else(|| SuiConnectorError::SuiEventParse("nonce".to_string()))?
                .parse::<u64>()?;

            let callback_fn = obj
                .get("callback_fn")
                .ok_or_else(|| SuiConnectorError::SuiEventParse("callback_fn".to_string()))?
                .as_str()
                .ok_or_else(|| SuiConnectorError::SuiEventParse("callback_fn".to_string()))?
                .to_string();

            let caller_contract = obj
                .get("caller_contract")
                .ok_or_else(|| SuiConnectorError::SuiEventParse("caller_contract".to_string()))?
                .as_str()
                .ok_or_else(|| SuiConnectorError::SuiEventParse("caller_contract".to_string()))?
                .to_string();

            let client_obj_addr = obj
                .get("client_obj_addr")
                .ok_or_else(|| SuiConnectorError::SuiEventParse("client_obj_addr".to_string()))?
                .as_str()
                .ok_or_else(|| SuiConnectorError::SuiEventParse("client_obj_addr".to_string()))?
                .to_string();

            let client_seed = obj
                .get("client_seed")
                .ok_or_else(|| SuiConnectorError::SuiEventParse("client_seed".to_string()))?
                .as_str()
                .ok_or_else(|| SuiConnectorError::SuiEventParse("client_seed".to_string()))?
                .to_string();

            let num_confirmations = obj
                .get("num_confirmations")
                .ok_or_else(|| SuiConnectorError::SuiEventParse("num_confirmations".to_string()))?
                .as_str()
                .ok_or_else(|| SuiConnectorError::SuiEventParse("num_confirmations".to_string()))?
                .to_string();

            let rng_count = obj
                .get("rng_count")
                .ok_or_else(|| SuiConnectorError::SuiEventParse("rng_count".to_string()))?
                .as_u64()
                .ok_or_else(|| SuiConnectorError::SuiEventParse("rng_count".to_string()))?;

            let instance_id = obj
                .get("instance_id")
                .ok_or_else(|| SuiConnectorError::SuiEventParse("instance_id".to_string()))?
                .as_str()
                .ok_or_else(|| SuiConnectorError::SuiEventParse("instance_id".to_string()))?
                .parse::<u64>()?;

            let message = &format!(
                "{nonce}:{rng_count}:{instance_id}:{caller_contract}:{callback_fn}:{client_seed}",
            );

            Ok(SuiRequestEvent {
                chain_point: SuiHistoryPoint {
                    event_seq: event.id.event_seq,
                    tx_digest: event.id.tx_digest.into_inner(),
                },
                message: message.as_bytes().to_vec(),
                nonce,
                callback_fn,
                caller_contract,
                client_obj_addr,
                client_seed,
                num_confirmations,
                rng_count,
                instance_id,
                thash: event.id.tx_digest.into_inner().to_vec(),
                chain_id: ChainId::Sui,
                reception_time: Instant::now(),
            })
        }
        _ => Err(SuiConnectorError::SuiEventParse(
            "Unsupported Sui Field".to_string(),
        )),
    }
}
