use common::chains::ChainId;
use common::VrfRequest;
use connectors::RequestEvent;
use std::time::Instant;
use sui_types::base_types::TransactionDigest;

use crate::errors::SuiConnectorError;
use crate::SuiHistoryPoint;

/// The Sui specific VRF Request
#[derive(Clone, Debug)]
pub struct SuiRequestEvent {
    /// The sequence of the event
    pub chain_point: SuiHistoryPoint,
    /// Encoded message for the VRF Request
    pub message: Vec<u8>,
    /// Unique nonce for the VRF Request
    pub nonce: u64,
    /// Callback function name
    pub callback_fn: String,
    /// Contract which requested VRF
    pub caller_contract: String,
    /// Address of the client Object
    pub client_obj_addr: String,
    /// VRF Seed
    pub client_seed: String,
    /// Number of confirmations before processing the event
    pub num_confirmations: String,
    /// Number of random numbers requested
    pub rng_count: u64,
    /// Instance Id of the smart contract
    pub instance_id: u64,
    /// Transaction hash of the event
    pub thash: Vec<u8>,
    /// Source Chain Id
    pub chain_id: ChainId,
    /// Reception time to get elapsed time
    pub reception_time: Instant,
}

impl SuiRequestEvent {
    pub(crate) fn event_id(&self) -> Result<u64, SuiConnectorError> {
        let nonce = self.nonce;
        Ok(nonce)
    }
}

impl RequestEvent for SuiRequestEvent {
    type CallerIdentifier = String;
    type Error = SuiConnectorError;

    fn to_vrf_request(&self) -> Result<Option<VrfRequest>, Self::Error> {
        Ok(Some(VrfRequest {
            message: self.message.clone(),
            chain_id: self.chain_id,
            block_hash: vec![],
            txhash: self.thash.to_vec(),
            nonce: [self.nonce, 0, 0, 0],
        }))
    }

    fn get_tx_hash(&self) -> String {
        TransactionDigest::new(self.thash.clone().try_into().unwrap()).to_string()
    }

    fn short_log(&self) -> String {
        format!("nonce: {}, message: {:?}", self.nonce, self.message)
    }

    fn get_vrf_nonce(&self) -> u64 {
        self.nonce
    }

    fn get_reception_time(&self) -> Instant {
        self.reception_time
    }

    fn get_caller(&self) -> Self::CallerIdentifier {
        self.caller_contract.clone()
    }
}
