use connectors::recovery_point::RecoveryPoint;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Ord, PartialOrd, Eq, PartialEq, Serialize, Deserialize, Copy)]
pub struct SuiHistoryPoint {
    pub event_seq: i64,
    pub tx_digest: [u8; 32],
}

pub type SuiRecoveryPoint = RecoveryPoint<u64, SuiHistoryPoint>;
