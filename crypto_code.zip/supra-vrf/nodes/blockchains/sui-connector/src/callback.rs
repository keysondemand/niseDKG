use crate::{errors::SuiConnectorError, SuiRequestEvent};

use crate::config::SuiConfig;
use common::chains::ChainId;
use common::influx_metrics::Metrics;
use common::CommitteeData;
use log::info;
use nidkg_helper::{
    nidkg::BlsSignature,
    utils::{convert_49bg1_48bg1, convert_97bg2_96bg2},
};
use shared_crypto::intent::Intent;
use std::str::FromStr;
use sui_keys::keystore::{AccountKeystore, InMemKeystore};
use sui_sdk::rpc_types::{SuiTransactionBlockEffects, SuiTransactionBlockResponseOptions};
use sui_sdk::{json::SuiJsonValue, types::base_types::ObjectID, SuiClient, SuiClientBuilder};
use sui_types::crypto::SuiKeyPair;
use sui_types::{quorum_driver_types::ExecuteTransactionRequestType, transaction::Transaction};

pub struct SupraSuiClient {
    pub(crate) client: SuiClient,
    pub(crate) key_store: InMemKeystore,
}

impl SupraSuiClient {
    pub async fn new(
        config: &SuiConfig,
        chain_secret_keys_hex: &[String],
    ) -> Result<SupraSuiClient, SuiConnectorError> {
        let client = SuiClientBuilder::default()
            .ws_url(&config.sc_wss_url)
            .build(&config.sc_client_url)
            .await?;
        let mut key_store = InMemKeystore::default();

        for key in chain_secret_keys_hex {
            let key_pair = SuiKeyPair::from_str(key)
                .map_err(|err| SuiConnectorError::SuiKeyPair(err.to_string()))?;
            key_store
                .add_key(key_pair)
                .map_err(|err| SuiConnectorError::SuiKeyPair(err.to_string()))?;
        }
        Ok(SupraSuiClient { client, key_store })
    }

    pub async fn generate_callback(
        &self,
        signature: BlsSignature,
        event: SuiRequestEvent,
        config: SuiConfig,
        concurrency_index: usize,
    ) -> Result<(), SuiConnectorError> {
        let package_object_id = ObjectID::from_hex_literal(&event.caller_contract)?;

        let split_mod_fun: Vec<&str> = event.callback_fn.split("::").collect();
        let module = split_mod_fun[0];
        let function = split_mod_fun[1];

        let message = &event.message;
        let signature = convert_49bg1_48bg1(signature.bls12381.sig_g1);

        let signer = self.key_store.addresses()[concurrency_index];

        let tx_data = self
            .client
            .transaction_builder()
            .move_call(
                signer,
                package_object_id,
                module,
                function,
                vec![],
                vec![
                    SuiJsonValue::from_str(&event.client_obj_addr)?,
                    SuiJsonValue::from_str(&config.dkg_resource_id)?,
                    SuiJsonValue::from_str(&format!("\"{}\"", event.nonce))?,
                    SuiJsonValue::from_bcs_bytes(None, message)?,
                    SuiJsonValue::from_bcs_bytes(None, &signature)?,
                    SuiJsonValue::from_str(&format!("\"{}\"", event.rng_count))?,
                    SuiJsonValue::from_str(&format!("{:?}", event.client_seed))?,
                ],
                None,
                30000000,
            )
            .await?;

        let signature = self
            .key_store
            .sign_secure(&signer, &tx_data, Intent::sui_transaction())?;

        let response = self
            .client
            .quorum_driver_api()
            .execute_transaction_block(
                Transaction::from_data(tx_data, Intent::sui_transaction(), vec![signature])
                    .verify()?,
                SuiTransactionBlockResponseOptions::default(),
                Some(ExecuteTransactionRequestType::WaitForLocalExecution),
            )
            .await;

        match response {
            Ok(response) => {
                info!("tx_resp: {:?}", response.digest);
                let tx_hash = response.digest.to_string();
                if let Some(effects) = response.effects {
                    let SuiTransactionBlockEffects::V1(effect) = effects;
                    if let sui_sdk::rpc_types::SuiExecutionStatus::Failure { error } = effect.status
                    {
                        let err = error.clone();
                        if error == "InsufficientGas" {
                            Metrics::out_of_compute(&ChainId::Sui, error, event.nonce, tx_hash);
                        } else {
                            Metrics::cb_break(&ChainId::Sui, error, event.nonce, tx_hash);
                        }
                        return Err(SuiConnectorError::SuiCallback(err));
                    }
                }
                Ok(())
            }
            Err(error) => {
                log::error!("RPC connectivity break: {error:?}");
                Metrics::rpc_break(&ChainId::Sui, error.to_string(), event.nonce, "");
                Err(SuiConnectorError::SuiCallback(error.to_string()))
            }
        }
    }

    pub async fn add_public_key(
        &self,
        config: &SuiConfig,
        committee_data: CommitteeData,
    ) -> Result<(), SuiConnectorError> {
        let package_object_id = ObjectID::from_hex_literal(&config.sc_address)?;

        let pubkey_bls12381_g2 = committee_data.committee_pubkey.bls12381.pub_key_g2;
        let new_pubkey = convert_97bg2_96bg2(pubkey_bls12381_g2);

        let signer = self.key_store.addresses()[0];

        let tx_data = self
            .client
            .transaction_builder()
            .move_call(
                signer,
                package_object_id,
                "SupraContract",
                "add_dkg_public_key",
                vec![],
                vec![
                    // SuiJsonValue::from_str(&config.dkg_resource_id)?,
                    SuiJsonValue::from_bcs_bytes(None, &new_pubkey)?,
                ],
                None,
                30000000,
            )
            .await?;

        let signature = self
            .key_store
            .sign_secure(&signer, &tx_data, Intent::sui_transaction())?;

        let response = self
            .client
            .quorum_driver_api()
            .execute_transaction_block(
                Transaction::from_data(tx_data, Intent::sui_transaction(), vec![signature])
                    .verify()?,
                SuiTransactionBlockResponseOptions::default(),
                Some(ExecuteTransactionRequestType::WaitForLocalExecution),
            )
            .await?;
        info!("add_public_key response: {:?}", response);
        Ok(())
    }
}
