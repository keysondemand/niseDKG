//! Error types for the Sui Connector
use connectors::{recovery_point::RecoveryPointError, StreamError};
use thiserror::Error;

/// Errors encountered during VRF Request handling
#[allow(missing_docs)]
#[derive(Error, Debug)]
pub enum SuiConnectorError {
    #[error("Wss connection lost due")]
    WssConnectionLost,

    #[error("Http connection lost")]
    HttpConnectionLost,

    #[error("Failed to initialize recovery point: {0}")]
    RecoveryPoint(#[from] RecoveryPointError),

    #[error("failed to serialize nonce {0:?} into Uint [u64;4]")]
    NonceDeSerialization(String),

    #[error("Unable to parse Sui Event: {0}")]
    SuiEventParse(String),

    #[error("Error with failed anyhow err :{0}")]
    Anyhow(#[from] anyhow::Error),

    #[error("Error while parsing to int: {0}")]
    ParseInt(#[from] std::num::ParseIntError),

    #[error("Error during patse Sui Object Id {0}")]
    SuiObjectIDParse(#[from] sui_types::base_types::ObjectIDParseError),

    #[error("Error with signature err :{0}")]
    Signature(#[from] signature::Error),

    #[error("Error with Sui types err :{0}")]
    Sui(#[from] sui_types::error::SuiError),

    #[error("Error with Sui Key Pair from_str err:{0}")]
    SuiKeyPair(String),

    #[error("Error with Sui sdk err:{0}")]
    SuiSdk(#[from] sui_sdk::error::Error),

    #[error("Error with Sui callback  err:{0}")]
    SuiCallback(String),
}

impl StreamError for SuiConnectorError {
    fn is_wss_error(&self) -> bool {
        matches!(self, SuiConnectorError::WssConnectionLost)
    }
}
