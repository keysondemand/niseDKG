# Testing the sui connector in the free node (Local environment)

## Install the SUI CLI in your machine
```
cargo install --locked --git https://github.com/MystenLabs/sui.git --branch devnet sui
```
for more installation steps: https://docs.sui.io/devnet/build/install#install-sui-binaries

## Sui Wallet Address

Run this command to check your current wallet address (and copy this address)

```
sui client active-address
```

Then replace **supraAddress** address in [smart-contracts/sui/Move.toml](../../../smart-contracts/sui/Move.toml) file, with the address copied above.

## Sui CLI environment

check current environment of sui

```
sui client active-env
```

Create `localnet` environment 

```
sui client new-env --alias localnet --rpc http://127.0.0.1:9000
```

If it's not `loclnet` then switch to `localnet`

```
sui client switch --env localnet
```

Then start sui node

```
sui genesis -force
sui start
```

Go to [smart-contract/sui](../../../smart-contracts/sui) directory and deploy the smart contract as below command

```
sui client publish --gas-budget 1000
```

## Setup Sui Free-node config.toml

In config.toml add:

```
[sui.sui]
sc_client_url = "http://127.0.0.1:9000"
sc_wss_url = "ws://127.0.0.1:9000"
sc_address = ""
chain_secret_key_hex = ""
dkg_resource_id = ""
```

`sc_address` - when you deploy SUI vrf SC, you will get Immutable object address, use this object address
`chain_secret_key_hex` - take from here: `/home/{user}/.sui/sui_config`
`dkg_resource_id` - initially it's empty

## How to get dkg_resource_id?

Check free-node .env file as below and start vrf-node in your local system

```
VRF_ENDPOINT=127.0.0.1:26000
BACKUP_VRF_ENDPOINT=127.0.0.1:4545
```

Run binary add-pubkey-sui and you will get the transaction_digest
search this transaction here https://explorer.sui.io/?network=local, and then you get new created Object.
copy this object address and replace dkg_resource_id

After configure all the Free-node config.toml, Start sui free-node with `features --sui`

## Next we need to deploy Example/gaming smart contract to test the SUI VR

Go to [sdk/sui/vrf-framework/Move.toml](../../../sdk/sui/vrf-framework/Move.toml) directory and replace supra address with SUI VRF deployed SC address

Go to [sdk/sui/teen-patti-example](../../../sdk/sui/teen-patti-example) and deploy this SC 
```
sui client publish --gas-budget 1000
```

Once successfully deploy the SC call
```
sui client call --package {package_id} --module ExampleContract --function rng_request --gas-budget 9000 --args {object_id} {package_id} {supra_config_obj} {u8:rng_count} {u64:client_seed}
```

`package_id` - Teen-patti deployed smart contract address
`object_id` - Teen-patti's shared object address
`supra_config_obj` - supra config object address
