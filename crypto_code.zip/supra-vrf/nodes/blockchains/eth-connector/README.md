# eth-connector

## Testing Recoverable Errors

When calling the supra generator contract, there are certain errors that we can recover from. To test if they work as intended for a specific chain,

```shell
ERR_TEST_RPC=<rpc url> ERR_TEST_PRIVATE_KEY=<private key>  cargo test --package eth-connector --lib -- callback::error_test --show-output --test-threads=1
```

### Environment

note that a .env file is also supported

- `ERR_TEST_RPC`: HTTP Rpc endpoint for the chain to test
- `ERR_TEST_PRIVATE_KEY`: Private Key to test with. Only a small amount of funds are used
- `ERR_TEST_RATE_LIMIT`: can be set to `true` to enable rate limit testing. its recommended to remove `--test-threads=1` when testing rate limit and using `callback::error_test::test_rate_limit_against_rpc` directly

### Failures

The tests might fail due to the following reasons:

1. Recoverable Error implementation needs amendment - If the implementation doesn't cover an error, or the chain uses a different error, the implementation needs to be amended  
2. Rate Limit Test might fail if `ERR_TEST_RATE_LIMIT` is set on an rpc which doesn't have rate limit, or the test is not aggressive enough
3. `test_max_fee_lt_block_base_fee` if `send_transaction` returns a hash even though the transaction doesn't get included (as confirmed by the receipt being `None`). this is weird behaviour & should be investigated further