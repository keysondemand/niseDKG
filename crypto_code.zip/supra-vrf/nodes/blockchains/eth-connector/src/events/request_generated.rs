use crate::event_meta_data::EventMetadata;
use crate::events::{EthEvent, EventParseError};
use crate::request::get_keccak_256_hash;
use common::chains::ChainId;
use common::VrfRequest;
use connectors::RequestEvent;
use primitive_types::{H160, H256, U256};
use std::any::type_name;
use std::fmt;
use std::fmt::{Display, Formatter};
use std::time::Instant;
use web3::ethabi::{Bytes, Event, EventParam, Hash, LogParam, ParamType, RawLog, Token, Uint};
use web3::types::{Log, U64};

/// Corresponds to event `RequestGenerated` defined in SupraGeneratorContract
/// enriched with some useful metadata.
#[derive(Debug, Clone)]
pub struct EthRequestEvent {
    pub(crate) nonce: Token,
    #[allow(unused)]
    pub(crate) instance_id: Token,
    pub(crate) caller_contract: Token,
    pub(crate) function_name: Token,
    pub(crate) rng_count: Token,
    pub(crate) num_confirmations: U256,
    pub(crate) client_seed: Token,
    pub(crate) client_wallet_address: Token,

    // Meta data.
    pub(crate) block_number: U64,
    pub(crate) message: Bytes,
    pub(crate) block_hash: H256,
    pub(crate) tx_hash: H256,
    pub(crate) chain_id: ChainId,
    pub(crate) reception_time: Instant,
}

impl EthRequestEvent {
    /// Eth structure of this event.
    fn structure() -> Event {
        Event {
            name: "RequestGenerated".to_string(),
            inputs: vec![
                EventParam {
                    name: "nonce".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "instanceId".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "callerContract".to_string(),
                    kind: ParamType::Address,
                    indexed: false,
                },
                EventParam {
                    name: "functionName".to_string(),
                    kind: ParamType::String,
                    indexed: false,
                },
                EventParam {
                    name: "rngCount".to_string(),
                    kind: ParamType::Uint(8),
                    indexed: false,
                },
                EventParam {
                    name: "numConfirmations".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "clientSeed".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "clientWalletAddress".to_string(),
                    kind: ParamType::Address,
                    indexed: false,
                },
            ],
            anonymous: false,
        }
    }

    /// Performs a conversion of number of confirmations to u64.
    /// This is fine because the block number can only be as large as u64,
    /// however, supra generator contract lists num_confirmations as U256.
    pub fn num_confirmations(&self) -> u64 {
        self.num_confirmations.as_u64()
    }
}

impl EthEvent<Log> for EthRequestEvent {
    fn signature() -> Hash {
        Self::structure().signature()
    }

    fn try_from(log: &Log, chain_id: &ChainId) -> Result<Self, EventParseError> {
        let tx_hash = log.transaction_hash.ok_or(EventParseError::AbsentData {
            log: Box::new(log.clone()),
            missing_data: "transaction hash".to_string(),
        })?;

        let block_hash = log.block_hash.ok_or(EventParseError::AbsentData {
            log: Box::new(log.clone()),
            missing_data: "block hash".to_string(),
        })?;

        let block_number = log.block_number.ok_or(EventParseError::AbsentData {
            log: Box::new(log.clone()),
            missing_data: "block number".to_string(),
        })?;

        let [nonce, instance_id, caller_contract, function_name, rng_count, num_confirmations, client_seed, client_wallet_address]: [LogParam;
            8] = Self::structure().parse_log(RawLog {
            topics: vec![Self::signature()],
            data: log.data.0.clone(),
        })?.params.try_into().map_err(|_| EventParseError::UnexpectedStructure {
            event_name: type_name::<Self>().to_string(),
            log: Box::new(log.clone()),
        })?;

        let message = get_keccak_256_hash(
            &block_hash,
            &nonce.value,
            &rng_count.value,
            &instance_id.value,
            &caller_contract.value,
            &function_name.value,
            &client_seed.value,
        );
        Ok(EthRequestEvent {
            nonce: nonce.value,
            instance_id: instance_id.value,
            caller_contract: caller_contract.value,
            function_name: function_name.value,
            rng_count: rng_count.value,
            num_confirmations: num_confirmations
                .value
                .into_uint()
                .unwrap_or_else(|| Uint::from(1)),
            client_seed: client_seed.value,
            client_wallet_address: client_wallet_address.value,

            // Meta data.
            block_number,
            message,
            block_hash,
            tx_hash,
            chain_id: *chain_id,
            reception_time: Instant::now(),
        })
    }
}

impl RequestEvent for EthRequestEvent {
    type CallerIdentifier = H160;
    type Error = EventParseError;

    fn to_vrf_request(&self) -> Result<Option<VrfRequest>, Self::Error> {
        Ok(Some(VrfRequest {
            message: self.message.clone(),
            chain_id: self.chain_id,
            block_hash: self.block_hash.0.to_vec(),
            nonce: self
                .nonce
                .clone()
                .into_uint()
                .ok_or_else(|| EventParseError::ConversionError {
                    from: self.nonce.clone(),
                    to: "Uint".to_string(),
                })?
                .0,
            txhash: self.tx_hash.0.to_vec(),
        }))
    }

    fn get_tx_hash(&self) -> String {
        self.tx_hash.to_string()
    }

    fn short_log(&self) -> String {
        format!("nonce: {}, message: {:?}", self.nonce, self.message)
    }

    fn get_vrf_nonce(&self) -> u64 {
        self.nonce
            .clone()
            .into_uint()
            .expect("Nonce is an uint")
            .as_u64()
    }

    fn get_reception_time(&self) -> Instant {
        self.reception_time
    }

    fn get_caller(&self) -> Self::CallerIdentifier {
        self.caller_contract
            .clone()
            .into_address()
            .expect("Caller Contract is address")
    }
}

impl Display for EthRequestEvent {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result<(), fmt::Error> {
        let EthRequestEvent {
            block_number,
            nonce,
            num_confirmations,
            ..
        } = self;

        write!(f, "event originated from block number {block_number}, nonce: {nonce}, num_confirmation: {num_confirmations}")
    }
}

#[derive(Debug, Clone)]
/// An [EthRequestEvent] bundled with the raw source event.
pub struct EthStreamEvent {
    pub(crate) decoded: EthRequestEvent,
    pub(crate) raw: Log,
}

impl EthStreamEvent {
    /// Eth structure of this event.
    fn structure() -> Event {
        EthRequestEvent::structure()
    }
}

impl EthEvent<Log> for EthStreamEvent {
    fn signature() -> Hash {
        Self::structure().signature()
    }

    fn try_from(log: &Log, chain_id: &ChainId) -> Result<Self, EventParseError> {
        <EthRequestEvent as EthEvent<_>>::try_from(log, chain_id).map(|decoded| Self {
            decoded,
            raw: log.clone(),
        })
    }
}

impl From<&EthStreamEvent> for EventMetadata {
    fn from(event: &EthStreamEvent) -> Self {
        Self {
            block_number: event.raw.block_number.map(|n| n.as_u64()),
            block_hash: event.raw.block_hash,
            tx_hash: event.raw.transaction_hash,
            tx_event_index: event.raw.transaction_log_index,
            topics: event.raw.topics.clone(),
        }
    }
}
