use common::chains::ChainId;
use thiserror::Error;
use web3::ethabi::{Hash, Token};
use web3::types::Log;

mod nonce_processed;
pub use nonce_processed::NonceProcessed;

mod request_generated;
pub use request_generated::{EthRequestEvent, EthStreamEvent};

/// This trait defines properties of an event that allow  searching for this kind of event on the blockchain,
/// and a method converting raw logs to appropriate structures.
pub trait EthEvent<T> {
    /// Signature of an event allowing searching this kind of events.
    fn signature() -> Hash;

    /// Conversion from raw logs to this kind of events.
    fn try_from(log: &T, chain_id: &ChainId) -> Result<Self, EventParseError>
    where
        Self: Sized;
}

#[derive(Debug, Error)]
pub enum EventParseError {
    #[error("Event `{event_name}` cannot be parsed from {log:?}")]
    UnexpectedStructure { event_name: String, log: Box<Log> },

    #[error("Failed to convert `{from:?}` to `{to}`")]
    ConversionError { from: Token, to: String },

    #[error("Log `{log:?}` is missing {missing_data}")]
    AbsentData { log: Box<Log>, missing_data: String },

    #[error(transparent)]
    EthAbiError(#[from] web3::ethabi::Error),
}
