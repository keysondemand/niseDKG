use crate::events::{EthEvent, EventParseError};
use common::chains::ChainId;
use std::any::type_name;
use web3::ethabi::{Event, EventParam, Hash, LogParam, ParamType, RawLog};
use web3::types::{Address, Log, U256};

/// Corresponds to event `NonceProcessed` defined in SupraGeneratorContract.
#[derive(Debug, Clone)]
#[allow(unused)]
pub struct NonceProcessed {
    pub(crate) nonce: U256,
    pub(crate) address: Address,
    pub(crate) timestamp: U256,
}

impl NonceProcessed {
    /// Eth structure of this event.
    fn structure() -> Event {
        Event {
            name: "NonceProcessed".to_string(),
            inputs: vec![
                EventParam {
                    name: "nonce".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "clientWalletAddress".to_string(),
                    kind: ParamType::Address,
                    indexed: false,
                },
                EventParam {
                    name: "timestamp".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
            ],
            anonymous: false,
        }
    }
}

impl EthEvent<Log> for NonceProcessed {
    fn signature() -> Hash {
        Self::structure().signature()
    }

    fn try_from(log: &Log, _chain_id: &ChainId) -> Result<Self, EventParseError> {
        let [nonce, address, timestamp]: [LogParam; 3] = Self::structure()
            .parse_log(RawLog {
                topics: vec![Self::signature()],
                data: log.data.0.clone(),
            })?
            .params
            .try_into()
            .map_err(|_| EventParseError::UnexpectedStructure {
                event_name: type_name::<Self>().to_string(),
                log: Box::new(log.clone()),
            })?;

        Ok(Self {
            nonce: nonce
                .value
                .clone()
                .into_uint()
                .ok_or(EventParseError::ConversionError {
                    from: nonce.value,
                    to: "Uint".to_string(),
                })?,
            address: address.value.clone().into_address().ok_or(
                EventParseError::ConversionError {
                    from: address.value,
                    to: "Address".to_string(),
                },
            )?,
            timestamp: timestamp.value.clone().into_uint().ok_or(
                EventParseError::ConversionError {
                    from: timestamp.value,
                    to: "Uint".to_string(),
                },
            )?,
        })
    }
}
