use std::collections::BTreeMap;

/// This is a wrapper around a queue that stores a value and
/// allows fetching them later with respect to some Epoch
#[derive(Default)]
pub struct DeferredStore<Epc, T> {
    backing: BTreeMap<Epc, Vec<T>>,
}

impl<Epc, T> DeferredStore<Epc, T> {
    pub fn new() -> Self {
        Self {
            backing: BTreeMap::new(),
        }
    }
}

impl<Epc: Ord + Copy, T> DeferredStore<Epc, T> {
    /// Store a value that will be taken at a future epoch
    pub fn defer(&mut self, epoch: Epc, value: T) {
        self.backing
            .entry(epoch)
            .or_insert_with(std::vec::Vec::new)
            .push(value);
    }

    /// Consum all values till a certain epoch
    /// No guarantees are made about the order of the values
    pub fn drain_till(&mut self, till_epoch: Epc) -> impl Iterator<Item = T> + '_ {
        DeferredDrain {
            inner: &mut self.backing,
            max_epoch: till_epoch,
            cur_iter: None,
        }
    }
}

struct DeferredDrain<'a, Epc, T> {
    inner: &'a mut BTreeMap<Epc, Vec<T>>,
    max_epoch: Epc,
    cur_iter: Option<Vec<T>>,
}

impl<Epc: Ord + Copy, T> Iterator for DeferredDrain<'_, Epc, T> {
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        if let Some(val) = self.cur_iter.as_mut().and_then(|v| v.pop()) {
            return Some(val);
        }

        let (min_epoch, _) = self.inner.first_key_value()?;
        let min_epoch = *min_epoch;
        if min_epoch > self.max_epoch {
            return None;
        }

        let mut cur_iter = self.inner.remove(&min_epoch).unwrap();
        let fv = cur_iter.pop()?;

        self.cur_iter = Some(cur_iter);

        Some(fv)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let Some((min_epoch, _)) = self.inner.first_key_value() else {
            return (0, Some(0));
        };
        let min_epoch = *min_epoch;
        if min_epoch > self.max_epoch {
            return (0, Some(0));
        }

        // minimum 1, calculating maximum is as expensive as collecting the iterator
        (1, None)
    }
}

#[cfg(test)]
mod test {
    use super::DeferredStore;

    #[test]
    fn single_epoch() {
        let mut store = DeferredStore::new();
        store.defer(0, 0);
        store.defer(0, 1);

        let mut drained: Vec<_> = store.drain_till(0).collect();
        drained.sort(); // This is important as the ordering is not guaranteed
        assert_eq!(drained, vec![0, 1]);

        assert!(store.drain_till(0).next().is_none());
    }

    #[test]
    fn multi_epoch() {
        let mut store = DeferredStore::new();
        store.defer(0, 0);
        store.defer(0, 1);
        store.defer(1, 2);
        store.defer(1, 3);

        let mut drained_0 = store.drain_till(0).collect::<Vec<_>>();
        drained_0.sort();
        assert_eq!(drained_0, vec![0, 1]);

        let mut drained_1 = store.drain_till(1).collect::<Vec<_>>();
        drained_1.sort();
        assert_eq!(drained_1, vec![2, 3]);

        assert!(store.drain_till(1).next().is_none());
    }

    #[test]
    fn multi_epoch_combined() {
        let mut store = DeferredStore::new();
        let mut cnt = 0;
        for i in 0..3 {
            for _ in 0..2 {
                store.defer(i, cnt);
                cnt += 1;
            }
        }

        let mut drained = store.drain_till(2).collect::<Vec<_>>();
        drained.sort();
        assert_eq!(drained, (0..cnt).collect::<Vec<_>>());

        assert!(store.drain_till(2).next().is_none());
    }
}
