use std::collections::BTreeSet;
use std::pin::Pin;
use std::sync::Arc;
use std::time::{Duration, Instant};

use async_stream::stream;
use common::{chains::ChainId, influx_metrics::Metrics, with_retries, VrfCallback};
use connectors::{
    recovery_point::{RecoveryPoint, RecoveryPointWriter},
    try_or_continue, try_or_skip, BcConnector, VrfTx,
};

use log::{info, trace};
use secp256k1::SecretKey;

use tokio::sync::mpsc::UnboundedReceiver;
use tokio::task::AbortHandle;
use tokio_stream::{Stream, StreamExt};

use async_trait::async_trait;
use connectors::recovery_point::optimize_block_ranges;
use connectors::RequestEvent;
use web3::types::H256;
use web3::{
    api::Eth,
    contract::Contract,
    transports::Http,
    types::{U256, U64},
};

use crate::data_provider::DataProvider;
use crate::events::EthEvent;
use crate::{
    callback::submit_response_transaction, deferred_store::DeferredStore,
    gas_provider::EthGasProvider, BlockNumber, EthConnectorError, EthRequestEvent,
    MaybeRequestEvent, Nonce, ProcessedNonceCache,
};
use crate::{EthStreamEvent, NonceProcessed, MAX_CONSECUTIVE_EVENT_FROM_HTTP};

/// The Ethereum connector.
pub struct EthConnector<P> {
    pub(crate) data_provider: Arc<P>,
    pub(crate) smart_contract: Contract<Http>,
    pub(crate) deposit_contract: Contract<Http>,
    pub(crate) eth_callback_client: Eth<Http>,
    pub(crate) is_ws_enabled: bool,
    pub(crate) chain_secret_keys: Vec<SecretKey>,
    pub(crate) polling_interval: Duration,
    pub(crate) recovery_point: RecoveryPoint<Nonce, BlockNumber>,
    pub(crate) chain_id: ChainId,
    pub(crate) block_span: u64,
    pub(crate) gas_limit: U256,
    pub(crate) gas_provider: EthGasProvider,
    /// Back-up nodes will not perform event catch-ups.
    pub(crate) is_backup_node: bool,
}

impl<P> EthConnector<P>
where
    P: DataProvider<Block = U64> + Send + Sync + 'static,
    <P as DataProvider>::Error: std::fmt::Display,
    EthConnectorError: From<<P as DataProvider>::Error>,
    EthRequestEvent: EthEvent<<P as DataProvider>::RawEvent>,
    EthStreamEvent: EthEvent<<P as DataProvider>::RawEvent>,
    NonceProcessed: EthEvent<<P as DataProvider>::RawEvent>,
{
    /// Get Raw logs for a given filter.
    /// Consider an adequate value for `block_span`.
    fn get_raw_logs(
        data_provider: Arc<P>,
        block_span: u64,
        mut start_block: u64,
        end_block: u64,
        enable_catchup_logs: bool,
    ) -> impl Stream<Item = Result<EthRequestEvent, EthConnectorError>> + 'static {
        stream! {
            while start_block < end_block {
                // "end_block" number should not less than to_block(start_block_u64 + block_span) number, otherwise it should "to_block = end_block"
                let to_block = if end_block > (start_block + block_span) {
                    start_block + block_span
                } else {
                    end_block
                };

                let logs = with_retries(3, || {
                    data_provider
                    .get_events::<EthRequestEvent>(
                        start_block,
                        Some(to_block),
                    )
                    }).await?;

                for log in logs {
                    yield log.map_err(|err| err.into());
                }
                start_block += block_span + 1;
            }
            // TODO: LOW PRIORITY. blockchain recovery point should be written here as well
            if enable_catchup_logs {
                info!("{} catch up completed", data_provider.chain_id())
            }
        }
    }

    /// Get past VRF Requests
    fn get_past_requests(
        data_provider: Arc<P>,
        block_span: u64,
        start_block: u64,
        end_block: u64,
        enable_catchup_logs: bool,
    ) -> impl Stream<Item = Result<EthRequestEvent, EthConnectorError>> + 'static {
        let inner = Self::get_raw_logs(
            data_provider,
            block_span,
            start_block,
            end_block,
            enable_catchup_logs,
        );

        stream! {
            tokio::pin!(inner);
            while let Some(log) = inner.next().await {
                yield log;
            }
        }
    }

    /// This is just a wrapper over get_past_logs
    /// Waits for N seconds and fetches all the logs that were produced in that interval, in a loop
    /// as a side effect, it will also sync the nonce storage if this is a backup node
    async fn polling_evstream(
        &self,
        event_extra_delay: u64,
    ) -> Result<impl Stream<Item = Result<EthRequestEvent, EthConnectorError>>, EthConnectorError>
    {
        let mut start_block = self.data_provider.block_number().await? + 1;

        let interval = self.polling_interval;
        // source Block Num + num_confirmations => Events
        let mut late_ev = DeferredStore::new();
        let chain_id = self.chain_id;

        let data_provider = self.data_provider.clone();

        Ok(stream! {
            loop {
                tokio::time::sleep(interval).await;

                let cur_block = try_or_skip!(
                    data_provider
                        .block_number()
                        .await
                        .map_err(EthConnectorError::from),
                        yield
                );

                if cur_block <= start_block {
                    continue;
                }


                let catchup_stream: Vec<_> = {
                    let inner = with_retries(3, || { data_provider
                        .get_events::<EthRequestEvent>(
                            start_block,
                            Some(cur_block),
                        )})
                        .await
                        .map_err(EthConnectorError::from);

                    try_or_skip!(inner, yield)
                };

                for ev in catchup_stream.into_iter() {
                    let ev = try_or_skip!(ev.map_err(EthConnectorError::from), yield);
                    trace!("Event received (without confirmation delay) on the http polling stream with nonce: {}", ev.nonce);
                    late_ev.defer(ev.block_number.as_u64() + ev.num_confirmations() + event_extra_delay, ev);
                }

                for ev in late_ev.drain_till(cur_block) {
                    Metrics::pick_event_log(
                        &chain_id,
                        ev.nonce.clone(),
                        ev.caller_contract.to_string(),
                        "http"
                    );
                    yield Ok(ev);
                }

                start_block = cur_block;
            }
        })
    }

    /// The websocket stream for eth chains by default is not robust
    /// it can push unconfirmed events (i.e events that have been included in a block but that block isn't confirmed yet)
    /// in this case we re-fetch the event as the data in it can be stale(due to it depending upon block hash)
    ///
    /// We also try to mitigate block chain re-organizations
    ///
    /// This robust stream roughly works this way:
    ///
    /// 1. If the base stream pushes an unconfirmed event we pause the stream and wait for its block to be confirmed
    /// 2. The stream defers the event after a single confirmation to a queue
    /// 3. This queue is used to then yield it after N confirmations (depending on the event's num_confirmation parameter)
    async fn robust_ws_stream(
        data_provider: Arc<P>,
        chain_id: ChainId,
        event_extra_delay: u64,
    ) -> Result<AbortOnDrop<Result<EthRequestEvent, EthConnectorError>>, EthConnectorError> {
        let (sender, receiver) = tokio::sync::mpsc::unbounded_channel();

        let mut block_sub = with_retries(3, || data_provider.get_block_stream()).await?;

        let mut ev_sub_own =
            with_retries(3, || data_provider.get_event_stream::<EthStreamEvent>()).await?;

        let handle = tokio::spawn(async move {
            // source Block Num + num_confirmations => Events
            let mut late_ev = DeferredStore::new();

            let mut last_block_received_time = Instant::now();

            loop {
                tokio::select! {
                    Some(ev) = ev_sub_own.next() => {
                        // Help the IDE a little. Likely has no effect on the compiler output.
                        let ev: Result<EthStreamEvent, EthConnectorError>  = ev
                            .map_err(|err| err.into());

                        let ev = try_or_continue!(ev, sender);

                        let defer_until = ev.decoded.block_number + ev.decoded.num_confirmations() + event_extra_delay;
                        late_ev.defer(defer_until, ev);
                    },
                    Some(block) = block_sub.next() => {
                        // Help the IDE a little. Likely has no effect on the compiler output.
                        let block: Result<Option<U64>, EthConnectorError>  = block.map_err(|err| err.into());

                        let block = try_or_continue!(block, sender);
                        let Some(block_num) = block else {
                            // TODO: if the confirmed block is never published we'll have to start polling
                            // block number is none for unconfirmed block. We eventually do need the confirmed block
                            continue; // Unconfirmed block, we dont care
                        };

                        let block_received_time = Instant::now();

                        let time_between_block_secs = block_received_time.duration_since(last_block_received_time).as_secs();

                        last_block_received_time = block_received_time;

                        info!("Block received from the websocket {block_num}. Time elapsed since previous block: {time_between_block_secs}");

                        for ev in late_ev.drain_till(block_num) {
                            let sender = sender.clone();
                            let data_provider = data_provider.clone();
                            tokio::spawn( async move {
                                let event_metadata = (&ev).into();
                                match data_provider.confirm_or_fetch::<EthStreamEvent>(ev, event_metadata).await {
                                    Ok(Some(ev)) => {
                                        let ev = ev.decoded;
                                        Metrics::pick_event_log(&chain_id, ev.nonce.clone(), ev.caller_contract.to_string(), "ws");
                                        info!("Sending event with nonce {} to the websocket (delayed) stream. Time spent waiting for confirmation={}", ev.nonce, ev.reception_time.elapsed().as_secs());
                                        let _ = sender.send(Ok(ev));
                                    },
                                    Ok(None) => {
                                        // do nothing
                                    }
                                    Err(err) => {
                                        let _ = sender.send(Err(EthConnectorError::from(err)));
                                    }
                                }
                            });
                        }
                    },
                    else => break
                }
            }
            let _ = sender.send(Err(EthConnectorError::WssConnectionLost));
        });
        Ok(AbortOnDrop {
            abort_handle: handle.abort_handle(),
            recv: receiver,
        })
    }

    /// Extracts logs from a specific transaction hash
    pub async fn get_logs_for_txn(
        &self,
        tx_hash: H256,
    ) -> Result<impl Iterator<Item = EthRequestEvent>, EthConnectorError> {
        Ok(self
            .data_provider
            .get_events_for_transaction::<EthRequestEvent>(&tx_hash)
            .await?
            .into_iter())
    }

    /// Check if a given nonce has already been processed by another free node.
    /// uses a cache to reduce the amount of http calls to the RPC endpoint during catchup
    async fn is_nonce_already_processed_with_cache(
        data_provider: Arc<P>,
        processed_nonce_cache: &mut ProcessedNonceCache,
        nonce: U256,
    ) -> Result<bool, EthConnectorError> {
        // check if the nonce is already in the local cache of known processed nonce
        let nonce_exists = processed_nonce_cache.nonce_processed.contains(&nonce);
        if nonce_exists {
            return Ok(true);
        }

        // if not, fetch all nonce in a block range between last checked block and latest block
        // get the start block number from cache
        let start_block = processed_nonce_cache.last_checked_block;

        let latest_block = data_provider.block_number().await?;

        let mut is_nonce_found = false;

        // check if the nonce processed than it will consider response verification is false
        let logs = with_retries(3, || {
            data_provider.get_events::<NonceProcessed>(start_block.as_u64(), None)
        })
        .await?;

        for log in logs {
            let fetched_nonce = log?.nonce;
            processed_nonce_cache.nonce_processed.insert(fetched_nonce);
            if nonce == fetched_nonce {
                is_nonce_found = true;
            }
        }

        // update start block number
        // here I get the block number in array's first element, cause it always comes in first element
        processed_nonce_cache.last_checked_block = U64::from(latest_block);

        Ok(is_nonce_found)
    }

    /// Checks if an eth request is already processed by another free node with cache
    /// if so, it returns MaybeRequestEvent::EventAlreadyProcessed
    /// else, MaybeRequestEvent::RequestEvent is returned
    async fn check_eth_request_with_cache(
        event: EthRequestEvent,
        data_provider: Arc<P>,
        processed_nonce_cache: &mut ProcessedNonceCache,
    ) -> Result<MaybeRequestEvent, EthConnectorError> {
        let nonce = event
            .nonce
            .clone()
            .into_uint()
            .expect("The nonce must be a unint");
        let nonce_already_processed = Self::is_nonce_already_processed_with_cache(
            data_provider,
            processed_nonce_cache,
            nonce,
        )
        .await?;
        if !nonce_already_processed {
            return Ok(MaybeRequestEvent::RequestEvent(event));
        }

        info!(
            "Skipping event already processed: event {} in block {}",
            &event.nonce, &event.block_number
        );
        Ok(MaybeRequestEvent::EventAlreadyProcessed {
            block_number: event.block_number,
            nonce,
        })
    }
}

#[async_trait]
impl<P> BcConnector for EthConnector<P>
where
    P: DataProvider<Block = U64> + Send + Sync + 'static,
    <P as DataProvider>::Error: std::fmt::Display,
    EthConnectorError: From<<P as DataProvider>::Error>,
    EthRequestEvent: EthEvent<<P as DataProvider>::RawEvent>,
    EthStreamEvent: EthEvent<<P as DataProvider>::RawEvent>,
    NonceProcessed: EthEvent<<P as DataProvider>::RawEvent>,
{
    type RequestEvent = MaybeRequestEvent;
    type Error = EthConnectorError;
    type Nonce = Nonce;
    type BlockNumber = BlockNumber;

    async fn catchup(
        &self,
    ) -> Result<Box<dyn Stream<Item = Result<Self::RequestEvent, Self::Error>> + Send>, Self::Error>
    {
        if self.is_backup_node {
            // The node is running in a backup node, and thus should not perform a catchup.
            return Ok(Box::new(tokio_stream::empty()));
        }

        let chain_id = *self.data_provider.chain_id();

        let mut missed_block_ranges = self.recovery_point.get_recovery_ranges();
        let Some(latest_processed_block_number)= self.recovery_point.get_latest_processed_block() else {
            return Ok(Box::new(tokio_stream::empty()));
        };

        // let eth_http_client = self.eth_http_client.clone();
        let data_provider = self.data_provider.clone();

        // The reason why we send the latest block separately, is because of lifetime considerations
        // To make the last range, we need the current block on the chain,
        // but to do so we need to make an async network call, and if we borrowed the recovery point
        // across the await point, then the future wouldn't be 'static (it would only have
        // the lifetime of the reference).
        let current_block_num = data_provider.block_number().await?;
        info!("current_block_num: {current_block_num:?}");

        missed_block_ranges.push((
            latest_processed_block_number,
            BlockNumber::from(current_block_num),
        ));

        missed_block_ranges = optimize_block_ranges(missed_block_ranges);

        let mut processed_nonce_cache = ProcessedNonceCache {
            nonce_processed: BTreeSet::new(),
            last_checked_block: missed_block_ranges[0].0, // we know that there's at least one element in the missed_block_ranges vector
        };

        let block_span = self.block_span;

        let stream = stream! {
            // we iterate on the missing block ranges, and make a request for each of them,
            // streaming the events sequentially (the all the events from the first range,
            // then all the events from the second one, and so on).
            for (start, end) in missed_block_ranges {
                info!("{chain_id} catching up from {start} to {end}");

                let partial_stream = EthConnector::<P>::get_past_requests(
                    data_provider.clone(),
                    block_span,
                    start.as_u64(),
                    end.as_u64(),
                    true,
                );

                tokio::pin!(partial_stream);

                while let Some(event) =  partial_stream.next().await{
                    let event = try_or_skip!(event, yield);
                    log::info!("Catching up: event {} in block {}", &event.nonce, &event.block_number);
                    Metrics::pick_event_log(&chain_id, event.clone().nonce, event.caller_contract.to_string(), "catchup");

                    yield EthConnector::<P>::check_eth_request_with_cache(event,
                        data_provider.clone(),
                        &mut processed_nonce_cache).await;
                }
            }
        };

        Ok(Box::new(stream))
    }

    async fn start_listening(
        &self,
    ) -> Result<Box<dyn Stream<Item = Result<Self::RequestEvent, Self::Error>> + Send>, Self::Error>
    {
        let chain_id = self.chain_id;

        // we add an arbitrary ten blocks delay to the backup node, to reduce the proability of the backup node processing an event that the leader node already processed.
        let extra_delay = if self.is_backup_node { 15 } else { 0 };

        let polling_stream = self.polling_evstream(extra_delay).await?;

        if !self.is_ws_enabled {
            let fin_stream = stream! {
                tokio::pin!(polling_stream);
                while let Some(ev) = polling_stream.next().await {
                    yield ev.map(MaybeRequestEvent::RequestEvent);
                }
            };
            // we fallback to polling stream if websocket stream is not available
            return Ok(Box::new(fin_stream));
        };

        let ws_stream =
            Self::robust_ws_stream(self.data_provider.clone(), chain_id, extra_delay).await?;

        let data_provider = self.data_provider.clone();

        let fin_stream = stream! {

            tokio::pin!(ws_stream);
            tokio::pin!(polling_stream);

            let mut ev_cache = BTreeSet::new();
            let mut consecutive_event_from_http = 0;

            loop {
                // we count the events that comes from http without having been seen
                // from the websocket channel before. If we see too much of them, we just stop the process
                // and wait for the free node's main loop to restart.
                //
                // for a leader node, we only process the event coming from the websocket channel,
                // and we process all of them.
                tokio::select! {
                    Some(ev) = polling_stream.next() => {
                        // Help the IDE a bit.
                        let ev = try_or_skip!(ev, yield);
                        let ev_id = ev.get_vrf_nonce();

                        // We have seen this event from ws before, so we skip it
                        if ev_cache.remove(&ev_id) {
                            consecutive_event_from_http = 0;
                            continue;
                        }

                        ev_cache.insert(ev_id);
                        consecutive_event_from_http += 1;

                        if consecutive_event_from_http > MAX_CONSECUTIVE_EVENT_FROM_HTTP {
                            log::warn!("{chain_id}: too many consecutive events from http, trying to reconnect to the websocket endpoint");

                            let stream_res = EthConnector::<P>::robust_ws_stream(
                                data_provider.clone(),
                                chain_id,
                                extra_delay
                            ).await;

                            match stream_res {
                                Ok(new_ws_stream) => {
                                    ws_stream.set(new_ws_stream)
                                },
                                Err(err) => {
                                    log::error!("{chain_id}, impossible to reconnect to the websocket endpoint, stopping early");
                                    yield(Err(err));
                                    break;
                                }
                            }

                            consecutive_event_from_http = 0;

                        }
                    },
                    Some(ev) = ws_stream.next() => {
                        let ev = try_or_skip!(ev, yield);
                        let ev_id = ev.get_vrf_nonce();
                        // if this event wasn't observed by http stream, only then we need to add it to the cache
                        if !ev_cache.remove(&ev_id) {
                            ev_cache.insert(ev_id);
                        }
                        yield Ok(MaybeRequestEvent::RequestEvent(ev));
                    },
                    else => {
                        log::warn!("{chain_id}: websocket transport stopped streaming, stopping early");
                        break;
                    }
                };

                // We have a priliminary cache eviction logic where:
                // 1. If websocket stream yields an event before http, http stream will remove it later
                // 2. If http stream yields an event before websocket, websocket stream will remove it later
                // 3. If websocket stream consecutively misses events, we stop the stream (thus ev_cache is discarded)
                // but:
                // 1. If websocket stream misses an event, the event is never evicted
                // 2. If http stream misses an event, the event is never evicted
                // "1" can happen, but "2" should be far more rare
                // If this warning is printed, it is very likely that the websocket stream is misbehaving alot
                if ev_cache.len() > 512 {
                    log::warn!("eth-connector: ev_cache has more than 512 elements! consider adding cache eviction logic");
                }
            }
        };

        Ok(Box::new(fin_stream))
    }

    async fn verify_callback_nonce(
        &mut self,
        _: Self::RequestEvent,
        _: &VrfCallback,
    ) -> Result<bool, Self::Error> {
        unimplemented!()
    }

    async fn send_callback_tx(
        &self,
        concurrency_index: usize,
        callback: Option<VrfTx>,
        event: Self::RequestEvent,
        rpw: RecoveryPointWriter<Nonce, BlockNumber>,
    ) -> Result<(), Self::Error> {
        let block_number = event.get_block_number();
        let nonce = event.get_nonce();

        let MaybeRequestEvent::RequestEvent(event) = event else {
            rpw.add_point(nonce.as_u64(), block_number);
            return Ok(());
        };

        let callback = callback.expect("Empty VRF transaction"); // the vrf transaction can never be none
                                                                 // if the event isn't an already processed one

        // TODO: can BIG::to_string be replaced with BIG::to_bytes?
        let signature: (String, String) = (
            callback.bls_signature.bn254.sig_g1.getx().to_string(),
            callback.bls_signature.bn254.sig_g1.gety().to_string(),
        );

        let nonce = event
            .nonce
            .clone()
            .into_uint()
            .expect("event nonce must be uint")
            .as_u64();
        let block_number = event.block_number;

        // if, for some reason, the nonce as already been processed by this free node, don't call the callback
        // it can happen because during catchup we re-fetch the block surrounding a missing nonce,
        // because the missing nonce could be in the same block as an already processed nonce.
        if self.recovery_point.has_nonce_been_processed(nonce) {
            info!(
                "{}: Nonce {} has allready been processed, skipping",
                self.chain_id, event.nonce
            );
            return Ok(());
        }

        submit_response_transaction(
            event,
            signature.into(),
            &self.smart_contract,
            &self.deposit_contract,
            &self.eth_callback_client,
            &self.chain_secret_keys[concurrency_index],
            &self.gas_provider,
            *self.data_provider.chain_id(),
            self.gas_limit,
        )
        .await?;

        rpw.add_point(nonce, block_number);

        Ok(())
    }

    async fn close_connector(&mut self) {
        // TODO: this should be implemented, right ?
    }

    fn concurrency_limit(&self) -> usize {
        self.chain_secret_keys.len()
    }
}

/// A wrapper on top of AbortHandle, that make sure the handle is aborted when the stream is dropped dropped.
/// This is used to make sure that the robust_ws_stream tasks never keeps running in
/// the background when it should not, even when errors occur
struct AbortOnDrop<T> {
    abort_handle: AbortHandle,
    recv: UnboundedReceiver<T>,
}

impl<T> Stream for AbortOnDrop<T> {
    type Item = T;

    fn poll_next(
        mut self: Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        self.recv.poll_recv(cx)
    }
}

impl<T> Drop for AbortOnDrop<T> {
    fn drop(&mut self) {
        self.abort_handle.abort()
    }
}
