//! Utils for EVM VRF Requests

use crate::{EthEvent, EthRequestEvent, NonceProcessed};
use web3::contract::tokens::Tokenizable;
use web3::ethabi::{encode, Bytes, Token};
use web3::signing::keccak256;
use web3::types::{Address, BlockNumber, Filter, FilterBuilder, H256, U256, U64};

/// Public Key format for EVM Smart Contract
pub type PublicKeyPoint = ((U256, U256), (U256, U256));

/// Catchup Filter for the VRF Request Event & VRF Processed Response Event
// NO usages found.
pub fn get_catchup_filter_with_response(
    sc_address: Address,
    start_block_number: U64,
    end_block_number: U64,
) -> Filter {
    let req_event_id = H256::from(keccak256(EthRequestEvent::signature().as_bytes()));
    let resp_event_id = H256::from(keccak256(NonceProcessed::signature().as_bytes()));
    FilterBuilder::default()
        .address(vec![sc_address])
        .from_block(BlockNumber::Number(start_block_number))
        .to_block(BlockNumber::Number(end_block_number))
        .topics(Some(vec![req_event_id, resp_event_id]), None, None, None)
        .build()
}

/// Keccak256 hash of the VRF Request Event
pub fn get_keccak_256_hash(
    bhash: &H256,
    nonce: &Token,
    rng_count: &Token,
    instance_id: &Token,
    caller_contract: &Token,
    function_name: &Token,
    client_seed: &Token,
) -> Bytes {
    let abi_encoded_message = encode(&[
        bhash.into_token(),
        nonce.clone(),
        rng_count.clone(),
        instance_id.clone(),
        caller_contract.clone(),
        function_name.clone(),
        client_seed.clone(),
    ]);
    Bytes::from(keccak256(abi_encoded_message.as_slice()))
}
