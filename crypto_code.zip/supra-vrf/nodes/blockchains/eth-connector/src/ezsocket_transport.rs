use std::{
    collections::{BTreeMap, HashMap},
    fmt::Debug,
    future::Future,
    sync::{
        atomic::{AtomicUsize, Ordering},
        Arc,
    },
};

use async_trait::async_trait;
use ezsockets::{Client as EzClient, ClientConfig, ClientExt, Error as EzError};
use jsonrpc_core as rpc;
use log;
use tokio::sync::{mpsc, oneshot};
use tokio_stream::wrappers::UnboundedReceiverStream;
use url::Url;
use web3::{
    api::SubscriptionId, error::TransportError, DuplexTransport, RequestId, Result as Web3Res,
    Transport,
};

type ReqResult = Vec<Web3Res<rpc::Value>>;

#[derive(Debug)]
struct Web3MessageHandler {
    event_pubs: BTreeMap<SubscriptionId, mpsc::UnboundedSender<rpc::Value>>,
    req_senders: HashMap<RequestId, oneshot::Sender<Web3Res<ReqResult>>>,
}

impl Web3MessageHandler {
    fn handle_msg(&mut self, msg: &[u8]) {
        if let Ok(notification) = web3::helpers::to_notification_from_slice(msg) {
            if let rpc::Params::Map(params) = notification.params {
                let id = params.get("subscription");
                let result = params.get("result");

                let (id, result) =
                    if let (Some(&rpc::Value::String(ref id)), Some(result)) = (id, result) {
                        (SubscriptionId::from(id.clone()), result)
                    } else {
                        log::warn!("Got unsupported notification {:?}", id);
                        return;
                    };

                let ev_pub = self.event_pubs.get(&id);
                if ev_pub.is_none() {
                    log::warn!("Got notification for unknown sub {:?}", id);
                    return;
                }
                let ev_pub = ev_pub.unwrap();

                if let Err(e) = ev_pub.send(result.clone()) {
                    log::error!("Error sending notification: (id: {:?}) err:{:?}", id, e);
                }
            }
            return;
        }

        let resp = web3::helpers::to_response_from_slice(msg);
        let outputs = match resp {
            Ok(rpc::Response::Single(output)) => vec![output],
            Ok(rpc::Response::Batch(outputs)) => outputs,
            _ => vec![],
        };

        let id = match outputs.get(0) {
            Some(&rpc::Output::Success(ref suc)) => suc.id.clone(),
            Some(&rpc::Output::Failure(ref fail)) => fail.id.clone(),
            None => rpc::Id::Num(0),
        };

        let num = if let rpc::Id::Num(num) = id {
            num
        } else {
            log::warn!("Got unsupported response: id {:?}", id);
            return;
        };

        let Some(req_sender) = self.req_senders.remove(&(num as usize)) else {
            log::warn!("Got response for unknown request id {}", num);
            return;
        };

        if let Err(e) = req_sender.send(web3::helpers::to_results_from_outputs(outputs)) {
            log::warn!("Sending response to dealloc'd channel {:?}", e);
        }
    }
}

#[derive(Debug)]
enum HandlerCall {
    Request {
        id: RequestId,
        sender: oneshot::Sender<Web3Res<ReqResult>>,
    },
    Sub {
        id: SubscriptionId,
        sender: mpsc::UnboundedSender<rpc::Value>,
    },
    UnSub(SubscriptionId),
}

#[async_trait]
impl ClientExt for Web3MessageHandler {
    type Params = HandlerCall;

    async fn text(&mut self, text: String) -> Result<(), EzError> {
        self.handle_msg(text.as_bytes());
        Ok(())
    }

    async fn binary(&mut self, bytes: Vec<u8>) -> Result<(), EzError> {
        self.handle_msg(bytes.as_ref());
        Ok(())
    }

    async fn call(&mut self, param: HandlerCall) -> Result<(), EzError> {
        match param {
            HandlerCall::Request { id, sender } => {
                if self.req_senders.insert(id, sender).is_some() {
                    log::warn!("Replacing existing request with id {}", id);
                }
            }
            HandlerCall::Sub { id, sender } => {
                if self.event_pubs.insert(id.clone(), sender).is_some() {
                    log::warn!("Replacing existing subscription with id {:?}", id)
                }
            }
            HandlerCall::UnSub(id) => {
                if self.event_pubs.remove(&id).is_none() {
                    log::warn!(
                        "Unsubscribing from non-existent subscription with id {:?}",
                        id
                    )
                }
            }
        }

        Ok(())
    }
}

type EzHandle = EzClient<Web3MessageHandler>;

#[derive(Clone, Debug)]
struct EzSocketInner {
    req_ctr: Arc<AtomicUsize>,
    handle: EzHandle,
}

impl EzSocketInner {
    async fn new(url: Url) -> Web3Res<Self> {
        let conf = ClientConfig::new(url);
        let (handle, future) = ezsockets::connect(
            |_| Web3MessageHandler {
                event_pubs: Default::default(),
                req_senders: Default::default(),
            },
            conf,
        )
        .await;
        tokio::spawn(async move {
            if let Err(e) = future.await {
                log::error!("web3: EzSocketListener errored out err:{}", e);
            }
        });

        Ok(Self {
            req_ctr: Arc::new(AtomicUsize::new(1)),
            handle,
        })
    }

    async fn sender(handle: EzHandle, id: RequestId, request: rpc::Request) -> RpcRes {
        let (s, r) = oneshot::channel();
        handle.call(HandlerCall::Request { id, sender: s }).await;

        handle.text(web3::helpers::to_string(&request)).await;

        let Ok(v) = r.await else {
             return Err(transport_err_msg("Unable to send requests, Handler Down"));
        };

        v?.get(0)
            .ok_or_else(|| transport_err_msg("No Response available"))?
            .clone()
    }
}

type RpcRes = Web3Res<rpc::Value>;
type ReqFutGen<F> = fn(EzHandle, RequestId, rpc::Request) -> F;

pub(crate) struct Web3EzSocket<F: Future<Output = RpcRes>> {
    inner: EzSocketInner,
    req_sender: ReqFutGen<F>,
}

#[inline]
fn transport_err_msg(e: &str) -> web3::Error {
    web3::Error::Transport(TransportError::Message(e.into()))
}

pub(crate) async fn web3_ezsocket_new(
    url: Url,
) -> Web3Res<Web3EzSocket<impl Future<Output = RpcRes>>> {
    let inner = EzSocketInner::new(url).await?;
    Ok(Web3EzSocket {
        inner,
        req_sender: EzSocketInner::sender,
    })
}

impl<F: Future<Output = RpcRes>> Debug for Web3EzSocket<F> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.inner.fmt(f)
    }
}

impl<F: Future<Output = RpcRes>> Clone for Web3EzSocket<F> {
    fn clone(&self) -> Self {
        Self {
            inner: self.inner.clone(),
            req_sender: self.req_sender.clone(),
        }
    }
}

impl<F: Future<Output = RpcRes>> Transport for Web3EzSocket<F> {
    type Out = F;

    fn prepare(&self, method: &str, params: Vec<rpc::Value>) -> (RequestId, rpc::Call) {
        let id = self.inner.req_ctr.fetch_add(1, Ordering::AcqRel);
        let req = web3::helpers::build_request(id, method, params);

        (id, req)
    }

    fn send(&self, id: RequestId, request: rpc::Call) -> Self::Out {
        (self.req_sender)(self.inner.handle.clone(), id, rpc::Request::Single(request))
    }
}

impl<F: Future<Output = RpcRes>> DuplexTransport for Web3EzSocket<F> {
    type NotificationStream = UnboundedReceiverStream<rpc::Value>;

    fn subscribe(
        &self,
        id: web3::api::SubscriptionId,
    ) -> web3::error::Result<Self::NotificationStream> {
        let (ev_pub, ev_sub) = mpsc::unbounded_channel();
        let handle = self.inner.handle.clone();

        // Avoiding this would require forking ezsockets!
        tokio::spawn(async move {
            handle.call(HandlerCall::Sub { id, sender: ev_pub }).await;
        });

        Ok(UnboundedReceiverStream::new(ev_sub))
    }

    fn unsubscribe(&self, id: web3::api::SubscriptionId) -> web3::error::Result<()> {
        let handle = self.inner.handle.clone();

        // Avoiding this would require forking ezsockets!
        tokio::spawn(async move {
            handle.call(HandlerCall::UnSub(id)).await;
        });

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    // Based on https://github.com/tomusdrw/rust-web3/blob/master/src/transports/ws.rs#L503
    use super::*;
    use jsonrpc_core as rpc;
    use soketto::handshake;
    use tokio::net::TcpListener;
    use tokio_stream::{wrappers::TcpListenerStream, StreamExt};
    use tokio_util::compat::TokioAsyncReadCompatExt;
    use web3::Transport;

    #[tokio::test]
    async fn should_send_a_request() {
        let _ = env_logger::try_init();
        // given
        let addr = "127.0.0.1:3000";
        let listener = TcpListener::bind(addr).await.expect("Failed to bind");
        println!("Starting the server.");
        tokio::spawn(server(listener, addr));

        let endpoint = Url::parse("ws://127.0.0.1:3000").unwrap();
        let ws = web3_ezsocket_new(endpoint).await.unwrap();

        // when
        let res = ws
            .execute("eth_accounts", vec![rpc::Value::String("1".into())])
            .await
            .unwrap();

        // then
        assert_eq!(res, rpc::Value::String("x".into()));
    }

    async fn server(listener: TcpListener, addr: &str) {
        let mut incoming = TcpListenerStream::new(listener);
        println!("Listening on: {}", addr);
        while let Some(Ok(socket)) = incoming.next().await {
            let mut server = handshake::Server::new(TokioAsyncReadCompatExt::compat(socket));
            let key = {
                let req = server.receive_request().await.unwrap();
                req.key()
            };
            let accept = handshake::server::Response::Accept {
                key,
                protocol: None,
            };
            server.send_response(&accept).await.unwrap();
            let (mut sender, mut receiver) = server.into_builder().finish();
            loop {
                let mut data = Vec::new();
                match receiver.receive_data(&mut data).await {
                    Ok(data_type) if data_type.is_text() => {
                        assert_eq!(
                            std::str::from_utf8(&data),
                            Ok(
                                r#"{"jsonrpc":"2.0","method":"eth_accounts","params":["1"],"id":1}"#
                            )
                        );
                        sender
                            .send_text(r#"{"jsonrpc":"2.0","id":1,"result":"x"}"#)
                            .await
                            .unwrap();
                        sender.flush().await.unwrap();
                    }
                    Err(soketto::connection::Error::Closed) => break,
                    e => panic!("Unexpected data: {:?}", e),
                }
            }
        }
    }
}
