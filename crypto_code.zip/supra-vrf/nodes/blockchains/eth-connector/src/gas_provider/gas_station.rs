//! Gas station gas price provider

use crate::EthConnectorError;
use async_trait::async_trait;
use reqwest::{Client, IntoUrl, Url};
use serde::Deserialize;

use super::{parser::parse_gwei, GasPrice, GasProvider};

pub struct GasStation {
    url: Url,
    client: Client,
}

impl GasStation {
    pub fn new(url: impl IntoUrl) -> Result<Self, EthConnectorError> {
        Ok(Self {
            url: url.into_url()?,
            client: Client::builder().user_agent("Rust").build()?,
        })
    }
}

#[derive(Default, Debug, Clone, PartialEq, Deserialize)]
#[serde(rename_all = "camelCase")]
struct GasStationResp {
    safe_low: GasInfo,
    standard: GasInfo,
    fast: GasInfo,
    estimated_base_fee: f64,
    block_time: i64,
    block_number: i64,
}

#[derive(Default, Debug, Clone, PartialEq, Deserialize)]
#[serde(rename_all = "camelCase")]
struct GasInfo {
    max_priority_fee: f64,
    max_fee: f64,
}

#[async_trait]
impl GasProvider for GasStation {
    async fn gas_price(&self) -> Result<GasPrice, EthConnectorError> {
        let resp: GasStationResp = self
            .client
            .get(self.url.clone())
            .send()
            .await?
            .json()
            .await?;

        let max_priority_fee = resp.fast.max_priority_fee * 1.15;
        let max_fee = resp.estimated_base_fee + max_priority_fee;
        Ok(GasPrice::Eip1559 {
            max_fee: parse_gwei(max_fee),
            max_priority_fee: parse_gwei(max_priority_fee),
        })
    }
}
