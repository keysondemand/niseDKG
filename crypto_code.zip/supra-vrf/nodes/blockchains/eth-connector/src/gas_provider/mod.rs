//! Gas price providers for Eth based chains
mod gas_station;
mod owlracle;
mod parser;

use enum_dispatch::enum_dispatch;
pub use gas_station::*;
pub use owlracle::*;

use crate::EthConnectorError;
use async_trait::async_trait;
use serde_json::Value;
use std::future::Future;
use web3::{
    api::Eth,
    contract::Options,
    transports::Http,
    types::{U256, U64},
    Transport,
};

/// Gas Price
/// either Legacy or Eip1559(London hard fork)
#[derive(Debug, Clone, Copy)]
pub(crate) enum GasPrice {
    Legacy(U256),
    Eip1559 {
        max_priority_fee: U256,
        max_fee: U256,
    },
}

impl GasPrice {
    /// update the max gas price or the gas price(for legacy txn)
    pub fn update_price(&mut self, f: impl FnOnce(U256) -> U256) {
        match self {
            GasPrice::Legacy(price) => *price = f(*price),
            GasPrice::Eip1559 {
                max_fee,
                max_priority_fee,
            } => {
                let base_fee = *max_fee - *max_priority_fee;
                *max_priority_fee = f(*max_priority_fee);
                *max_fee = *max_priority_fee + base_fee;
            }
        }
    }

    /// get the current max gas price or the gas price(for legacy txn)
    pub fn price(&self) -> U256 {
        match self {
            GasPrice::Legacy(price) => *price,
            GasPrice::Eip1559 { max_fee, .. } => *max_fee,
        }
    }

    /// update the web3 options with the current gas price
    pub fn update_options(&self, options: &mut Options) {
        match self {
            GasPrice::Legacy(price) => {
                options.gas_price = Some(*price);
            }
            GasPrice::Eip1559 {
                max_priority_fee,
                max_fee,
            } => {
                options.gas_price = Some(*max_priority_fee);
                options.max_fee_per_gas = Some(*max_fee);
                // 2 is the transaction type for EIP1559
                options.transaction_type = Some(U64::from(2));
            }
        }
    }
}

/// Provider which can fetch the current gas price
#[async_trait]
#[enum_dispatch(EthGasProvider)]
pub(crate) trait GasProvider {
    /// Fetch the current gas price, in wei
    async fn gas_price(&self) -> Result<GasPrice, EthConnectorError>;
}

#[async_trait]
impl<O: Send + Future<Output = web3::Result<Value>>, T: Transport<Out = O> + Sync> GasProvider
    for Eth<T>
{
    async fn gas_price(&self) -> Result<GasPrice, EthConnectorError> {
        Ok(GasPrice::Legacy(self.gas_price().await?))
    }
}

type EthHttp = Eth<Http>;

#[enum_dispatch]
pub(crate) enum EthGasProvider {
    EthHttp,
    GasStation,
    Owlracle,
}
