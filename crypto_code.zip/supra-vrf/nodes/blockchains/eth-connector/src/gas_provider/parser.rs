use web3::types::U256;

pub fn parse_gwei<S>(amount: S) -> U256
where
    S: ToString,
{
    let exponent: u32 = 9;
    let mut amount_str = amount.to_string().replace('_', "");
    let negative = amount_str.chars().next().unwrap_or_default() == '-';
    let dec_len = if let Some(di) = amount_str.find('.') {
        amount_str.remove(di);
        amount_str[di..].len() as u32
    } else {
        0
    };

    if dec_len > exponent {
        // Truncate the decimal part if it is longer than the exponent
        let amount_str = &amount_str[..(amount_str.len() - (dec_len - exponent) as usize)];
        if negative {
            // Edge case: We have removed the entire number and only the negative sign is left.
            //            Return 0 as a I256 given the input was signed.
            if amount_str == "-" {
                U256::zero()
            } else {
                U256::from_dec_str(amount_str).unwrap()
            }
        } else {
            U256::from_dec_str(amount_str).unwrap()
        }
    } else if negative {
        // Edge case: Only a negative sign was given, return 0 as a I256 given the input was signed.
        if amount_str == "-" {
            U256::zero()
        } else {
            let mut n = U256::from_dec_str(&amount_str).unwrap();
            n *= U256::from(10)
                .checked_pow(U256::from(exponent - dec_len))
                .unwrap();
            // .ok_or(InitializationError::ParseOverflow)?;
            n
        }
    } else {
        let mut a_uint = U256::from_dec_str(&amount_str).unwrap();
        a_uint *= U256::from(10)
            .checked_pow(U256::from(exponent - dec_len))
            .unwrap();
        // .ok_or(InitializationError::ParseOverflow)?;
        a_uint
    }
}
