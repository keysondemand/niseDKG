//! Owlracle gas price provider

use std::sync::RwLock;

use async_trait::async_trait;
use governor::{
    clock::DefaultClock,
    middleware::NoOpMiddleware,
    state::{InMemoryState, NotKeyed},
    Quota, RateLimiter,
};
use reqwest::{Client, IntoUrl, Url};
use serde::{Deserialize, Serialize};

use crate::EthConnectorError;

use super::{parser::parse_gwei, GasPrice, GasProvider};

type DirectRateLimit = RateLimiter<NotKeyed, InMemoryState, DefaultClock, NoOpMiddleware>;

struct OwlracleInner {
    url: Url,
    client: Client,
    api_key: ApiKeyQuery,
}

impl OwlracleInner {
    fn new(url: impl IntoUrl, api_key: String) -> Result<Self, EthConnectorError> {
        let url = url.into_url()?;
        let client = Client::new();
        let api_key = ApiKeyQuery { apikey: api_key };
        Ok(Self {
            url,
            client,
            api_key,
        })
    }

    async fn gas_price_fetch(&self) -> Result<GasPrice, EthConnectorError> {
        let resp: GasPriceResp = self
            .client
            .get(self.url.join("gasprice").unwrap())
            .query(&self.api_key)
            .send()
            .await?
            .json()
            .await?;
        // 90% block acceptance rate
        let fast = resp.speeds[2].clone();
        Ok(GasPrice::Eip1559 {
            max_fee: parse_gwei(fast.max_fee_per_gas),
            max_priority_fee: parse_gwei(fast.max_priority_fee_per_gas),
        })
    }
}

pub struct Owlracle {
    inner: OwlracleInner,
    rate_limit: DirectRateLimit,
    cache: RwLock<GasPrice>,
}

impl Owlracle {
    pub async fn new(url: impl IntoUrl, api_key: String) -> Result<Self, EthConnectorError> {
        let inner = OwlracleInner::new(url, api_key)?;

        // owlracle allows 100 requests per hour
        let quota =
            Quota::per_hour(100u32.try_into().unwrap()).allow_burst(2u32.try_into().unwrap());
        let rate_limit = RateLimiter::direct(quota);
        rate_limit.check().unwrap(); // Unwrap Safety: This is the first request

        let gp = inner.gas_price_fetch().await?;

        Ok(Self {
            inner,
            rate_limit,
            cache: RwLock::new(gp),
        })
    }
}

#[async_trait]
impl GasProvider for Owlracle {
    async fn gas_price(&self) -> Result<GasPrice, EthConnectorError> {
        if self.rate_limit.check().is_err() {
            // return the last known gas price
            return Ok(*self.cache.read().unwrap());
        }

        let gp = self.inner.gas_price_fetch().await?;
        *self.cache.write().unwrap() = gp;
        Ok(gp)
    }
}

#[derive(Default, Debug, Clone, PartialEq, Serialize)]
struct ApiKeyQuery {
    apikey: String,
}

#[derive(Default, Debug, Clone, PartialEq, Deserialize)]
#[serde(rename_all = "camelCase")]
struct GasPriceResp {
    timestamp: String,
    last_block: i64,
    avg_time: f64,
    avg_tx: f64,
    avg_gas: f64,
    speeds: Vec<Speed>,
}

#[derive(Default, Debug, Clone, PartialEq, Deserialize)]
#[serde(rename_all = "camelCase")]
struct Speed {
    acceptance: f64,
    max_fee_per_gas: f64,
    max_priority_fee_per_gas: f64,
    base_fee: f64,
    estimated_fee: f64,
}
