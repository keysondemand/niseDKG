//! Error types for the Ethereum connector.
use crate::{callback, events};
use connectors::{recovery_point::RecoveryPointError, StreamError};
use thiserror::Error;
use web3::ethabi::Token;

/// Error during VRF Handling
#[allow(missing_docs)]
#[derive(Error, Debug)]
pub enum EthConnectorError {
    #[error("Not found in log: {0}")]
    NotFoundInLog(&'static str),

    #[error(transparent)]
    LogParsing(#[from] web3::ethabi::Error),

    // these errors are often network related, and they may be worth retrying the request
    #[error("Web3 client error: {0}")]
    Web3Transport(#[from] web3::Error),

    #[error("Web3 wss connection lost due")]
    WssConnectionLost,

    #[error("failed to serialize nonce {0:?} into Uint [u64;4]")]
    NonceDeSerialization(Token),

    #[error("Failed to initialize recovery point: {0}")]
    RecoveryPoint(#[from] RecoveryPointError),

    #[error("Http Client Error: {0}")]
    Reqwest(#[from] reqwest::Error),

    #[error(transparent)]
    CallbackTxError(#[from] callback::error::CallbackTxError),

    #[error("Data provider failed: {0}")]
    DataProviderError(String),

    #[error(transparent)]
    EventParseError(#[from] events::EventParseError),
}

impl StreamError for EthConnectorError {
    fn is_wss_error(&self) -> bool {
        matches!(self, EthConnectorError::WssConnectionLost)
    }
}
