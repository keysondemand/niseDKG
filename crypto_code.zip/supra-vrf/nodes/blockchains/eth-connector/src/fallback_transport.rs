use std::time::Duration;

use tokio::time::timeout;
use web3::{transports::Http, Transport};

/// Http Transport for Web3 that uses a fallback transport if the primary transport errors or times out.
#[derive(Debug, Clone)]
pub(crate) struct HttpWithFallback {
    http: Http,
    fallback: Http,
    timeout: Duration,
}

impl HttpWithFallback {
    /// Create a new Http transport with fallback
    pub fn new(rpc: &str, fallback: &str, timeout: Duration) -> web3::Result<Self> {
        Ok(Self {
            http: Http::new(rpc)?,
            fallback: Http::new(fallback)?,
            timeout,
        })
    }
}

impl Transport for HttpWithFallback {
    type Out = <Http as Transport>::Out;

    fn prepare(
        &self,
        method: &str,
        params: Vec<jsonrpc_core::Value>,
    ) -> (web3::RequestId, jsonrpc_core::Call) {
        self.http.prepare(method, params)
    }

    fn send(&self, id: web3::RequestId, request: jsonrpc_core::Call) -> Self::Out {
        let http_fut = self.http.send(id, request.clone());
        let fallback_fut = self.fallback.send(id, request);
        let req_timeout = self.timeout;

        Box::pin(async move {
            let timed_fut = timeout(req_timeout, http_fut);
            match timed_fut.await {
                Err(_) => {
                    log::warn!(
                        "fallback transport: http transport timed out, falling back to backup"
                    );
                    fallback_fut.await
                }
                Ok(Err(e)) => {
                    log::warn!(
                        "fallback transport: http transport err: {e}, falling back to backup"
                    );
                    fallback_fut.await
                }
                Ok(r) => r,
            }
        })
    }
}
