//! Configurations for the evm blockchain connector

use connectors::{recovery_point::RecoveryPointWriter, RecoveryPointError};
use url::Url;
use web3::types::{Address, H160, U64};

use std::collections::HashSet;
use std::error::Error;
use std::str::FromStr;

use std::time::Duration;

use common::chains::ChainId;
use log::info;

use secp256k1::SecretKey;
use web3::Web3;

use web3::transports::Http;

type Nonce = u64;
type BlockNumber = U64;

use async_trait::async_trait;
use connectors::Init;
use serde::{Deserialize, Serialize};
use std::fmt::Debug;
use std::sync::Arc;

use crate::{
    connector::EthConnector,
    gas_provider::{EthGasProvider, GasStation, Owlracle},
    get_contract_instance, EthConnectorError,
};

const fn default_polling_interval() -> u64 {
    10
}
const fn default_block_span() -> u64 {
    10000
}

const fn default_gas_limit() -> u64 {
    18_000_000
}

/// Configuration for gas provider
#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum GasProviderConfig {
    /// Gas station
    GasStation {
        /// Rest API url for gas station
        gas_station_api: String,
    },
    /// Owlracle
    Owlracle {
        /// Rest API url for owlracle
        owlracle_api: String,
        /// API key for owlracle
        api_key: String,
    },
}

/// Configuration for eth connector (for EVM-based chains)
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct EthConfig {
    pub(crate) sc_address: String,
    pub(crate) deposit_sc_address: String,
    pub(crate) sc_client_url: String,
    pub(crate) sc_client_callback_url: Option<String>,
    pub(crate) sc_wss_url: Option<String>,
    #[serde(default = "default_polling_interval")]
    pub(crate) polling_interval_secs: u64,
    #[serde(default = "default_block_span")]
    pub(crate) block_span: u64,
    #[serde(default = "default_gas_limit")]
    pub(crate) gas_limit: u64,
    pub(crate) sc_whitelist: Option<HashSet<String>>,
    #[serde(default)]
    pub(crate) sc_blacklist: HashSet<String>,
    pub(crate) gas_provider: Option<GasProviderConfig>,
    /// State whether the node is a back-up node (true) or primary (false)
    #[serde(default)]
    pub(crate) is_backup_node: bool,
}

/// Secrets Configuration for eth connector
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct EthSecretConfig {
    /// (deprecated) Private Key
    pub chain_secret_key_hex: Option<String>,
    /// List of private keys for the chain
    pub chain_secret_keys_hex: Option<Vec<String>>,
}

use crate::data_provider::{Web3DataProvider, Web3DataProviderError};
use thiserror::Error;

/// Errors encountered during initialization of the Ethereum Connector
#[allow(missing_docs)]
#[derive(Error, Debug)]
pub enum InitializationError {
    #[error("Failure to initialize web3 HTTP client, with error {source}")]
    HttpWeb3Error { source: web3::Error },

    #[error("Invalid Secret Key: {0}")]
    SecretKeyError(#[from] secp256k1::Error),

    #[error("Missing secret key or keys: at least one of fields `chain_secret_keys_hex` or `chain_secret_key_hex` must exist and contain at least one key in the configuration")]
    MissingSecretKeyError,

    #[error("Invalid smart contract address: {0}")]
    SmartContractAddressError(#[from] Box<dyn Error>),

    #[error("Cannot get the smart contract instance, with error: {0}")]
    GetContractInstanceError(#[from] EthConnectorError),

    #[error("Invalid URL, error: {0}")]
    UrlParseError(#[from] url::ParseError),

    #[error(transparent)]
    RecoveryPointError(#[from] RecoveryPointError),

    #[error("Web3 error, cannot get the latest block on chain from the RPC node, with error {0}")]
    GetLatestBlockError(#[from] web3::Error),

    #[error("Failure to initialize web3 data provider, with error {0:?}")]
    Web3DataProvider(#[from] Web3DataProviderError),
}

fn parse_addrs(addrs: &HashSet<String>) -> Result<HashSet<H160>, InitializationError> {
    addrs
        .iter()
        .map(|address| H160::from_str(address))
        .collect::<Result<_, _>>()
        .map_err(|e| InitializationError::SmartContractAddressError(Box::new(e)))
}

impl GasProviderConfig {
    async fn initialize_provider(&self) -> Result<EthGasProvider, EthConnectorError> {
        Ok(match self {
            GasProviderConfig::GasStation {
                gas_station_api: url,
            } => EthGasProvider::from(GasStation::new(url)?),
            Self::Owlracle {
                owlracle_api,
                api_key,
            } => EthGasProvider::from(Owlracle::new(owlracle_api, api_key.clone()).await?),
        })
    }
}

#[async_trait]
impl Init for EthConfig {
    type InitializationError = InitializationError;
    type Connector = EthConnector<Web3DataProvider>;

    /// Perform the initialization of a blockchain connector
    /// Construct a new Ethereum Backup Connector
    async fn initialize_connector(
        &self,
        chain_id: ChainId,
        secrets: Vec<String>,
    ) -> Result<
        (
            RecoveryPointWriter<Nonce, BlockNumber>,
            EthConnector<Web3DataProvider>,
        ),
        InitializationError,
    > {
        let config = self;

        let eth_http_client = Web3::new(
            Http::new(&config.sc_client_url)
                .map_err(|err| InitializationError::HttpWeb3Error { source: err })?,
        )
        .eth();

        let chain_secret_keys = secrets
            .iter()
            .map(|key| SecretKey::from_str(key))
            .collect::<Result<Vec<SecretKey>, secp256k1::Error>>()?;

        // on the following line, we use a type-erased error, because we don't easily have access to the `rustc_hex::FromHexError` error that is returned by the `Address::from_str` function.
        let smart_contract_address =
            Address::from_str(&config.sc_address).map_err(|e| Box::new(e) as Box<dyn Error>)?;
        let smart_contract = get_contract_instance(
            smart_contract_address,
            eth_http_client.clone(),
            "SMART_CONTRACT_ABI_PATH",
        )?;

        let deposit_sc_address = Address::from_str(&config.deposit_sc_address)
            .map_err(|e| Box::new(e) as Box<dyn Error>)?;
        let deposit_contract = get_contract_instance(
            deposit_sc_address,
            eth_http_client.clone(),
            "DEPOSIT_CONTRACT_ABI_PATH",
        )?;
        let eth_wss_url = config
            .sc_wss_url
            .as_ref()
            .map(|s| Url::parse(s))
            .transpose()?;

        let (recovery_point_writer, recovery_point) = RecoveryPointWriter::init(chain_id)?;

        info!("{chain_id}: starting point= {:?}", recovery_point);

        let gas_provider = match config.gas_provider.as_ref() {
            Some(c) => c.initialize_provider().await?,
            None => EthGasProvider::from(eth_http_client.clone()),
        };

        let data_provider = Arc::new(
            Web3DataProvider::new(
                chain_id,
                eth_wss_url.as_ref().map(|url| url.as_ref()),
                &config.sc_client_url,
                &smart_contract_address,
            )
            .await
            .map_err(InitializationError::Web3DataProvider)?,
        );
        let eth_callback_client = config
            .sc_client_callback_url
            .as_ref()
            .map(|url| {
                Ok::<_, InitializationError>(
                    Web3::new(
                        Http::new(url)
                            .map_err(|err| InitializationError::HttpWeb3Error { source: err })?,
                    )
                    .eth(),
                )
            })
            .unwrap_or_else(|| Ok(eth_http_client.clone()))?;

        Ok((
            recovery_point_writer,
            EthConnector {
                data_provider,
                smart_contract,
                deposit_contract,
                eth_callback_client,
                is_ws_enabled: eth_wss_url.is_some(),
                chain_secret_keys,
                polling_interval: Duration::from_secs(config.polling_interval_secs),
                recovery_point,
                block_span: config.block_span,
                chain_id,
                gas_limit: config.gas_limit.into(),
                gas_provider,
                is_backup_node: config.is_backup_node,
            },
        ))
    }

    fn whitelist(&self) -> Option<Result<HashSet<H160>, InitializationError>> {
        self.sc_whitelist.as_ref().map(parse_addrs)
    }

    fn blacklist(&self) -> Result<HashSet<H160>, InitializationError> {
        parse_addrs(&self.sc_blacklist)
    }
}
