use primitive_types::{H256, U256};
use std::fmt::Debug;

#[derive(Debug, Clone)]
pub struct EventMetadata {
    pub block_number: Option<u64>,
    pub block_hash: Option<H256>,
    pub tx_hash: Option<H256>,
    pub tx_event_index: Option<U256>,
    pub topics: Vec<H256>,
}
