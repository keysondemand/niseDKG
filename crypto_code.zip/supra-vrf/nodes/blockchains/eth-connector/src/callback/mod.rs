//! Utils for Sending Vrf Callback & Transaction
pub mod error;
#[cfg(test)]
mod error_test;
use common::chains::ChainId;

use connectors::RequestEvent;

use log::{debug, info, warn};
use secp256k1::SecretKey;
use std::str::FromStr;
use std::time::Duration;
use web3::api::Eth;
use web3::contract::{Contract, Options};

use jsonrpc_core::error::Error as RPCError;
use web3::ethabi::{Event, EventParam, Log as EthAbiLog, LogParam, ParamType, RawLog, Token};
use web3::signing::{Key, SecretKeyRef};
use web3::transports::Http;
use web3::types::BlockNumber::Latest;
use web3::types::{Address, BlockId, BlockNumber, Log, U256};

use crate::gas_provider::GasProvider;
use crate::{EthConnectorError, EthRequestEvent};
use common::with_retries;
use error::{CallbackTxError, RecoverableCallbackError};

/// Identifier of a Event processed by the free node
pub const PROCESSED_EVENT_IDENTIFIER: &[u8] = b"NonceProcessed(uint256,address,uint256)";

impl From<(String, String)> for U256Signature {
    fn from(value: (String, String)) -> Self {
        // The following «expect» are Ok-ish since we always generate the string from BN numbers.
        // We could probably redesign things so that we don't go through String convertion,
        // and avoid the unwrap altogether, but it's probably not worth the hassle
        U256Signature {
            x: U256::from_str(&value.0).expect("cannot cast string to U256"),
            y: U256::from_str(&value.1).expect("cannot cast string to U256"),
        }
    }
}

/// Serialized BLS signature for EVM
pub struct U256Signature {
    /// `x` co-ordinate of the signature
    pub x: U256,
    /// `y` co-ordinate of the signature
    pub y: U256,
}

/// Submits the VRF Transaction to the blockchain
/// Warning: this function consumes gas, which means real money. It should never be retried in case of failure.
/// call_gas_limit is the gas limit for the transaction, but the client balance is deducted based on an estimate
#[allow(clippy::too_many_arguments)]
pub(crate) async fn submit_response_transaction(
    event: EthRequestEvent,
    signature: U256Signature,
    smart_contract: &Contract<Http>,
    deposit_contract: &Contract<Http>,
    eth_http_client: &Eth<Http>,
    chain_secret_key: &SecretKey,
    gas_provider: &impl GasProvider,
    chain_id: ChainId,
    call_gas_limit: U256,
) -> Result<(), CallbackTxError> {
    let pk_ref = SecretKeyRef::new(chain_secret_key);
    let from = pk_ref.address();

    let gas_estimation = retry_gas_limit_unless_transaction_reverted(
        3,
        &event.chain_id,
        smart_contract,
        eth_http_client,
        &event,
        &signature,
        from,
    )
    .await
    .map_err(|err| {
        CallbackTxError::log_and_emit_failed_gas_estimation(chain_id, err.to_string(), &event)
    })?;

    let caller_fund = check_client_deposit_balance(deposit_contract, &event.client_wallet_address)
        .await
        .map_err(|err| {
            CallbackTxError::log_and_emit_failed_check_client_deposit_balance(
                chain_id,
                err.to_string(),
                &event,
            )
        })?;

    let mut options = Options::with(|opt| opt.gas = Some(call_gas_limit.max(gas_estimation)));

    // when the error comes from a gas fee issue, we don't want to wait
    // we want to retry and submit the callback as soon as possible
    // on the other hand, we don't want to end up being stuck in a endless hot loop, so we only retry once
    let mut is_gas_fee_related_retry = false;

    let mut nonce = None;

    info!(
        "{chain_id}: executing callback for event: {}",
        event.short_log()
    );
    debug!("full event: {event:?}");
    // Below is a workaround for nonce collisions till we properly implement a Nonce Manager
    // for evm chains
    // It also handles rate limiting
    loop {
        // we want to be sure that the nonce isn't updated if we're retrying instantly because of a gas fee error
        if !is_gas_fee_related_retry {
            nonce = with_retries(3, || async move {
                get_pending_transaction_count(eth_http_client, chain_secret_key).await
            })
            .await
            .ok(); // That's OK if we don't set nonce in case there's an error here because when
                   // attempting to send the transaction, the library will make the call to get it
                   // anyway the difference being that it will only try to get it from validated
                   // transactions and not pending transactions, which means there's a risk that
                   // the transaction ends up failing because we're trying to reuse a nonce that
                   // is currently used in a pending transaction
        }
        options.nonce = nonce;

        let mut gas_price = match gas_provider.gas_price().await {
            Ok(gas_price) => gas_price,
            Err(err) => {
                log::error!(
                    "{chain_id}: failed to get gas price for callback transaction with response = {err}, falling back to legacy",
                );
                GasProvider::gas_price(eth_http_client)
                    .await
                    .map_err(|err| {
                        CallbackTxError::log_and_emit_failed_gas_estimation(
                            chain_id,
                            err.to_string(),
                            &event,
                        )
                    })?
            }
        };

        // if we've just failed a gas fee error, we want to retry with 1.125² more gas than what the rpc node suggests to be “sure” that it gets included no matter what.
        // the 1.125 comes from how the base fee works since EIP-1559
        if is_gas_fee_related_retry {
            gas_price.update_price(|price| {
                // the gas price is an INTEGER, so we can't just use percentages. 1 + 2/7 is close enough to 1.125² while being slightly superior, so it's doing the job
                let premium = (price / 7) * 2;
                price + premium
            });
        }
        gas_price.update_options(&mut options);

        let tx_fee_wei = gas_estimation * gas_price.price();

        let message = format!("nonce: {} gas_price: {:?}, gas_estimation: {gas_estimation}, tx_fee_wei: {tx_fee_wei}, caller_fund: {caller_fund}", event.nonce, options.gas_price);
        info!("{message}");

        if caller_fund < tx_fee_wei {
            return Err(CallbackTxError::log_and_emit_client_balance_low(
                chain_id, message, &event,
            ));
        }

        let event_copy = event.clone();

        let _nonce = event.nonce.clone();
        let _tx_hash = event.tx_hash;

        match smart_contract
            .signed_call(
                "generateRngCallback",
                (
                    event_copy.nonce,
                    event_copy.block_hash,
                    event_copy.message,
                    [signature.x, signature.y],
                    event_copy.rng_count,
                    event_copy.client_seed,
                    event_copy.caller_contract,
                    event_copy.function_name,
                    event_copy.client_wallet_address,
                    Token::Uint(tx_fee_wei),
                ),
                options.clone(),
                &pk_ref.clone(),
            )
            .await
        {
            Err(e) => {
                let mut rec_err = RecoverableCallbackError::handle_cb_error(e, &event)?;
                if rec_err.is_gas_fee_related_retry && is_gas_fee_related_retry {
                    rec_err.sleep = Duration::from_secs(4);
                    rec_err.is_gas_fee_related_retry = false;
                    rec_err.message = "transaction gas price less than block fee twice in a row"
                }
                is_gas_fee_related_retry = rec_err.is_gas_fee_related_retry;

                warn!(
                    "{chain_id}: {} for nonce, retrying in {} secs",
                    rec_err.message,
                    rec_err.sleep.as_secs()
                );
                tokio::time::sleep(rec_err.sleep).await;
                continue;
            }
            Ok(v) => {
                info!("{chain_id}: IMPORTANT Callback transaction hash {:?}. Event: {event} IMPORTANT, time spent processing the event = {} seconds", v, event.reception_time.elapsed().as_secs());
                break;
            }
        }
    }

    Ok(())
}

// pub async fn get_pending_transaction_count(
//     sc_client_url: &str,
//     sk: SecretKey)
//     -> anyhow::Result<U256> {
//     let http = web3::transports::Http::new(sc_client_url).unwrap();
//     let req: String = hex::encode(&SecretKeyRef::new(&sk).address().to_fixed_bytes());
//     let x: rpc::Value = http.execute("eth_getTransactionCount",
//                              vec![serde_json::Value::String(req.clone()),
//                                   serde_json::Value::String("pending".to_string())]).await.unwrap();
//     match x {
//         rpc::Value::String(a) => {
//             info!("tcount: {:?}",a);
//             Ok(U256::from_str(&a)?)
//         }
//         _ => {
//             anyhow::bail!("did not get a valid response from RPC for eth_getTransactionCount")
//         }
//     }
// }

/// Finds the number of pending transactions for the given account.
pub async fn get_pending_transaction_count(
    eth_http_client: &Eth<Http>,
    sk: &SecretKey,
) -> Result<U256, EthConnectorError> {
    let transaction_count = eth_http_client
        .transaction_count(SecretKeyRef::new(sk).address(), Some(BlockNumber::Pending))
        .await?;
    Ok(transaction_count)
}

/// Extracts nonce from a processed event
pub fn handle_processed_callback(log: Log) -> Result<U256, EthConnectorError> {
    let event = Event {
        name: "NonceProcessed".to_string(),
        inputs: vec![
            EventParam {
                name: "nonce".to_string(),
                kind: ParamType::Uint(256),
                indexed: false,
            },
            EventParam {
                name: "clientWalletAddress".to_string(),
                kind: ParamType::Address,
                indexed: false,
            },
            EventParam {
                name: "timestamp".to_string(),
                kind: ParamType::Uint(256),
                indexed: false,
            },
        ],
        anonymous: false,
    };
    let res: EthAbiLog = event.parse_log(RawLog {
        topics: vec![event.signature()],
        data: log.data.0,
    })?;

    let [nonce, _, _]: [LogParam; 3] = res
        .params
        .try_into()
        .map_err(|_| EthConnectorError::NotFoundInLog("arguments not found in event"))?;

    let nonce_dup = nonce.clone(); // we clone the nonce here to be able to pass it in the error message in case an error occurs
    let nonce = nonce
        .value
        .into_uint()
        .ok_or(EthConnectorError::NonceDeSerialization(nonce_dup.value))?;

    Ok(nonce)
}

/// Scale gas limit based on rng count
/// scaling function is based on quadratic fit for the following data points
/// (0, 1), (150, 1.1), (250, 1.2)
fn scale_gas_limit(rng_cnt: u64, gas_limit: U256) -> U256 {
    let rng_cnt = rng_cnt as f64;
    let scale = 1. + (0.00047 * rng_cnt) + (1.34e-6) * (rng_cnt * rng_cnt);

    // we only care about the first 2 significant digits of scale
    (gas_limit * ((scale * 100.) as u64)) / 100
}

/// Estimate the callback transaction gas
async fn gas_estimation(
    chain: &ChainId,
    smart_contract: &Contract<Http>,
    eth_http_client: &Eth<Http>,
    event: EthRequestEvent,
    signature: &U256Signature,
    from: Address,
) -> web3::contract::Result<U256> {
    let options = match chain {
        ChainId::Arbitrum => {
            let block = eth_http_client.block(BlockId::Number(Latest)).await?;
            let base_fee_per_gas = block.ok_or(web3::Error::Unreachable)?.base_fee_per_gas;
            let max_fee_per_gas = base_fee_per_gas.map(|gas| (gas * 3) / 2); // here 3 / 2 is almost 1.5
            let max_priority_gas_fee_per_gas = base_fee_per_gas.map(|gas| (gas * 5) / 4); // here 5 / 4 is almost 1.25

            Options::with(|op| {
                op.max_fee_per_gas = max_fee_per_gas;
                op.max_priority_fee_per_gas = max_priority_gas_fee_per_gas;
            })
        }
        _ => Options::default(),
    };

    let rng_count = event
        .rng_count
        .clone()
        .into_uint()
        .ok_or("Unable to convert to uint".to_string())?;
    let estimate =
        estimate_gas_limit(smart_contract, event.clone(), signature, from, options).await?;

    Ok(scale_gas_limit(rng_count.as_u64(), estimate))
}

async fn estimate_gas_limit(
    smart_contract: &Contract<Http>,
    event: EthRequestEvent,
    signature: &U256Signature,
    from: Address,
    options: Options,
) -> web3::contract::Result<U256> {
    let tx_fee_wei = Token::Uint(U256::from(0));
    smart_contract
        .estimate_gas(
            "generateRngCallback",
            (
                event.nonce.clone(),
                event.block_hash,
                event.message.clone(),
                [signature.x, signature.y],
                event.rng_count.clone(),
                event.client_seed.clone(),
                event.caller_contract.clone(),
                event.function_name.clone(),
                event.client_wallet_address.clone(),
                tx_fee_wei,
            ),
            from,
            options,
        )
        .await
}

/// Get client Balance before execute
async fn check_client_deposit_balance(
    deposit_contract: &Contract<Http>,
    from: &Token,
) -> web3::contract::Result<U256> {
    let from = from
        .clone()
        .into_address()
        .ok_or_else(|| web3::Error::Decoder("Invalid client wallet Address".to_string()))?;
    deposit_contract
        .query("checkClientFund", from, from, Options::default(), None)
        .await
}

/// this is basically `common::with_retries` but for gas_limit only, and it doesn't retry if the error is “execution reverted: Nonce has already been processed”
async fn retry_gas_limit_unless_transaction_reverted(
    number_of_retries: usize,
    chain: &ChainId,
    smart_contract: &Contract<Http>,
    eth_http_client: &Eth<Http>,
    event: &EthRequestEvent,
    signature: &U256Signature,
    from: Address,
) -> web3::contract::Result<U256> {
    let op = || {
        gas_estimation(
            chain,
            smart_contract,
            eth_http_client,
            event.clone(),
            signature,
            from,
        )
    };

    let retry_time_interval_u64: u64 = 3;
    let retry_time_interval: Duration = Duration::from_secs(retry_time_interval_u64);

    let mut last_error = match op().await {
        Ok(return_value) => return Ok(return_value),
        Err(err) => err,
    };

    for _ in 0..number_of_retries {
        // don't attempt to retry if the error is “execution reverted: Nonce has already been processed”
        if matches!(last_error, web3::contract::Error::Api(web3::Error::Rpc(RPCError { ref message, .. })) if message == "execution reverted: Nonce has already been processed"){
            return Err(last_error);
        }

        warn!(
            "Error {last_error} when trying to get gas estimation, retrying in {retry_time_interval_u64} seconds"
        );
        tokio::time::sleep(retry_time_interval).await;
        match op().await {
            Ok(return_value) => return Ok(return_value),
            Err(err) => last_error = err,
        }
    }

    Err(last_error)
}
