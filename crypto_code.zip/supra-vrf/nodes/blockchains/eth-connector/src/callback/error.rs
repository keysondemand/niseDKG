//! Callback Error handling

use std::time::Duration;

use common::{chains::ChainId, influx_metrics::Metrics};
use jsonrpc_core::{types::error::Error as RPCError, ErrorCode};
use thiserror::Error;
use web3::{error::TransportError, ethabi::Token};

use crate::EthRequestEvent;

/// Error during submission of a callback transaction.
#[allow(missing_docs)]
#[derive(Debug, Error)]
pub enum CallbackTxError {
    #[error(
        r#"{chain_id}: failed to estimate callback transaction with response = {message}
          Skipping the transaction completely"#
    )]
    FailedGasEstimation { chain_id: ChainId, message: String },

    #[error("{chain_id}: Client deposit check error : {message}")]
    FailedCheckClientDepositBalance { chain_id: ChainId, message: String },

    #[error(
        r#"{chain_id}: failed to process the transaction with response = Not enough deposit balance in client wallet : {caller_wallet_address}.
          Skipping the transaction completely"#,
    )]
    ClientBalanceLow {
        chain_id: ChainId,
        message: String,
        caller_wallet_address: Token,
    },

    #[error("{chain_id}: RPC server nonce error -32003 {message} for nonce {nonce}")]
    NonceError {
        chain_id: ChainId,
        message: String,
        nonce: Token,
    },

    #[error("{chain_id}: RPC server out of funds to pay for gas error {server_error_code:?} {message} for nonce {nonce}")]
    OutOfFundsToPayForGas {
        chain_id: ChainId,
        message: String,
        nonce: Token,
        server_error_code: i64,
    },

    #[error(
        r#"{chain_id}:: RPC failed to process the transaction for nonce {nonce}
          with code {server_error_code:?}
          with response = {message}.
          Skipping the transaction completely"#
    )]
    RpcBreak {
        chain_id: ChainId,
        message: String,
        nonce: Token,
        server_error_code: Option<i64>,
    },
}

impl CallbackTxError {
    /// Log the error and produce [Self::FailedGasEstimation].
    pub(crate) fn log_and_emit_failed_gas_estimation(
        chain_id: ChainId,
        message: String,
        event: &EthRequestEvent,
    ) -> Self {
        Metrics::failed_gas_estimation(
            &chain_id,
            message.clone(),
            event.nonce.clone(),
            event.tx_hash,
        );
        Self::FailedGasEstimation { chain_id, message }
    }

    /// Log the error and produce [Self::FailedCheckClientDepositBalance].
    pub(crate) fn log_and_emit_failed_check_client_deposit_balance(
        chain_id: ChainId,
        message: String,
        event: &EthRequestEvent,
    ) -> Self {
        Metrics::failed_check_client_deposit_balance(
            &chain_id,
            message.clone(),
            event.nonce.clone(),
            event.tx_hash,
        );

        Self::FailedCheckClientDepositBalance { chain_id, message }
    }

    /// Log the error and produce [Self::ClientBalanceLow].
    pub(crate) fn log_and_emit_client_balance_low(
        chain_id: ChainId,
        message: String,
        event: &EthRequestEvent,
    ) -> Self {
        Metrics::client_balance_low(
            &chain_id,
            message.clone(),
            event.nonce.clone(),
            event.tx_hash,
        );

        Self::ClientBalanceLow {
            chain_id,
            message,
            caller_wallet_address: event.client_wallet_address.clone(),
        }
    }

    /// Log the error and produce [Self::NonceError].
    pub(crate) fn log_and_emit_nonce_error(
        chain_id: ChainId,
        message: String,
        event: &EthRequestEvent,
    ) -> Self {
        Metrics::nonce_err(
            &chain_id,
            message.clone(),
            event.nonce.clone(),
            event.tx_hash,
        );

        Self::NonceError {
            chain_id,
            message,
            nonce: event.nonce.clone(),
        }
    }

    /// Log the error and produce [Self::OutOfFundsToPayForGas].
    pub(crate) fn log_and_emit_out_of_funds_to_pay_for_gas(
        chain_id: ChainId,
        message: String,
        event: &EthRequestEvent,
        server_error_code: i64,
    ) -> Self {
        Metrics::out_of_gas(
            &chain_id,
            message.clone(),
            event.nonce.clone(),
            event.tx_hash,
        );

        Self::OutOfFundsToPayForGas {
            chain_id,
            message,
            nonce: event.nonce.clone(),
            server_error_code,
        }
    }

    /// Log the error and produce [Self::RpcBreak].
    pub(crate) fn log_and_emit_rpc_break(
        chain_id: ChainId,
        message: String,
        server_error_code: Option<i64>,
        event: &EthRequestEvent,
    ) -> Self {
        Metrics::rpc_break(
            &chain_id,
            message.clone(),
            event.nonce.clone(),
            event.tx_hash,
        );

        Self::RpcBreak {
            chain_id,
            message,
            nonce: event.nonce.clone(),
            server_error_code,
        }
    }

    /// irrecoverable RPC server error with code -3200x
    fn log_and_emit_3200x_error(code: i64, message: String, ev: &EthRequestEvent) -> Self {
        if message.starts_with("nonce") {
            return Self::log_and_emit_nonce_error(ev.chain_id, message, ev);
        }
        if message.starts_with("Insufficient funds for gas") {
            return Self::log_and_emit_out_of_funds_to_pay_for_gas(ev.chain_id, message, ev, code);
        }

        Self::log_and_emit_rpc_break(ev.chain_id, message, Some(code), ev)
    }
}

/// Smart contract call error that can be recovered from.
#[derive(Debug)]
pub(crate) struct RecoverableCallbackError {
    /// Error message.
    pub message: &'static str,
    /// Error is due to gas fees
    pub is_gas_fee_related_retry: bool,
    /// Time to sleep before retrying
    pub sleep: Duration,
}

impl RecoverableCallbackError {
    /// Create a new instance.
    /// default is_gas_fee_related_retry = false
    /// default sleep = 4 seconds
    const fn new(message: &'static str) -> Self {
        Self {
            message,
            is_gas_fee_related_retry: false,
            sleep: Duration::from_secs(4),
        }
    }

    /// set is_gas_fee_related_retry to true
    const fn gas_fee_related_retry(mut self) -> Self {
        self.is_gas_fee_related_retry = true;
        self
    }

    /// set sleep time in seconds
    const fn sleep_secs(mut self, secs: u64) -> Self {
        self.sleep = Duration::from_secs(secs);
        self
    }

    /// RPC Server Error with error code -3200x
    fn log_and_emit_3200x_error(
        code: i64,
        message: String,
        ev: &EthRequestEvent,
    ) -> Result<Self, CallbackTxError> {
        if message == "replacement transaction underpriced"
            || message.starts_with("failed to replace tx for account")
        {
            Metrics::tx_underpriced(&ev.chain_id, message, ev.nonce.clone(), ev.tx_hash);
            return Ok(Self::new("transaction underpriced error"));
        }
        if message.starts_with("max fee per gas less than block base fee") {
            Metrics::out_of_compute(&ev.chain_id, message, ev.nonce.clone(), ev.tx_hash);
            return Ok(
                Self::new("transaction gas price less than block base fee for nonce")
                    .gas_fee_related_retry()
                    .sleep_secs(0),
            );
        }

        Err(CallbackTxError::log_and_emit_3200x_error(code, message, ev))
    }

    fn log_and_emit_rpc_error(
        err: RPCError,
        ev: &EthRequestEvent,
    ) -> Result<Self, CallbackTxError> {
        let RPCError { message, code, .. } = err;
        match code {
            ErrorCode::ServerError(code @ (-32003 | -32000)) => {
                Ok(Self::log_and_emit_3200x_error(code, message, ev)?)
            }
            _ => Err(CallbackTxError::log_and_emit_rpc_break(
                ev.chain_id,
                message,
                None,
                ev,
            )),
        }
    }

    /// Handle a callback error
    /// also log the error in metrics
    /// returns Err(CallbackTxError) if the error is not recoverable
    /// returns Ok(RecoverableCallbackError) if we can recover from the error (note that its still an error!)
    pub fn handle_cb_error(
        err: web3::Error,
        ev: &EthRequestEvent,
    ) -> Result<Self, CallbackTxError> {
        match err {
            web3::Error::Rpc(rpc) => Self::log_and_emit_rpc_error(rpc, ev),
            web3::Error::Transport(TransportError::Code(429)) => {
                Ok(Self::new("rate limited").sleep_secs(5))
            }
            other_error => Err(CallbackTxError::log_and_emit_rpc_break(
                ev.chain_id,
                other_error.to_string(),
                None,
                ev,
            )),
        }
    }
}
