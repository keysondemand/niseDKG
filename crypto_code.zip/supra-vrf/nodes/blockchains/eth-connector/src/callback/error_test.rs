use std::{
    str::FromStr,
    thread,
    time::{Duration, Instant},
};

use common::chains::ChainId;
use serde_json::Value;
use tokio::{sync::mpsc, task::JoinSet};

use crate::EthRequestEvent;
use jsonrpc_core::error::Error as RPCError;
use secp256k1::SecretKey;
use web3::{
    contract::Contract,
    ethabi::Token,
    signing::{Key, SecretKeyRef},
    transports::Http,
    types::{BlockId, BlockNumber, TransactionParameters, H160, H256},
    Web3,
};

use super::error::{CallbackTxError, RecoverableCallbackError};

struct TestSetup {
    rpc: Web3<Http>,
    addr: H160,
    pkey: SecretKey,
    rate_limit_test: bool,
}

impl Drop for TestSetup {
    fn drop(&mut self) {
        // wait for block confirmation after test is complete
        thread::sleep(Duration::from_secs(5));
    }
}

fn mock_event() -> EthRequestEvent {
    EthRequestEvent {
        block_number: 0.into(),
        message: Vec::new(),
        nonce: Token::Int(0.into()),
        caller_contract: Token::Address(H160::zero()),
        instance_id: Token::Int(0.into()),
        function_name: Token::String(String::new()),
        rng_count: Token::Int(1.into()),
        block_hash: H256::zero(),
        tx_hash: H256::zero(),
        client_seed: Token::Uint(0.into()),
        num_confirmations: 1.into(),
        client_wallet_address: Token::Address(H160::zero()),
        chain_id: ChainId::Anvil,
        reception_time: Instant::now(),
    }
}

fn load_setup() -> TestSetup {
    let rpc_s = dotenv::var("ERR_TEST_RPC").unwrap();
    let pkey_s = dotenv::var("ERR_TEST_PRIVATE_KEY").unwrap();
    let test_rate_limit = dotenv::var("ERR_TEST_RATE_LIMIT")
        .map(|s| s == "true")
        .unwrap_or_default();

    let rpc = Web3::new(Http::new(&rpc_s).unwrap());
    let pkey = SecretKey::from_str(&pkey_s).unwrap();
    let pkr = SecretKeyRef::new(&pkey);
    let addr = pkr.address();

    TestSetup {
        rpc,
        addr,
        pkey,
        rate_limit_test: test_rate_limit,
    }
}

/// Test tx underpriced error by first sending a transfer txn with Nonce X & Gas Price G+20000
/// then trying to replace it with another Txn with Nonce X but with Gas Price G
#[tokio::test]
async fn test_tx_underpriced_against_rpc() {
    let setup = load_setup();
    let eth = setup.rpc.eth();
    let nonce = eth.transaction_count(setup.addr, None).await.unwrap();

    let mut transfer_tx = TransactionParameters {
        to: Some(setup.addr),
        nonce: Some(nonce),
        ..Default::default()
    };
    transfer_tx.gas += 20000.into();

    let accounts = setup.rpc.accounts();
    let signed_1 = accounts
        .sign_transaction(transfer_tx.clone(), &setup.pkey)
        .await
        .unwrap();
    transfer_tx.gas -= 20000.into();
    let signed_2 = accounts
        .sign_transaction(transfer_tx.clone(), &setup.pkey)
        .await
        .unwrap();

    eth.send_raw_transaction(signed_1.raw_transaction)
        .await
        .unwrap();
    let err = eth
        .send_raw_transaction(signed_2.raw_transaction)
        .await
        .unwrap_err();
    assert!(RecoverableCallbackError::handle_cb_error(err, &mock_event()).is_ok());
}

/// Test nonce re-use error by first sending a transfer txn with Nonce X & Gas Price G
/// and waiting for its confirmation
/// then sending another Txn with Nonce X but with Gas Price G+20000
#[tokio::test]
async fn test_nonce_reuse_against_rpc() {
    let setup = load_setup();
    let eth = setup.rpc.eth();
    let nonce = eth.transaction_count(setup.addr, None).await.unwrap();

    let mut transfer_tx = TransactionParameters {
        to: Some(setup.addr),
        nonce: Some(nonce),
        ..Default::default()
    };

    let accounts = setup.rpc.accounts();
    let signed_1 = accounts
        .sign_transaction(transfer_tx.clone(), &setup.pkey)
        .await
        .unwrap();
    transfer_tx.gas += 20000.into();
    let signed_2 = accounts
        .sign_transaction(transfer_tx.clone(), &setup.pkey)
        .await
        .unwrap();

    let poll_interval = Duration::from_millis(1200);
    setup
        .rpc
        .send_raw_transaction_with_confirmation(signed_1.raw_transaction, poll_interval, 1)
        .await
        .unwrap();

    let err = eth
        .send_raw_transaction(signed_2.raw_transaction)
        .await
        .unwrap_err();
    let err = RecoverableCallbackError::handle_cb_error(err, &mock_event()).unwrap_err();
    assert!(matches!(err, CallbackTxError::NonceError { .. }));
}

/// Test failure when transaction gas is too low
/// by sending a transfer txn with gas price 1000 (transfer requires 21k gas)
#[tokio::test]
async fn test_gas_too_low() {
    let setup = load_setup();
    let eth = setup.rpc.eth();
    let nonce = eth.transaction_count(setup.addr, None).await.unwrap();

    let transfer_tx = TransactionParameters {
        to: Some(setup.addr),
        nonce: Some(nonce),
        gas: 1000.into(),
        ..Default::default()
    };
    let signed = setup
        .rpc
        .accounts()
        .sign_transaction(transfer_tx, &setup.pkey)
        .await
        .unwrap();

    let err = eth
        .send_raw_transaction(signed.raw_transaction)
        .await
        .unwrap_err();
    let err = RecoverableCallbackError::handle_cb_error(err, &mock_event()).unwrap_err();
    assert!(
        matches!(err, CallbackTxError::RpcBreak { message, .. } if message == "intrinsic gas too low")
    )
}

/// Test failure when wallet can't pay for gas
/// works by generating a random private key
#[tokio::test]
async fn test_out_of_funds() {
    let setup = load_setup();
    let eth = setup.rpc.eth();
    let pkey = SecretKey::new(&mut rand::thread_rng());
    let pkr = SecretKeyRef::new(&pkey);

    let transfer_tx = TransactionParameters {
        to: Some(pkr.address()),
        ..Default::default()
    };
    let signed = setup
        .rpc
        .accounts()
        .sign_transaction(transfer_tx, &pkey)
        .await
        .unwrap();
    let err = eth
        .send_raw_transaction(signed.raw_transaction)
        .await
        .unwrap_err();
    let err = RecoverableCallbackError::handle_cb_error(err, &mock_event()).unwrap_err();
    assert!(matches!(err, CallbackTxError::OutOfFundsToPayForGas { .. }));
}

/// Test gas estimation failure when duplicate nonce is hit
/// using a mock contract
#[tokio::test]
async fn test_duplicate_sc_nonce() {
    let setup = load_setup();
    let chain_id = setup.rpc.eth().chain_id().await.unwrap();

    let contract_json =
        include_str!("../../../../../smart-contracts/eth/out/ErrorTest.sol/ErrorTest.json");
    let contract_json: Value = serde_json::from_str(contract_json).unwrap();
    let abi = serde_json::to_vec(&contract_json["abi"]).unwrap();
    let bytecode = contract_json["bytecode"]["object"].as_str().unwrap();

    let builder = Contract::deploy(setup.rpc.eth(), &abi).unwrap();
    let contract = builder
        .sign_with_key_and_execute(bytecode, (), &setup.pkey, Some(chain_id.as_u64()))
        .await
        .unwrap();

    let err = contract
        .estimate_gas("revertNonceUsed", (), setup.addr, Default::default())
        .await
        .unwrap_err();
    assert!(
        matches!(err, web3::contract::Error::Api(web3::Error::Rpc(RPCError { message, .. })) if message == "execution reverted: Nonce has already been processed")
    );
}

/// Test TX by setting max_fee_per_gas << block_base_fee
/// NOTICE: not supported on chains without EIP-1559
/// NOTICE: this fails on anvil due to unexpected behavior of the node
#[tokio::test]
async fn test_max_fee_lt_block_base_fee() {
    let setup = load_setup();
    let eth = setup.rpc.eth();
    let nonce = eth.transaction_count(setup.addr, None).await.unwrap();

    let block = eth
        .block(BlockId::Number(BlockNumber::Latest))
        .await
        .unwrap()
        .unwrap();
    let Some(base_fee) = block.base_fee_per_gas else {
        eprintln!("EIP-1559 not supported, skipping");
        return;
    };

    let tx = TransactionParameters {
        to: Some(setup.addr),
        nonce: Some(nonce),
        max_fee_per_gas: Some(base_fee / 4),
        transaction_type: Some(2u64.into()),
        ..Default::default()
    };
    let signed = setup
        .rpc
        .accounts()
        .sign_transaction(tx, &setup.pkey)
        .await
        .unwrap();
    let err = match eth.send_raw_transaction(signed.raw_transaction).await {
        Ok(hash) => {
            let receipt = eth.transaction_receipt(hash).await;
            panic!(
                "tx should have failed, got receipt: {:?}, hash: {hash:?}",
                receipt
            );
        }
        Err(e) => e,
    };
    let rec = RecoverableCallbackError::handle_cb_error(err, &mock_event());
    if let Err(e) = rec {
        panic!("tx should have been recoverable, got error: {:?}", e);
    }
}

/// Tries its best to rate limit the rpc server
/// by spamming concurrent block queries
/// this won't pass on dedicated nodes, or nodes without rate limit
#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn test_rate_limit_against_rpc() {
    let setup = load_setup();
    if !setup.rate_limit_test {
        eprintln!("rate limit test disabled, skipped");
        return;
    }

    let ev = mock_event();
    let (tx, mut rx) = mpsc::channel(100);

    let mut set = JoinSet::new();
    for _ in 0..500 {
        let eth = setup.rpc.eth();
        let fut = async move {
            let n = eth.block_number().await?;
            let block = eth
                .block(BlockId::Number(BlockNumber::Number(n)))
                .await?
                .unwrap();
            for tx in block.transactions {
                eth.transaction_receipt(tx).await?;
            }
            Ok(())
        };
        let tx = tx.clone();
        set.spawn(async move {
            if let Err(e) = fut.await {
                _ = tx.send(e).await;
            }
        });
    }
    drop(tx);

    let err = rx.recv().await.unwrap();
    set.shutdown().await;
    assert!(RecoverableCallbackError::handle_cb_error(err, &ev).is_ok());
}
