use std::time::Duration;

use common::chains::ChainId;
use common::errors::VRFError;
use common::VrfRequest;
use connectors::vrf_config::VrfConfig;
use log::warn;
use web3::{types::H256, Transport};

use web3::Web3;

use web3::transports::Http;
use web3::types::Log;

use crate::events::EthEvent;
use crate::fallback_transport::HttpWithFallback;
use crate::EthRequestEvent;

const H256_LENGTH: usize = 32;

async fn check_vrf_txn(
    chain_id: ChainId,
    transport: impl Transport,
    txn_hash: H256,
    message: &[u8],
) -> Result<bool, VRFError> {
    let web3_client = Web3::new(transport);
    let eth_client = web3_client.eth();
    let Some(receipt) = eth_client.transaction_receipt(txn_hash).await? else {
        warn!("Transaction {txn_hash} doesn't exist on chain");
        return Ok(false);
    };
    let current_block_num = eth_client.block_number().await?.as_usize();

    // Find the VRF Request and ensure it matches the message and has enough confirmations
    let event_verified = receipt.logs.into_iter().any(|log| {
        let event_block = log.block_number.unwrap_or_default().as_usize();
        let eth_request_event = <EthRequestEvent as EthEvent<Log>>::try_from(&log, &chain_id);

        matches!(
            eth_request_event,
            Ok(EthRequestEvent {
                message: msg,
                ..
            }) if msg == message && current_block_num >= event_block
        )
    });

    if !event_verified {
        warn!("Transaction {txn_hash} doesn't have enough confirmation on chain");
    }
    Ok(event_verified)
}

/// verify on the blockchain the specified request
/// return true if the request is verified, false if verification fail
/// and an error if teh verification process can't be done correctly.
pub async fn verify_request(config: &VrfConfig, request: &VrfRequest) -> Result<bool, VRFError> {
    let chain_id = request.chain_id;

    let eth_config = config.eth.get(&chain_id).ok_or_else(|| {
        VRFError::Ethereum(format!(
            "verify_request no config found for request chain id:{chain_id:?}"
        ))
    })?;

    //Test tx hash length because H256::from_slice() panic if the size is not right.
    if request.txhash.len() != H256_LENGTH {
        return Err(VRFError::Ethereum(format!(
            "Eth connector Verify request bad request txn_hash length:{}",
            request.txhash.len()
        )));
    }

    let txn_hash = H256::from_slice(request.txhash.as_slice());

    if let Some(backup_sc_client_url) = eth_config.backup_sc_client_url.as_ref() {
        let transport = HttpWithFallback::new(
            &eth_config.sc_client_url,
            backup_sc_client_url,
            Duration::from_secs(eth_config.request_timeout_secs),
        )?;
        check_vrf_txn(chain_id, transport, txn_hash, &request.message).await
    } else {
        let transport = Http::new(&eth_config.sc_client_url)?;
        check_vrf_txn(chain_id, transport, txn_hash, &request.message).await
    }
}

// cargo test -- test_vrf_request --exact --nocapture
#[tokio::test]
#[cfg(ignore)]
async fn test_vrf_request() {
    let chain_id = ChainId::Anvil;
    let vrf_request = VrfRequest {
        message: [
            35, 205, 30, 200, 104, 232, 9, 138, 171, 138, 142, 129, 101, 120, 149, 38, 165, 127,
            77, 78, 190, 20, 116, 171, 126, 193, 98, 185, 127, 62, 79, 223,
        ]
        .to_vec(),
        block_hash: H256::from("37e4cc3af781f26a67efff82b9e6f837c4c2cd908e82af77151990d28351d2dc")
            .0
            .to_vec(),
        txhash: H256::from("e2b3ec186c3886b707fe4844f7577d87bfe5f7a6058f54530319595599d29098")
            .0
            .to_vec(),
        nonce: [1, 2, 3, 4],
        chain_id: chain_id,
    };
    let config = Config::new(Some("../../free-node/config.toml"))
        .load()
        .unwrap();

    let eth_connector = EthConnector;

    let data = eth_connector.verify_request(&vrf_request).await;
    assert!(data.is_ok());
    assert!(data.unwrap());
}
