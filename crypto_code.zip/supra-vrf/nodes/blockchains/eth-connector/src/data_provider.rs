use crate::event_meta_data::EventMetadata;
use crate::events::{EthEvent, EventParseError};
use crate::EthConnectorError;
use async_trait::async_trait;
use common::chains::ChainId;
use futures_lite::StreamExt;
use log::info;
use std::any::type_name;
use std::fmt;
use std::fmt::Debug;
use std::pin::Pin;
use std::task::{Context, Poll};
use thiserror::Error;
use tokio_stream::Stream;
use web3::api::SubscriptionStream;
use web3::ethabi::Hash;
use web3::transports::{Http, WebSocket};
use web3::types::{
    Address, BlockHeader as Web3BlockHeader, BlockId, BlockNumber, FilterBuilder, H256, U64,
};
use web3::Web3;

#[async_trait]
/// A [DataProvider] serves as an interface between a data source (e.g. a blockchain)
/// and an event consumer (e.g., [EthConnector]) transforming the raw data
/// provided by the underlying source to event consumers.
/// Data provider is inherently designed to work with blocks of data.
pub trait DataProvider {
    /// A block of data, e.g., a single block number.
    type Block: 'static;

    /// Data encoding an event.
    type RawEvent: 'static;

    /// Error type.
    type Error: Debug + Send + Sync + 'static;

    /// Returns a stream of [`Option`]<[`Self::Block`]>.
    /// It is [`None`] when block is unconfirmed.
    async fn get_block_stream(
        &self,
    ) -> Result<
        Pin<Box<dyn Stream<Item = Result<Option<Self::Block>, Self::Error>> + Send>>,
        Self::Error,
    >;

    /// Returns a stream of events of type `E`.
    async fn get_event_stream<E>(
        &self,
    ) -> Result<Pin<Box<dyn Stream<Item = Result<E, Self::Error>> + Send>>, Self::Error>
    where
        E: EthEvent<Self::RawEvent>;

    /// Fetches a batch of events in a single go emitted in blocks `from` until `to`
    /// and corresponding to the listed topics.
    /// if `to` is absent, all events until the latest block will be fetched.
    async fn get_events<E>(
        &self,
        from: u64,
        to: Option<u64>,
    ) -> Result<Vec<Result<E, Self::Error>>, Self::Error>
    where
        E: EthEvent<Self::RawEvent>;

    /// Fetches a batch of events corresponding to a particular transaction.
    async fn get_events_for_transaction<E>(&self, tx_hash: &H256) -> Result<Vec<E>, Self::Error>
    where
        E: EthEvent<Self::RawEvent>;

    /// Get current block number.
    async fn block_number(&self) -> Result<u64, Self::Error>;

    async fn block_hash(&self, block_number: u64) -> Result<H256, Self::Error>;

    /// This function is required as the log stream often pushes unconfirmed logs.
    /// If the log is unconfirmed it will either return it as is or fetch it again.
    async fn confirm_or_fetch<E>(
        &self,
        event: E,
        metadata: EventMetadata,
    ) -> Result<Option<E>, Self::Error>
    where
        E: EthEvent<Self::RawEvent> + Clone + Send + Sync + 'static;

    fn chain_id(&self) -> &ChainId;
}

/// Data provider based on web3-rs.
pub struct Web3DataProvider {
    chain_id: ChainId,
    //
    /// Address of the Supra generator contract. Name is aligned with its Solidity counter-part.
    supra_generator_contract: Address,
    //
    ws_url: Option<String>,
    http: Web3<Http>,
}

impl Debug for Web3DataProvider {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Web3DataProvider")
            .field("chain_id", &self.chain_id)
            .field("supra_generator_contract", &self.supra_generator_contract)
            .field("ws_url", &self.ws_url)
            .field("http", &"HTTP connection established")
            .finish()
    }
}

impl Web3DataProvider {
    pub(crate) async fn new(
        chain_id: ChainId,
        ws_url: Option<&str>,
        http_url: &str,
        supra_generator_contract: &Address,
    ) -> Result<Self, Web3DataProviderError> {
        let http = {
            let transport = Http::new(http_url)?;
            Web3::new(transport)
        };

        Ok(Self {
            chain_id,
            //
            supra_generator_contract: *supra_generator_contract,
            //
            ws_url: ws_url.map(|url| url.to_string()),
            http,
        })
    }

    pub(crate) async fn establish_ws_connection(
        url: &str,
    ) -> Result<Web3<WebSocket>, Web3DataProviderError> {
        WebSocket::new(url)
            .await
            .map(Web3::new)
            .map_err(Web3DataProviderError::Web3Transport)
    }
}

#[async_trait]
impl DataProvider for Web3DataProvider {
    type Block = U64;
    type RawEvent = web3::types::Log;
    type Error = Web3DataProviderError;

    async fn get_block_stream(
        &self,
    ) -> Result<
        Pin<Box<dyn Stream<Item = Result<Option<Self::Block>, Self::Error>> + Send>>,
        Self::Error,
    > {
        let stream = if let Some(url) = self.ws_url.as_ref() {
            let ws = Self::establish_ws_connection(url).await?;
            WsStream::<Web3BlockHeader>::new(&ws).await?
        } else {
            return Err(Web3DataProviderError::NoWsAddress);
        };

        let stream = stream.map(|value| value.map(|bh| bh.number));

        Ok(Box::pin(stream))
    }

    async fn get_event_stream<E>(
        &self,
    ) -> Result<Pin<Box<dyn Stream<Item = Result<E, Self::Error>> + Send>>, Self::Error>
    where
        E: EthEvent<Self::RawEvent>,
    {
        let stream = if let Some(url) = self.ws_url.as_ref() {
            let ws = Self::establish_ws_connection(url).await?;
            WsStream::<web3::types::Log>::new(&ws, &self.supra_generator_contract, E::signature())
                .await?
        } else {
            return Err(Web3DataProviderError::NoWsAddress);
        };

        let chain_id = self.chain_id;
        let stream = stream.map(move |value| match value {
            Ok(raw) => E::try_from(&raw, &chain_id).map_err(|error| {
                Web3DataProviderError::ConversionError {
                    from: type_name::<Self::RawEvent>().to_string(),
                    to: type_name::<E>().to_string(),
                    error,
                }
            }),

            Err(err) => Err(err),
        });

        Ok(Box::pin(stream))
    }

    async fn get_events<E>(
        &self,
        from: u64,
        to: Option<u64>,
    ) -> Result<Vec<Result<E, Self::Error>>, Self::Error>
    where
        E: EthEvent<Self::RawEvent>,
    {
        let filter = FilterBuilder::default()
            .address(vec![self.supra_generator_contract])
            .from_block(BlockNumber::Number(U64::from(from)))
            .to_block(if let Some(to) = to {
                BlockNumber::Number(U64::from(to))
            } else {
                BlockNumber::Latest
            })
            .topics(Some(vec![E::signature()]), None, None, None)
            .build();

        info!(
            "{} catching up on events from `{from}` to `{to:?}`",
            self.chain_id
        );

        let logs_filter = self.http.eth_filter().create_logs_filter(filter).await?;
        info!("{} got the log filter", self.chain_id);

        let logs = logs_filter.logs().await?;
        info!("{} got the catch-up logs", self.chain_id);

        Ok(logs
            .into_iter()
            .map(|raw| {
                E::try_from(&raw, &self.chain_id).map_err(|error| {
                    Web3DataProviderError::ConversionError {
                        from: type_name::<Self::RawEvent>().to_string(),
                        to: type_name::<E>().to_string(),
                        error,
                    }
                })
            })
            .collect::<Vec<_>>())
    }

    async fn get_events_for_transaction<E>(&self, tx_hash: &H256) -> Result<Vec<E>, Self::Error>
    where
        E: EthEvent<Self::RawEvent>,
    {
        let receipt = self
            .http
            .eth()
            .transaction_receipt(*tx_hash)
            .await
            .map_err(Web3DataProviderError::Web3Transport)?
            .ok_or(Web3DataProviderError::TxNotFound(*tx_hash))?;

        let topics = vec![E::signature()];

        let smart_contract_address = self.supra_generator_contract;

        Ok(receipt
            .logs
            .into_iter()
            .filter_map(move |raw| {
                if raw.address != smart_contract_address
                    || !topics.iter().any(|topic| raw.topics.contains(topic))
                {
                    return None;
                }

                E::try_from(&raw, &self.chain_id).ok()
            })
            .collect::<Vec<_>>())
    }

    async fn block_number(&self) -> Result<u64, Self::Error> {
        self.http
            .eth()
            .block_number()
            .await
            .map(|n| n.as_u64())
            .map_err(Web3DataProviderError::Web3Transport)
    }

    async fn block_hash(&self, block_number: u64) -> Result<H256, Self::Error> {
        self.http
            .eth()
            .block(BlockId::Number(block_number.into()))
            .await?
            .ok_or(Web3DataProviderError::BlockNotFound(block_number))?
            .hash
            .ok_or(Web3DataProviderError::BlockDataAbsent {
                data_kind: "hash".to_string(),
                block_number,
            })
    }

    /// This function is required as the log stream often pushes unconfirmed logs.
    /// If the log is unconfirmed it will either return it as is or fetch it again.
    ///
    /// It does this through the block hash in the event log
    /// This also takes care of the case of block re-orgs.
    async fn confirm_or_fetch<E>(
        &self,
        event: E,
        metadata: EventMetadata,
    ) -> Result<Option<E>, Self::Error>
    where
        E: EthEvent<Self::RawEvent> + Clone + Send + Sync + 'static,
    {
        let event_block_hash =
            metadata
                .block_hash
                .ok_or(Web3DataProviderError::EventMetadataAbsent {
                    data_kind: "block hash".to_string(),
                    metadata: metadata.clone(),
                })?;

        // `log.raw` contains `block_hash`, but one, apparently, need to fetch it again due to possible reorgs.
        let block_hash = {
            let block_number = metadata.block_number.ok_or_else(|| {
                Web3DataProviderError::EventMetadataAbsent {
                    data_kind: "block number".to_string(),
                    metadata: metadata.clone(),
                }
            })?;

            self.block_hash(block_number).await?
        };

        if block_hash == event_block_hash {
            return Ok(Some(event));
        }

        let log_tx_hash = metadata
            .tx_hash
            .ok_or(Web3DataProviderError::EventMetadataAbsent {
                data_kind: "transaction hash".to_string(),
                metadata: metadata.clone(),
            })?;

        let Some(tx) = self.http.eth().transaction_receipt(log_tx_hash).await? else {
            // Tx was never included
            return Ok(None)
        };

        let fetched_log = tx.logs.into_iter().find(|l| {
            l.topics == metadata.topics && l.transaction_log_index == metadata.tx_event_index
        });

        fetched_log
            .map(|raw| {
                // Application of map will produce Option<Result<E, Self::Error>>
                // which will be `transpose` -d into Result<Option<E>, Self::Error>.
                E::try_from(&raw, &self.chain_id).map_err(|error| {
                    Web3DataProviderError::ConversionError {
                        from: type_name::<Self::RawEvent>().to_string(),
                        to: type_name::<E>().to_string(),
                        error,
                    }
                })
            })
            .transpose()
    }

    fn chain_id(&self) -> &ChainId {
        &self.chain_id
    }
}

pub(crate) struct WsStream<I> {
    inner: SubscriptionStream<WebSocket, I>,
}

impl WsStream<Web3BlockHeader> {
    pub(crate) async fn new(ws: &Web3<WebSocket>) -> Result<Self, Web3DataProviderError> {
        Ok(Self {
            inner: ws.eth_subscribe().subscribe_new_heads().await?,
        })
    }
}

impl WsStream<web3::types::Log> {
    pub(crate) async fn new(
        ws: &Web3<WebSocket>,
        smart_contract_address: &Address,
        event_signature: Hash,
    ) -> Result<Self, Web3DataProviderError> {
        let ev_filter = FilterBuilder::default()
            .address(vec![*smart_contract_address])
            .topics(Some(vec![event_signature]), None, None, None)
            .build();

        Ok(Self {
            inner: ws.eth_subscribe().subscribe_logs(ev_filter).await?,
        })
    }
}

impl<I> Stream for WsStream<I>
where
    I: serde::de::DeserializeOwned,
{
    type Item = Result<I, Web3DataProviderError>;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut()
            .inner
            .poll_next(cx)
            .map_err(Web3DataProviderError::Web3Transport)
    }
}

#[derive(Debug, Error)]
pub enum Web3DataProviderError {
    #[error(transparent)]
    Web3Transport(#[from] web3::Error),
    #[error("Log {log:?} is missing `{data_kind}`")]
    LogDataAbsent {
        data_kind: String,
        log: Box<web3::types::Log>,
    },
    #[error("Event meta data {metadata:?} is missing `{data_kind}`")]
    EventMetadataAbsent {
        data_kind: String,
        metadata: EventMetadata,
    },
    #[error("Block number `{block_number}` is missing `{data_kind}`")]
    BlockDataAbsent {
        data_kind: String,
        block_number: u64,
    },
    #[error("Ws address has not been provided")]
    NoWsAddress,
    #[error("No block with id {0} is found")]
    BlockNotFound(u64),
    #[error("No transaction with hash id {0} is found")]
    TxNotFound(H256),
    #[error("Conversion error: {from} -> {to}. Reason: {error}")]
    ConversionError {
        from: String,
        to: String,
        error: EventParseError,
    },
}

impl From<Web3DataProviderError> for EthConnectorError {
    fn from(err: Web3DataProviderError) -> Self {
        EthConnectorError::DataProviderError(format!("{err:?}"))
    }
}
