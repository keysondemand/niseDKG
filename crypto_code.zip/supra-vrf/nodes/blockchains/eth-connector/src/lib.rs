//! The Connector for Ethereum (and other EVM based chains)

#![warn(missing_docs)]
pub mod callback;
pub mod config;
mod gas_provider;
// pub mod test;
mod data_provider;
mod deferred_store;
mod event_meta_data;
mod fallback_transport;
pub mod request;
mod verify_request;

mod events;
pub use events::{EthEvent, EthRequestEvent, EthStreamEvent, NonceProcessed};

use connectors::RequestEvent;
pub use verify_request::verify_request;

mod connector;
pub use connector::EthConnector;

mod error;
pub use error::EthConnectorError;

use web3::types::{H160, U256};

use std::collections::BTreeSet;

use std::fs;
use std::time::Instant;

use common::VrfRequest;
pub use config::{EthConfig, EthSecretConfig};

use log::warn;

use web3::types::{Address, U64};

use web3::api::Eth;
use web3::contract::Contract;
use web3::transports::Http;

// if we encounter more than 10 events coming from the HTTP stream without a single one from the Websocket in the meantime,
// it likely means the Websocket stream has stalled and we should just restart it.
const MAX_CONSECUTIVE_EVENT_FROM_HTTP: u8 = 10;

type Nonce = u64;
type BlockNumber = U64;

/// A cache of known processed blocks, used and populated only by the `is_nonce_already_processed` function in this module
#[derive(Default)]
struct ProcessedNonceCache {
    nonce_processed: BTreeSet<U256>,
    last_checked_block: U64,
}

/// A wrapper around the request event, to make the distinction between the event that have been processed already, and the one that haven't.
#[derive(Clone, Debug)]
pub enum MaybeRequestEvent {
    /// if it's a real request event, not processed yet
    RequestEvent(EthRequestEvent),
    /// if we'd found the event to be processed already
    EventAlreadyProcessed {
        /// the number of the block the event comes from
        block_number: U64,
        /// the event's nonce
        nonce: U256,
    },
}

impl MaybeRequestEvent {
    fn get_nonce(&self) -> U256 {
        match self {
            MaybeRequestEvent::RequestEvent(request_event) => request_event
                .nonce
                .clone()
                .into_uint()
                .expect("The nonce must be a unint"),
            MaybeRequestEvent::EventAlreadyProcessed { nonce, .. } => *nonce,
        }
    }

    fn get_block_number(&self) -> U64 {
        match self {
            MaybeRequestEvent::RequestEvent(request_event) => request_event.block_number,
            MaybeRequestEvent::EventAlreadyProcessed { block_number, .. } => *block_number,
        }
    }
}

impl RequestEvent for MaybeRequestEvent {
    type CallerIdentifier = H160;
    type Error = EthConnectorError;

    fn to_vrf_request(&self) -> Result<Option<VrfRequest>, Self::Error> {
        match self {
            MaybeRequestEvent::RequestEvent(request_event) => request_event
                .to_vrf_request()
                .map_err(EthConnectorError::EventParseError),
            MaybeRequestEvent::EventAlreadyProcessed { .. } => Ok(None),
        }
    }

    fn get_tx_hash(&self) -> String {
        match self {
            MaybeRequestEvent::RequestEvent(request_event) => request_event.get_tx_hash(),
            MaybeRequestEvent::EventAlreadyProcessed { .. } => {
                "Already processed event".to_string()
            }
        }
    }

    fn short_log(&self) -> String {
        match self {
            MaybeRequestEvent::RequestEvent(request_event) => request_event.short_log(),
            MaybeRequestEvent::EventAlreadyProcessed { nonce, .. } => {
                format!("Already processed event with nonce: {nonce}")
            }
        }
    }

    fn get_vrf_nonce(&self) -> u64 {
        self.get_nonce().as_u64()
    }

    fn get_reception_time(&self) -> Instant {
        match self {
            MaybeRequestEvent::RequestEvent(ev) => ev.get_reception_time(),
            MaybeRequestEvent::EventAlreadyProcessed { .. } => Instant::now(),
        }
    }

    fn get_caller(&self) -> Self::CallerIdentifier {
        match self {
            MaybeRequestEvent::RequestEvent(request_event) => request_event.get_caller(),
            // Safe as we don't care about the caller of an already processed event
            MaybeRequestEvent::EventAlreadyProcessed { .. } => Default::default(),
        }
    }
}

fn get_contract_instance(
    sc_address: Address,
    eth_http_client: Eth<Http>,
    path: &str,
) -> Result<Contract<Http>, EthConnectorError> {
    // The following expects() are OK since this part will be removed before being deployed to production: the smart contract ABI will likely be statically linked and not fetched based on a environment variable
    let path = dotenv::var(path).unwrap_or_else(|_| panic!("Missing {path} environment variable"));
    let smart_contract_abi =
        fs::read_to_string(path).expect("Failed to open the smart contract abi path");

    let json_value: serde_json::Value =
        serde_json::from_str(&smart_contract_abi).expect("failed to parse smart contract");

    let abi_string = json_value["abi"].to_string();

    Ok(
        Contract::from_json(eth_http_client, sc_address, abi_string.as_bytes())
            .expect("failed to get the contract instance"),
    )
}

//TODO update the test
// cargo test -- test_verify_callback --exact --nocapture
// #[tokio::test]
// async fn test_verify_callback() {
//     let config = Config::new(Some("../../free-node/config.toml"))
//         .load()
//         .unwrap();
//     let chain_id = ChainId::Anvil;
//     let mut eth_callback_connector = EthConnector {
//         chain_id,
//         config: config.eth.get(&chain_id).unwrap().clone(),
//         nonce_processed: BTreeMap::new(),
//         start_from: 0,
//     };

//     let pub_key = socrypto::PublicKey::new([0x8; 32]);

//     let vrf_callback = VrfCallback {
//         nonce: [1, 0, 0, 0],
//         signs: vec![(1, pub_key, vec![11], vec![22])],
//         block_hash: bincode::serialize(
//             "37e4cc3af781f26a67efff82b9e6f837c4c2cd908e82af77151990d28351d2dc",
//         )
//         .unwrap(),
//         txhash: bincode::serialize(
//             "e2b3ec186c3886b707fe4844f7577d87bfe5f7a6058f54530319595599d29098",
//         )
//         .unwrap(),
//         chain_id,
//     };

//     let verify = eth_callback_connector
//         .verify_callback_nonce(&vrf_callback)
//         .await;

//     assert!(!verify.unwrap());
// }
