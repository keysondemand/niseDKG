
# Aptos connector

Rough setup guide

## API URLS
#### TESTNET
	APTOS_REST_URL=https://fullnode.testnet.aptoslabs.com/v1
	APTOS_FAUCET_URL=

#### DEVNET
	APTOS_REST_URL=https://fullnode.devnet.aptoslabs.com/v1
	APTOS_FAUCET_URL=https://faucet.devnet.aptoslabs.com

#### LOCAL
	APTOS_REST_URL=http://localhost:8080
	APTOS_FAUCET_URL=http://localhost:8081

## Steps to setup the Smart Contracts and Nodes 
    • aptos init (select [lcoal |devnet | testnet] *1) [supra-vrf/smart-contracts/aptos]
    • update the wallet id in the Move.toml file with the new wallet id
    • update the free-node config.toml file with the account address and secret_key
    • update .env file in free-node with the aptos account and secret
    • update the Move.toml in supra-vrf/sdk/aptos/vrf-framework with the new account addr
    • aptos init (Same net as *1) [supra-vrf/sdk/aptos/example]
    • update Move.toml in supra-vrf/sdk/aptos/example with the new address
### Fund wallets on TESTNET
	• Get all the wallet private keys so that you can add all the wallets to Petra
    • Fund the wallets with [https://aptoslabs.com/testnet-faucet](https://aptoslabs.com/testnet-faucet) as there is no API to do this with

### Fund wallets on DEVNET or LOCAL
	• [supra-vrf/sdk/aptos/example] aptos account fund-with-faucet --account default --amount 1000
	• [supra-vrf/smart-contracts/aptos] aptos account fund-with-faucet --account default --amount 1000

### Compile and Publish the Smart Contracts
    • [supra-vrf/smart-contracts/aptos] aptos move compile
    • [supra-vrf/smart-contracts/aptos] aptos move publish
    • [supra-vrf/sdk/aptos/example] aptos move compile
    • [supra-vrf/sdk/aptos/example] aptos move publish
 
### Setup VRF-Node and Free-Node
    • make sure you have the required files to run vrf-node [To Be Added]
    • make sure that the free-node .env file poitns to the testnet
    • Add the VRF pub key to aptos with RUST_LOG=info RUST_BACKTRACE=1 cargo run --bin add-pubkey-aptos
    • Start the VRF Node [supra-vrf/nodes/vrf-node] RUST_LOG=vrf_node,sodkg,soruntime=trace RUST_BACKTRACE=1 THRESHOLD_NUMBER=3 SMR_NODE_ADDR=127.0.0.1:25000 MIN_NUMBER_OF_NODE=5 cargo run --release --bin start_committee
    • Start the Free-Node [supra-vrf/nodes/free-node] RUST_LOG=info RUST_BACKTRACE=1 cargo run

## Steps to play GamingContract [supra-vrf/sdk/aptos/example] 
    • aptos move run --function-id default::GamingContract::create_lottery
    • aptos init (Same net as *1) --profile player1
    • aptos init (Same net as *1) --profile player2
    
### Fund wallets on TESTNET
	• Get all the wallet private keys so that you can add all the wallets to Petra
    • Fund the wallets with [https://aptoslabs.com/testnet-faucet](https://aptoslabs.com/testnet-faucet) as there is no API to do this with

### Fund wallets on DEVNET or LOCAL
	• [supra-vrf/sdk/aptos/example] aptos account fund-with-faucet --account player1 --amount 1000
	• [supra-vrf/sdk/aptos/example] aptos account fund-with-faucet --account player2 --amount 1000
### Enter Players into lottery, Request the Random number and payout the winner
    • aptos move run --function-id default::GamingContract::enter_player --args u64:105 --profile player1
    • aptos move run --function-id default::GamingContract::enter_player --args u64:110 --profile player2
    • aptos move run --function-id default::GamingContract::request_random_number
    • aptos move run --function-id default::GamingContract::pay_to_winner
