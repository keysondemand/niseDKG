//! Utils for handling VRF Callback Transactions
use crate::error::AptosConnectorError;
use aptos_sdk::rest_client::{
    aptos_api_types::TransactionPayload as TransactionPayloadRes, Transaction,
};

use common::errors::VRFError;
use lru_time_cache::LruCache;
use std::collections::HashMap;
use std::str;

use std::sync::{Arc, RwLock};

lazy_static::lazy_static!(
    /// Cache for transactions processed by the Account
    pub static ref ACCOUNT_TX: Arc<RwLock<HashMap<String, String>>> = Arc::new(RwLock::new(HashMap::new()));
    /// Cache for transaction sequence starting
    pub static ref TX_START: Arc<RwLock<usize>> = Arc::new(RwLock::new(0));
);

/// Verifies the a VRF Callback
pub async fn verify_callback_nonce(
    callback: &Vec<u8>,
    sequence_number: u64,
    rest_url: String,
    account_addr: String,
) -> Result<bool, AptosConnectorError> {
    // first get transacted in cache and check the callback transaction in already is exist or not
    // let transactions = ACCOUNT_TX.read().expect("Unable to read").get(sequence_number);
    let sequence_number = sequence_number.to_string();
    let sequence_number = sequence_number.as_str();

    // if callback transacted not found then it will check with the latest transaction record in BC
    if ACCOUNT_TX
        .read()
        .map_err(|err| VRFError::RwPoison(err.to_string()))?
        .get(sequence_number)
        .is_none()
    {
        let start = *TX_START
            .read()
            .map_err(|err| VRFError::RwPoison(err.to_string()))?;
        let transactions: Vec<Transaction> =
            get_account_transactions(rest_url, account_addr, start).await?;

        let mut start = TX_START
            .write()
            .map_err(|err| VRFError::RwPoison(err.to_string()))?;
        *start += transactions.len();

        check_callback_in_tx(&transactions, callback, sequence_number)
    } else {
        Ok(true)
    }
}

/// This function check the callback function is already transacted in BC
/// If transacted then it will return false
/// Else it will true
fn check_callback_in_tx(
    transactions: &Vec<Transaction>,
    callback: &Vec<u8>,
    sequence_number: &str,
) -> Result<bool, AptosConnectorError> {
    let mut callback_tx = true;
    for tx in transactions {
        if let Transaction::UserTransaction(user_tx) = tx {
            if user_tx.info.success {
                if let TransactionPayloadRes::EntryFunctionPayload(data) = &user_tx.request.payload
                {
                    let transaction_fun = format!(
                        "{}::{}::{}",
                        data.function.module.address, data.function.module.name, data.function.name
                    );

                    // check callback_function name with transacted function
                    if callback == &transaction_fun.as_bytes().to_vec() {
                        let hex_seq_num = format!("0x{}", hex::encode(sequence_number));
                        let arg_seq_num =
                            data.arguments[0].as_str().ok_or(VRFError::ParseString)?;
                        if hex_seq_num == arg_seq_num {
                            callback_tx = false;
                        }
                    }
                    if !data.arguments.is_empty() {
                        ACCOUNT_TX
                            .write()
                            .map_err(|err| VRFError::RwPoison(err.to_string()))?
                            .insert(
                                data.arguments[0]
                                    .as_str()
                                    .ok_or(VRFError::ParseString)?
                                    .to_string(),
                                transaction_fun,
                            );
                    }
                }
            }
        }
    }

    Ok(callback_tx)
}

/// get account transaction from start query param
/// It will store tx in cache an well start point also stored in cache
async fn get_account_transactions(
    rest_url: String,
    account_addr: String,
    start: usize,
) -> Result<Vec<Transaction>, reqwest::Error> {
    reqwest::Client::new()
        .get(format!(
            "{rest_url}/accounts/{account_addr}/transactions?start={start}"
        ))
        .send()
        .await?
        .json::<Vec<Transaction>>()
        .await
}

/// Verifies a VRF Callback and caches the result
pub async fn verify_callback_nonce_lru(
    callback: Vec<u8>,
    sequence_number: &str,
    lru_cache: &mut LruCache<String, String>,
    start: &mut usize,
    rest_url: String,
    account_addr: String,
) -> Result<bool, VRFError> {
    // first get transacted in cache and check the callback transaction in already is exist or not
    let transactions = lru_cache.get(sequence_number);

    if transactions.is_none() {
        let transactions =
            get_account_transactions(rest_url, account_addr, start.to_owned()).await?;
        let status = check_callback_in_tx_lru(
            transactions.to_owned(),
            callback,
            sequence_number,
            lru_cache,
        )?;
        *start += transactions.len();

        Ok(status)
    } else {
        Ok(true)
    }
}

/// This function check the callback function is already transacted in BC
/// If transacted then it will return false
/// Else it will true
fn check_callback_in_tx_lru(
    transactions: Vec<Transaction>,
    callback: Vec<u8>,
    sequence_number: &str,
    lru_cache: &mut LruCache<String, String>,
) -> Result<bool, VRFError> {
    let mut callback_tx = true;
    for tx in transactions {
        if let Transaction::UserTransaction(user_tx) = tx {
            if user_tx.info.success {
                if let TransactionPayloadRes::EntryFunctionPayload(data) = user_tx.request.payload {
                    let transaction_fun = format!(
                        "{}::{}::{}",
                        data.function.module.address, data.function.module.name, data.function.name
                    );

                    // check callback_function name with transacted function
                    if callback == transaction_fun.as_bytes().to_vec() {
                        let hex_seq_num = format!("0x{}", hex::encode(sequence_number));
                        let arg_seq_num =
                            data.arguments[0].as_str().ok_or(VRFError::ParseString)?;
                        if hex_seq_num == arg_seq_num {
                            callback_tx = false;
                        }
                    }

                    if !data.arguments.is_empty() {
                        lru_cache.insert(
                            data.arguments[0]
                                .as_str()
                                .ok_or(VRFError::ParseString)?
                                .to_string(),
                            transaction_fun,
                        );
                    }
                }
            }
        }
    }

    Ok(callback_tx)
}
