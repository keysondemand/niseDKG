//! Configurations for the aptos blockchain connector
use aptos_types::account_address::AccountAddress;
use async_trait::async_trait;
use common::chains::ChainId;
use connectors::{recovery_point::RecoveryPointWriter, Init};
use log::info;
use serde::{Deserialize, Serialize};
use std::{collections::HashSet, fmt::Debug};

use crate::{
    supra_aptos_sdk::SupraAptosClient, AptosConnector, AptosConnectorError, AptosHistoryPoint,
};

const fn default_request_interval() -> u64 {
    1000
}

/// Configuration for the Aptos Connector
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct AptosConfig {
    /// Aptos Client URL
    pub sc_client_url: String,
    /// Aptos Generator smart contract
    pub sc_address: String,
    /// Creation number for the Aptos generator smart contract
    pub(crate) creation_num: String,
    /// Polling interval for aptos event stream
    #[serde(default = "default_request_interval")]
    pub(crate) request_interval: u64,
    pub(crate) sc_whitelist: Option<HashSet<String>>,
    #[serde(default)]
    pub(crate) sc_blacklist: HashSet<String>,
}

/// Secrets configuration for Aptos
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct AptosSecretConfig {
    /// Private key to send transactions (in hex format)
    pub chain_secret_key_hex: String,
}

fn parse_addrs(addrs: &HashSet<String>) -> Result<HashSet<AccountAddress>, AptosConnectorError> {
    addrs
        .iter()
        .map(|addr| AccountAddress::from_hex_literal(addr))
        .collect::<Result<_, _>>()
        .map_err(|e| e.into())
}

/// The Init trait, responsible for the initialization of the connector
#[async_trait]
impl Init for AptosConfig {
    type InitializationError = AptosConnectorError;
    type Connector = AptosConnector;

    /// Perform the initialization of a blockchain connector
    async fn initialize_connector(
        &self,
        chain_id: ChainId,
        secrets: Vec<String>,
    ) -> Result<
        (RecoveryPointWriter<u64, AptosHistoryPoint>, AptosConnector),
        Self::InitializationError,
    > {
        let (recovery_point_writer, recovery_point) = RecoveryPointWriter::init(chain_id)?;
        let aptos_http_client = SupraAptosClient::new(self.sc_client_url.clone())?;
        info!("{chain_id}: starting point= {:?}", recovery_point);
        Ok((
            recovery_point_writer,
            AptosConnector {
                aptos_client: aptos_http_client,
                config: self.clone(),
                recovery_point,
                chain_secret_key_hex: secrets[0].clone(),
            },
        ))
    }

    fn whitelist(&self) -> Option<Result<HashSet<AccountAddress>, Self::InitializationError>> {
        self.sc_whitelist.as_ref().map(parse_addrs)
    }

    fn blacklist(&self) -> Result<HashSet<AccountAddress>, Self::InitializationError> {
        parse_addrs(&self.sc_blacklist)
    }
}
