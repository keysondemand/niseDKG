//! Minimal Aptos SDK implementation based on the official Aptos SDK
use std::convert::TryFrom;
use std::str;
use std::time::Duration;

use blst::min_pk::{SecretKey as BlsSecretKey, Signature};
use ed25519_dalek::{PublicKey, SecretKey};
use nidkg_helper::nidkg::BlsSignature;
use nidkg_helper::utils::convert_97bg2_96bg2;
use tiny_keccak::{Hasher, Sha3};

use aptos::common::utils::{chain_id, get_sequence_number};
use aptos_sdk::move_types::identifier::Identifier;
use aptos_sdk::rest_client::{error::RestError, Client, Transaction};
use aptos_sdk::{crypto::ed25519::Ed25519PrivateKey, move_types::language_storage::ModuleId};
use aptos_sdk::{transaction_builder::TransactionFactory, types::LocalAccount};
use aptos_types::account_address::AccountAddress;
use aptos_types::transaction::{EntryFunction, SignedTransaction, TransactionPayload};
use common::chains::ChainId;
use common::influx_metrics::Metrics;
use log::{error, info, warn};

use crate::error::AptosConnectorError;
use crate::types::EventTransaction;
use crate::AptosRequestEvent;

/// The identifier for Rng Event
pub const EVENT_STRUCT: &str = "SupraContract::SupraEventHandler";
/// The field containing the Rng Event
pub const EVENT_FIELD: &str = "rng_request";

/// An Aptos Account
pub struct Account {
    signing_key: SecretKey,
    sender_key: Ed25519PrivateKey,
}

impl Account {
    /// Bls Public Key of the account
    // TODO: why does this exist?
    pub fn _pk(&self) -> Result<blst::min_pk::PublicKey, AptosConnectorError> {
        BlsSecretKey::from_bytes(&self.signing_key.to_bytes())
            .map(|sk| sk.sk_to_pk())
            .map_err(AptosConnectorError::BLST)
    }

    /// Load from raw secret key
    pub fn from_secret_key(input: String) -> Result<Self, AptosConnectorError> {
        let input = input.trim_start_matches("0x");
        let h = hex::decode(input)?;
        let signing_key = SecretKey::from_bytes(&h)?;
        let sender_key = Ed25519PrivateKey::try_from(&*signing_key.to_bytes().to_vec())?;
        Ok(Account {
            signing_key,
            sender_key,
        })
    }

    /// Sign a message with the BLS Secret Key
    pub fn sign_message(&mut self, msg: &str) -> Result<Signature, AptosConnectorError> {
        let dst = "BLS_SIG_BLS12381G2_XMD:SHA-256_SSWU_RO_POP_".as_bytes();
        let msg_bytes = msg.as_bytes();
        BlsSecretKey::from_bytes(&self.signing_key.to_bytes())
            .map(|sk| sk.sign(msg_bytes, dst, &[]))
            .map_err(AptosConnectorError::BLST)
    }

    /// Returns the address associated with the given account
    pub fn address(&self) -> String {
        self.auth_key()
    }

    /// Returns the auth_key for the associated account
    pub fn auth_key(&self) -> String {
        let mut sha3 = Sha3::v256();
        sha3.update(PublicKey::from(&self.signing_key).as_bytes());
        sha3.update(&[0u8]);

        let mut output = [0u8; 32];
        sha3.finalize(&mut output);
        hex::encode(output)
    }

    /// Get the account's address
    pub fn to_address(&self) -> Result<AccountAddress, AptosConnectorError> {
        AccountAddress::from_hex_literal(&format!("0x{}", self.address())).map_err(|e| e.into())
    }

    /// Constructs a transaction from a payload and sign it
    pub async fn setup_transaction(
        &self,
        payload: &TransactionPayload,
        rest_client: &Client,
        sequence_number: u64,
    ) -> Result<SignedTransaction, AptosConnectorError> {
        let transaction_factory = TransactionFactory::new(chain_id(rest_client).await?)
            .with_gas_unit_price(100)
            .with_max_gas_amount(90_000);

        let sender_key = self.sender_key.clone();
        let sender_account =
            &mut LocalAccount::new(self.to_address()?, sender_key, sequence_number);
        Ok(sender_account
            .sign_with_transaction_builder(transaction_factory.payload(payload.clone())))
    }

    /// Sends a transaction to the blockchain
    pub async fn submit_transaction(
        &self,
        payload: TransactionPayload,
        rest_client: Client,
        sequence_number: u64,
    ) -> Result<Transaction, AptosConnectorError> {
        let sequence_number = if sequence_number == 0 {
            self.get_seq_num(&rest_client).await?
        } else {
            sequence_number
        };

        loop {
            info!(
                "submitting transaction with sequence number: {}",
                sequence_number
            );
            let transaction = self
                .setup_transaction(&payload, &rest_client, sequence_number)
                .await;
            let tx = transaction?.clone();

            let response = rest_client.submit_and_wait(&tx).await;
            if let Err(error) = &response {
                match error {
                    RestError::Api(ref e) => {
                        if e.error.vm_error_code == Some(3) {
                            warn!("sequence number too old, retrying");
                            Metrics::nonce_err(&ChainId::Aptos, error, sequence_number, "");
                            tokio::time::sleep(Duration::from_secs(1)).await;
                            continue;
                        } else if e.error.vm_error_code == Some(5) {
                            error!("INSUFFICIENT_BALANCE_FOR_TRANSACTION_FEE");
                            Metrics::out_of_gas(&ChainId::Aptos, error, sequence_number, "");
                        } else if e.error.vm_error_code == Some(14) {
                            error!("MAX_GAS_UNITS_BELOW_MIN_TRANSACTION_GAS_UNITS");
                            Metrics::out_of_compute(&ChainId::Aptos, error, sequence_number, "");
                        } else {
                            error!("Aptos: Callback Error {:?}", e.error);
                            Metrics::cb_break(&ChainId::Aptos, error, sequence_number, "");
                        }
                        return Err(AptosConnectorError::Aptos(e.error.clone()));
                    }
                    _ => {
                        Metrics::cb_break(&ChainId::Aptos, error.to_string(), sequence_number, "");
                    }
                }
            }
            return response.map(|r| r.into_inner()).map_err(|e| e.into());
        }
    }

    /// Get the current sequence number for this account
    pub async fn get_seq_num(&self, rest_client: &Client) -> Result<u64, AptosConnectorError> {
        get_sequence_number(rest_client, self.to_address()?)
            .await
            .map_err(|e| e.into())
    }
}

/// Aptos RPC Client
pub struct SupraAptosClient {
    /// Internal HTTP client
    #[doc(hidden)]
    pub rest_client: Client,
}

impl SupraAptosClient {
    /// Represents an account as well as the private, public key-pair for the Aptos blockchain.
    pub fn new(url: String) -> Result<Self, AptosConnectorError> {
        url.parse::<reqwest::Url>()
            .map(|url| Self {
                rest_client: Client::new(url),
            })
            .map_err(|e| AptosConnectorError::UrlParse(e.to_string()))
    }

    /// Sends the VRF Transaction to the blockchain
    pub async fn generate_callback(
        &self,
        account: &mut Account,
        request_event: &AptosRequestEvent,
        sequence_number: u64,
        bls_signature: BlsSignature,
    ) -> Result<Transaction, AptosConnectorError> {
        let signature = convert_97bg2_96bg2(bls_signature.bls12381.sig_g2);
        self.callback_script(
            account,
            &request_event.event_data,
            request_event.message.clone(),
            signature,
            sequence_number,
        )
        .await
    }

    async fn submit_transaction(
        &self,
        account: &mut Account,
        payload: TransactionPayload,
        sequence_number: u64,
    ) -> Result<Transaction, AptosConnectorError> {
        let tx = account
            .submit_transaction(payload, self.rest_client.clone(), sequence_number)
            .await;
        if let Ok(tx_hash) = tx
            .as_ref()
            .map(|t| t.transaction_info().map(|ti| ti.hash.0.to_vec()))
        {
            info!("Transaction hash: {:?}", tx_hash.map(hex::encode));
        }
        tx
    }

    async fn callback_script(
        &self,
        account: &mut Account,
        event_data: &EventTransaction,
        message: Vec<u8>,
        signature: Vec<u8>,
        sequence_number: u64,
    ) -> Result<Transaction, AptosConnectorError> {
        let address = AccountAddress::from_hex_literal(&event_data.data.caller_address)?;
        let split_mod_fun: Vec<&str> = event_data.data.callback_fn.split("::").collect();
        let cb_module = split_mod_fun[0];
        let cb_function = split_mod_fun[1];
        let client_seed = &event_data.data.client_seed.parse::<u64>()?;
        let payload = TransactionPayload::EntryFunction(EntryFunction::new(
            ModuleId::new(address, Identifier::new(cb_module)?),
            Identifier::new(cb_function)?,
            vec![],
            vec![
                bcs::to_bytes(&event_data.sequence_number.parse::<u64>()?)?,
                bcs::to_bytes(&message)?,
                bcs::to_bytes(&signature)?,
                bcs::to_bytes(&event_data.data.rng_count)?,
                bcs::to_bytes(client_seed)?,
            ],
        ));
        self.submit_transaction(account, payload, sequence_number)
            .await
    }

    /// Gets the sequence number for an account
    pub async fn get_seq_num(&self, account: &Account) -> Result<u64, AptosConnectorError> {
        account.get_seq_num(&self.rest_client).await
    }

    /// Adds a DKG Key for the generator account
    pub async fn _add_dkg_public_key(
        &self,
        account: &mut Account,
        address_addr: String,
        sequence_number: u64,
        owner_pub_key: Vec<u8>,
    ) -> Result<Transaction, AptosConnectorError> {
        let address = AccountAddress::from_hex_literal(address_addr.as_str())?;

        let payload = TransactionPayload::EntryFunction(EntryFunction::new(
            ModuleId::new(address, Identifier::new("SupraContract")?),
            Identifier::new("add_dkg_public_key")?,
            vec![],
            vec![bcs::to_bytes(&owner_pub_key)?],
        ));
        self.submit_transaction(account, payload, sequence_number)
            .await
    }

    /// Updates the DKG Public Key
    pub async fn _update_dkg_public_key(
        &self,
        account: &mut Account,
        address_addr: String,
        sequence_number: u64,
        signature: BlsSignature,
    ) -> Result<Transaction, AptosConnectorError> {
        let address = AccountAddress::from_hex_literal(address_addr.as_str())?;
        let h = hex::decode("0x4b87d801124f8a7f9c5429b857af0c4351e849c54a21d8cff7652c7a4543985c")?;
        let signing_key = SecretKey::from_bytes(&h)?;
        let new_public_key = BlsSecretKey::from_bytes(signing_key.as_bytes())
            .map_err(AptosConnectorError::BLST)?
            .sk_to_pk();
        let message = "update_dkg_public_key";

        let payload = TransactionPayload::EntryFunction(EntryFunction::new(
            ModuleId::new(address, Identifier::new("SupraContract")?),
            Identifier::new("update_dkg_public_key")?,
            vec![],
            vec![
                bcs::to_bytes(message.as_bytes())?,
                bcs::to_bytes(&signature.into_bytes().to_vec())?,
                bcs::to_bytes(&new_public_key.to_bytes().to_vec())?,
            ],
        ));
        self.submit_transaction(account, payload, sequence_number)
            .await
    }

    /// Fetches the nonce of the latest Genrator event
    pub async fn get_last_event_nonce(
        &self,
        account: AccountAddress,
    ) -> Result<u64, AptosConnectorError> {
        let event = self
            .rest_client
            .get_account_events(
                account,
                &format!("0x{account}::{EVENT_STRUCT}"),
                EVENT_FIELD,
                None,
                Some(1),
            )
            .await?;

        Ok(event
            .inner()
            .get(0)
            .map(|e| e.sequence_number.0)
            .unwrap_or_else(|| 0))
    }
}

#[cfg(ignore = "")]
fn bytes_to_u64(bytes: Vec<u8>) -> u64 {
    let mut value = 0;
    let mut i = 0;
    while i < 8 {
        value = value | ((bytes[i] as u64) << ((8 * (7 - i)) as u8));
        i = i + 1;
    }
    return value;
}
