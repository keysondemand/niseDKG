//! Aptos specific types
use common::errors::VRFError;
use serde::{Deserialize, Serialize};
use socrypto::{digest, Digest, Hash};

/// Transaction Containing the Event
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct EventTransaction {
    /// Event
    pub data: SupraEvent,
    guid: Guid,
    /// Sequence number of the event
    pub sequence_number: String,
    #[serde(rename = "type")]
    type_field: String,
    /// Version
    pub version: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
struct Guid {
    creation_number: String,
    account_address: String,
}

/// Raw Event received from the blockchain
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SupraEvent {
    /// Instance Id of the contract
    pub instance_id: String,
    /// Caller which requested RNG
    pub caller_address: String,
    /// Callback function name
    pub callback_fn: String,
    /// Number of random numbers requested
    pub rng_count: u8,
    /// Client Seed
    pub client_seed: String,
}

impl Digest for SupraEvent {
    fn digest(&self) -> Hash {
        let bytes = vec![
            self.instance_id.as_bytes().to_vec(),
            self.caller_address.as_bytes().to_vec(),
            self.callback_fn.as_bytes().to_vec(),
            self.rng_count.to_be_bytes().to_vec(),
            self.client_seed.as_bytes().to_vec(),
        ];
        let hash_bytes: Vec<u8> = bytes.into_iter().flatten().collect();
        digest(hash_bytes.as_slice())
    }
}

impl SupraEvent {
    /// Json Serialize the event
    pub fn try_into_bytes(self) -> Result<Vec<u8>, VRFError> {
        Ok(serde_json::to_vec(&self)?)
    }

    /// Json Deserialize the event
    pub fn from_bytes(data: &[u8]) -> Result<Self, VRFError> {
        Ok(serde_json::from_slice::<Self>(data)?)
    }
}
