//! Error types for Aptos Connector
use aptos_sdk::crypto::CryptoMaterialError;
use common::errors::{ConfigError, VRFError};
use connectors::{recovery_point::RecoveryPointError, StreamError};
use thiserror::Error;

/// Errors during handling of VRF Requests
#[allow(missing_docs)]
#[derive(Error, Debug)]
pub enum AptosConnectorError {
    #[error(transparent)]
    Aptos(#[from] aptos_sdk::rest_client::aptos_api_types::AptosError),
    #[error("BLST error")]
    BLST(blst::BLST_ERROR),
    #[error(transparent)]
    Bcs(#[from] bcs::Error),
    #[error(transparent)]
    Cli(#[from] aptos::common::types::CliError),
    #[error("ConfigError: {0}")]
    Config(#[from] ConfigError),
    #[error(transparent)]
    Crypto(#[from] aptos_sdk::crypto::error::Error),

    #[error(transparent)]
    CryptoMata(#[from] CryptoMaterialError),

    #[error(transparent)]
    FromHex(#[from] hex::FromHexError),

    #[error(transparent)]
    Signature(#[from] ed25519_dalek::SignatureError),

    #[error(transparent)]
    ParseInt(#[from] std::num::ParseIntError),
    #[error(transparent)]
    Rest(#[from] aptos_sdk::rest_client::error::RestError),
    #[error("failed to serialize nonce into Uint [u64;4]")]
    NonceDeSerialization,
    #[error(transparent)]
    MoveAccountAddressParse(
        #[from] aptos_sdk::move_types::account_address::AccountAddressParseError,
    ),
    #[error("Failed to initialize recovery point: {0}")]
    RecoveryPoint(#[from] RecoveryPointError),
    #[error("VRFError: {0}")]
    VRF(#[from] VRFError),
    #[error("WSS connection lost due")]
    WssConnectionLost,
    #[error("reqwest error: {0}")]
    Reqwest(#[from] reqwest::Error),

    #[error("Error parsing url :{0}")]
    UrlParse(String),
}

impl StreamError for AptosConnectorError {
    fn is_wss_error(&self) -> bool {
        matches!(
            self,
            AptosConnectorError::VRF(VRFError::BcConnectorFetch(_))
        )
    }
}
