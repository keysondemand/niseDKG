//! Utils for processing an Aptos VRF Request
use crate::config::AptosConfig;
use crate::types::EventTransaction;
use crate::{AptosHistoryPoint, AptosRequestEvent};
use aptos_sdk::rest_client::aptos_api_types::{Block, X_APTOS_BLOCK_HEIGHT};
use common::chains::ChainId;
use common::errors::{ConfigError, VRFError};
use common::{with_retries, VrfRequest};
use connectors::vrf_config::VrfConfig;
use log::debug;
use serde::{Deserialize, Serialize};
use socrypto::{Digest, Hash};
use std::collections::BTreeMap;
use std::ops::RangeTo;
use std::time::Instant;

/// Data for a VRF Callback
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct CallbackData {
    /// Address of the caller
    pub address: String,
    /// Module in the caller
    pub module_name: String,
    /// Function to call in the module
    pub function: String,
}

pub(crate) async fn get_events(
    config: &AptosConfig,
    start_point: &mut u64,
    req_tx_block_cache: &mut BTreeMap<usize, Vec<EventTransaction>>,
) -> Result<Vec<Result<AptosRequestEvent, VRFError>>, VRFError> {
    let mut events = vec![];

    let event_response = with_retries(3, || async {
        get_event(
            &config.sc_client_url,
            &config.sc_address,
            &config.creation_num,
            start_point,
        )
        .await
    })
    .await;

    match event_response {
        Ok(mut event_res) => {
            *start_point += event_res.0.len() as u64;

            let current_block_height = event_res.1.parse::<usize>()?;
            let mut keys = vec![];

            // check previous request event
            for (key, _) in req_tx_block_cache.range(RangeTo {
                end: current_block_height,
            }) {
                keys.push(*key);
            }

            // remove keys from hashmap
            for key in keys {
                let event_data = req_tx_block_cache.remove(&key).unwrap();
                for event in event_data {
                    event_res.0.push(event);
                }
            }

            for event_data in event_res.0 {
                let req_tx_block =
                    get_block_by_height(&config.sc_client_url, &event_data.version).await?;
                let nonce = event_data.sequence_number.parse::<u64>()?;

                let message = vec![
                    nonce.to_le_bytes().to_vec(),
                    event_data.data.rng_count.to_be_bytes().to_vec(),
                    event_data.data.instance_id.as_bytes().to_vec(),
                    event_data.data.caller_address.as_bytes().to_vec(),
                    event_data.data.callback_fn.as_bytes().to_vec(),
                    event_data
                        .data
                        .client_seed
                        .parse::<u64>()?
                        .to_le_bytes()
                        .to_vec(),
                ]
                .into_iter()
                .flatten()
                .collect();

                log::info!("New event processing {:?}", &event_data.sequence_number);
                events.push(Ok(AptosRequestEvent {
                    event_data: event_data.clone(),
                    chain_point: AptosHistoryPoint {
                        sequence_number: nonce,
                    },
                    message,
                    nonce,
                    chain_id: ChainId::Aptos,
                    callback: event_data.data.callback_fn.as_bytes().to_vec(),
                    block_hash: Hash::new(*req_tx_block.block_hash.0.as_ref()),
                    tx_hash: event_data.data.digest(),
                    reception_time: Instant::now(),
                }));
            }
        }
        Err(err) => {
            log::error!("Error {:?}", err);
            events.push(Err(VRFError::BcConnectorFetch(err.to_string())))
        }
    }

    Ok(events)
}

/// Error from Aptos RPC
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct AptosErrorMessage {
    /// Error message
    pub message: String,
    /// Error Code
    pub error_code: String,
    vm_error_code: String,
}

/// Response from Aptos RPC
#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum AptosResponse {
    /// Event
    Event(Vec<EventTransaction>),
    /// Block
    Block(Block),
    /// Error
    ErrorMessage(AptosErrorMessage),
}

/// Verifies an Aptos Request
pub async fn verify_request(config: &VrfConfig, request: &VrfRequest) -> Result<bool, VRFError> {
    if let Some(config) = config.aptos.get(&ChainId::Aptos) {
        let start = request.nonce[0];
        let (event_transaction, _current_block_height) = get_event(
            &config.sc_client_url,
            &config.sc_address,
            &config.creation_num,
            &start,
        )
        .await?;
        if let Some(event) = event_transaction.first() {
            if event.sequence_number != request.nonce[0].to_string() {
                return Ok(false);
            }
            let req_tx_hash = TryInto::<[u8; 32]>::try_into(request.clone().txhash)
                .map_err(|e| VRFError::HashArrayLength(e.len()))?;
            if event.data.digest() != Hash::new(req_tx_hash) {
                return Ok(false);
            }
            return Ok(true);
        }
    } else {
        return Err(VRFError::Config(ConfigError::AptosConfigNotFound));
    }
    Ok(false)
}

pub(crate) async fn get_event(
    rest_url: &str,
    account_addr: &str,
    creation_num: &str,
    start: &u64,
) -> Result<(Vec<EventTransaction>, String), VRFError> {
    let response = reqwest::Client::new()
        .get(&format!(
            "{rest_url}/accounts/{account_addr}/events/{creation_num}?start={start}"
        ))
        .send()
        .await?;

    debug!("Aptos GetEvent response Response: {:?}", response);

    let current_block_height = response
        .headers()
        .get(X_APTOS_BLOCK_HEIGHT)
        .and_then(|h| h.to_str().ok())
        .map(|h| h.to_string())
        .ok_or(VRFError::GetCurrentBlock)?;
    let event_transaction: Vec<EventTransaction> = response.json().await?;
    Ok((event_transaction, current_block_height))
}

pub(crate) async fn get_block_by_height(
    rest_url: &str,
    block_height: &str,
) -> Result<Block, VRFError> {
    Ok(reqwest::Client::new()
        .get(format!("{rest_url}/blocks/by_version/{block_height}"))
        .send()
        .await?
        .json::<Block>()
        .await?)
}
