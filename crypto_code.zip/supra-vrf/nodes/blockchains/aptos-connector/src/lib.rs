//! The Connector for the Aptos Blockchain

#![warn(missing_docs)]

pub mod callback;
mod config;
mod error;
pub mod request;
pub mod supra_aptos_sdk;
pub mod types;
use connectors::recovery_point::{
    optimize_block_ranges, RecoveryPoint, RecoveryPointError, RecoveryPointWriter,
};
use connectors::{try_or_skip, RequestEvent};
pub use request::verify_request;
mod request_event;
use crate::callback::verify_callback_nonce;
use crate::request::get_events;
use crate::supra_aptos_sdk::SupraAptosClient;
use crate::types::EventTransaction;
use async_stream::stream;
use async_trait::async_trait;
use common::chains::ChainId;
use common::influx_metrics::Metrics;
use common::VrfCallback;
pub use config::{AptosConfig, AptosSecretConfig};
use connectors::{BcConnector, VrfTx};
pub use error::AptosConnectorError;
use log::info;
pub use request_event::AptosRequestEvent;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use supra_aptos_sdk::Account;
use thiserror::Error;
use tokio_stream::Stream;

/// Errors encounted during aptos connector initialization
#[allow(missing_docs)]
#[derive(Error, Debug)]
pub enum InitializationError {
    #[error(transparent)]
    RecoveryPoint(#[from] RecoveryPointError),
}

/// The Aptos Recovery point
pub type AptosRecoveryPoint = RecoveryPoint<u64, AptosHistoryPoint>;

/// Aptos History point
#[derive(Default, Debug, Clone, Serialize, Deserialize, Ord, PartialOrd, Eq, PartialEq, Copy)]
pub struct AptosHistoryPoint {
    /// event sequence_number/nonce
    pub sequence_number: u64,
}

/// The Aptos Connector
pub struct AptosConnector {
    aptos_client: SupraAptosClient,
    recovery_point: AptosRecoveryPoint,
    /// The configuration being used by the connector
    pub config: AptosConfig,
    chain_secret_key_hex: String,
}

#[async_trait]
impl BcConnector for AptosConnector {
    type RequestEvent = AptosRequestEvent;
    type Error = AptosConnectorError;
    type Nonce = u64;
    type BlockNumber = AptosHistoryPoint;

    async fn catchup(
        &self,
    ) -> Result<Box<dyn Stream<Item = Result<Self::RequestEvent, Self::Error>> + Send>, Self::Error>
    {
        let config = self.config.clone();
        let chain_secret_key = &self.chain_secret_key_hex;

        let account = Account::from_secret_key(chain_secret_key.clone())?;

        let mut missed_nonce_ranges = self.recovery_point.get_recovery_nonce_ranges();
        let current_nonce = self
            .aptos_client
            .get_last_event_nonce(account.to_address()?)
            .await?;

        let Some(latest_processed_nonce) = self.recovery_point.get_latest_processed_nonce() else {
            return Ok(Box::new(tokio_stream::empty()));
        };

        if current_nonce > latest_processed_nonce {
            missed_nonce_ranges.push((latest_processed_nonce, current_nonce));
        }

        missed_nonce_ranges = optimize_block_ranges(missed_nonce_ranges);

        let mut req_tx_block_cache: BTreeMap<usize, Vec<EventTransaction>> = BTreeMap::new();
        info!(
            "Free node is now starting catchup requests from: {:#?}",
            latest_processed_nonce
        );

        let catchup_stream = stream! {
            for (mut start, end) in missed_nonce_ranges.clone() {
                info!("catching up from {start} to {end}");
                let events = get_events(&config, &mut start, &mut req_tx_block_cache).await?;
                for event in events {
                    if let Ok(e) = event {
                        Metrics::pick_event_log(&ChainId::Aptos, e.nonce, e.clone().event_data.data.caller_address, "catchup");
                        yield Ok(e);
                    } else  {
                        yield event.map_err(|e| e.into())
                    }
                }
            }
        };
        Ok(Box::new(catchup_stream))
    }

    async fn start_listening(
        &self,
    ) -> Result<Box<dyn Stream<Item = Result<Self::RequestEvent, Self::Error>> + Send>, Self::Error>
    {
        let chain_secret_key = &self.chain_secret_key_hex;

        let account = Account::from_secret_key(chain_secret_key.clone())?;
        let mut start = self
            .aptos_client
            .get_last_event_nonce(account.to_address()?)
            .await?;

        info!(
            "Free node is now listening new Aptos requests from latest sequence number: {:#?}",
            start
        );
        let config = self.config.clone();
        let mut req_tx_block_cache: BTreeMap<usize, Vec<EventTransaction>> = BTreeMap::new();

        let ev_stream = stream! {
            loop {
                let events = try_or_skip!(get_events(&config, &mut start, &mut req_tx_block_cache).await, yield);
                for event in events {
                    if let Ok(e) = &event {
                        let caller_address = e.event_data.data.caller_address.to_string();
                        Metrics::pick_event_log(&ChainId::Aptos, e.nonce, caller_address, "http");
                    }
                    yield event.map_err(|e| e.into());
                }
                tokio::time::sleep(tokio::time::Duration::from_millis(config.request_interval)).await;
            }
        };
        Ok(Box::new(ev_stream))
    }

    async fn verify_callback_nonce(
        &mut self,
        request_event: Self::RequestEvent,
        _vrf_tx: &VrfCallback,
    ) -> Result<bool, Self::Error> {
        verify_callback_nonce(
            &request_event.callback,
            request_event.get_vrf_nonce(),
            self.config.sc_client_url.clone(),
            self.config.sc_address.clone(),
        )
        .await
    }

    async fn send_callback_tx(
        &self,
        _concurrency_index: usize,
        callback: Option<VrfTx>,
        request_event: Self::RequestEvent,
        recovery_point_writer: RecoveryPointWriter<u64, AptosHistoryPoint>,
    ) -> Result<(), Self::Error> {
        let callback = callback.expect("empty vrf transaction"); // the VRF transaction can never be None for Aptos

        let nonce = request_event.nonce;
        let chain_point = request_event.chain_point;

        // if, for some reason, the nonce as already been processed by this free node, don't call the callback
        // it can happen because during catchup we re-fetch the block surrounding a missing nonce,
        // because the missing nonce could be in the same block as an already processed nonce.
        if self.recovery_point.has_nonce_been_processed(nonce) {
            info!("Aptos: Nonce {nonce} has already been processed, skipping");
            return Ok(());
        }

        let chain_secret_key = &self.chain_secret_key_hex;

        let mut account = Account::from_secret_key(chain_secret_key.clone())?;
        let sequence_number: u64 = self.aptos_client.get_seq_num(&account).await?;

        self.aptos_client
            .generate_callback(
                &mut account,
                &request_event,
                sequence_number,
                callback.bls_signature,
            )
            .await
            .map(|_| ())?;

        recovery_point_writer.add_point(nonce, chain_point);
        Ok(())
    }

    async fn close_connector(&mut self) {}
}
