use crate::{types::EventTransaction, AptosConnectorError, AptosHistoryPoint};
use aptos_types::account_address::AccountAddress;
use common::chains::ChainId;
use common::VrfRequest;
use connectors::RequestEvent;
use socrypto::Hash;
use std::fmt::{Display, Formatter};
use std::time::Instant;

/// Aptos VRF Request Event
#[derive(Debug, Clone)]
pub struct AptosRequestEvent {
    pub(crate) event_data: EventTransaction,
    pub(crate) chain_point: AptosHistoryPoint,
    pub(crate) nonce: u64,
    pub(crate) message: Vec<u8>,
    pub(crate) chain_id: ChainId,
    pub(crate) callback: Vec<u8>,
    pub(crate) block_hash: Hash,
    pub(crate) tx_hash: Hash,
    pub(crate) reception_time: Instant,
}

impl Display for AptosRequestEvent {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "AptosRequestEvent {{ event_data: {:?}, chain_point: {:?}, nonce: {:?}, message: {:?}, chain_id: {:?}, callback: {:?}, block_hash: {:?} }}",
            self.event_data, self.chain_point, self.nonce, std::str::from_utf8(&self.message), self.chain_id, std::str::from_utf8(&self.callback), self.block_hash
        )
    }
}

impl RequestEvent for AptosRequestEvent {
    type CallerIdentifier = AccountAddress;
    type Error = AptosConnectorError;

    fn to_vrf_request(&self) -> Result<Option<VrfRequest>, Self::Error> {
        Ok(Some(VrfRequest {
            message: self.message.clone(),
            chain_id: self.chain_id,
            block_hash: self.block_hash.0.to_vec(),
            nonce: [self.nonce, 0, 0, 0],
            txhash: self.tx_hash.0.to_vec(),
        }))
    }

    fn get_tx_hash(&self) -> String {
        String::new()
    }

    fn short_log(&self) -> String {
        format!("nonce: {}, message: {:?}", self.nonce, self.message)
    }

    fn get_vrf_nonce(&self) -> u64 {
        self.nonce
    }

    fn get_reception_time(&self) -> Instant {
        self.reception_time
    }

    fn get_caller(&self) -> Self::CallerIdentifier {
        AccountAddress::from_hex_literal(&self.event_data.data.caller_address)
            .expect("invalid caller in event?!")
    }
}
