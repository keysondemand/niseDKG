use common::errors::VRFError;
use common::influx_metrics::Metrics;
use common::VrfClient;
pub use common::{chains::ChainId, VrfRequest};
use connectors::VrfTx;
use log::debug;
use nidkg_helper::nidkg::{BlsSignature, DleqProofGLOW};
use nidkg_helper::utils::combine_signatures;
use std::collections::BTreeMap;
use std::net::SocketAddr;
use std::sync::Arc;

#[derive(Clone)]
pub struct VrfConnector {
    client: Arc<VrfClient>,
    threshold: usize,
}

impl VrfConnector {
    pub async fn connect(
        vrf_rpc_addr: SocketAddr,
        backup_vrf_rpc_addr: SocketAddr,
    ) -> VrfConnector {
        let vrf_conn = VrfClient::new(vrf_rpc_addr, backup_vrf_rpc_addr);
        let committee_data = vrf_conn
            .get_committee_data()
            .await
            .expect("couldn't get committee data from VRF");

        VrfConnector {
            client: Arc::new(vrf_conn),
            threshold: committee_data.threshold_f,
        }
    }

    pub async fn send_request(&self, request: &VrfRequest) -> Result<VrfTx, VRFError> {
        let start = std::time::Instant::now();
        let callback = self.client.send_request(request).await?;
        Metrics::vrf_req_res_time(&request.chain_id, request.nonce[0], start);
        let mut valid_sig_list: BTreeMap<u64, BlsSignature> = BTreeMap::new();
        for (node_id, _, bls_signature, glow_proof) in &callback.signs {
            let Ok(gp) = DleqProofGLOW::try_from(glow_proof.as_slice()) else {
                continue;
            };
            let Ok(psig) = BlsSignature::try_from(bls_signature.as_slice()) else {
                continue;
            };
            let mut glow_sig_check = false;
            // TODO doing a string check right now, but we should implement eq
            if (psig.bls12381.sig_g1.to_string() == gp.nizk_g1_12381.0.h_x.to_string())
                && (psig.bls12381.sig_g2.to_string() == gp.nizk_g2_12381.0.h_x.to_string())
                && (psig.bn254.sig_g1.to_string() == gp.nizk_g1_254.0.h_x.to_string())
            // && (psig.bn254.sig_g2.to_string() == gp.nizk_g2_254.0.h_x.to_string())
            {
                glow_sig_check = true;
            }

            if gp.verify().is_ok() && glow_sig_check {
                valid_sig_list.insert(*node_id, psig);
            }
        }
        let bls_signature = combine_signatures(&valid_sig_list, self.threshold)
            .map_err(|_| VRFError::BlsSign("signature combination failed".to_string()))?;
        debug!("{:?}", bls_signature);
        Ok(VrfTx { bls_signature })
    }
}
