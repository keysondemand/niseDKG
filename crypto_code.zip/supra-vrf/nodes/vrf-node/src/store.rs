//! VRF Store Utilities

use common::{errors::ConfigError, VrfRequest};
use std::io::{BufWriter, Write};
use std::{collections::HashMap, fs};
use toml_edit::easy as toml;

use crate::data::VrfGenerateCallback;

const VRF_REQUESTS_FILE: &str = "vrf_request_logs.toml";
const VRF_REQUESTS_KEY: &str = "VRF_REQUESTS";

/// Stores a K-V pair in the VRF Store
pub fn store_key_value(filename: &str, key: Vec<u8>, value: Vec<u8>) {
    let key_str = String::from_utf8(key).unwrap();

    //read toml file
    let bytes: String = fs::read_to_string(filename).unwrap_or_else(|_| String::new());
    let mut content = toml::from_str::<toml::map::Map<String, toml::Value>>(&bytes).unwrap();
    //DKG store
    if key_str == sodkg::state::DKG_DATA_KEY {
        let data: sodkg::persistence::DkgData = bincode::deserialize(&value[..]).unwrap();
        let value = toml::to_string_pretty(&data).unwrap();
        content.insert(key_str, toml::Value::String(value));
    }

    let toml_string = toml::to_string(&content).expect("Could not encode TOML value");
    fs::write(filename, toml_string).expect("Could not write to file!");
}

/// Reads the VRF Store file
pub fn read_store(filename: &str) -> Option<toml::map::Map<String, toml::Value>> {
    fs::read_to_string(filename)
        .and_then(|bytes| {
            toml::from_str::<toml::map::Map<String, toml::Value>>(&bytes).map_err(|err| {
                log::error!("Error during store file read:{}", err);
                std::io::Error::new(std::io::ErrorKind::Other, "Toml error")
            })
        })
        .ok()
}

/// Appends a [`VrfGenerateCallback`] to the vrf requests log file
pub fn vrf_callback_log(vrf_generate_callback: &VrfGenerateCallback) {
    if !std::path::Path::new(VRF_REQUESTS_FILE).exists() {
        let res = fs::File::create(VRF_REQUESTS_FILE)
            .map_err(|err| format!("Error during create file:{err}"));
        if let Err(err) = res {
            log::error!("{}", err);
            return;
        }
    }

    let res = fs::OpenOptions::new()
        .write(true)
        .append(true)
        .open(VRF_REQUESTS_FILE)
        .map(|vrf_req_file| {
            let mut vrf_req_file = BufWriter::new(vrf_req_file);

            toml::Value::try_from(vrf_generate_callback.request.clone())
                .map(|value| {
                    let mut content: toml::map::Map<String, toml::Value> = toml::map::Map::new();
                    content.insert(
                        VRF_REQUESTS_KEY.to_string(),
                        toml::Value::Array(vec![value]),
                    );
                    toml::to_string(&content)
                        .map(|toml_string| {
                            write!(
                                vrf_req_file,
                                "
{toml_string}"
                            )
                        })
                        .map_err(|err| format!("Error during to_string Value of VRFRequest:{err}"))
                })
                .map_err(|err| format!("Error during try_from VRFRequest:{err}"))
        })
        .map_err(|err| format!("Error during open VRFRequest file as append mode:{err}"));

    if let Err(err) = res {
        log::error!("{}", err);
    }
}

/// Reads the vrf requests log file
pub fn get_vrf_callback_log() -> Result<Vec<VrfRequest>, ConfigError> {
    let bytes = fs::read_to_string(VRF_REQUESTS_FILE).map_err(|_| ConfigError::ReadFile {
        location: format!("{:?}", VRF_REQUESTS_FILE),
    })?;
    let content = toml::from_str::<toml::map::Map<String, toml::Value>>(&bytes)
        .map_err(ConfigError::ParseFile)?;
    let get_vrf_requests = content.get(VRF_REQUESTS_KEY);

    get_vrf_requests
        .map(|value| {
            let req_val_str = toml::Value::to_string(value);
            let req_val_str_rplc = req_val_str.replace("[[]]", "[[vrf_requests]]");
            let vrf_requests_map =
                toml::from_str::<HashMap<String, Vec<VrfRequest>>>(&req_val_str_rplc)
                    .map_err(ConfigError::ParseFile)?;
            vrf_requests_map
                .get("vrf_requests")
                .map(|vrf_request| Ok(vrf_request.to_vec()))
                .or_else(|| Some(Ok(vec![])))
                .unwrap()
        })
        .or_else(|| Some(Ok(vec![])))
        .unwrap()
}
