//! VRF Node Config and related Utilities

use crate::authsc::AuthScConfig;
use sodkg::config::DkgConfig;
use sodkg::load_dkg_config;
use std::env;
use std::env::VarError;
use std::net::Ipv4Addr;
use std::net::SocketAddr;

/// The default file for VRF node persistent storage
pub const STORE_FILE_NAME: &str = "vrf_store.toml";

/// The VRF node configuration
#[derive(Debug, Clone)]
pub struct VrfNodeConfig {
    /// f+1 value
    pub dkgconfig: DkgConfig,
    /// Bootstrap node address (Optional)
    pub bootstrap_addr: Option<SocketAddr>,
    /// node address use to bind network.
    pub node_bind_addr: SocketAddr,
    /// node address use to connect to.
    pub node_public_addr: SocketAddr,
    /// SMR nodes rpc addresses
    pub smr_nodes_rpc: Vec<SocketAddr>,
    /// RPC node address
    pub rpc_node_addr: SocketAddr,
    /// DKB data store file name
    pub store_filename: String,
    /// Auth SC configuration
    pub authsc: AuthScConfig,
}

/// Loads the VRF Node Configuration
pub fn load_vrf_config() -> VrfNodeConfig {
    //load parameters from conf
    //node bind address
    let node_bind_addr = env::var("NODE_BIND_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map_err(|_| {
                log::warn!(
                    "Provided NODE_BIND_ADDR:{} not recognized. use default 127.0.0.1:25200",
                    s
                );
                VarError::NotPresent
            })
        })
        .unwrap_or_else(|_| SocketAddr::from((Ipv4Addr::new(127, 0, 0, 1), 25_200)));

    //node public address
    let node_public_addr = env::var("NODE_PUBLIC_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map_err(|_| {
                log::warn!(
                    "Provided NODE_PUBLIC_ADDR:{} not recognized. use default bind address",
                    s
                );
                VarError::NotPresent
            })
        })
        .unwrap_or(node_bind_addr);

    let smr_nodes_rpc = env::var("SMR_NODE_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map(|a| vec![a]).map_err(|_| {
                log::warn!("Provided SMR_NODE_ADDR:{} not recognized. exit", s);
                VarError::NotPresent
            })
        })
        .or_else(|_| {
            env::var("SMR_RPC_ACCESS").and_then(|s| {
                string_array_to_vec_of_address(&s).map_err(|_| {
                    log::warn!("Provided SMR_RPC_ACCESS:{} not recognized. exit", s);
                    VarError::NotPresent
                })
            })
        })
        .expect("SMR_NODE_ADDR or SMR_RPC_ACCESS not defined or not an IP address, exit");

    let rpc_node_addr = env::var("RPC_NODE_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map_err(|_| {
                log::warn!("Provided RPC_NODE_ADDR:{} not recognized. exit", s);
                VarError::NotPresent
            })
        })
        .expect("RPC_NODE_ADDR not defined or not an IP address, exit.");
    //Bootstrap node address Optional
    let bootstrap_addr = env::var("BOOTSTRAP_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map_err(|_| {
                log::warn!(
                    "Provided BOOTSTRAP_ADDR:{} not recognized. Start with no bootstrap",
                    s
                );
                VarError::NotPresent
            })
        })
        .ok();

    //node public address
    let store_filename =
        env::var("STORE_FILE_NAME").unwrap_or_else(|_| STORE_FILE_NAME.to_string());

    let authsc = crate::authsc::load_auth_config();

    VrfNodeConfig {
        dkgconfig: load_dkg_config(),
        bootstrap_addr,
        node_bind_addr,
        node_public_addr,
        smr_nodes_rpc,
        rpc_node_addr,
        store_filename,
        authsc,
    }
}

/// Transform a vec of IP addresses in a string ( like "[127.0.0.1:26200, 127.0.0.1:26201, 127.0.0.1:26202]") into a vector of SocketAddr
pub fn string_array_to_vec_of_address(
    array: &str,
) -> Result<Vec<SocketAddr>, std::net::AddrParseError> {
    array
        .trim_matches(|c| c == '[' || c == ']')
        .split(',')
        .map(|n| n.trim().parse())
        .collect()
}
