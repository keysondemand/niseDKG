use thiserror::Error;

// TODO(clippy): Remove Error Postfix
#[allow(clippy::enum_variant_names)]
#[derive(Error, Debug)]
pub enum VrfError {
    #[error("General err:{0}")]
    General(String),
    #[error("Error during P2P send:{0}")]
    P2PConnection(#[from] sop2p::P2PError),
    #[error("Error during SMR send Tx:{0}")]
    SmrCOnnection(#[from] smrhotstuffclient::SmrClientError),
    #[error("Error during bincode serialisation {0}")]
    BinecodeSer(#[from] Box<bincode::ErrorKind>),
    #[error("Error during partial signature verification err:{0}")]
    PartialSignVerification(String),
    #[error("Error request verification fail err:{0}")]
    RequestVerification(String),
}
