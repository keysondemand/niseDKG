# Vrf meeting

Mainnet needs:
 * latency: Max 2 to 4s Arbitrum (justbet) / Matic: 10 confirmation => 20s Dotchain / DFK Cleton 
 * gaz : 10 req second cost to much. 
 * volume: 8000 req per day. 2 to 3 per second per game. 4 services ready to use. => 10 to 20 tx per second better 50 total.
 * reliability: ask customer. justbet: majority of Tx under 4s. less than 1% upper than 4s and no missing. 

 New Feature deployed: number of confirmation to wait for.

 gaz price: to be define. Max cost they are able to pay and current version cost from testnet use. => to be done.


## Issues:
### Nonce management and callback tx error. 
 * one private key per fee node: back pressure because can't process the callback with one key. Need to wait until the response back from the rpc. too slow. Latency of the success RPC call.
 * Too many request error: need to wait.

 -> grouped callback reach the SC gaz limit fast.

 Solution:
  * Multiple private key: can send at the same time 2 callback with different keys.
  * Run RPC node: Running our own node can solve because the rpc node manage the nonce and tx.

#### Private key: 
   pro: 
    * easy to add / remove.
    * same security.
    * reliability with 2 free node.
    * can use public RPC.

   cons: 
    * account management. 
    * monitoring: key management

 Complexity on the automation side.
 We have to define the number of key we need.

#### RPC node:
  pro:
   * solve nonce and Tx pb in a more reliable way.

  cons:
   * no public RPC.
   * Sign point of failure need at least 2 RPC node.
   * monitoring is important.

#### remarks
Retry failure to manage. 

Private key solution to be increase but for now validate the concept to see how it works with simple logic.

=> for mainnet solution to be confirmed. Management is ok for mainnet.

RPC node can solve the pb too. A mix of both can be define depending of the blockchain.

### Gaz price
If the block is full the price rise. If the Tx gaz fee is less the tx is rejected. In case of this failure increase teh fee by 20% and resend. To be tested. 
Gaz manage IEP 1559 new allow to be aware of a gaz pb. The RPC and web3 client should be compatible. To be tested
Waste money if too high.

### VRF committee become committee
Don't verify the Tx. To be activated

### VRF RPC node connection
Need a RPC node connection that can be the same as Free node. Only read but need reliability.


# Main net
Need to monitor gaz fee.
Backup free node.
Key management and security.
Who pay the gaz?
White and black list. Drain gaz fee.
Infra, Automation process: be able to react fast: deployment and monitoring.


# Actions:
* Test private key if it solve the nonce pb.
* test RPC node with the nonce and perf pb for Arbritum. Valdiate the complexity to have a RPC node.
* bench the VRF committee for the number of Tx handled per second.
* Version deployment process not very clear. A hot fix is deployed in which version. The process should be define explicitly.
* Backup free node.
* Mainnet: Monitor current gaz use in Devnet to evaluate the cost on mainnet.
* Mainnet: Dev Gaz monitoring.
* Mainnet: Deploy the Abritum RPC node and validate the solution.
* Mainnet: define who is paying on mainnet.
* Mainnet: infra update: monitoring, deployment, update.
* Mainnet: While list development.



