// let params_vec = res.params.to_vec();
// let nonce = (params_vec.get(0)).context("nonce not found in event")?.value.clone();
// let chain_id = params_vec.get(1).context("chain_id not found in event")?.value.clone();
// let callerContract = params_vec.get(2).context("callerContract not found in event")?.value.clone();
// let functionName = params_vec.get(3).context("functionName not found in event")?.value.clone();
// let rngCount = params_vec.get(4).context("rngCount not found in event")?.value.clone();
// let clientSeed = params_vec.get(6).context("rngCount not found in event")?.value.clone();
// Ok(
//     (get_keccak_256_hash(&bhash,&nonce,&rngCount,&chain_id,&callerContract,&functionName, &clientSeed),
//      (bhash.into_token(), nonce,callerContract,functionName,rngCount, clientSeed)
//     )
// )

use crate::errors::VrfError;
use common::VrfCallback;
use sodkg::DleqProofGLOW;

use common::VrfRequest;
use socrypto::PublicKey;
use sodkg::BlsSignature;
use sosmr::DkgCommittee;
use std::collections::BTreeMap;
use tokio::sync::oneshot;

// async fn verify_request(
//     request: VrfRequest,
// ) -> Box<dyn Event<Data = VrfEventData, EventType = VrfEventType>> {
//     log::info!("connect bc to verify Request:{:?}", request);
//     todo!()
// }

pub struct VrfGenerateCallback {
    pub request: VrfRequest,
    pub threshold: usize,
    pub partial_sign_list: BTreeMap<PublicKey, (u64, BlsSignature, DleqProofGLOW)>,
    pub sender: oneshot::Sender<Result<VrfCallback, VrfError>>,
}

impl VrfGenerateCallback {
    pub fn new(
        request: VrfRequest,
        threshold: usize,
        sender: oneshot::Sender<Result<VrfCallback, VrfError>>,
    ) -> Self {
        VrfGenerateCallback {
            request,
            threshold,
            partial_sign_list: BTreeMap::new(),
            sender,
        }
    }

    pub fn add_partialsign(
        &mut self,
        dkg_committee: &DkgCommittee,
        node_id: PublicKey,
        signature: BlsSignature,
        proof: DleqProofGLOW,
    ) -> Result<bool, VrfError> {
        log::trace!(
            "VrfGenerateCallback add_partialsign for:{} nb parial sign:{}",
            node_id,
            self.partial_sign_list.len()
        );

        if self.partial_sign_list.contains_key(&node_id) {
            return Ok(false);
        }

        //verify the share is inside the committee
        let (node_number, public_share) = dkg_committee
            .committee
            .iter()
            .find(|node| node.identity == node_id)
            .map(|n| (n.node_number, n.public_share.to_owned()))
            .ok_or_else(|| {
                VrfError::PartialSignVerification(format!(
                    "Receive a partial sign from a node not in the committee. node:{node_id}"
                ))
            })?;

        // verify with the partial share proof.
        // TODO doing a string check right now, but we should implement eq
        // BlsPublicKey contains the 4 type of public key
        let partial_proof_res = (signature.bls12381.sig_g1.to_string()
            == proof.nizk_g1_12381.0.h_x.to_string())
            && (signature.bls12381.sig_g2.to_string() == proof.nizk_g2_12381.0.h_x.to_string())
            && (signature.bn254.sig_g1.to_string() == proof.nizk_g1_254.0.h_x.to_string())
            // && (signature.bn254.sig_g2.to_string() == proof.nizk_g2_254.0.h_x.to_string())
            && proof.verify().is_ok();

        let verification = public_share.map(|pk| {
            partial_proof_res
                && (pk.bls12381.pub_key_g1.tostring() == proof.nizk_g1_12381.0.g_x.tostring())
                && (pk.bls12381.pub_key_g2.tostring() == proof.nizk_g2_12381.0.g_x.tostring())
                && (pk.bn254.pub_key_g1.tostring() == proof.nizk_g1_254.0.g_x.tostring())
            // && (pk.bn254.pub_key_g2.tostring() == proof.nizk_g2_254.0.g_x.tostring())
        });
        match verification {
            None => Ok(false), //no partial pubkey
            Some(true) => {
                //verification ok
                self.partial_sign_list
                    .insert(node_id, (node_number, signature, proof));
                Ok(self.partial_sign_list.len() >= self.threshold)
            }
            //verification fail.
            Some(false) => Err(VrfError::PartialSignVerification(format!(
                "Partial signature verification fail for node:{node_id}"
            ))),
        }
    }
}

#[cfg(test)]
mod tests {
    // Note this useful idiom: importing names from outer (for mod tests) scope.
    use super::*;
    use crate::test::test_utils;
    use common::chains::ETH_DOMAIN;
    use sosmr::DkgCommittee;

    const DKG_COMMITTEE_1_NODE_0: &str = include!("test/vrf_store_dkg_1_node_0.toml");
    const DKG_COMMITTEE_1_NODE_1: &str = include!("test/vrf_store_dkg_1_node_1.toml");
    const DKG_COMMITTEE_2_NODE_0: &str = include!("test/vrf_store_dkg_2_node_0.toml");

    // test add_partialsign method:
    // Given: self.threshold of 2, a committee with 3 nodes, node id, bls signature and proof, self.partial_sign_list empty
    // 1) call with a good sign and proof : Ok (false)
    // 2) call with a good sign bad proof : Err(err)
    // 3) call with bad sign, good proof: Err(err)
    // 4) call with a node id (good sign and prooff) not in the commitee: Err(err)
    // 5) call 2 time the same node-id sign prof: Ok(false), Ok(false)
    // 6) call 2 time with right node and good sign,proof : Ok(false), Ok(true)
    // 7) call 3 time 1. with right node and good sign,proof, 2. with other node id and bad sign and 3. other node id and sign,proof : Ok(false), Err(), Ok(true)
    #[test]
    fn test_add_partialsign_1() {
        let (tx, _rx) = oneshot::channel();
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let mut vrf_generate_callback = VrfGenerateCallback {
            request: vrf_request.clone(),
            threshold: 2,
            partial_sign_list: BTreeMap::new(),
            sender: tx,
        };

        let dkg_committee: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_0);
        let node_id = dkg_committee.committee[0].identity;

        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee.bls_privkey);
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id, signature, proof);

        assert!(&partial_sign.is_ok());
        assert!(!&partial_sign.unwrap());
    }

    // 2) call with a good sign, bad proof : Err(err)
    #[test]
    fn test_add_partialsign_2() {
        let (tx, _rx) = oneshot::channel();
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let mut vrf_generate_callback = VrfGenerateCallback {
            request: vrf_request.clone(),
            threshold: 2,
            partial_sign_list: BTreeMap::new(),
            sender: tx,
        };

        let dkg_committee: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_0);
        let node_id = dkg_committee.committee[0].identity;

        // good sign and proof
        let (signature, _proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee.bls_privkey);

        // bad sign and proof (different committee sign, proof)
        let dkg_committee_2: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_2_NODE_0);
        let (_signature_2, proof_2) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee_2.bls_privkey);
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id, signature, proof_2);

        assert!(&partial_sign.is_err());
    }

    // 3) call with bad sign, good proof: Err(err)
    #[test]
    fn test_add_partialsign_3() {
        let (tx, _rx) = oneshot::channel();
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let mut vrf_generate_callback = VrfGenerateCallback {
            request: vrf_request.clone(),
            threshold: 2,
            partial_sign_list: BTreeMap::new(),
            sender: tx,
        };

        let dkg_committee: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_0);
        let node_id = dkg_committee.committee[0].identity;

        // good sign and proof
        let (_signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee.bls_privkey);

        // bad sign and proof (different committee sign, proof)
        let dkg_committee_2: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_2_NODE_0);
        let (signature_2, _proof_2) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee_2.bls_privkey);
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id, signature_2, proof);

        assert!(&partial_sign.is_err());
    }

    // 4) call with a node id (good sign and prooff) not in the commitee: Err(err)
    #[test]
    fn test_add_partialsign_4() {
        let (tx, _rx) = oneshot::channel();
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let mut vrf_generate_callback = VrfGenerateCallback {
            request: vrf_request.clone(),
            threshold: 2,
            partial_sign_list: BTreeMap::new(),
            sender: tx,
        };

        let dkg_committee: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_0);

        // define different committee node_id
        let dkg_committee_2: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_2_NODE_0);
        let node_id = dkg_committee_2.committee[4].identity;

        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee_2.bls_privkey);
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id, signature, proof);

        assert!(&partial_sign.is_err());
    }

    // 5) call 2 time the same node-id sign prof: Ok(false), Ok(false)
    #[test]
    fn test_add_partialsign_5() {
        let (tx, _rx) = oneshot::channel();
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let mut vrf_generate_callback = VrfGenerateCallback {
            request: vrf_request.clone(),
            threshold: 2,
            partial_sign_list: BTreeMap::new(),
            sender: tx,
        };

        let committee: DkgCommittee = test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_0);
        let node_id = committee.committee[0].identity;

        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &committee.bls_privkey);

        // first call - with right node and good sign,proof
        let partial_sign =
            vrf_generate_callback.add_partialsign(&committee, node_id, signature, proof);
        assert!(&partial_sign.is_ok());
        assert!(!&partial_sign.unwrap());

        // second call - with same node and good sign,proof
        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &committee.bls_privkey);
        let partial_sign =
            vrf_generate_callback.add_partialsign(&committee, node_id, signature, proof);
        assert!(&partial_sign.is_ok());
        assert!(!&partial_sign.unwrap());
    }

    // 6) call 2 time with right node and good sign,proof : Ok(false), Ok(true)
    #[test]
    fn test_add_partialsign_6() {
        let (tx, _rx) = oneshot::channel();
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let mut vrf_generate_callback = VrfGenerateCallback {
            request: vrf_request.clone(),
            threshold: 2,
            partial_sign_list: BTreeMap::new(),
            sender: tx,
        };

        let dkg_committee: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_0);
        let node_id = dkg_committee.committee[0].identity;

        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee.bls_privkey);

        // first call - with 1st node and good sign,proof
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id, signature, proof);
        assert!(&partial_sign.is_ok());
        assert!(!&partial_sign.unwrap());

        // second call - with 2nd node and good sign,proof
        let dkg_committee_node_1: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_1);
        let node_id_2 = dkg_committee.committee[1].identity;
        let (signature_2, proof_2) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee_node_1.bls_privkey);
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id_2, signature_2, proof_2);
        assert!(&partial_sign.is_ok());
        assert!(&partial_sign.unwrap());
    }

    // 7) call 3 time 1. with right node and good sign,proof, 2. with other node id and bad sign and 3. other node id and sign,proof : Ok(false), Err(), Ok(true)
    #[test]
    fn test_add_partialsign_7() {
        let (tx, _rx) = oneshot::channel();
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let mut vrf_generate_callback = VrfGenerateCallback {
            request: vrf_request.clone(),
            threshold: 2,
            partial_sign_list: BTreeMap::new(),
            sender: tx,
        };

        let dkg_committee: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_0);
        let node_id = dkg_committee.committee[0].identity;

        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee.bls_privkey);

        // first call - with right node and good sign,proof
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id, signature, proof);
        assert!(&partial_sign.is_ok());
        assert!(!&partial_sign.unwrap());

        // second call - with other node id and bad sign,proof
        let dkg_committee_2: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_2_NODE_0);
        let node_id_2 = dkg_committee.committee[0].identity;
        let (signature_2, proof_2) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee_2.bls_privkey);
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id_2, signature_2, proof_2);
        assert!(&partial_sign.is_ok());

        // third call - other node id and good sign,proof
        let dkg_committee_node_1: DkgCommittee =
            test_utils::get_test_dkg_committee(DKG_COMMITTEE_1_NODE_1);
        let node_id_3 = dkg_committee.committee[1].identity;
        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee_node_1.bls_privkey);
        let partial_sign =
            vrf_generate_callback.add_partialsign(&dkg_committee, node_id_3, signature, proof);
        assert!(&partial_sign.is_ok());
        assert!(&partial_sign.unwrap());
    }
}
