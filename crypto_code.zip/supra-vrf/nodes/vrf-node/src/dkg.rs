use crate::ElGamalPrivateKey;
use futures::stream::FuturesOrdered;
use futures::stream::FuturesUnordered;
use futures::StreamExt;
use smrhotstuffclient::HotstuffSmrClient;
use socrypto::SecretKey;
use sodkg::config::DkgConfig;
use sodkg::state::DkgEvent;
use soruntime::state::Action;
use soruntime::state::Event;
use sosmr::DkgCommittee;
use sosmr::{SmrDkgType, SmrTransactionProtocol, TxExecutionStatus};
use std::net::SocketAddr;
use tokio::sync::mpsc;

pub async fn dkg_run_loop(
    node_priv_key: SecretKey,
    node_elgamal_secret_key: ElGamalPrivateKey,
    smr_nodes_rpc: Vec<SocketAddr>,
    dkgconfig: DkgConfig,
    committee_sender: mpsc::Sender<DkgCommittee>,
) {
    let smr_client = HotstuffSmrClient::with_rpc_access(smr_nodes_rpc).await;
    let mut block_receiver = smr_client.subscribe_blocks().await;

    //ordered because SMT Tx processing must be processed in receive order.
    let mut event_process_futures = FuturesOrdered::new();
    let mut fetch_batch_tx_return_futures = FuturesUnordered::new();

    let mut action_exec_futures = FuturesUnordered::new();

    //Bootstrap DKG
    log::trace!("VRF run_loop start waiting for Publish Tx.");
    let res = smr_client
        .bottstrap_dkg(
            &node_priv_key,
            &node_elgamal_secret_key,
            SmrDkgType::Vrf,
            dkgconfig,
            &mut block_receiver,
        )
        .await;
    let mut event_processor = match res {
        Ok((new_event_processos, actions)) => {
            if !actions.is_empty() {
                actions.into_iter().for_each(|action| {
                    action_exec_futures.push(futures::future::ready(action));
                });
            }
            new_event_processos
        }
        Err(err) => {
            log::error!(
                "Error during DKG restarting using publish tx:{}. Exit process",
                err
            );
            return;
        }
    };

    //start loop
    log::trace!("start run loop");

    loop {
        tokio::select! {
            //SMR Tx processing
            Some(block) = block_receiver.recv() => {
                let loop_smr_client = smr_client.clone();
                let fetch_tx_list_handle = tokio::spawn(async move {
                    //log::trace!("receive block batch len:{}",batches.len());
                    match loop_smr_client.fetch_batch_for_protocol(&block, SmrTransactionProtocol::Dkg(SmrDkgType::Vrf)).await {
                        Ok(batches) => Some(batches
                        .into_iter()
                        .flat_map(|batch| {
                             batch.into_iter_tx().filter_map(|(status, tx)| (status == TxExecutionStatus::Success).then_some(tx))
                                 .filter_map(|tx| {
                                     log::trace!("DKG Run_loop Proceed received Success tx with for round:{} type:{:?}"
                                         , block.round, tx.tx_sub_type,);
                                         match sodkg::transaction::convert_received_smrtx_to_event(&tx, block.round) {
                                             Ok(event) => Some(event),
                                             Err(err) => {
                                                 log::warn!("Error during smr tx convertion in event:{err}");
                                                 None
                                             },
                                         }
                                 }).collect::<Vec<DkgEvent>>()
                        }).collect::<Vec<DkgEvent>>()),
                        Err(err) => {
                            log::warn!("Error during fetching Batch from SMR :{err}");
                            None
                         },
                    }
                });
                fetch_batch_tx_return_futures.push(fetch_tx_list_handle);
            }
            //get fetched events from blocks
            Some(res) = fetch_batch_tx_return_futures.next() => {
                match res {
                    Ok(Some(events)) => events.into_iter().for_each(|event| event_process_futures.push_back(futures::future::ready(event))),
                    Ok(None) => (), //error already logged
                    Err(err) => log::warn!("Error during fetching Batch Tx from SMR task execution :{err}"),
                }
            }

            //process receive event future
            Some(event) = event_process_futures.next() => {
                log::trace!("Run_loop Proceed event:{}", event.event_type());
                let actions = event_processor.process_event(Box::new(event));
                actions.into_iter().for_each(|action| {
                    action_exec_futures.push(futures::future::ready(action));
                });
            }

            //execute action future
            Some(action) = action_exec_futures.next() => {
                log::trace!("DKG Run_loop Proceed action");
                if let Action::SendEventOut(event) = action {
                    let event = event.data();
                    if let sodkg::state::DkgEventData::Committee(ref dkgdata) = event {
                        let committee = dkgdata.clone();
                        log::trace!("VRF run_loop new DKG committee set bls publickey:{:?}", committee.bls_privkey.public_key());
                        if let Err(err) = committee_sender.send(committee).await {
                            log::warn!("Error during sending new DKG on dkg channel:{}", err);
                        }
                    }

                } else if let Action::SendSMRTx(tx)  = action{
                    log::trace!(
                        "manage_action send tx sender:{} type:{:?} signature:{}",
                        tx.sender,
                        tx.tx_sub_type,
                        hex::encode(tx.get_signature().flatten())
                    );
                    let loop_smr_client = smr_client.clone();
                    tokio::spawn(async move {
                        if let Err(err) = loop_smr_client.send_tx(tx).await{
                            log::warn!("Error during sending Tx to Smr:{}", err);
                        }
                    });
                }
            }
        }
    }
}
