//torun: RUST_LOG=vrf_node,sodkg=trace RUST_BACKTRACE=1 THRESHOLD_NUMBER=3 SMR_NODE_ADDR=127.0.0.1:25000 RPC_NODE_ADDR=127.0.0.1:26000 MIN_NUMBER_OF_NODE=5 cargo run --bin vrf-node

use connectors::vrf_config::VrfConfig as BlockChainConnectorConfig;
use dotenv::dotenv;
use socrypto::SecretKey;
use sodkg::ElGamalPrivateKey;
use std::env;
use std::env::VarError;
use std::sync::Arc;

#[tokio::main]
async fn main() {
    env_logger::init();
    dotenv().ok();

    //Node private Key
    let node_priv_key = env::var("B64_NODE_PRIVATE_KEY")
        .and_then(|encoded_priv| {
            SecretKey::decode_base64(&encoded_priv).map_err(|_| VarError::NotPresent)
        })
        .or_else(|_| {
            env::var("NODE_PRIVATE_KEY").and_then(|encoded_priv| {
                let bytes: &[u8] = &hex::decode(encoded_priv).unwrap();
                SecretKey::try_from(bytes).map_err(|_| VarError::NotPresent)
            })
        })
        .unwrap_or_else(|_| {
            //TODO remove and return an error. Only for test
            let key = SecretKey::generate();
            let node_public_key = socrypto::PublicKey::try_from(&key).unwrap(); //should not panic other the node should stop.

            log::info!(
                "B64_NODE_PRIVATE_KEY or NODE_PRIVATE_KEY var not defined. Generate a new one:{}",
                key.encode_base64()
            );
            log::info!("Generated public key:{}", node_public_key.encode_base64());
            key
        });

    let node_elgamal_secret_key = env::var("B64_NODE_ELGAMAL_PRIVATE_KEY")
        .and_then(|encoded_priv| {
            ElGamalPrivateKey::decode_base64(&encoded_priv).map_err(|_| VarError::NotPresent)
        })
        .or_else(|_| {
            env::var("NODE_ELGAMAL_PRIVATE_KEY").and_then(|encoded_priv| {
                ElGamalPrivateKey::try_from(hex::decode(encoded_priv).unwrap())
                    .map_err(|_| VarError::NotPresent)
            })
        })
        .unwrap_or_else(|_| {
            let key = ElGamalPrivateKey::generate();
            log::info!(
                "B64_NODE_ELGAMAL_PRIVATE_KEY or NODE_ELGAMAL_PRIVATE_KEY var not defined. Generate a new one:{}",
                key.encode_base64()
            );
            key
        });

    let node_config = vrf_node::config::load_vrf_config();

    let blockchain_connector_config =
        Arc::new(BlockChainConnectorConfig::new(None).load().unwrap());

    vrf_node::start_node(
        node_priv_key,
        node_elgamal_secret_key,
        node_config,
        blockchain_connector_config,
    )
    .await;
}
