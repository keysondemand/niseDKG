//! The VRF Node. Responsible for Distributed Key Generation and VRF generation.
#![warn(missing_docs)]

use connectors::vrf_config::VrfConfig as BlockChainConnectorConfig;
use socrypto::SecretKey;
use sodkg::ElGamalPrivateKey;
use std::sync::Arc;

pub mod authsc;
mod blockchain;
pub mod config;
mod data;
mod dkg;
mod errors;
mod message;
mod rpc;
mod run_loop;
pub mod store;

#[cfg(test)]
mod test;

/// Start a VRF node
pub async fn start_node(
    node_priv_key: SecretKey,
    node_elgamal_secret_key: ElGamalPrivateKey,
    node_config: config::VrfNodeConfig,
    blockchain_connector_config: Arc<BlockChainConnectorConfig>,
) {
    crate::run_loop::run(
        node_priv_key,
        node_elgamal_secret_key,
        node_config,
        blockchain_connector_config,
    )
    .await;
}
