//TODO timeout to purge pending request
//DKG data integration in VRF. init from file and end dkg nitif.
//RPC client.

use crate::config::VrfNodeConfig;
use crate::data::VrfGenerateCallback;
use crate::errors::VrfError;
use crate::message::MessageSender;
use crate::message::VRFMessage;
use crate::rpc::{RpcContent, RpcVrfServer};
use crate::store::vrf_callback_log;
use common::SerdeCommitteeData;
use common::VrfCallback;
use connectors::vrf_config::VrfConfig as BlockChainConnectorConfig;
use futures::stream::FuturesUnordered;
use futures::StreamExt;
use socrypto::Hash;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::ElGamalPrivateKey;
use sop2p::serialize::serialize;
use sop2p::PeerEvent;
use sosmr::DkgCommittee;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::mpsc;
use toml_edit::easy as toml;

const DEFAULT_REQUEST_TIMEOUT_IN_MILLI: Duration = Duration::from_millis(5000);

pub async fn run(
    node_priv_key: SecretKey,
    node_elgamal_secret_key: ElGamalPrivateKey,
    node_config: VrfNodeConfig,
    #[allow(unused_variables)] blockchain_connector_config: Arc<BlockChainConnectorConfig>,
) {
    let node_public_key = PublicKey::try_from(&node_priv_key).unwrap(); //should not panic other the node should stop.
    log::info!("Vrf node start node:{}", node_public_key);

    //Manage AuthSc Access
    #[cfg(feature = "use_auth")]
    let node_network_manager = {
        let auth_maker =
            auth_sc_connector::p2p::SmrAuthManager::new(auth_sc_connector::AuthScNetwork::VRF);
        sop2p::new_async_with_auth(
            node_config.node_bind_addr,
            node_config.node_public_addr,
            node_priv_key.clone(),
            node_config.bootstrap_addr,
            auth_maker,
        )
        .await
        .unwrap()
    };
    #[cfg(not(feature = "use_auth"))]
    let node_network_manager = sop2p::new_async(
        node_config.node_bind_addr,
        node_config.node_public_addr,
        node_priv_key.clone(),
        node_config.bootstrap_addr,
    )
    .await
    .unwrap();

    let p2p_sender = MessageSender::new(node_network_manager.get_command_sender());
    let mut receiver = node_network_manager.subscribe_to_event();

    //init RPC
    let (rpc_tx, mut rpx_rx) = mpsc::channel(100);
    let _rpc_handle = RpcVrfServer::spawn(node_config.rpc_node_addr, rpc_tx);

    //async collection
    //let mut action_exec_futures = FuturesUnordered::new();
    let mut signed_request_handle_futures = FuturesUnordered::new();
    let mut process_request_futures = FuturesUnordered::new();
    let mut sign_request_return_futures = FuturesUnordered::new();

    //Local variable
    let mut committee: Option<DkgCommittee> = None;
    let mut current_pending_request: HashMap<Hash, (Instant, VrfGenerateCallback)> = HashMap::new();

    //init DKG state
    //load persisted committee
    let (committee_sender, mut committee_rcv) = mpsc::channel(100);
    match crate::store::read_store(&node_config.store_filename)
        .and_then(|mut list| list.remove(sodkg::state::DKG_DATA_KEY))
        .and_then(|val| {
            if let toml::Value::String(content) = val {
                toml::from_str::<sodkg::persistence::DkgData>(&content).map(|pers| DkgCommittee::from(&pers)).map_err(|err| {
                    log::error!("Can't read DkgCommittee persisted data. Not committee data, wait for a new DKG");
                    err
                }).ok()
            } else {
                log::error!(
                    "Can't read DkgCommittee persisted data. Not a String, wait for a new DKG"
                );
                None
            }
        }) {
            Some(c) => {
                log::info!("Set DKG committee from file");
                committee = Some(c)},
            None => {
                log::info!("Start DKG committee definition from SMR.");
                let prikey = node_priv_key.clone();
                let dkg_conf= node_config.dkgconfig.clone();
                tokio::spawn(async move {
                    crate::dkg::dkg_run_loop(
                        prikey,
                        node_elgamal_secret_key,
                        node_config.smr_nodes_rpc,
                        dkg_conf,
                        committee_sender,
                    ).await;
                });
            }

        }

    //Request timeout timer
    let mut request_timer = tokio::time::interval(DEFAULT_REQUEST_TIMEOUT_IN_MILLI / 2); //verify every half desired max time.

    //start loop
    log::trace!("start run loop");

    loop {
        tokio::select! {
            _ = request_timer.tick() => {
                 //trace!("Peer {bind_ip} tick");
                //get all pending request and compare request Ts with current time.
                let timeout_ids: Vec<Hash> = current_pending_request.iter().filter_map(|(req_id, (instant, _))| {
                    (instant.elapsed() > DEFAULT_REQUEST_TIMEOUT_IN_MILLI).then_some(*req_id)
                }).collect();
                timeout_ids.into_iter().for_each(|req_id| if let Some((_, reqgen)) = current_pending_request.remove(&req_id) {
                    log::warn!("Vrf request timout error:{}", req_id);
                    if reqgen.sender.send(Err(VrfError::General("Request timeout".to_string()))).is_err() {
                        log::warn!("Oneshot return Channel error distant connection closed");
                    }
                });
            }
            //DKG committee update
            Some(c) = committee_rcv.recv() => {
                log::info!("DKG committee done from SMR.");
                committee = Some(c)
            }

            //New request arrive from RPC
            Some(content) = rpx_rx.recv() =>{
                match content {
                    RpcContent::VrfRequest(request, oneshot) => {
                //forward request to other nodes
                        match committee {
                            Some(ref committee) =>{
                                log::trace!(
                                    "Receive Free Node request:{} for chain:{} tx_hash:{}",
                                    request.get_id(),
                                    request.chain_id,
                                    hex::encode(&request.txhash)
                                );
                                //send request to other nodes
                                let message = VRFMessage::Request(request.clone());
                                 p2p_sender
                                .send_message_to_connected_peers(serialize(message).to_vec())
                                .await; //use a channel. Spawn not needed.

                                //process request locally
                                process_request_futures.push(futures::future::ready((None, committee.bls_privkey.clone(), request.clone())));

                                //save request
                                current_pending_request.insert(
                                    request.get_id(),
                                    (
                                        Instant::now(),
                                        VrfGenerateCallback::new(request, node_config.dkgconfig.threshold_f, oneshot),
                                    ),
                                );                            },
                            None => {
                                log::warn!("receive Request with DKG note done.");
                                if let Err(err) = oneshot.send(Err(VrfError::General("DKG not done".to_string()))){
                                    log::error!("Channel error during sending back callback:{err:?}");
                                }
                            }
                        }
                    },
                    RpcContent::CommitteePubkey(oneshot) => {

                        if oneshot.send(committee.as_ref().map(|c| {
                            SerdeCommitteeData{
                                    committee_pubkey: c.threshold_pubkey.into_bytes(),
                                    threshold_f: node_config.dkgconfig.threshold_f,
                                    min_number_of_node: node_config.dkgconfig.min_number_of_node,
                                    nb_dealer: node_config.dkgconfig.nb_dealer,
                                    dealer_threshold_g: node_config.dkgconfig.dealer_threshold_g,
                            }
                        })).is_err(){
                            log::warn!("Oneshot return Channel error distant connection closed");
                        }
                    },
                }
            },
            //New message arrive from P2P
            msg = receiver.recv() => {
                match msg {
                    Ok(msg) => match msg {
                        PeerEvent::NewPeerConnected(_) =>(),
                        PeerEvent::MessageReceived(peer, bytes) => {
                            let bytes = bytes.to_vec();
                            //log::trace!("PeerEvent::MessageReceived:{:?}", bytes);

                            let message = sop2p::serialize::deserialize(&bytes.into());
                            match message {
                                Ok(VRFMessage::Request(request)) => {
                                    log::trace!("receive VRFMessage::VrfRequest:{} chain_id:{} from:{}", request.get_id(), request.chain_id, peer.pubkey);
                                    //sign teh request an send it back.
                                    match committee {
                                        Some(ref commitee) =>{
                                            process_request_futures.push(futures::future::ready((Some(peer), commitee.bls_privkey.clone(), request)));
                                        }
                                        None => {
                                            log::warn!("receive message Request with DKG not done.");
                                            //send error to sender node
                                            let message = VRFMessage::SignError(request.get_id());
                                             p2p_sender
                                            .send_message_to_peer(peer.pubkey, serialize(message).to_vec())
                                            .await; //use a channel. Spawn not needed.
                                        }
                                    };

                                }
                                Ok(VRFMessage::SignCallback(req_id, sign, proof)) => {
                                    log::trace!("receive VRFMessage::VrfSignCallback:{} from:{}", req_id, peer.pubkey);
                                    sign_request_return_futures.push(futures::future::ready((peer.pubkey, req_id, sign, proof)));
                                }
                                //if an error occurs during peer sign wait for other sign or timeout if not enough sign succeed
                                Ok(VRFMessage::SignError(req_id)) => {
                                    let get_pending_request = current_pending_request.get(&req_id);
                                    if let Some((_, vrf_generate_callback)) = get_pending_request { vrf_callback_log(vrf_generate_callback); }
                                    log::warn!("receive an error during peer node:{} request sign processing for req id:{}",peer.pubkey , req_id);
                                }
                                Err(err) => log::warn!("VRF node error during P2P msg deserialization:{err}"),
                            }
                        }
                        PeerEvent::PeerConnectionError(addr) => {
                            log::warn!("Receive Connection error on peer:{addr} ");
                        }
                        PeerEvent::PeerUnreachable(addr) => {
                            log::warn!("Peer:{addr} Disconnected");
                        }
                    },
                    Err(err) => {
                        log::error!("VRF node error during receiving message:{:?}", err);
                        break;
                    }
                }
            },
            //return from the request sign execution.
            Some(res) = signed_request_handle_futures.next() => {
                match res {
                    Ok((req_id, peer, Ok((sign, proof)))) => {
                        log::trace!("return Ok from the request sign execution: req_id:{req_id}");
                        match peer {
                            Some(peer) => {
                                let message = VRFMessage::SignCallback(req_id, sign, proof);
                                p2p_sender
                                .send_message_to_peer( peer, serialize(message).to_vec())
                                .await; //use a channel. Spawn not needed.
                            }
                            None => sign_request_return_futures.push(futures::future::ready((node_public_key, req_id, sign, proof))),
                        }
                    }
                    Ok((req_id, peer, Err(err))) => {
                         log::trace!("return Err from the request sign execution: req_id:{req_id}. peer:{} err:{err}", peer.as_ref().unwrap_or(&node_public_key));
                         let get_pending_request = current_pending_request.get(&req_id);
                         if let Some((_,vrf_generate_callback)) = get_pending_request { vrf_callback_log(vrf_generate_callback); }
                         log::error!("Error request:{} verification fail:{err} for peer:{}", req_id, peer.as_ref().unwrap_or(&node_public_key));
                         match peer {
                             Some(peer) => {
                                let message = VRFMessage::SignError(req_id);
                                p2p_sender
                                .send_message_to_peer(peer, serialize(message).to_vec())
                                .await; //use a channel. Spawn not needed.
                            }
                            None => {
                                //remove request from list and send back error
                                if let Some((_, reqgen)) = current_pending_request.remove(&req_id) {
                                    if reqgen.sender.send(Err(VrfError::General("Request verification fail".to_string()))).is_err() {
                                        log::warn!("Oneshot return Channel error distant connection closed");
                                    }
                                }
                            },
                        }
                    }
                    Err(err) => log::error!("Error during sign processing :{err}"),
                }
            }
            //new request sign arrive
            Some((pubkey, req_id, sign, proof)) = sign_request_return_futures.next() => {
                log::trace!("new request:{req_id} sign arrive from:{pubkey}.");
                let Some(ref committee) = committee else {
                            log::error!("Error get sign but DKG not done");
                            continue;
                        };
                let send_callback = current_pending_request.get_mut(&req_id).map(|(_, reqgen)|
                    reqgen.add_partialsign(committee, pubkey, sign, proof).unwrap_or_else(|err| {
                        log::warn!("Request:{req_id} partial sign from node:{pubkey} verification fail because:{}.", err);
                        false
                    })).unwrap_or(false);
                if send_callback {
                    let (_, reqgen) = current_pending_request.remove(&req_id).unwrap(); //unwrap ok test just before.
                    log::trace!(
                        "Send back collected sign for request:{} for chain:{} tx_hash:{}",
                        req_id,
                        reqgen.request.chain_id,
                        hex::encode(&reqgen.request.txhash)
                    );
                    let callback = VrfCallback::new(
                        reqgen.request.txhash,
                        reqgen.request.block_hash,
                        reqgen.request.nonce,
                        reqgen.request.chain_id,
                        reqgen.partial_sign_list.into_iter().map(|(pk, (number, sign, proof))| (number, pk, sign, proof)).collect());
                    if reqgen.sender.send(Ok(callback)).is_err() {
                        log::warn!("Oneshot return Channel error distant connection closed");
                    }
                }
            }
            //do local request process: verify + sign
            Some((peer, bls_privkey, request)) = process_request_futures.next() => {
                let req_hash = request.get_id();
                let bls_priv_key = bls_privkey.clone();
                //verify the request and sign teh request in//
                let sign_req = request.clone();

                #[cfg(feature = "verify_tx")]
                let cloned_blockchain_connector_config = Arc::clone(&blockchain_connector_config);
                let sign_request_handle = tokio::spawn(async move {
                    #[cfg(feature = "verify_tx")]
                    let val = crate::blockchain::verify_vrf_request(&cloned_blockchain_connector_config, &sign_req).await;
                    #[cfg(not(feature = "verify_tx"))]
                    let val = crate::blockchain::verify_vrf_request().await;
                    let id = peer.as_ref().map(|p| p.pubkey).unwrap_or_else(|| node_public_key);
                    log::trace!("Peer:{} Verify request:{} from peer:{} return:{val:?}", node_public_key, request.get_id(), id);
                    let res = match val {
                        Ok(val) => val,
                        Err(err) => {
                            return (req_hash, peer.map(|p| p.pubkey), Err(VrfError::RequestVerification(format!("Error during request verification for peer:{id}, err:{err}."))));
                        }
                    };
                    if !res {
                        return (req_hash, peer.map(|p| p.pubkey), Err(VrfError::RequestVerification(format!("Request verification fail for peer:{id}."))));
                    }
                    let res = tokio::task::spawn_blocking(move || {
                        sign_req.sign_partial_bls(common::chains::ETH_DOMAIN.as_ref(), &bls_priv_key)
                    }).await.unwrap();
                    //log::trace!("RUN SIGN {node_public_key}, message:{:?} BLS:{:?} sign:{:?}", sign_req.message, bls_privkey.public_key(), res.0);
                    (req_hash, peer.map(|p| p.pubkey), Ok(res))
                });
                signed_request_handle_futures.push(sign_request_handle);
            }
        }
    }
}
