#[cfg(feature = "verify_tx")]
use {
    common::chains::ChainType, common::VrfRequest,
    connectors::vrf_config::VrfConfig as BlockChainConnectorConfig,
};

use common::errors::VRFError;

#[allow(unused_variables)]
#[cfg(feature = "verify_tx")]
pub async fn verify_vrf_request(
    blockchain_connector_config: &BlockChainConnectorConfig,
    request: &VrfRequest,
) -> Result<bool, VRFError> {
    match request.chain_id.get_chain_type() {
        #[cfg(feature = "eth")]
        ChainType::Evm => {
            Ok(eth_connector::verify_request(blockchain_connector_config, request).await?)
        }
        #[cfg(not(feature = "eth"))]
        ChainType::Evm => Ok(true),
        #[cfg(feature = "aptos")]
        ChainType::Aptos => {
            Ok(aptos_connector::verify_request(blockchain_connector_config, request).await?)
        }
        #[cfg(not(feature = "aptos"))]
        ChainType::Aptos => Ok(true),
        #[cfg(feature = "sui")]
        ChainType::Sui => {
            Ok(sui_connector::verify_request(blockchain_connector_config, request).await?)
        }
        #[cfg(not(feature = "sui"))]
        ChainType::Sui => Ok(true),
        #[cfg(feature = "mock_connector")]
        ChainType::DevMockChain => mock_verify_request().await,
    }
}

#[cfg(not(feature = "verify_tx"))]
pub async fn verify_vrf_request() -> Result<bool, VRFError> {
    Ok(true)
}

#[cfg(feature = "mock_connector")]
async fn mock_verify_request() -> Result<bool, VRFError> {
    use std::env;
    use std::time::Duration;
    let sleep_time = env::var("SIMULATED_FULL_NODE_RESPONSE_TIME")
        .map(|str| str.parse().unwrap())
        .unwrap_or(100);
    tokio::time::sleep(Duration::from_millis(sleep_time)).await;
    Ok(true)
}
