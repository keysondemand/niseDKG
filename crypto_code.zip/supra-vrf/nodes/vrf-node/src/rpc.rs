use crate::errors::VrfError;
use common::SerdeCommitteeData;
use common::VrfCallback;
use common::VrfRequest;
use std::net::SocketAddr;
use tokio::sync::mpsc;
use tokio::sync::oneshot;
use tokio::task::JoinHandle;
use warp::http::Response;
use warp::Filter;
use warp::Reply;

pub enum RpcContent {
    VrfRequest(VrfRequest, oneshot::Sender<Result<VrfCallback, VrfError>>),
    CommitteePubkey(oneshot::Sender<Option<SerdeCommitteeData>>),
}

pub struct RpcVrfServer;

impl RpcVrfServer {
    pub fn spawn(bind_address: SocketAddr, req_sender: mpsc::Sender<RpcContent>) -> JoinHandle<()> {
        tokio::spawn(async move {
            Self.run(bind_address, req_sender).await;
        })
    }

    /// Main loop responsible to accept incoming connections .
    async fn run(&self, bind_address: SocketAddr, request_sender: mpsc::Sender<RpcContent>) {
        let request_sender_clone = request_sender.clone();
        let generate_req = warp::post()
            .and(warp::path("rpc"))
            .and(warp::path("v1"))
            .and(warp::path("generate_rn"))
            .and(warp::path::end())
            .and(warp::body::content_length_limit(1024 * 512))
            .and(warp::body::bytes())
            .and(warp::any().map(move || request_sender_clone.clone()))
            .and_then(
                move |req_bytes: bytes::Bytes, req_sender: mpsc::Sender<RpcContent>| {
                    handler::generate_rn(req_bytes, req_sender)
                },
            );

        let pk_sender_clone = request_sender.clone();
        let get_committee_key_req = warp::get()
            .and(warp::path("rpc"))
            .and(warp::path("v1"))
            .and(warp::path("committee_sign"))
            .and(warp::path::end())
            .and(warp::any().map(move || pk_sender_clone.clone()))
            .and_then(move |req_sender: mpsc::Sender<RpcContent>| {
                handler::get_committee_key(req_sender)
            });

        let routes = generate_req
            .or(get_committee_key_req)
            .with(warp::cors().allow_any_origin());

        warp::serve(routes).run(bind_address).await;
    }
}

mod handler {
    use super::*;
    use std::convert::Infallible;

    pub async fn get_committee_key(
        tx_sender: mpsc::Sender<RpcContent>,
    ) -> Result<impl Reply, Infallible> {
        let (tx, rx) = oneshot::channel();
        if let Err(err) = tx_sender.send(RpcContent::CommitteePubkey(tx)).await {
            log::error!("Vrf Rpc send channel error:{}", err);
            return Ok(warp::reply::with_status(
                warp::reply::json(&serde_json::json!({
                    "message": "Internal error",
                })),
                warp::http::StatusCode::INTERNAL_SERVER_ERROR,
            )
            .into_response());
        }
        match rx.await {
            Ok(Some(committee)) => match committee.into_bytes() {
                Ok(c) => Ok(Response::builder()
                    .status(200)
                    .header("content-type", "application/octet-stream")
                    .body(c)
                    .into_response()),
                Err(err) => {
                    log::error!("Error during committee bytes serialization:{}", err);
                    Ok(warp::reply::with_status(
                        warp::reply::json(&serde_json::json!({
                            "message": "internal error"
                        })),
                        warp::http::StatusCode::SERVICE_UNAVAILABLE,
                    )
                    .into_response())
                }
            },
            Ok(None) => Ok(warp::reply::with_status(
                warp::reply::json(&serde_json::json!({
                    "message": "DKG not done"
                })),
                warp::http::StatusCode::INTERNAL_SERVER_ERROR,
            )
            .into_response()),
            Err(err) => {
                log::error!("Error oneshot channel fail:{}", err);
                Ok(warp::reply::with_status(
                    warp::reply::json(&serde_json::json!({
                        "message": "internal error"
                    })),
                    warp::http::StatusCode::SERVICE_UNAVAILABLE,
                )
                .into_response())
            }
        }
    }

    pub async fn generate_rn(
        req_bytes: bytes::Bytes,
        tx_sender: mpsc::Sender<RpcContent>,
    ) -> Result<impl Reply, Infallible> {
        //        match bincode::deserialize::<VrfRequest>(&req_bytes[..]) {
        match VrfRequest::try_from(&req_bytes[..]) {
            Ok(request) => {
                let (tx, rx) = oneshot::channel();
                if let Err(err) = tx_sender.send(RpcContent::VrfRequest(request, tx)).await {
                    log::error!("Vrf Rpc send channel error:{}", err);
                    return Ok(warp::reply::with_status(
                        warp::reply::json(&serde_json::json!({
                            "message": "Internal error",
                        })),
                        warp::http::StatusCode::INTERNAL_SERVER_ERROR,
                    )
                    .into_response());
                }
                match rx.await {
                    Ok(Ok(callback)) => match callback.into_bytes() {
                        Ok(res) => Ok(Response::builder()
                            .status(200)
                            .header("content-type", "application/octet-stream")
                            .body(res)
                            .into_response()),
                        Err(err) => {
                            log::error!("Error during callback serialization error:{}", err);
                            Ok(warp::reply::with_status(
                                warp::reply::json(&serde_json::json!({
                                    "message": "internal error"
                                })),
                                warp::http::StatusCode::INTERNAL_SERVER_ERROR,
                            )
                            .into_response())
                        }
                    },
                    Ok(Err(err)) => Ok(warp::reply::with_status(
                        warp::reply::json(&serde_json::json!({
                            "message": err.to_string()
                        })),
                        warp::http::StatusCode::INTERNAL_SERVER_ERROR,
                    )
                    .into_response()),

                    Err(err) => {
                        log::error!("Error oneshot channel fail:{}", err);
                        Ok(warp::reply::with_status(
                            warp::reply::json(&serde_json::json!({
                                "message": "internal error"
                            })),
                            warp::http::StatusCode::INTERNAL_SERVER_ERROR,
                        )
                        .into_response())
                    }
                }
            }
            Err(err) => {
                log::error!("Receive bad encoded request error:{}", err);
                Ok(warp::reply::with_status(
                    warp::reply::json(&serde_json::json!({
                        "message": "error bad request format"
                    })),
                    warp::http::StatusCode::INTERNAL_SERVER_ERROR,
                )
                .into_response())
            }
        }
    }
}
