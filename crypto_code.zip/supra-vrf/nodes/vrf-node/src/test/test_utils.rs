use crate::authsc::{load_auth_config, AuthScConfig};
use crate::config::{load_vrf_config, VrfNodeConfig, STORE_FILE_NAME};
use common::VrfRequest;
use sodkg::config::DkgConfig;
use sodkg::load_dkg_config;
use sosmr::DkgCommittee;
use std::env;
use toml_edit::easy as toml;

pub fn get_test_vrf_request() -> VrfRequest {
    VrfRequest {
        message: [
            35, 205, 30, 200, 104, 232, 9, 138, 171, 138, 142, 129, 101, 120, 149, 38, 165, 127,
            77, 78, 190, 20, 116, 171, 126, 193, 98, 185, 127, 62, 79, 223,
        ]
        .to_vec(),
        block_hash: bincode::serialize(
            "37e4cc3af781f26a67efff82b9e6f837c4c2cd908e82af77151990d28351d2dc",
        )
        .unwrap(),
        txhash: bincode::serialize(
            "e2b3ec186c3886b707fe4844f7577d87bfe5f7a6058f54530319595599d29098",
        )
        .unwrap(),
        nonce: [1, 0, 0, 0],
        chain_id: common::chains::ChainId::Anvil,
    }
}

pub fn get_test_dkg_committee(buffer: &str) -> DkgCommittee {
    let data = toml::from_str::<sodkg::persistence::DkgData>(buffer)
        .map(|pers| DkgCommittee::from(&pers))
        .map_err(|err| {
            log::error!(
                "Can't read DkgCommittee persisted data. Not committee data, wait for a new DKG"
            );
            err
        })
        .ok();
    data.unwrap()
}

pub fn vrf_config() -> VrfNodeConfig {
    env::set_var("NODE_PUBLIC_ADDR", "127.0.0.1:3050");
    env::set_var("SMR_RPC_ACCESS", "127.0.0.1:3051");
    env::set_var("NODE_BIND_ADDR", "127.0.0.1:3051");
    env::set_var("RPC_NODE_ADDR", "127.0.0.1:3052");
    env::set_var("BOOTSTRAP_ADDR", "127.0.0.1:3053");
    env::set_var("STORE_FILE_NAME", STORE_FILE_NAME);

    load_vrf_config()
}

pub fn dkg_config() -> DkgConfig {
    env::set_var("THRESHOLD_NUMBER", "5");
    env::set_var("MIN_NUMBER_OF_NODE", "6");
    env::set_var("NB_DEALERS", "3");
    env::set_var("DEALER_THRESHOLD", "1");

    load_dkg_config()
}

pub fn auth_config() -> AuthScConfig {
    env::set_var("AUTHSC_CLIENT_URL", "127.0.0.1:4050");
    env::set_var("AUTHSC_ADDRESS", "127.0.0.1:4051");

    load_auth_config()
}
