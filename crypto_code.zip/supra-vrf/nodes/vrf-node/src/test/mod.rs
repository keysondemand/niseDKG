use crate::config::{load_vrf_config, string_array_to_vec_of_address, STORE_FILE_NAME};
use crate::data::VrfGenerateCallback;

use crate::store::{get_vrf_callback_log, read_store, store_key_value, vrf_callback_log};
use crate::test::test_utils::{auth_config, dkg_config, vrf_config};
#[cfg(feature = "auth-sc-connector")]
use auth_sc_connector::p2p::load_auth_config;

use common::VrfRequest;

use serial_test::serial;

use std::env;
use std::net::SocketAddr;

use tokio::sync::oneshot;

pub mod test_utils;

#[test]
#[should_panic]
#[serial]
fn invalid_vrf_config_test() {
    env::remove_var("SMR_NODE_ADDR");
    env::remove_var("SMR_RPC_ACCESS");
    env::remove_var("RPC_NODE_ADDR");
    // env::remove_var("NODE_PUBLIC_ADDR");
    // env::remove_var("NODE_BIND_ADDR");
    // env::remove_var("BOOTSTRAP_ADDR");
    // env::remove_var("STORE_FILE_NAME");
    load_vrf_config();
}

#[test]
#[serial]
fn valid_dkg_config() {
    env::remove_var("THRESHOLD_NUMBER");
    env::remove_var("MIN_NUMBER_OF_NODE");
    env::remove_var("NB_DEALERS");
    env::remove_var("DEALER_THRESHOLD");

    let config = dkg_config();
    assert_eq!(config.threshold_f, 5);
    assert_eq!(config.min_number_of_node, 6);
    assert_eq!(config.nb_dealer, 3);
    assert_eq!(config.dealer_threshold_g, 1);
}

#[test]
#[serial]
fn valid_vrf_config_test() {
    let config = vrf_config();
    let node_bind_addr = "127.0.0.1:3051".parse::<SocketAddr>().unwrap();
    assert_eq!(config.node_bind_addr, node_bind_addr);
    assert!(config.bootstrap_addr.is_some());

    let smr_nodes_rpc = "127.0.0.1:3051".parse::<SocketAddr>().unwrap();
    let mut add_vec = vec![];
    add_vec.push(smr_nodes_rpc);
    assert_eq!(config.smr_nodes_rpc, add_vec);

    let rpc_node_addr = "127.0.0.1:3052".parse::<SocketAddr>().unwrap();
    assert_eq!(config.rpc_node_addr, rpc_node_addr);

    assert_eq!(config.store_filename, STORE_FILE_NAME);
}

#[test]
#[serial]
fn test_array_vec_conversion() {
    let arr = "[127.0.0.1:26200, 127.0.0.1:26201, 127.0.0.1:26202]";
    assert!(string_array_to_vec_of_address(arr).is_ok());

    let arr = "127.01:26200, 127.0.0.1:26201, 127.0.0.1:26202";
    assert!(string_array_to_vec_of_address(arr).is_err());

    let arr = "";
    assert!(string_array_to_vec_of_address(arr).is_err());
}

#[cfg(feature = "auth-sc-connector")]
#[test]
#[serial]
fn invalid_auth_sc_config() {
    let auth_config = load_auth_config();
    assert_ne!("", auth_config.sc_client_url);
    assert_ne!("", auth_config.sc_address);
}

#[test]
#[serial]
fn valid_auth_config_test() {
    let config = auth_config();
    assert_eq!(config.sc_client_url, "127.0.0.1:4050");
    assert_eq!(config.sc_address, "127.0.0.1:4051");
}

#[test]
#[serial]
fn test_store() {
    store_key_value(
        "test.toml",
        "DKG1".as_bytes().to_vec(),
        "hello_world".as_bytes().to_vec(),
    );
    assert!(read_store("test.toml").is_some())
}

#[test]
#[serial]
fn test_vrf_call_back() {
    let (tx, _rx) = oneshot::channel();
    let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
    let callback = VrfGenerateCallback::new(vrf_request, 0, tx);
    vrf_callback_log(&callback);
    assert!(get_vrf_callback_log().is_ok())
}
