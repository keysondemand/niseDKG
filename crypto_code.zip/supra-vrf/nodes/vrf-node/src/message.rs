use bytes::BufMut;
use bytes::Bytes;
use bytes::BytesMut;
use common::VrfRequest;
use socrypto::Hash;
use socrypto::PublicKey;
use socrypto::HASH_LENGTH;
use sodkg::BlsSignature;
use sodkg::DleqProofGLOW;
use sodkg::{BLSPROOF_LEN, BLS_SIGNATURE_LEN};
use sop2p::serialize::extract_array;
use sop2p::serialize::is_buffer_large_enough;
use sop2p::serialize::FromBytes;
use sop2p::serialize::IntoBytes;
use sop2p::NetworkCommandSender;
use sop2p::P2PError;
use sop2p::PeerInfo;
use std::collections::HashMap;

pub struct MessageSender {
    sender: NetworkCommandSender,
}

impl MessageSender {
    pub fn new(sender: NetworkCommandSender) -> Self {
        MessageSender { sender }
    }

    pub async fn send_message_to_connected_peers(&self, message: Vec<u8>) {
        let connected_peers = self.sender.get_peers().await.unwrap_or_default();
        self.sender
            .send_message_to_some_peers(connected_peers, message)
            .await;
    }

    pub async fn send_message_to_peer(&self, to: PublicKey, message: Vec<u8>) {
        let connected_peers = self.get_connected_peers().await;
        if let Some(peer) = connected_peers.get(&to) {
            self.sender
                .send_message_to_peer(peer.clone(), message)
                .await;
        }
    }

    async fn get_connected_peers(&self) -> HashMap<PublicKey, PeerInfo> {
        match self.sender.get_peers().await {
            Ok(peers) => peers.into_iter().map(|peer| (peer.pubkey, peer)).collect(),
            Err(err) => {
                log::warn!("VRF MessageSender errors during get_peers :{}", err);
                HashMap::new()
            }
        }
    }
}

#[allow(clippy::large_enum_variant)]
#[derive(Clone, Debug)]
pub enum VRFMessage {
    Request(VrfRequest),
    // TODO(clippy): Reduce the total size of the enum
    SignCallback(Hash, BlsSignature, DleqProofGLOW),
    SignError(Hash),
}

impl PartialEq for VRFMessage {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (VRFMessage::Request(self_req), VRFMessage::Request(other_req)) => {
                self_req.eq(other_req)
            }
            (
                VRFMessage::SignCallback(self_hash, self_bls_sign, self_dleq_proof),
                VRFMessage::SignCallback(other_hash, other_bls_sign, other_dleq_proof),
            ) => {
                self_hash.eq(other_hash)
                    && self_bls_sign.eq(other_bls_sign)
                    && self_dleq_proof.eq(other_dleq_proof)
            }
            (VRFMessage::SignError(self_hash), VRFMessage::SignError(other_hash)) => {
                self_hash.eq(other_hash)
            }
            _ => false,
        }
    }
}

impl Eq for VRFMessage {}

impl FromBytes for VRFMessage {
    fn from_bytes(buffer: &Bytes, mut start: usize) -> Result<(Self, usize), P2PError> {
        is_buffer_large_enough(buffer, start + 1)?;
        let header = buffer[start];
        start += 1;
        let (val, length) = match header {
            2 => {
                let (req_bytes, length): (Vec<u8>, usize) = FromBytes::from_bytes(buffer, start)?;
                let request = VrfRequest::try_from(req_bytes).map_err(|err| {
                    P2PError::DeserializeError(format!(
                        "error during VrfRequest deserialisation :{err}"
                    ))
                })?;

                let event = VRFMessage::Request(request);
                (event, length)
            }
            3 => {
                is_buffer_large_enough(
                    buffer,
                    start + HASH_LENGTH + BLS_SIGNATURE_LEN + BLSPROOF_LEN,
                )?;
                let hash = Hash::new(extract_array(&buffer[start..start + HASH_LENGTH]).map_err(
                    |err| {
                        P2PError::DeserializeError(format!(
                            "error during VrfSignCallback hash deserialisation :{err}"
                        ))
                    },
                )?);
                start += HASH_LENGTH;
                let sign = BlsSignature::try_from(&buffer[start..start + BLS_SIGNATURE_LEN])
                    .map_err(|err| {
                        P2PError::DeserializeError(format!(
                            "error during VrfSignCallback BlsSignature creation:{err}"
                        ))
                    })?;
                start += BLS_SIGNATURE_LEN;
                let proof = DleqProofGLOW::try_from(&buffer[start..start + BLSPROOF_LEN]).map_err(
                    |err| {
                        P2PError::DeserializeError(format!(
                            "error during VrfSignCallback DleqProofGLOW creation:{err}"
                        ))
                    },
                )?;

                let event = VRFMessage::SignCallback(hash, sign, proof);
                (event, HASH_LENGTH + BLS_SIGNATURE_LEN + BLSPROOF_LEN)
            }
            4 => {
                is_buffer_large_enough(buffer, start + HASH_LENGTH)?;
                let hash = Hash::new(extract_array(&buffer[start..start + HASH_LENGTH]).map_err(
                    |err| {
                        P2PError::DeserializeError(format!(
                            "error during VrfSignError hash deserialisation :{err}"
                        ))
                    },
                )?);
                let event = VRFMessage::SignError(hash);
                (event, HASH_LENGTH)
            }
            _ => {
                return Err(P2PError::DeserializeError(format!(
                    "VRFMessage from_bytes error, unknown event type:{header}"
                )))
            }
        };
        Ok((val, 1 + length))
    }
}

impl IntoBytes for VRFMessage {
    fn into_bytes(self, buffer: &mut BytesMut) {
        match self {
            VRFMessage::Request(request) => {
                buffer.put_u8(2);
                IntoBytes::into_bytes(request.to_bytes(), buffer);
            } //unwrap ok because request are verified at the reception
            VRFMessage::SignCallback(req_id, sign, proof) => {
                buffer.put_u8(3);
                buffer.extend_from_slice(req_id.as_ref());
                buffer.extend_from_slice(&sign.into_bytes());
                buffer.extend_from_slice(&proof.into_bytes());
            }
            VRFMessage::SignError(hash) => {
                buffer.put_u8(4);
                buffer.extend_from_slice(hash.as_ref());
            }
        }
    }

    fn bytes_len(&self) -> usize {
        match self {
            VRFMessage::Request(request) => {
                1 + request.message.len()
                    + request.block_hash.len()
                    + request.txhash.len()
                    + 4 * 4
                    + 1
                    + 3 * 4
            }
            VRFMessage::SignCallback(_, _, _) => 1 + HASH_LENGTH + BLS_SIGNATURE_LEN + BLSPROOF_LEN,
            VRFMessage::SignError(_) => 1 + HASH_LENGTH,
        }
    }
}

#[cfg(test)]
mod tests {
    // Note this useful idiom: importing names from outer (for mod tests) scope.
    use super::*;
    use crate::test::test_utils;
    use common::chains::ETH_DOMAIN;
    use sodkg::BlsPartialSignature;
    use sosmr::DkgCommittee;

    const DKG_COMMITTEE_FILE1: &str = include!("test/vrf_store_dkg_1_node_0.toml");

    // test VRFMessage IntoBytes FromBytes conversion:
    // 1) For each enum variant create one, convert into byte array, recreate it with from_bytes and compare the content from original variant.
    // 2) Do the same with an Vec<VRFMessage> for each variant.
    #[test]
    fn test_message_bytes_convertion() {
        // initiall variable declaration
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let hash = vrf_request.get_id();
        let dkg_committee: DkgCommittee = test_utils::get_test_dkg_committee(DKG_COMMITTEE_FILE1);
        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee.bls_privkey);

        // ----------------- test - VRFMessage::Request
        let vrf_req = VRFMessage::Request(vrf_request);
        let mut vrf_req_buffer = BytesMut::new();
        vrf_req.clone().into_bytes(&mut vrf_req_buffer);
        let vrf_req_new = VRFMessage::from_bytes(&Bytes::from(vrf_req_buffer), 0)
            .unwrap()
            .0;
        assert!(vrf_req.eq(&vrf_req_new));
        // ----------------- end

        // ----------------- VRFMessage::VrfSignCallback
        let vrf_sign_callback = VRFMessage::SignCallback(hash, signature, proof);
        let mut vrf_sign_callback_buffer = BytesMut::new();
        vrf_sign_callback
            .clone()
            .into_bytes(&mut vrf_sign_callback_buffer);
        let vrf_sign_callback_new =
            VRFMessage::from_bytes(&Bytes::from(vrf_sign_callback_buffer), 0)
                .unwrap()
                .0;
        assert!(vrf_sign_callback.eq(&vrf_sign_callback_new));
        // ----------------- end

        // ----------------- test - VRFMessage::VrfSignError
        let vrf_sign_error = VRFMessage::SignError(hash);
        let mut vrf_sign_error_buffer = BytesMut::new();
        vrf_sign_error
            .clone()
            .into_bytes(&mut vrf_sign_error_buffer);
        let vrf_sign_error_new = VRFMessage::from_bytes(&Bytes::from(vrf_sign_error_buffer), 0)
            .unwrap()
            .0;
        assert!(vrf_sign_error.eq(&vrf_sign_error_new));
        // ------------------ end
    }

    #[test]
    fn test_message_bytes_convertion_vec() {
        // initiall variable declaration
        let vrf_request: VrfRequest = test_utils::get_test_vrf_request();
        let hash = vrf_request.get_id();
        let dkg_committee: DkgCommittee = test_utils::get_test_dkg_committee(DKG_COMMITTEE_FILE1);
        let (signature, proof) =
            vrf_request.sign_partial_bls(ETH_DOMAIN.as_ref(), &dkg_committee.bls_privkey);

        // all VRFMessage test in vector
        let _bls_sign = BlsPartialSignature(signature.clone());
        let vrf_req = VRFMessage::Request(vrf_request);
        let vrf_sign_callback = VRFMessage::SignCallback(hash, signature, proof);
        let vrf_sign_error = VRFMessage::SignError(hash);
        let vrf_messages = vec![
            vrf_req.clone(),
            vrf_sign_callback.clone(),
            vrf_sign_error.clone(),
            vrf_req,
            vrf_sign_error,
            vrf_sign_callback,
        ];

        let mut buffer = BytesMut::new();
        vrf_messages.clone().into_bytes(&mut buffer);
        let bytes = buffer.split().freeze();
        let vrf_messages_new = Vec::<VRFMessage>::from_bytes(&bytes, 0).unwrap().0;
        assert_eq!(vrf_messages, vrf_messages_new);
    }
}
