//! Auth Smart Contract Utils
use socrypto::PublicKey;
use std::env;
use std::env::VarError;

#[cfg(feature = "use_auth")]
/// Validate the identity of a public key
pub async fn validate_identity(
    pubkey: PublicKey,
    auth_sc: &auth_sc_connector::AuthScClient,
) -> Result<bool, String> {
    auth_sc
        .check_address_exist(pubkey)
        .await
        .map_err(|err| format!("Unable to validate_identity cause:{err}"))
}

#[cfg(not(feature = "use_auth"))]
/// Mock implementation for validate_identity
pub async fn validate_identity(
    _pubkey: PublicKey,
    _auth_sc: &Option<String>,
) -> Result<bool, String> {
    Ok(true)
}

/// Configuration of the Auth Smart Contract
#[derive(Debug, Clone)]
pub struct AuthScConfig {
    /// Url of the RPC client
    pub sc_client_url: String,
    /// Address of the Auth Smart Contract
    pub sc_address: String,
}

/// Load AuthSC configuration, optionally from environment variables
/// takes AUTHSC_CLIENT_URL, AUTHSC_ADDRESS, otherwise fallbacks to predefined values
pub fn load_auth_config() -> AuthScConfig {
    let sc_client_url = env::var("AUTHSC_CLIENT_URL")
        .and_then(|s| {
            s.parse::<String>().map_err(|_| {
                log::warn!(
                    "Provided AUTHSC_CLIENT_URL:{} not recognized. use default sc client url",
                    s
                );
                VarError::NotPresent
            })
        })
        .unwrap_or_else(|_| {
            "https://goerli.infura.io/v3/4e1930aa5d3746908f69149b0731416b".to_string()
        });

    let sc_address = env::var("AUTHSC_ADDRESS")
        .and_then(|s| {
            s.parse::<String>().map_err(|_| {
                log::warn!(
                    "Provided AUTHSC_ADDRESS:{} not recognized. use default bind address",
                    s
                );
                VarError::NotPresent
            })
        })
        .unwrap_or_else(|_| "8990b947b6b7d09e6316d32f85276553f9631f7b".to_string());

    log::info!("Auth config sc_client_url:{sc_client_url} sc_address:{sc_address}");
    AuthScConfig {
        sc_client_url,
        sc_address,
    }
}

#[cfg(feature = "use_auth")]
/// Init Auth authentication to connect to the smart contract with VRF node parameters.
pub fn vrf_init_auth_sc(config: &AuthScConfig) -> auth_sc_connector::AuthScClient {
    auth_sc_connector::AuthScClient::new(
        config.sc_client_url.clone(),
        config.sc_address.clone(),
        auth_sc_connector::AuthScNetwork::VRF,
    )
}
