#VRF Node

## Run a VRF node

Start a VRF node. To start define the following env var:
* `B64_NODE_PRIVATE_KEY`: ed25519 node private key, base64 encoded. If you start the node without this parameters, it will generate a new one and print it. It's a convenient way to get new private.
* `B64_NODE_ELGAMAL_PRIVATE_KEY`: Elgamal node private key, base64 encoded. If you start the node without this parameters, it will generate a new one and print it. It's a convenient way to get new private.
* `NODE_BIND_ADDR`: the node bind ip address. On AWS machine the now can have to bind on the 0.0.0.0 address and use the machine address as public one.
* `NODE_PUBLIC_ADDR`: Optional. if the bind ip address is different from the public one. Define the public one here otherwise it use the bind address.
* `BOOTSTRAP_ADDR`: Optional. public ip address of the first bootstrap node. If not provide mean that it's a bootstrap node.
* `SMR_NODE_ADDR`: address of the SMR node RPC access
* `RPC_NODE_ADDR`: address of the RPC access the VRF node will bind to.
* `THRESHOLD_NUMBER`: f+1 value, default 3.
* `MIN_NUMBER_OF_NODE`: number of node in the DKG, default 4.
* `NB_DEALERS`: number of node that are dealer, default 3.
* `DEALER_THRESHOLD`: g+1 value, default 2
* `STORE_FILE_NAME`: Optional file path to the store where DKG committee data are stored. Default: vrf_store.toml.

Example of start commands:

To start the first VRF node  with bind is:0.0.0.0 and public address: 127.0.0.1:25100 and SMR rpc access of 127.0.0.1:25000

First build the node: cargo build --release

Then start the exe: `RUST_BACKTRACE=1 RUST_LOG=info NODE_BIND_ADDR=0.0.0.0:25100 NODE_PUBLIC_ADDR=127.0.0.1:25100 B64_NODE_PRIVATE_KEY="/aNKoCcFDA2EdrpRsA7eBVyrluiy9iD/zNFs91CqXLU5EKQ04TEzIqRImNGP95P99zMlXf6mLluNSDexC0j88A==" SMR_NODE_ADDR="127.0.0.1:25000" THRESHOLD_NUMBER=4 MIN_NUMBER_OF_NODE=5 NB_DEALERS=3 DEALER_THRESHOLD=2 ./target/release/vrf-node`

## Auth SC

By default the Auth Sc verification is activated. For it you need to define these env variables:
 * `AUTHSC_CLIENT_URL`: Eth Rpc access URL
 * `AUTHSC_ADDRESS: Eth` address of the Auth Sc.

To deactivate auth Sc, use the --no-default-features flag for cargo build.

For Auth Sc contract installation see the [auth-smart-contract repository](https://github.com/Entropy-Foundation/auth-smart-contract) documentation.