# Local run with verify_tx feature only
RUST_LOG=vrf_node,sodkg,soruntime=trace RUST_BACKTRACE=1 THRESHOLD_NUMBER=3 SMR_NODE_ADDR=127.0.0.1:25000 MIN_NUMBER_OF_NODE=5 cargo run --release --bin start_committee --no-default-features --features verify_tx
