use std::str::FromStr;
use secp256k1::SecretKey;
use web3::api::Eth;
use web3::contract::Options;
use web3::signing::{Key, SecretKeyRef};
use web3::types::{Address, U256, Bytes, BytesArray};
use web3::contract::Contract;
use web3::transports::Http;
use web3::contract::tokens::Tokenize;
use hex;
use futures::executor::block_on;
use rand::RngCore;
use web3::ethabi::{FixedBytes, Token, Uint};
// use web3::ethabi::ParamType::FixedBytes;

#[derive(Debug, Clone)]
struct ContractError;

#[repr(u8)]
pub enum Networks {
    SMR,
    VRF,
    Oracle
}

pub fn get_eth(sc_client_url: String) -> Eth<Http> {
    let http = Http::new(sc_client_url.as_str()).unwrap();
    let web3 = web3::Web3::new(http);
    web3.eth()
}

pub fn get_contract_instance(sc_address: &str, abi_bytes: &[u8], eth: Eth<Http>) -> anyhow::Result<Contract<Http>> {
    Contract::from_json(
        eth,
        Address::from_str(sc_address)?,
        &abi_bytes,
    ).map_err(anyhow::Error::msg)
}

pub async fn add_address(sc: &Contract<Http>, pk: &SecretKey, address: &[u8;32], network: Networks) -> anyhow::Result<()> {
    let mut options = Options::default();
    options.gas = Some(U256::from(5000000));
    sc.signed_call_with_confirmations("addAddress",
                           (Token::Uint(Uint::from(0)),
                            Token::FixedBytes(address.to_vec())),
                            options,
                           1,
                           pk).await.unwrap();
    Ok(())
}

pub async fn get_addresses(sc: &Contract<Http>, pk: &SecretKey, network: Networks) -> Vec<Vec<u8>> {
    let mut options = Options::default();
    options.gas = Some(U256::from(5000000));
    let x: Vec<FixedBytes> = sc.query("getList", (U256::from(network as u8),), pk.address(), options, None).await.unwrap();
    x.iter().map(|b| b.to_vec()).collect()
}

#[tokio::main]
async fn main() {
    // start anvil with -b 2.
    // without anvil automatically producing blocks,
    // there is no confirmation
    // and the binary gets stuck
    let sc_client_url = "http://127.0.0.1:8545".to_string();
    let sc_address = "5FbDB2315678afecb367f032d93F642f64180aa3".to_string();
    let pk = SecretKey::from_str("ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80").unwrap();
    let pk_ref = SecretKeyRef::new(&pk);
    let sc = get_contract_instance(&sc_address,
                                   include_bytes!("./auth_abi.json").as_slice(),
                                   get_eth(sc_client_url)).unwrap();

    let mut random_bytes = [0u8;32];
    rand::thread_rng().fill_bytes(&mut random_bytes);
    add_address(&sc, &pk_ref, &random_bytes, Networks::SMR).await.unwrap();

    let res = get_addresses(&sc, &pk, Networks::SMR).await;
    println!("{:?}",res);
    assert!(res.contains(&random_bytes.to_vec()));
}

