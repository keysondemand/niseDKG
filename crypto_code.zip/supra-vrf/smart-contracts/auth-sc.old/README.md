# Testing
1. install foundry
2. in a separate terminal start anvil with 2 second block time
   1. anvil -b 2
3. cd foundry
4. forge build
5. forge create src/SupraAUTH.sol:SupraAUTH --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
6. check the contract address that SupraAUTH is deployed to
   1. it should be 5FbDB2315678afecb367f032d93F642f64180aa3 on a fresh install
   2. but even if its not, it's ok - just make note of the address as <auth_address>
7. cd auth-reader-example
8. ensure that main.rs has sc_address=<auth_address>
9. cargo run --release
