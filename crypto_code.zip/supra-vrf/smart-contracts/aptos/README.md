## Aptos Supra SC

### Dependencies and installation

```
Aptos CLI : 1.0.2
AptosFramework for move rev: aptos-cli-v1.0.2
```

- Install aptos CLI 1.0.2 `RUSTFLAGS="--cfg tokio_unstable" cargo install --git https://github.com/aptos-labs/aptos-core.git aptos --tag aptos-cli-v1.0.2`.
- After installing Aptos CLI, you have to start local test net server `aptos node run-local-testnet --with-faucet` or you can use devnet server.

  **Note**: Two ports are enabled during local testnet 8080 and 8081 (make sure ports are available), rest URL `http://127.0.0.1:8080` and Faucet URL `http://127.0.0.1:8081` respectively.

### Deploy Supra SC

**Compile and Deploy Supra SC**

Here are some Aptos server URL information's
```toml
[local] 
rest_url = "http://127.0.0.1:8080"
faucet_url = "http://127.0.0.1:8081"

[devnet] 
rest_url = "https://fullnode.devnet.aptoslabs.com/v1"
faucet_url = "https://faucet.devnet.aptoslabs.com"

[testnet]
rest_url = "https://fullnode.testnet.aptoslabs.com/v1"
faucet_url = "https://faucet.testnet.aptoslabs.com"
```

- Inside the [smart-contracts/aptos](./) directory run command `aptos init`. It will ask you to Choose network from then enter `local` value, if you do not assign any value then it will consider `devnet`.
- After that it will ask you **Enter your private key** then no need to enter input, just enter and New account are created.
- You can find you account credentials details inside `.aptos/config.yaml` file.
```yaml
---
profiles:
  default:
    private_key: "private_key"
    public_key: "public_key"
    account: account_address
    rest_url: "rest_url"
    faucet_url: "faucet_url"
```
- Now compile the SC `aptos move compile`.
- Then here we need to add funds to SC address `aptos account fund-with-faucet --account ${address}`
- Before publish the SC make sure you defined correct account address of `supra` in [Move.toml](Move.toml) file.

    **Note** : You can find the account address inside [.aptos/config.yaml](.aptos/config.yaml) file. Also need to add `0x` prefix for account address in [Move.toml](Move.toml) if not added.
- Once compilation is done without an error then publish SC `aptos move publish`.
