//! Helpers for u8 arrays of large sizes
use schemars::{
    schema::{ArrayValidation, InstanceType, SchemaObject},
    JsonSchema,
};
use serde::{Deserialize, Serialize};
use serde_big_array::BigArray;

/// Wrapper over `[u8; N]`
#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, Eq)]
pub struct BigArr<const N: usize>(#[serde(with = "BigArray")] pub [u8; N]);

// Based on https://github.com/GREsau/schemars/blob/60bfc6ee49d841d91c924eb7fe4d89e9f44d8736/schemars/src/json_schema_impls/array.rs#L29
impl<const N: usize> JsonSchema for BigArr<N> {
    fn is_referenceable() -> bool {
        false
    }

    fn schema_name() -> String {
        format!("Array_size_{N}_of_uint8")
    }

    fn json_schema(gen: &mut schemars::gen::SchemaGenerator) -> schemars::schema::Schema {
        SchemaObject {
            instance_type: Some(InstanceType::Array.into()),
            array: Some(Box::new(ArrayValidation {
                items: Some(gen.subschema_for::<u8>().into()),
                max_items: Some(N as u32),
                min_items: Some(N as u32),
                ..Default::default()
            })),
            ..Default::default()
        }
        .into()
    }
}
