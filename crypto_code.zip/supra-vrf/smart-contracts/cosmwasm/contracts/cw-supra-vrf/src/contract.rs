//! Actual implementation of the contract
#[cfg(not(feature = "library"))]
use cosmwasm_std::entry_point;
use cosmwasm_std::{to_binary, Binary, Deps, DepsMut, Env, MessageInfo, Response, StdResult};
use cw2::set_contract_version;

use crate::error::ContractError;
use crate::msg::{ExecuteMsg, InstantiateMsg, QueryMsg};
use crate::state::{State, STATE};

// version info for migration info
const CONTRACT_NAME: &str = "cw-supra-vrf";
const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");

/// Initializes the contract
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: InstantiateMsg,
) -> Result<Response, ContractError> {
    let state = State {
        instance_id: 1,
        bls_key: msg.bls_key,
        nonce: 0,
    };
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;
    STATE.save(deps.storage, &state)?;

    Ok(Response::new().add_attribute("method", "instantiate"))
}

/// Handles an [`ExecuteMsg`]
/// thus mutating the state of the contract
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn execute(
    deps: DepsMut,
    _env: Env,
    info: MessageInfo,
    msg: ExecuteMsg,
) -> Result<Response, ContractError> {
    match msg {
        ExecuteMsg::RngRequest {
            rng_cnt,
            client_seed,
            num_confirmations,
        } => execute::rng_request(deps, info, rng_cnt, client_seed, num_confirmations),
        ExecuteMsg::VerifyCallback { msg, sig } => execute::verify_callback(deps, info, msg, sig),
    }
}

pub mod execute {
    //! [`ExecuteMsg`] handlers
    use crate::{
        big_arr::BigArr, events::RngRequestEvent, msg::VerifyCallbackMsg, rng_msg::SupraRngMsg,
        sig::bls12381_verify,
    };
    use cosmwasm_std::{SubMsg, Uint256};
    use sha2::{Digest, Sha256};

    use super::*;

    /// Handler for [`ExecuteMsg::RngRequest`]
    pub fn rng_request(
        deps: DepsMut,
        info: MessageInfo,
        rng_cnt: u8,
        client_seed: Uint256,
        num_confirmations: u64,
    ) -> Result<Response, ContractError> {
        let state = STATE.update(deps.storage, |mut state| {
            state.nonce += 1;
            Ok::<_, ContractError>(state)
        })?;

        Ok(Response::new().add_event(
            RngRequestEvent {
                nonce: state.nonce,
                instance_id: state.instance_id,
                caller_address: info.sender,
                rng_cnt,
                client_seed,
                // Num confirmation is capped at 20
                num_confirmations: num_confirmations.min(20).max(1),
            }
            .into(),
        ))
    }

    /// Handler for [`ExecuteMsg::VerifyCallback`]
    pub fn verify_callback(
        deps: DepsMut,
        _info: MessageInfo,
        msg: VerifyCallbackMsg,
        sig: BigArr<96>,
    ) -> Result<Response, ContractError> {
        let state = STATE.load(deps.storage)?;
        let encoded = bincode::serialize(&msg)?;
        bls12381_verify(&state.bls_key.0, &sig.0, encoded.as_slice())?;

        let rng_list: Vec<_> = (0..msg.rng_cnt)
            .map(|i| {
                let mut rand_num = Sha256::new();
                rand_num.update(sig.0);
                rand_num.update(i.to_be_bytes());
                Uint256::new(rand_num.finalize().into())
            })
            .collect();

        let sub_msg = SupraRngMsg {
            rng_list,
            nonce: msg.nonce,
        }
        .into_cosmos_msg(msg.caller_address)?;

        Ok(Response::new().add_submessage(SubMsg::new(sub_msg)))
    }
}

/// Handles a [`QueryMsg`]
/// These do not mutate the state of the contract
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn query(deps: Deps, _env: Env, msg: QueryMsg) -> StdResult<Binary> {
    match msg {
        QueryMsg::GetInstanceId {} => to_binary(&query::instance_id(deps)?),
        QueryMsg::GetBlsKey {} => to_binary(&query::bls_key(deps)?),
    }
}

pub mod query {
    //! Handlers for [`QueryMsg`]
    use crate::msg::{GetBlsKeyResponse, GetInstanceIdResponse};

    use super::*;

    /// Handler for [`QueryMsg::GetInstanceId`]
    pub fn instance_id(deps: Deps) -> StdResult<GetInstanceIdResponse> {
        let state = STATE.load(deps.storage)?;
        Ok(GetInstanceIdResponse {
            instance_id: state.instance_id,
        })
    }

    /// Handler for [`QueryMsg::GetBlsKey`]
    pub fn bls_key(deps: Deps) -> StdResult<GetBlsKeyResponse> {
        let state = STATE.load(deps.storage)?;
        Ok(GetBlsKeyResponse {
            bls_key: state.bls_key,
        })
    }
}

#[cfg(test)]
mod tests {
    use blst::min_sig::SecretKey;
    use cosmwasm_std::{
        from_binary,
        testing::{mock_dependencies, mock_env, mock_info},
        to_binary, CosmosMsg, DepsMut, Env, Event, MessageInfo, Response, WasmMsg,
    };

    use crate::{
        big_arr::BigArr,
        contract::query,
        msg::{
            ExecuteMsg, GetBlsKeyResponse, GetInstanceIdResponse, InstantiateMsg, QueryMsg,
            VerifyCallbackMsg,
        },
        rng_msg::SupraRngMsg,
    };

    use super::{execute, instantiate};

    fn do_instantiate(deps: DepsMut, env: Env, info: MessageInfo) -> (Response, SecretKey) {
        let ikm = [0; 32]; // WARN: this is only appropriate for testing
        let sk = SecretKey::key_gen(&ikm, &[]).unwrap();

        let init_msg = InstantiateMsg {
            bls_key: BigArr(sk.sk_to_pk().serialize()),
        };

        let res = instantiate(deps, env, info, init_msg).unwrap();

        (res, sk)
    }

    fn rng_req(
        deps: DepsMut,
        env: Env,
        info: MessageInfo,
        rng_cnt: u8,
        client_seed: u64,
        num_confirmations: u64,
    ) -> Event {
        let msg = ExecuteMsg::RngRequest {
            rng_cnt,
            client_seed: client_seed.into(),
            num_confirmations,
        };

        let mut res = execute(deps, env, info, msg).unwrap();

        res.events.pop().unwrap()
    }

    /// Checks if the contract initializes correctly
    #[test]
    fn proper_initialization() {
        let env = mock_env();
        let info = mock_info("creator", &[]);
        let mut deps = mock_dependencies();

        let (res, sk) = do_instantiate(deps.as_mut(), env.clone(), info);

        assert_eq!(res.attributes[0], ("method", "instantiate"));

        let res = query(deps.as_ref(), env, QueryMsg::GetBlsKey {}).unwrap();
        let pubk_ser = BigArr(sk.sk_to_pk().serialize());
        assert_eq!(
            res,
            to_binary(&GetBlsKeyResponse { bls_key: pubk_ser }).unwrap()
        );
    }

    /// Checks if the contract emits an event properly on rng request
    #[test]
    fn rng_req_event() {
        let env = mock_env();
        let info = mock_info("some_contract", &[]);
        let mut deps = mock_dependencies();

        do_instantiate(deps.as_mut(), env.clone(), info.clone());
        let ev = rng_req(deps.as_mut(), env.clone(), info, 1, 0, 1);
        let ins_res = query(deps.as_ref(), env, QueryMsg::GetInstanceId {}).unwrap();
        let ins_res: GetInstanceIdResponse = from_binary(&ins_res).unwrap();

        assert_eq!(ev.ty, "rng-request");
        assert_eq!(ev.attributes[0].key, "nonce");
        assert_eq!(
            ev.attributes[1],
            ("instance_id", ins_res.instance_id.to_string())
        );
        assert_eq!(ev.attributes[2], ("caller_address", "some_contract"));
        assert_eq!(ev.attributes[3], ("rng_cnt", "1"));
        assert_eq!(ev.attributes[4], ("client_seed", "0"));
        assert_eq!(ev.attributes[5], ("num_confirmations", "1"));
    }

    /// Tests if a user can only set a minimum of 1 confirmations in rng request
    #[test]
    fn min_1_confirm() {
        let env = mock_env();
        let info = mock_info("creator", &[]);
        let mut deps = mock_dependencies();

        do_instantiate(deps.as_mut(), env.clone(), info.clone());
        let ev = rng_req(deps.as_mut(), env, info, 1, 0, 0);

        assert_eq!(ev.attributes[5].value, "1");
    }

    /// Tests if a user can only set a maximum of 20 confirmations in rng request
    #[test]
    fn max_20_confirms() {
        let env = mock_env();
        let info = mock_info("creator", &[]);
        let mut deps = mock_dependencies();

        do_instantiate(deps.as_mut(), env.clone(), info.clone());
        let ev = rng_req(deps.as_mut(), env, info, 1, 0, u64::MAX);

        assert_eq!(ev.attributes[5].value, "20");
    }

    /// Tests that the contract properly sends a callback to the the contract that has requested rng
    /// assuming that the vrf node generates rng
    #[test]
    fn verify_callback_works() {
        let env = mock_env();
        let info = mock_info("some_contract", &[]);
        let mut deps = mock_dependencies();

        let (_, sk) = do_instantiate(deps.as_mut(), env.clone(), info.clone());
        let ev = rng_req(deps.as_mut(), env.clone(), info.clone(), 20, 0, 1);

        let cb_msg = VerifyCallbackMsg {
            nonce: ev.attributes[0].value.parse().unwrap(),
            block_hash: [0; 32],
            rng_cnt: 20,
            client_seed: 0u64.into(),
            caller_address: info.sender.clone(),
        };
        let cb_ser = bincode::serialize(&cb_msg).unwrap();
        let sig = sk.sign(&cb_ser, b"BLS_SIG_BLS12381G1_XMD:SHA-256_SSWU_RO_NUL_", &[]);

        let mut res = execute(
            deps.as_mut(),
            env,
            info,
            ExecuteMsg::VerifyCallback {
                msg: cb_msg,
                sig: BigArr(sig.serialize()),
            },
        )
        .unwrap();
        let sub_msg = res.messages.remove(0);
        let CosmosMsg::Wasm(WasmMsg::Execute { contract_addr, msg, .. }) = sub_msg.msg else {
            panic!("invalid submsg");
        };

        assert_eq!(contract_addr, ev.attributes[2].value);

        let rng_msg: SupraRngMsg = from_binary(&msg).unwrap();

        assert_eq!(rng_msg.rng_list.len(), 20);
    }
}
