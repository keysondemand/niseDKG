//! Helpers for interacting with this contract
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use cosmwasm_std::{
    to_binary, Addr, CosmosMsg, CustomQuery, Querier, QuerierWrapper, StdResult, WasmMsg, WasmQuery,
};

use crate::msg::{ExecuteMsg, GetBlsKeyResponse, GetInstanceIdResponse, QueryMsg};

/// Helper struct for this contract
#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, Eq, JsonSchema)]
pub struct SupraVrfContract(pub Addr);

impl SupraVrfContract {
    /// Address of the contract
    pub fn addr(&self) -> Addr {
        self.0.clone()
    }

    /// Executes a message on the contract
    pub fn call<T: Into<ExecuteMsg>>(&self, msg: T) -> StdResult<CosmosMsg> {
        let msg = to_binary(&msg.into())?;
        Ok(WasmMsg::Execute {
            contract_addr: self.addr().into(),
            msg,
            funds: vec![],
        }
        .into())
    }

    /// Get Instance Id
    pub fn instance_id<Q, T, CQ>(&self, querier: &Q) -> StdResult<GetInstanceIdResponse>
    where
        Q: Querier,
        T: Into<String>,
        CQ: CustomQuery,
    {
        let msg = QueryMsg::GetInstanceId {};
        let query = WasmQuery::Smart {
            contract_addr: self.addr().into(),
            msg: to_binary(&msg)?,
        }
        .into();
        let res: GetInstanceIdResponse = QuerierWrapper::<CQ>::new(querier).query(&query)?;
        Ok(res)
    }

    /// Get Bls Public Key
    pub fn bls_key<Q, T, CQ>(&self, querier: &Q) -> StdResult<GetBlsKeyResponse>
    where
        Q: Querier,
        T: Into<String>,
        CQ: CustomQuery,
    {
        let msg = QueryMsg::GetBlsKey {};
        let query = WasmQuery::Smart {
            contract_addr: self.addr().into(),
            msg: to_binary(&msg)?,
        }
        .into();

        let res = QuerierWrapper::<CQ>::new(querier).query(&query)?;

        Ok(res)
    }
}
