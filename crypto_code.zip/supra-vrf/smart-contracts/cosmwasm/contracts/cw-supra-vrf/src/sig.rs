use blst::{
    min_sig::{PublicKey, Signature},
    BLST_ERROR,
};

use crate::ContractError;

const DST_G1: &[u8] = b"BLS_SIG_BLS12381G1_XMD:SHA-256_SSWU_RO_NUL_";

pub(crate) fn bls12381_verify(
    pub_key: &[u8; 192],
    sig: &[u8; 96],
    message: &[u8],
) -> Result<(), ContractError> {
    let pub_key = PublicKey::deserialize(pub_key).map_err(|_| ContractError::InvalidPublicKey)?;
    let signature = Signature::deserialize(sig).map_err(|_| ContractError::InvalidSignature)?;

    let res = signature.verify(true, message, DST_G1, &[], &pub_key, true);
    if res == BLST_ERROR::BLST_SUCCESS {
        Ok(())
    } else {
        Err(ContractError::Unauthorized {})
    }
}
