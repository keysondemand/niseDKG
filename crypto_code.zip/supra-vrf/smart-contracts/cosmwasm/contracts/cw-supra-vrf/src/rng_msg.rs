//! The Rng Message that must be handled by Supra VRF Users
use cosmwasm_schema::cw_serde;
use cosmwasm_std::{to_binary, CosmosMsg, StdResult, Uint256, WasmMsg};
use schemars::JsonSchema;

/// This message must be handled by all contracts which
/// request rng via [`crate::msg::ExecuteMsg::RngRequest`]
#[cw_serde]
pub struct SupraRngMsg {
    /// Unqiue Nonce associated with the request
    pub nonce: u64,
    /// List of random numbers
    pub rng_list: Vec<Uint256>,
}

impl SupraRngMsg {
    /// Serializes this message into a cosmosvm message
    pub fn into_cosmos_msg<T: Into<String>, C>(self, contract_addr: T) -> StdResult<CosmosMsg<C>>
    where
        C: Clone + std::fmt::Debug + PartialEq + JsonSchema,
    {
        let msg = to_binary(&self)?;
        let execute = WasmMsg::Execute {
            contract_addr: contract_addr.into(),
            msg,
            funds: vec![],
        };
        Ok(execute.into())
    }
}
