//! Persistent State of the Contract
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use cw_storage_plus::Item;

use crate::big_arr::BigArr;

/// The Persistent state
#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, Eq, JsonSchema)]
pub struct State {
    /// Instance Id of the contract
    pub instance_id: u64,
    /// Nonce Counter
    pub nonce: u64,
    /// Authority of the smart contract
    pub bls_key: BigArr<192>,
}

/// Helper for fetching the current State
pub const STATE: Item<State> = Item::new("state");
