//! Events emitted by the contract
use cosmwasm_std::{Addr, Event, Uint256};

/// Emitted when a new rng request is received
pub struct RngRequestEvent {
    /// Unique Nonce of the Request
    pub nonce: u64,
    /// Instance Id of this contract
    pub instance_id: u64,
    /// Rng Requestor
    pub caller_address: Addr,
    /// Number of random numbers requested
    pub rng_cnt: u8,
    /// Client Seed
    pub client_seed: Uint256,
    /// Number of confirmations to wait before processing the event
    pub num_confirmations: u64,
}

impl From<RngRequestEvent> for Event {
    fn from(val: RngRequestEvent) -> Self {
        Event::new("rng-request").add_attributes([
            ("nonce", val.nonce.to_string()),
            ("instance_id", val.instance_id.to_string()),
            ("caller_address", val.caller_address.to_string()),
            ("rng_cnt", val.rng_cnt.to_string()),
            ("client_seed", val.client_seed.to_string()),
            ("num_confirmations", val.num_confirmations.to_string()),
        ])
    }
}

/// Emitted when an Rng Request is processed
pub struct NonceProcessedEvent {
    nonce: u64,
}

impl From<NonceProcessedEvent> for Event {
    fn from(val: NonceProcessedEvent) -> Self {
        Event::new("nonce-processed").add_attribute("nonce", val.nonce.to_string())
    }
}
