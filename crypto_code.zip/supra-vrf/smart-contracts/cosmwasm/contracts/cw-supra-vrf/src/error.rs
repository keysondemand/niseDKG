//! Errors that can be returned by this contract
use cosmwasm_std::StdError;
use thiserror::Error;

/// Errors encountered during message handling
#[allow(missing_docs)]
#[derive(Error, Debug)]
pub enum ContractError {
    #[error("{0}")]
    Std(#[from] StdError),

    #[error("Unauthorized")]
    Unauthorized {},

    #[error("Invalid public key")]
    InvalidPublicKey,

    #[error("Invalid Signature")]
    InvalidSignature,

    #[error("Serialization Error {0}")]
    Serialization(#[from] bincode::Error),
}
