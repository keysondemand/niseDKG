# Cosmwasm

CosmWasm contracts for supra-vrf

## Building

Outputs the contracts to `artifacts`

```bash
cargo cw-optimizoor
```

## Tests

`cw-supra-vrf` has tests. you may run them with

```bash
cargo test --lib --package cw-supra-vrf
```

Each test has comments about what it checks