forge create --via-ir --rpc-url http://127.0.0.1:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 src/SupraRouterContract.sol:SupraRouterContract

forge create --via-ir --rpc-url http://127.0.0.1:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 src/SupraGeneratorContract.sol:SupraGeneratorContract --constructor-args 0xb2b5ca56968e81bf5845ee0e6c6888aff023d02790943f6947a389b2e2892ea5 0x5FbDB2315678afecb367f032d93F642f64180aa3 "["12474797184455552437605583740352806015278110158567951236113371972177401939827","14494998987889706405779937122594212194703577914067601846863788167081771857235","3382945674537103368208980114450342301868953517746872553877970338833975202079","20214191449171022588765201417012322695621309574871105927981424616111840096326"]" 0

forge create --via-ir --rpc-url http://127.0.0.1:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 src/examples/RNG.sol:Interaction --constructor-args 0x5FbDB2315678afecb367f032d93F642f64180aa3

cast send 0x5FbDB2315678afecb367f032d93F642f64180aa3 "setGeneratorContract(address)" "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512" --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80

forge create --via-ir --rpc-url http://127.0.0.1:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 src/examples/TeenPatti.sol:TeenPatti --constructor-args 0x5FbDB2315678afecb367f032d93F642f64180aa3

cast send 0x5FbDB2315678afecb367f032d93F642f64180aa3 "updateGeneratorContract(address)" "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512" --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
