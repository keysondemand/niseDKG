#!/bin/bash
# the example gaming contract has 2 functions
# 1. getRNG(uint8 x) -> this returns 'x' number of random numbers
# 2. getRNGForUser(uint8 x, string username) -> this also returns x number of random numbers
#    but the getRNGForUser function stores 'state' against the nonce. in this case, the state is 'username'
#    so the logs inside anvil should print eg: "getting 10 random numbers for username: Kevin"
if [ "$#" -eq 0 ]; then
cast send 0xB7f8BC63BbcaD18155201308C8f3540b07f84F5e "getRNG(uint8)" "1" --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
fi
if [ "$#" -eq 1 ]; then
cast send 0xB7f8BC63BbcaD18155201308C8f3540b07f84F5e "getRNG(uint8)" "$1" --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
fi
if [ "$#" -eq 2 ]; then
cast send 0xB7f8BC63BbcaD18155201308C8f3540b07f84F5e "getRNGForUser(uint8,string)" "$1" "$2" --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
fi
