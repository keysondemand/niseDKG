# supra-vrf-prod
supra-vrf-prod


### To Run Auto Deploy script, here are the commands

#### 1. Deploy smart contract

```
python3 ../auto-deploy-script.py deploy <PrivateKey> "<PublicKeyVector>"
```
This command will deploy router and generator contract

- eth
- avax
- optimism
- bsc
- matic
- arbitrum
- klaytn
- dfk
- iotex
- okex
- fx
- kcc
- watr
- aurora
- fantom
- tomochain
- celo
- telos
- cronos
- gnosis
- metis
- boba
- evmos
- dogechain


#### 2. Update public key
```
python3 ../auto-deploy-script.py send_tx <PrivateKey> "<PublicKeyVector>"
```