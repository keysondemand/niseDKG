forge create --via-ir --rpc-url http://54.144.207.40:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 src/SupraRouterContract.sol:SupraRouterContract

forge create --via-ir --rpc-url http://54.144.207.40:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 src/SupraGeneratorContract.sol:SupraGeneratorContract --constructor-args 0xb2b5ca56968e81bf5845ee0e6c6888aff023d02790943f6947a389b2e2892ea5 0x5FbDB2315678afecb367f032d93F642f64180aa3 "["21167083251790020769989292902507980553066521771088231124802883081933587017946","13618630266173377094301767141152631530000178297772880794288245598542162473230","7876818478891607582182772497988132178908933622894438034720625027265265547491","809629972259152751144705855165825393972702142138843429926673272010683820705"]" 0

forge create --via-ir --rpc-url http://54.144.207.40:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 src/examples/RNG.sol:Interaction --constructor-args 0x5FbDB2315678afecb367f032d93F642f64180aa3

cast send 0x5FbDB2315678afecb367f032d93F642f64180aa3 "setGeneratorContract(address)" "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512" --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --rpc-url http://54.144.207.40:8545

cast send 0x5FbDB2315678afecb367f032d93F642f64180aa3 "updateGeneratorContract(address)" "0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512" --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 --rpc-url http://54.144.207.40:8545

forge create --via-ir --rpc-url http://54.144.207.40:8545 --private-key 0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80 src/examples/Monitor.sol:Interaction --constructor-args 0x5FbDB2315678afecb367f032d93F642f64180aa3
