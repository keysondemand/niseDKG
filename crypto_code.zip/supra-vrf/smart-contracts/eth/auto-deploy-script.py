import json
import subprocess
import sys


class TestChainData(object):
    chain_name = ''
    rpc_url = ''
    is_legacy = ''

    def __init__(self, chain_name, chain_rpc_url, chain_is_legacy):
        self.chain_name = chain_name
        self.rpc_url = chain_rpc_url
        self.is_legacy = chain_is_legacy


# Test all chain for
# 1. Deploy contract on all chains
# 2. Add public key contract on all chains
def test_chains():
    task_type = sys.argv[1]
    private_key = sys.argv[2]
    bn_254_public_key = sys.argv[3]

    if task_type == 'deploy':
        test_deploy_contract(private_key, bn_254_public_key)
    else:
        test_update_public_key(private_key, bn_254_public_key)


def test_deploy_contract(private_key, bn_254_public_key):
    chains = {}
    for chain in chain_data():
        name = chain.chain_name
        rpc_url = chain.rpc_url
        is_legacy = chain.is_legacy

        try:
            (router_deploy_to, router_tx_hash) = test_router_contract(name, rpc_url, private_key, is_legacy)
            try:
                (generator_deploy_to, generator_tx_hash) = test_generator_contract(name, rpc_url, private_key,
                                                                                   bn_254_public_key,
                                                                                   router_deploy_to, router_tx_hash,
                                                                                   is_legacy)
                if generator_deploy_to != "" and generator_deploy_to != "":
                    chain_json_data = {
                        "generator": {
                            "deploy_to": generator_deploy_to,
                            "transaction_hash": generator_tx_hash,
                        },
                        "router": {
                            "deploy_to": router_deploy_to,
                            "transaction_hash": router_tx_hash,
                        }
                    }
                    chains[name] = chain_json_data
                    try:
                        set_generator_contract(router_deploy_to, generator_deploy_to, rpc_url, private_key,
                                               is_legacy)
                    except subprocess.CalledProcessError as e:
                        print(e)
            except subprocess.CalledProcessError as e:
                print(e)
        except subprocess.CalledProcessError as e:
            print(e)

    with open("all-chain.json", mode='w') as feeds_json:
        json.dump(chains, feeds_json)


def test_router_contract(name, rpc_url, private_key, is_legacy):
    print(name)
    cmd = f'forge create --via-ir --rpc-url {rpc_url} --private-key {private_key} src/SupraRouterContract.sol' \
          f':SupraRouterContract'

    if is_legacy:
        cmd = cmd + " --legacy"

    output = subprocess.check_output(cmd, shell=True)
    response = output.decode("utf-8").split("\n")

    transaction_hash = ""
    deployed_to = ""
    for resp in response:
        arr = resp.split(":")
        if arr[0] == "Transaction hash":
            transaction_hash = arr[1].strip()

        if arr[0] == "Deployed to":
            deployed_to = arr[1].strip()

    print(f"============================== Router Contract on {name} ==========================================")
    print(f'Deployed To : {deployed_to}')
    print(f'Transaction Hash : {transaction_hash}')
    print("====================================================================================================")

    return deployed_to, transaction_hash


def test_generator_contract(name, rpc_url, private_key, public_key, deployed_to, router_tx_hash, is_legacy):
    if deployed_to != "" and router_tx_hash != "":
        cmd = f'forge create --via-ir --rpc-url {rpc_url} --private-key {private_key} src/SupraGeneratorContract.sol' \
              f':SupraGeneratorContract --constructor-args ' \
              f'0xb2b5ca56968e81bf5845ee0e6c6888aff023d02790943f6947a389b2e2892ea5 ' \
              f'{deployed_to} "{public_key}" 0'

        if is_legacy:
            cmd = cmd + " --legacy"

        output = subprocess.check_output(cmd, shell=True)
        response = output.decode("utf-8").split("\n")

        transaction_hash = ""
        g_deployed_to = ""

        for resp in response:
            arr = resp.split(":")
            if arr[0] == "Transaction hash":
                transaction_hash = arr[1].strip()

            if arr[0] == "Deployed to":
                g_deployed_to = arr[1].strip()

        print(f"============================== Generator Contract on {name} ==========================================")
        print(f'Deployed To : {g_deployed_to}')
        print(f'Transaction Hash : {transaction_hash}')
        print("=======================================================================================================")
        return g_deployed_to, transaction_hash
    else:
        return "", ""


def set_generator_contract(r_deploy_to, g_deploy_to, rpc_url, private_key, is_legacy):
    cmd = f'cast send {r_deploy_to} "setGeneratorContract(address)" "{g_deploy_to}" --rpc-url {rpc_url} --private-key {private_key}'
    if is_legacy:
        cmd = cmd + " --legacy"
    subprocess.run(cmd, shell=True)


def test_update_public_key(private_key, bn_254_public_key):
    print("=======================================================")

    for chain in chain_data():
        print(chain.chain_name)

        with open("all-chain.json", mode='r') as feeds_json:
            json_data = json.load(feeds_json)
            if chain.chain_name in json_data:
                deploy_to = json_data[chain.chain_name]["generator"]["deploy_to"]
                send_tx(chain.rpc_url, private_key, bn_254_public_key, deploy_to, chain.is_legacy)


def send_tx(rpc_url, private_key, public_key, deployed_to, is_legacy):
    cmd = f'cast send {deployed_to} "updatePublicKey(uint256[4])" {public_key} --private-key {private_key}  --rpc-url {rpc_url}'

    if is_legacy:
        cmd = cmd + " --legacy"

    subprocess.run([cmd], shell=True)


def chain_data():
    return [
        TestChainData(chain_name="eth", chain_rpc_url="http://35.195.212.176:8545/", chain_is_legacy=False),
        TestChainData(chain_name="avax", chain_rpc_url="http://34.130.236.14:9650/ext/bc/C/rpc", chain_is_legacy=False),
        TestChainData(chain_name="optimism", chain_rpc_url="https://burned-old-market.optimism-goerli.quiknode.pro"
                                                           "/9129f6c70a6055f5ac1ebeb207dfbe4804ea0682/",
                      chain_is_legacy=False),
        TestChainData(chain_name="bsc", chain_rpc_url="http://34.76.233.245:8575/", chain_is_legacy=False),
        TestChainData(chain_name="arbitrum", chain_rpc_url="http://34.148.206.63:8547/", chain_is_legacy=False),
        TestChainData(chain_name="klaytn", chain_rpc_url="http://34.142.245.178:8551/", chain_is_legacy=False),
        TestChainData(chain_name="dfk",
                      chain_rpc_url="https://subnets.avax.network/defi-kingdoms/dfk-chain-testnet/rpc",
                      chain_is_legacy=False),
        TestChainData(chain_name="iotex", chain_rpc_url="https://babel-api.testnet.iotex.io/", chain_is_legacy=True),
        TestChainData(chain_name="kcc", chain_rpc_url="https://rpc-testnet.kcc.network/", chain_is_legacy=True),
        TestChainData(chain_name="watr", chain_rpc_url="https://rpc.dev.watr.org/", chain_is_legacy=True),
        TestChainData(chain_name="aurora", chain_rpc_url="https://testnet.aurora.dev/", chain_is_legacy=True),
        TestChainData(chain_name="fantom", chain_rpc_url="http://34.173.151.216:18545/", chain_is_legacy=False),
        TestChainData(chain_name="tomochain", chain_rpc_url="https://rpc.testnet.tomochain.com/", chain_is_legacy=True),
        TestChainData(chain_name="celo", chain_rpc_url="http://34.135.151.138:8545/", chain_is_legacy=False),
        TestChainData(chain_name="telos", chain_rpc_url="https://testnet.telos.net/evm", chain_is_legacy=True),
        TestChainData(chain_name="gnosis", chain_rpc_url="http://35.222.246.84:8545/", chain_is_legacy=False),
        TestChainData(chain_name="metis", chain_rpc_url="https://goerli.gateway.metisdevops.link/",
                      chain_is_legacy=True),
        TestChainData(chain_name="boba", chain_rpc_url="https://testnet.bnb.boba.network/", chain_is_legacy=True),
        TestChainData(chain_name="evmos", chain_rpc_url="https://eth.bd.evmos.dev:8545/", chain_is_legacy=False),
        TestChainData(chain_name="cronos", chain_rpc_url="http://35.196.227.113:8545/", chain_is_legacy=False),
        TestChainData(chain_name="dogechain", chain_rpc_url="https://rpc-devnet.dogechain.dog/", chain_is_legacy=True),
        TestChainData(chain_name="matic", chain_rpc_url="http://35.223.147.117:8545/", chain_is_legacy=False),
        TestChainData(chain_name="okex", chain_rpc_url="http://34.106.143.103:8545/", chain_is_legacy=True),
        TestChainData(chain_name="fx", chain_rpc_url="https://testnet-fx-json-web3.functionx.io:8545/",
                      chain_is_legacy=False),
        TestChainData(chain_name="astar", chain_rpc_url="https://shibuya.public.blastapi.io/", chain_is_legacy=False),
        # TestChain(chain_name="harmony", chain_rpc_url="https://api.s0.pops.one/", chain_is_legacy=True)
    ]


test_chains()
