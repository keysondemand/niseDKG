# Event explorer

The purpose of the event is explorer is to build a table listing
- nonce associated with a random number,
- block when a random number request was submitted (`r`),
- how many confirmation are required before the event shall be processed (`n`),
- block when a random number was submitted (`p`)

Observe that under ideal circumstance, `d := p - r - n = 1`.

Additionally, the block explorer builds a separate table listing irregular events,
i.e., those with `d > 1`, and those with either `p` or `r` absent.

## Requirements
 - Smart contacts in `../smart-contracts` must be built,
 - (For local setup) Anvil.

## Running locally
- Start anvil.
- Deploy the smart contract
  ```bash
  sh supra-vrf/smart-contracts/eth/deploy_local.sh
  ```
- Generate an rng request (or create a script executing the script below multiple times)
  ```bash
  sh supra-vrf/smart-contracts/eth/call_rang.sh
  ```
- Run the explorer
  ```bash 
  cargo r -- -a 0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512 -H http://localhost:8545 -f 0
  ```
- Inspect the `data` folder
  ```bash 
  ls supra-vrf/event-explorer/data
  ``` 

Run the executable with `--help` to learn about the required parameters. 