use crate::process::concurrent_fetch_and_log_events;
use clap::Parser;

mod csv;
mod events;
mod process;

/// Name of a csv file where raw stats will be written to.
/// This name will receive a timestamp as a suffix and "csv" as a file extension.
pub(crate) const RAW_CSV: &str = "raw";

/// Name of a csv file where filtered stats will be written to.
/// This name will receive a timestamp as a suffix and "csv" as a file extension.
pub(crate) const SLOW_CSV: &str = "slow";

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let _ = pretty_env_logger::try_init();

    let cli = Cli::parse();
    log::debug!("{cli:#?}");

    concurrent_fetch_and_log_events(&cli).await
}

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Cli {
    /// Blockchain http host.
    #[arg(short('H'), long)]
    http: String,

    /// RNG contract address.
    /// For the local setup, it is likely `0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512`.
    #[arg(short, long)]
    address: String,

    /// Start block.
    #[arg(short, long)]
    from: u64,

    /// End block, no value means until the currently last block.
    #[arg(short, long)]
    to: Option<u64>,

    /// Start nonce, by default it is the first requested nonce.
    #[arg(short, long, default_value_t = 1)]
    start: u64,

    /// Last nonce to consider, no value means we will exhaust all possible nonces.
    #[arg(short, long)]
    end: Option<u64>,

    /// Max number of blocks to request at once
    /// This is useful for chains that reject request with too high of a block range
    #[arg(short, long)]
    chunk_size: Option<u64>,

    /// Max number of concurrent tasks to retrieve the blocs
    /// This is only used if there's a chunking size (otherwise there is only one request, so no concurrency at all)
    #[arg(short('L'), long)]
    concurrency_limit: Option<usize>,
}
