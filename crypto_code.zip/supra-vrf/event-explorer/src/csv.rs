use crate::process::EventStat;
use csv::Writer;
use std::collections::BTreeMap;
use std::fs;
use std::fs::File;
use std::path::Path;
use web3::contract::tokens::Tokenizable;
use web3::types::U256;

/// Saves records to a csv file if they match the filter.
pub(crate) fn save_to_csv(
    file_name: &str,
    stats: &BTreeMap<U256, EventStat>,
    filter: Box<dyn Fn(&EventStat) -> bool>,
) -> anyhow::Result<()> {
    log::debug!("Writing to {file_name}");

    // Create a new CSV file.
    if let Some(parent_dir) = Path::new(file_name).parent() {
        fs::create_dir_all(parent_dir)?;
    }

    let file = File::create(file_name)?;

    // Create a CSV writer.
    let mut writer = Writer::from_writer(file);

    // Write the header row
    writer.write_record(["Nonce", "Submitted", "Confirmations", "Processed"])?;

    // Iterate over the HashMap and write each data point as a row.
    for (nonce, stat) in stats {
        // This conversion enables representation of `nonce` in hex
        // to harmonize with logs from `free node`.
        let nonce_token = nonce.into_token();

        if filter.as_ref()(stat) {
            writer.write_record(&[
                format!("{nonce_token}"),
                stat.block_requested
                    .map(|b| format!("{b}"))
                    .unwrap_or_default(),
                stat.required_confirmations
                    .map(|c| format!("{c}"))
                    .unwrap_or_default(),
                stat.block_processed
                    .map(|b| format!("{b}"))
                    .unwrap_or_default(),
            ])?;
        }
    }

    // Flush the writer and finish writing to the file
    writer.flush()?;

    Ok(())
}
