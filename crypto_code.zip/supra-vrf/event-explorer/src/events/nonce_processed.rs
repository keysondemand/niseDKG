use web3::ethabi::{Event, EventParam, Hash, LogParam, ParamType, RawLog};
use web3::types::{Address, Log, U256};

pub struct NonceProcessed {
    pub nonce: U256,
    pub client_wallet_address: Address,
    pub timestamp: U256,
}

impl NonceProcessed {
    fn event() -> Event {
        Event {
            name: "NonceProcessed".to_string(),
            inputs: vec![
                EventParam {
                    name: "nonce".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "clientWalletAddress".to_string(),
                    kind: ParamType::Address,
                    indexed: false,
                },
                EventParam {
                    name: "timestamp".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
            ],
            anonymous: false,
        }
    }
    pub fn signature() -> Hash {
        Self::event().signature()
    }
}

impl TryFrom<&Log> for NonceProcessed {
    type Error = anyhow::Error;

    fn try_from(log: &Log) -> Result<Self, Self::Error> {
        let [nonce, client_wallet_address, timestamp]: [LogParam; 3] = Self::event()
            .parse_log(RawLog {
                topics: vec![Self::signature()],
                data: log.data.0.clone(),
            })?
            .params
            .try_into()
            .map_err(|e| anyhow::anyhow!("{e:?} cannot be parsed to NonceProcessed"))?;

        Ok(Self {
            nonce: nonce
                .value
                .into_uint()
                .ok_or(anyhow::anyhow!("Can't parse nonce"))?,
            client_wallet_address: client_wallet_address
                .value
                .into_address()
                .ok_or(anyhow::anyhow!("Can't parse client_wallet_address"))?,
            timestamp: timestamp
                .value
                .into_uint()
                .ok_or(anyhow::anyhow!("Can't parse timestamp"))?,
        })
    }
}
