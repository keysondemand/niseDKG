use web3::ethabi::{Event, EventParam, Hash, LogParam, ParamType, RawLog};
use web3::types::{Address, Log, U256};

pub struct RequestGenerated {
    pub nonce: U256,
    pub instance_id: U256,
    pub caller_contract: Address,
    pub function_name: String,
    /// This value is actually u8, but let's be lazy and generous.
    pub rng_count: u32,
    pub num_confirmations: U256,
    pub client_seed: U256,
    pub client_wallet_address: Address,
}

impl RequestGenerated {
    fn event() -> Event {
        Event {
            name: "RequestGenerated".to_string(),
            inputs: vec![
                EventParam {
                    name: "nonce".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "instanceId".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "callerContract".to_string(),
                    kind: ParamType::Address,
                    indexed: false,
                },
                EventParam {
                    name: "functionName".to_string(),
                    kind: ParamType::String,
                    indexed: false,
                },
                EventParam {
                    name: "rngCount".to_string(),
                    kind: ParamType::Uint(8),
                    indexed: false,
                },
                EventParam {
                    name: "numConfirmations".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "clientSeed".to_string(),
                    kind: ParamType::Uint(256),
                    indexed: false,
                },
                EventParam {
                    name: "clientWalletAddress".to_string(),
                    kind: ParamType::Address,
                    indexed: false,
                },
            ],
            anonymous: false,
        }
    }
    pub fn signature() -> Hash {
        Self::event().signature()
    }
}

impl TryFrom<&Log> for RequestGenerated {
    type Error = anyhow::Error;

    fn try_from(log: &Log) -> Result<Self, Self::Error> {
        let [nonce,
        instance_id,
        caller_contract,
        function_name,
        rng_count,
        num_confirmations,
        client_seed,
        client_wallet_address]: [LogParam; 8] = Self::event().parse_log(RawLog {
            topics: vec![Self::signature()],
            data: log.data.0.clone(),
        })?
            .params
            .try_into()
            .map_err(|e| anyhow::anyhow!("{e:?} cannot be parsed to RequestGenerated"))?;

        Ok(Self {
            nonce: nonce
                .value
                .into_uint()
                .ok_or(anyhow::anyhow!("Can't parse nonce"))?,
            instance_id: instance_id
                .value
                .into_uint()
                .ok_or(anyhow::anyhow!("Can't parse instance_id"))?,
            caller_contract: caller_contract
                .value
                .into_address()
                .ok_or(anyhow::anyhow!("Can't parse caller_contract"))?,
            function_name: function_name
                .value
                .into_string()
                .ok_or(anyhow::anyhow!("Can't parse function_name"))?,
            rng_count: rng_count
                .value
                .into_uint()
                .ok_or(anyhow::anyhow!("Can't parse rng_count"))?
                .as_u32(),
            num_confirmations: num_confirmations
                .value
                .into_uint()
                .ok_or(anyhow::anyhow!("Can't parse num_confirmations"))?,
            client_seed: client_seed
                .value
                .into_uint()
                .ok_or(anyhow::anyhow!("Can't parse client_seed"))?,
            client_wallet_address: client_wallet_address
                .value
                .into_address()
                .ok_or(anyhow::anyhow!("Can't parse client_wallet_address"))?,
        })
    }
}
