use crate::csv::save_to_csv;
use crate::events::{NonceProcessed, RequestGenerated};
use crate::Cli;
use crate::{RAW_CSV, SLOW_CSV};
use chrono::Local;
use std::collections::BTreeMap;
use std::str::FromStr;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Semaphore;
use web3::contract::tokens::Tokenizable;
use web3::transports::Http;
use web3::types::{Address, BlockNumber, FilterBuilder, H160, U256, U64};
use web3::Web3;

async fn fetch_and_log_events(
    nonce_range: NonceRange,
    contract_address: H160,
    from: BlockNumber,
    to: BlockNumber,
    provider: Web3<Http>,
) -> anyhow::Result<BTreeMap<U256, EventStat>> {
    let mut stats: BTreeMap<U256, EventStat> = BTreeMap::new();

    // Left commented to showcase the contract construction.
    // It is not trivial.
    // let contract = {
    //     let smart_contract_abi = fs::read_to_string(ABI_LOCATION)?;
    //     let json_value: serde_json::Value = serde_json::from_str(&smart_contract_abi)?;
    //     let abi_string = json_value["abi"].to_string();
    //     Contract::from_json(provider.eth(), contract_address, abi_string.as_bytes())?
    // };

    let request_generated_signature = RequestGenerated::signature();
    let nonce_processed_signature = NonceProcessed::signature();

    // Build the event filter
    let filter = FilterBuilder::default()
        .address(vec![contract_address])
        .topics(
            Some(vec![request_generated_signature, nonce_processed_signature]),
            None,
            None,
            None,
        )
        .from_block(from)
        .to_block(to)
        .build();

    let logs = provider.eth().logs(filter).await?;

    for log in logs.into_iter() {
        let block_number = log.block_number.unwrap();

        if log.topics.contains(&request_generated_signature)
            && log.topics.contains(&nonce_processed_signature)
        {
            panic!("Event may not have several topics {:?}", log);
        } else if log.topics.contains(&request_generated_signature) {
            let event: RequestGenerated = (&log).try_into()?;

            // This `nonce` -> `token` conversion enables representation of `nonce` in hex
            // to harmonize with logs from `free node`.
            log::debug!("Request generated: nonce = {}", event.nonce.into_token());

            if !nonce_range.contains(&event.nonce.as_u64()) {
                log::trace!("\tNonce out of required range, skipping...");
                continue;
            }

            stats
                .entry(event.nonce)
                .and_modify(|stat| {
                    stat.block_requested = Some(block_number);
                    stat.required_confirmations = Some(event.num_confirmations);
                })
                .or_insert(EventStat {
                    block_requested: Some(block_number),
                    required_confirmations: Some(event.num_confirmations),
                    block_processed: None,
                });
        } else if log.topics.contains(&nonce_processed_signature) {
            let event: NonceProcessed = (&log).try_into()?;

            // This `nonce` -> `token` conversion enables representation of `nonce` in hex
            // to harmonize with logs from `free node`.
            log::debug!("Request generated: nonce = {}", event.nonce.into_token());

            if !nonce_range.contains(&event.nonce.as_u64()) {
                log::trace!("\tNonce out of required range, skipping...");
                continue;
            }

            stats
                .entry(event.nonce)
                .and_modify(|stat| stat.block_processed = Some(block_number))
                .or_insert(EventStat {
                    block_requested: None,
                    required_confirmations: None,
                    block_processed: Some(block_number),
                });
        } else {
            panic!("Unrequested event {log:?}");
        }
    }

    Ok(stats)
}

fn save(stats: &BTreeMap<U256, EventStat>) -> anyhow::Result<()> {
    let timestamp = Local::now().format("%Y-%m-%d_%H:%M:%S");

    let raw_name = format!("data/{RAW_CSV}_{timestamp}.csv");
    let no_filter = Box::new(|_: &EventStat| true);
    save_to_csv(&raw_name, stats, no_filter)?;

    let filtered_name = format!("data/{SLOW_CSV}_{timestamp}.csv",);
    let filter_slow = Box::new(|stat: &EventStat| {
        let Some(p) = stat.block_processed else {
            return true;
        };
        let Some(r) = stat.block_requested else {
            return true;
        };
        // It's OK to unwrap, because `required_confirmations` is set together with `requested`,
        // and that one contains a value.
        let n = U64::from(stat.required_confirmations.unwrap().as_u64());

        p - r - n > U64::one()
    });

    save_to_csv(&filtered_name, stats, filter_slow)
}

pub(crate) async fn concurrent_fetch_and_log_events(cli: &Cli) -> anyhow::Result<()> {
    let transport = Http::new(&cli.http)?;
    let provider = Web3::new(transport);

    let mut target_block = if let Some(t) = cli.to {
        t
    } else {
        let latest_block_number = provider.eth().block_number().await?.as_u64();
        log::info!("Latest block number: {latest_block_number}");
        latest_block_number
    };

    let permit_nb = cli.concurrency_limit.unwrap_or(1);
    let semaphore = Arc::new(Semaphore::new(permit_nb));

    let nonce_range: NonceRange = cli.into();
    let contract_address = Address::from_str(&cli.address)?;

    let stats = if let Some(chunk_size) = cli.chunk_size {
        let mut from = cli.from;

        let mut to = from + chunk_size;

        let mut stats_futures = Vec::new();

        while to < target_block {
            let semaphore = semaphore.clone();
            let moved_provider = provider.clone();
            let permit = semaphore
                .acquire_owned()
                .await
                .expect("the semaphore should always be open");
            let handle = tokio::spawn(async move {
                log::info!("Querying block from {from:?} to {to:?} (target block= {target_block})");

                let stats = match fetch_and_log_events(
                    nonce_range,
                    contract_address,
                    from.into(),
                    to.into(),
                    moved_provider.clone(),
                )
                .await
                {
                    Ok(stats) => Ok(stats),
                    Err(err) => {
                        // in case of error, wait for 2 seconds and retry.
                        log::warn!("An error occured when trying to fetch the events: {err}");
                        tokio::time::sleep(Duration::from_secs(2)).await;

                        let res = fetch_and_log_events(
                            nonce_range,
                            contract_address,
                            from.into(),
                            to.into(),
                            moved_provider,
                        )
                        .await;

                        let _ = res.as_ref().map_err(|err|{
                            log::error!("An error occured when re-trying: {err}, skipping the range from {from} to {to}");
                        });
                        res
                    }
                };

                drop(permit);

                stats
            });

            stats_futures.push(handle);
            from = to;
            to += chunk_size;

            // if there's no predefined end block (`to` option), then we need to refresh the target block here
            if cli.to.is_none() {
                let latest_block_number = provider.eth().block_number().await?.as_u64();
                log::info!("Latest block number: {latest_block_number}");
                target_block = latest_block_number;
            };
        }

        let last_block = if let Some(t) = cli.to {
            BlockNumber::from(t)
        } else {
            BlockNumber::Latest
        };

        log::info!("Querying block from {from:?} to {last_block:?}");
        let stats = fetch_and_log_events(
            nonce_range,
            contract_address,
            from.into(),
            last_block,
            provider.clone(),
        )
        .await?;

        let mut all_stats = vec![stats];

        for stats in stats_futures {
            let Ok(stats) = stats.await? else {
                    continue
            };
            all_stats.push(stats);
        }

        all_stats.into_iter().flatten().collect()
    } else {
        let from = BlockNumber::from(cli.from);
        let to = if let Some(t) = cli.to {
            BlockNumber::from(t)
        } else {
            BlockNumber::Latest
        };

        fetch_and_log_events(nonce_range, contract_address, from, to, provider).await?
    };

    save(&stats)
}

#[derive(Debug)]
pub(crate) struct EventStat {
    pub(crate) block_requested: Option<U64>,
    pub(crate) required_confirmations: Option<U256>,
    pub(crate) block_processed: Option<U64>,
}

/// Range for U256. Includes the lower border and does not include the higher border.
#[derive(Clone, Copy)]
pub(crate) struct NonceRange {
    start: u64,
    end: Option<u64>,
}

impl NonceRange {
    pub(crate) fn contains(&self, value: &u64) -> bool {
        self.start <= *value
            && if let Some(end) = self.end.as_ref() {
                *value <= *end
            } else {
                true
            }
    }
}

impl From<&Cli> for NonceRange {
    fn from(cli: &Cli) -> Self {
        Self {
            start: cli.start,
            end: cli.end,
        }
    }
}
