## Cron ##
### Low Deposit Balance cron ###
- Run this cron using `RUST_LOG=low_deposit_balance,scripts=info cargo run --release --bin low-deposit-balance`

## Reconciliation Scrip ##
### Data Collect ###
First collect all the callback transactions lists (start_block_number to end_block_number) and store in database.
- Run using this command `RUST_LOG=reco_data_collect,scripts=info cargo run --release --bin reco-data-collect`

### Execute ###
Process all the stored callback transaction settlement amount
- - Run using this command `RUST_LOG=reco_execute,scripts=info cargo run --release --bin reco-execute`