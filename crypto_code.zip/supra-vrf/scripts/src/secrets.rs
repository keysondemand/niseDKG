#[cfg(feature = "encrypted-secrets")]
use chacha20poly1305::aead::{Aead, OsRng};
#[cfg(feature = "encrypted-secrets")]
use chacha20poly1305::{AeadCore, KeyInit, XChaCha20Poly1305, XNonce};
use serde::{Deserialize, Serialize};

#[cfg(feature = "encrypted-secrets")]
const ENCRYPTED_CONFIG: &str = "./secrets.env.enc";

#[derive(Serialize, Deserialize, Debug, Default)]
pub struct SecretsConfig {
    pub secret_key_hex: String,
}

impl SecretsConfig {
    /// Loads secrets from an existing plaintext config
    pub fn load_plaintext() -> anyhow::Result<Self> {
        let secret_key_hex = dotenv::var("SUPRA_SECRET_KEY_HEX")?;
        let config = SecretsConfig { secret_key_hex };
        Ok(config)
    }

    #[cfg(feature = "encrypted-secrets")]
    /// Save the secrets to an encrypted config
    /// returns the key used to encrypt the config
    pub fn save_encrypted(self) -> anyhow::Result<[u8; 32]> {
        let key = XChaCha20Poly1305::generate_key(&mut OsRng);
        let cipher = XChaCha20Poly1305::new(&key);
        let nonce = XChaCha20Poly1305::generate_nonce(&mut OsRng);
        let raw_conf = toml_edit::easy::to_vec(&self)?;

        let mut enc_conf = nonce.to_vec();
        enc_conf.extend_from_slice(
            &cipher
                .encrypt(&nonce, raw_conf.as_ref())
                .expect("AEAD encryption failed?!"),
        );

        std::fs::write(ENCRYPTED_CONFIG, enc_conf)?;

        Ok(key.into())
    }

    /// Loads secrets from an existing config
    pub fn load() -> anyhow::Result<Self> {
        #[cfg(feature = "encrypted-secrets")]
        return Self::load_encrypted();

        #[cfg(not(feature = "encrypted-secrets"))]
        return Self::load_plaintext();
    }

    #[cfg(feature = "encrypted-secrets")]
    /// Loads secrets from an existing config
    pub fn load_encrypted() -> anyhow::Result<Self> {
        let enc_conf = std::fs::read(ENCRYPTED_CONFIG)?;
        let nonce = XNonce::from_slice(&enc_conf[..24]);
        let key = rpassword::prompt_password("Enter secret password(hex): ")?;

        let cipher = XChaCha20Poly1305::new_from_slice(
            &hex::decode(key).map_err(|_| anyhow::Error::msg("Invalid Key"))?,
        )
        .map_err(|_| anyhow::Error::msg("Invalid Key"))?;

        cipher
            .decrypt(nonce, &enc_conf[24..])
            .map_err(|_| anyhow::Error::msg("Invalid Key"))
            .and_then(|dec_conf| Ok(toml_edit::easy::from_slice(&dec_conf)?))
    }
}
