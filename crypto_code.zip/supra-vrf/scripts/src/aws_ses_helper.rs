use crate::types::{Customer, EmailTemplate};
use aws_config::meta::region::RegionProviderChain;
use aws_sdk_sesv2::types::{Body, Content, Destination, EmailContent, Message};
use aws_sdk_sesv2::{Client, Error};
use chrono::{TimeZone, Utc};
use log::info;
use web3::types::U256;

pub const AWS_FROM_EMAIL: &str = "noreply@supraoracles.com";

pub async fn setup_aws_ses() -> Client {
    let region_provider = RegionProviderChain::default_provider().or_else("us-east-1");
    let config = aws_config::from_env().region(region_provider).load().await;
    Client::new(&config)
}

pub fn format_message(
    template: &EmailTemplate,
    network_name: &str,
    customer: &Customer,
    category: u8,
    min_balance: U256,
    customer_balance: U256,
) -> (String, String) {
    let mut effective_balance =
        customer_balance.as_usize() as i128 - min_balance.as_usize() as i128;
    if effective_balance < 0 {
        effective_balance = 0
    }

    // ------------- Convert amount into "Wei" into "Ether" -------------
    let eb = effective_balance.to_string();
    let eb_map = ether_converter::convert(&eb, "wei");
    let effective_balance = eb_map
        .get("ether")
        .expect("not able to convert in ether effective_balance ")
        .clone()
        .parse::<f64>()
        .expect("Unable to parse f64 effective_balance");
    let formatted_eb = format!("{:.4}", effective_balance);

    let tb = customer_balance.as_usize().to_string();
    let tb_map = ether_converter::convert(&tb, "wei");
    let total_balance = tb_map
        .get("ether")
        .expect("not able to convert in ether total_balance ")
        .clone()
        .parse::<f64>()
        .expect("Unable to parse f64 total_balance");
    let formatted_tb = format!("{:.4}", total_balance);

    let mb = min_balance.as_usize().to_string();
    let mb_map = ether_converter::convert(&mb, "wei");
    let min_balance = mb_map
        .get("ether")
        .expect("not able to convert in ether min_balance")
        .clone()
        .parse::<f64>()
        .expect("Unable to parse f64 min_balance");
    let formatted_mb = format!("{:.4}", min_balance);
    // ------------------------------- END -------------------------------

    let timestamp = Utc::now().format("%Y-%m-%d %H:%M:%S %P %Z");
    let subject = template.clone().subject;
    let message = template.clone().content;
    let subject = subject
        .replace("{category}", &category.to_string())
        .replace("{network_name}", network_name);
    let message = message
        .replace("{network_name}", network_name)
        .replace("{wallet_address}", &customer.wallet_address)
        .replace("{category}", &category.to_string())
        .replace("{total_balance}", &formatted_tb)
        .replace("{min_balance}", &formatted_mb)
        .replace("{effective_balance}", &formatted_eb)
        .replace("{timestamp}", &timestamp.to_string());
    (subject, message)
}

pub fn format_rec_message(
    template: &EmailTemplate,
    network_name: &str,
    customer: &Customer,
    from_block_time: &U256,
    to_block_time: &U256,
    total_balance: U256,
    actual_tx_fee: i128,
    tx_fee_diff: i128,
) -> (String, String) {
    let from_timestamp = Utc
        .timestamp_opt(from_block_time.low_u64() as i64, 0)
        .unwrap();
    let to_timestamp = Utc
        .timestamp_opt(to_block_time.low_u64() as i64, 0)
        .unwrap();

    let timestamp = Utc::now().format("%Y-%m-%d %H:%M:%S %P %Z");
    let subject = template.clone().subject;
    let message = template.clone().content;
    let subject = subject
        .replace("{timestamp}", &timestamp.to_string())
        .replace("{network_name}", network_name);

    // ------------- Convert amount into "Wei" into "Ether" -------------
    let tb = total_balance.as_usize().to_string();
    let tb_map = ether_converter::convert(&tb, "wei");
    let total_balance = tb_map
        .get("ether")
        .expect("not able to convert in ether total_balance")
        .clone()
        .parse::<f64>()
        .expect("Unable to parse f64 total_balance");
    let formatted_tb = format!("{:.10}", total_balance);

    let atf = actual_tx_fee.to_string();
    let atf_map = ether_converter::convert(&atf, "wei");
    let actual_tx_fee = atf_map
        .get("ether")
        .expect("not able to convert in ether actual_tx_fee")
        .clone()
        .parse::<f64>()
        .expect("Unable to parse f64 actual_tx_fee");
    let formatted_atf = format!("{:.10}", actual_tx_fee);

    let tfd = tx_fee_diff.to_string();
    let tfd_map = ether_converter::convert(&tfd, "wei");
    let tx_fee_diff = tfd_map
        .get("ether")
        .expect("not able to convert in ether tx_fee_diff")
        .clone()
        .parse::<f64>()
        .expect("Unable to parse f64 tx_fee_diff");
    let formatted_tfd = format!("{:.10}", tx_fee_diff);

    let message = message
        .replace("{network_name}", network_name)
        .replace("{wallet_address}", &customer.wallet_address)
        .replace("{from_timestamp}", &from_timestamp.to_string())
        .replace("{to_timestamp}", &to_timestamp.to_string())
        .replace("{total_balance}", &formatted_tb)
        .replace("{actual_tx_fee}", &formatted_atf)
        .replace("{tx_fee_diff}", &formatted_tfd);

    (subject, message)
}

pub async fn send_message(
    client: &Client,
    list: &str,
    subject: &str,
    message: &str,
) -> Result<(), Error> {
    let aws_from_email = dotenv::var("AWS_FROM_EMAIL").unwrap_or(AWS_FROM_EMAIL.to_string());

    let dest = Destination::builder().to_addresses(list).build();
    let subject_content = Content::builder().data(subject).charset("UTF-8").build();
    let body_content = Content::builder().data(message).charset("UTF-8").build();
    let body = Body::builder().html(body_content).build();

    let msg = Message::builder()
        .subject(subject_content)
        .body(body)
        .build();

    let email_content = EmailContent::builder().simple(msg).build();

    client
        .send_email()
        .from_email_address(aws_from_email)
        .destination(dest)
        .content(email_content)
        .send()
        .await?;

    info!("Email sent to: {list}, subject: {subject}");

    Ok(())
}
