#[derive(Clone, Debug)]
pub struct Network {
    pub network_id: i32,
    pub network: String,
}

#[derive(Clone, Debug)]
pub struct Customer {
    pub customer_id: i32,
    pub wallet_address: String,
    pub email: String,
}

#[derive(Clone, Debug)]
pub struct EmailTemplate {
    pub template_id: i32,
    pub title: String,
    pub subject: String,
    pub content: String,
}

#[derive(Clone, Debug)]
pub struct LowBalanceNotification {
    pub customer_id: i32,
    pub below_50: bool,
    pub below_25: bool,
    pub below_10: bool,
    pub below_5: bool,
    pub below_0: bool,
    pub balance: i64,
    pub updated_at: chrono::DateTime<chrono::Utc>,
}

#[derive(Clone, Debug)]
pub struct CallbackTransaction {
    pub cb_tx_ud: i32,
    pub network_id: i32,
    pub customer_id: i32,
    pub nonce: i32,
    pub tx_hash: String,
    pub block_number: i64,
    pub estimated_tx_fee: i64,
    pub actual_tx_fee: i64,
    pub tx_fee_diff: i64,
    pub settlement_status: bool,
}

#[derive(Clone, Debug)]
pub struct Reconciliation {
    pub reco_id: i32,
    pub network_id: i32,
    pub customer_id: i32,
    pub start_block: i64,
    pub end_block: i64,
    pub total_estimated_fee: i64,
    pub total_actual_fee: i64,
    pub total_tx_fee: i64,
    pub reco_status: bool,
    pub email_status: bool,
    pub tx_hash: Option<String>,
}

#[derive(Clone, Debug)]
pub struct ExpandReconciliation {
    pub reco_id: Vec<i32>,
    pub network_id: i32,
    pub customer_id: i32,
    pub start_block: i64,
    pub end_block: i64,
    pub total_estimated_fee: i128,
    pub total_actual_fee: i128,
    pub total_tx_fee: i128,
    pub reco_status: bool,
    pub email_status: bool,
    pub tx_hash: Option<String>,
}

impl From<&Reconciliation> for ExpandReconciliation {
    fn from(value: &Reconciliation) -> Self {
        Self {
            reco_id: vec![value.reco_id],
            network_id: value.network_id,
            customer_id: value.customer_id,
            start_block: value.start_block,
            end_block: value.end_block,
            total_estimated_fee: value.total_estimated_fee as i128,
            total_actual_fee: value.total_actual_fee as i128,
            total_tx_fee: value.total_tx_fee as i128,
            reco_status: value.reco_status,
            email_status: value.email_status,
            tx_hash: None,
        }
    }
}

pub struct RecoCusGroup {
    pub customer_id: i32,
    pub total_estimated_fee: i64,
    pub total_actual_fee: i64,
    pub total_tx_fee: i64,
}
