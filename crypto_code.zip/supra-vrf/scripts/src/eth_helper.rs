use anyhow::Result;
use log::error;
use secp256k1::SecretKey;
use std::fs;
use std::str::FromStr;
use web3::api::Eth;
use web3::contract::{Contract, Options};
use web3::ethabi::{ParamType, Token};
use web3::signing::{keccak256, SecretKeyRef};
use web3::transports::Http;
use web3::types::{Address, BlockNumber, Filter, FilterBuilder, Transaction, H256, U256, U64};
use web3::Web3;

pub fn extract_txn_fee_from_generator(tx: &Transaction) -> Result<U256> {
    let param_def = vec![
        ParamType::Uint(256),
        ParamType::FixedBytes(32),
        ParamType::Bytes,
        ParamType::FixedArray(Box::new(ParamType::Uint(256)), 2),
        ParamType::Uint(8),
        ParamType::Uint(256),
        ParamType::Address,
        ParamType::String,
        ParamType::Address,
        ParamType::Uint(256),
    ];
    let dec_args = web3::ethabi::decode(&param_def, &tx.input.0[4..])?;
    dec_args[9]
        .clone()
        .into_uint()
        .ok_or_else(|| anyhow::anyhow!("Invalid transaction fee"))
}

fn get_contract_instance(
    sc_address: Address,
    eth_http_client: Eth<Http>,
    path: &str,
) -> Result<Contract<Http>> {
    // The following expects() are OK since this part will be removed before being deployed to production: the smart contract ABI will likely be statically linked and not fetched based on a environment variable
    let path = dotenv::var(path).expect("Missing SMART_CONTRACT_ABI_PATH environment variable");
    let smart_contract_abi =
        fs::read_to_string(path).expect("Failed to open the smart contract abi path");

    let json_value: serde_json::Value =
        serde_json::from_str(&smart_contract_abi).expect("failed to parse smart contract");

    let abi_string = json_value["abi"].to_string();

    Ok(
        Contract::from_json(eth_http_client, sc_address, abi_string.as_bytes())
            .expect("failed to get the contract instance"),
    )
}

pub fn get_deposit_instance(sc_client_url: &str, wallet_address: &str) -> Result<Contract<Http>> {
    let address = Address::from_str(wallet_address)?;
    let eth = get_eth(sc_client_url);
    get_contract_instance(address, eth, "DEPOSIT_CONTRACT_ABI_PATH")
}

pub fn get_generator_instance(sc_client_url: &str, wallet_address: &str) -> Result<Contract<Http>> {
    let address = Address::from_str(wallet_address)?;
    let eth = get_eth(sc_client_url);
    get_contract_instance(address, eth, "SMART_CONTRACT_ABI_PATH")
}

pub fn get_web3_client(sc_client_url: &str) -> Web3<Http> {
    let http = Http::new(sc_client_url).expect("Web3 client error");
    Web3::new(http)
}

pub fn get_eth(sc_client_url: &str) -> Eth<Http> {
    let web3 = get_web3_client(sc_client_url);
    web3.eth()
}

pub async fn get_balance_all_whitelisted(
    sc: &Contract<Http>,
    developer_address: &str,
) -> Result<(Vec<Address>, Vec<U256>, Vec<U256>)> {
    let from = Address::from_str(developer_address)?;
    sc.query(
        "checkBalanceAllWhitelisted",
        (),
        from,
        Options::default(),
        None,
    )
    .await
    .map_err(anyhow::Error::msg)
}

pub async fn check_min_balance_supra(sc: &Contract<Http>) -> Result<U256> {
    sc.query("checkMinBalanceSupra", (), None, Options::default(), None)
        .await
        .map_err(anyhow::Error::msg)
}

pub async fn check_client_balance(sc: &Contract<Http>, wallet_address: &str) -> Result<U256> {
    let from = Address::from_str(wallet_address)?;
    let params = Token::Address(from);
    sc.query("checkClientFund", params, from, Options::default(), None)
        .await
        .map_err(anyhow::Error::msg)
}

pub fn get_catchup_filter_for_event(
    sc_address: Address,
    start_block_number: U64,
    end_block_number: U64,
    event_type: &[u8],
) -> Filter {
    let h256_event_id = H256::from(keccak256(event_type));
    FilterBuilder::default()
        .address(vec![sc_address])
        .from_block(BlockNumber::Number(start_block_number))
        .to_block(BlockNumber::Number(end_block_number))
        .topics(Some(vec![h256_event_id]), None, None, None)
        .build()
}

pub async fn deposit_sc_execute_refund(
    deposit_sc: &Contract<Http>,
    pk: &SecretKey,
    receiver_address: &str,
    refund_amount: i128,
    from: &str,
) -> web3::error::Result<H256> {
    let pk_ref = SecretKeyRef::new(pk);
    let receiver_address = Address::from_str(receiver_address)
        .map_err(|_| web3::Error::Decoder("Invalid receiver address".to_string()))?;
    let address = Token::Address(receiver_address);
    let amount = Token::Uint(U256::from(refund_amount));

    let from = Address::from_str(from)
        .map_err(|_| web3::Error::Decoder("Invalid from address".to_string()))?;
    match deposit_sc
        .estimate_gas(
            "executeRefund",
            (address.clone(), amount.clone()),
            from,
            Options::default(),
        )
        .await
    {
        Ok(gas_estimate) => {
            let option = Options::with(|op| op.gas = Some(gas_estimate));
            deposit_sc
                .signed_call("executeRefund", (address, amount), option, pk_ref)
                .await
        }
        Err(err) => {
            error!("Gas estimation failed {:?}", err);
            Err(web3::Error::Decoder(err.to_string()))
        }
    }
}
