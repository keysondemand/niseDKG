use crate::types::{
    CallbackTransaction, Customer, EmailTemplate, LowBalanceNotification, Network, RecoCusGroup,
    Reconciliation,
};
use itertools::Itertools;
use log::{error, warn};
use sqlx::postgres::{PgPoolOptions, PgQueryResult, PgRow};
use sqlx::{Error, Pool, Postgres, Row};
use web3::types::{H256, U256, U64};

/// connect postgres database
pub async fn connect_db(db_host: &str) -> Result<Pool<Postgres>, Error> {
    PgPoolOptions::new()
        .max_connections(5)
        .connect(db_host)
        .await
}

/// Get network details by network name
pub async fn get_network_id(
    pool: &Pool<Postgres>,
    network: &str,
) -> Result<Option<Network>, Error> {
    match sqlx::query("SELECT * from networks WHERE network = $1")
        .bind(network)
        .fetch_one(pool)
        .await
    {
        Ok(pgrow) => {
            let response = Network {
                network_id: pgrow.get("network_id"),
                network: pgrow.get("network"),
            };
            Ok(Some(response))
        }
        Err(_) => Ok(None),
    }
}

/// get customer by wallet_address
pub async fn get_customer(
    pool: &Pool<Postgres>,
    wallet_address: &str,
) -> Result<Option<Customer>, Error> {
    match sqlx::query("SELECT * from customers WHERE UPPER(wallet_address) = UPPER($1)")
        .bind(wallet_address)
        .fetch_one(pool)
        .await
    {
        Ok(pgrow) => {
            let response = Customer {
                customer_id: pgrow.get("customer_id"),
                wallet_address: pgrow.get("wallet_address"),
                email: pgrow.get("email"),
            };
            Ok(Some(response))
        }
        Err(_) => Ok(None),
    }
}

/// get customer by customer_id
pub async fn get_customer_by_id(
    pool: &Pool<Postgres>,
    customer_id: &i32,
) -> Result<Option<Customer>, Error> {
    match sqlx::query("SELECT * from customers WHERE customer_id = $1")
        .bind(customer_id)
        .fetch_one(pool)
        .await
    {
        Ok(pgrow) => {
            let response = Customer {
                customer_id: pgrow.get("customer_id"),
                wallet_address: pgrow.get("wallet_address"),
                email: pgrow.get("email"),
            };
            Ok(Some(response))
        }
        Err(_) => Ok(None),
    }
}

/// get customer notification details
pub async fn get_notified_customer(
    pool: &Pool<Postgres>,
    customer_id: i32,
) -> Result<Option<LowBalanceNotification>, Error> {
    match sqlx::query("SELECT * from low_balance_notification WHERE customer_id = $1")
        .bind(customer_id)
        .fetch_one(pool)
        .await
    {
        Ok(pgrow) => {
            let response = LowBalanceNotification {
                customer_id: pgrow.get("customer_id"),
                below_50: pgrow.get("below_50"),
                below_25: pgrow.get("below_25"),
                below_10: pgrow.get("below_10"),
                below_5: pgrow.get("below_5"),
                below_0: pgrow.get("below_0"),
                balance: pgrow.get("balance"),
                updated_at: pgrow.get("updated_at"),
            };
            Ok(Some(response))
        }
        Err(_) => Ok(None),
    }
}

/// insert notification for customer
pub async fn insert_alert_notification(
    pool: &Pool<Postgres>,
    customer_id: i32,
    network_id: i32,
    category: u8,
    customer_balance: U256,
) {
    let mut query =
        "INSERT INTO low_balance_notification (customer_id,network_id,balance,".to_string();
    if category == 50 {
        query.push_str("below_50) VALUES ($1,$2,$3,true)");
    } else if category == 25 {
        query.push_str("below_25) VALUES ($1,$2,$3,true)");
    } else if category == 10 {
        query.push_str("below_10) VALUES ($1,$2,$3,true)");
    } else if category == 5 {
        query.push_str("below_5) VALUES ($1,$2,$3,true)");
    } else {
        query.push_str("below_0) VALUES ($1,$2,$3,true)");
    }
    match sqlx::query(&query)
        .bind(customer_id)
        .bind(network_id)
        .bind(customer_balance.as_usize() as i64)
        .execute(pool)
        .await
    {
        Ok(_) => {}
        Err(err) => {
            error!("Error - Insert data in low_balance_notification customer : {customer_id} err : {err}");
        }
    }
}

/// update notification for customer
pub async fn update_alert_notification(
    pool: &Pool<Postgres>,
    customer_id: i32,
    network_id: i32,
    category: u8,
    customer_balance: U256,
) {
    let mut query = "UPDATE low_balance_notification SET updated_at=$1,balance=$2,".to_string();
    if category == 50 {
        query.push_str("below_50=true WHERE (customer_id=$3 AND network_id=$4)");
    } else if category == 25 {
        query.push_str("below_25=true WHERE (customer_id=$3 AND network_id=$4)");
    } else if category == 10 {
        query.push_str("below_10=true WHERE (customer_id=$3 AND network_id=$4)");
    } else if category == 5 {
        query.push_str("below_5=true WHERE (customer_id=$3 AND network_id=$4)");
    } else {
        query.push_str("below_0=true WHERE (customer_id=$3 AND network_id=$4)");
    }
    match sqlx::query(&query)
        .bind(chrono::Utc::now())
        .bind(customer_balance.as_usize() as i64)
        .bind(customer_id)
        .bind(network_id)
        .execute(pool)
        .await
    {
        Ok(_) => {}
        Err(err) => {
            error!("Error - Update data in low_balance_notification customer : {customer_id} err : {err}");
        }
    };
}

/// Reset customer alert notifications
pub async fn reset_alert_notification(
    pool: &Pool<Postgres>,
    customer_id: i32,
    network_id: i32,
    customer_balance: U256,
) {
    let query = "UPDATE low_balance_notification SET updated_at=$1,balance=$2,below_50=false,below_25=false,below_10=false,below_5=false,below_0=false WHERE (customer_id=$3 AND network_id=$4)".to_string();
    match sqlx::query(&query)
        .bind(chrono::Utc::now())
        .bind(customer_balance.as_usize() as i64)
        .bind(customer_id)
        .bind(network_id)
        .execute(pool)
        .await
    {
        Ok(_) => {}
        Err(err) => {
            error!("Error - Reset data in low_balance_notification customer : {customer_id} err : {err}");
        }
    }
}

/// Get email template by title
pub async fn get_email_template(
    pool: &Pool<Postgres>,
    title: &str,
) -> Result<Option<EmailTemplate>, Error> {
    match sqlx::query("SELECT * from email_templates WHERE title = $1")
        .bind(title)
        .fetch_one(pool)
        .await
    {
        Ok(pgrow) => {
            let response = EmailTemplate {
                template_id: pgrow.get("template_id"),
                title: pgrow.get("title"),
                subject: pgrow.get("subject"),
                content: pgrow.get("content"),
            };
            Ok(Some(response))
        }
        Err(_) => Ok(None),
    }
}

/// Get all email templates
pub async fn get_all_email_templates(pool: &Pool<Postgres>) -> Result<Vec<EmailTemplate>, Error> {
    match sqlx::query("SELECT * from email_templates")
        .fetch_all(pool)
        .await
    {
        Ok(pgrow) => Ok(pgrow
            .iter()
            .map(|email_temp| EmailTemplate {
                template_id: email_temp.get("template_id"),
                title: email_temp.get("title"),
                subject: email_temp.get("subject"),
                content: email_temp.get("content"),
            })
            .collect::<Vec<EmailTemplate>>()),
        Err(_) => Ok(vec![]),
    }
}

/// Insert new callback_transaction logs
pub async fn insert_callback_transaction_logs(
    pool: &Pool<Postgres>,
    network_id: &i32,
    customer_id: &i32,
    nonce: usize,
    tx_hash: H256,
    block_number: U64,
    estimated_tx_fee: U256,
    actual_tx_fee: U256,
) {
    let mut tx_fee_diff = U256::default();
    let mut flag = false;
    if estimated_tx_fee > actual_tx_fee {
        tx_fee_diff = estimated_tx_fee - actual_tx_fee;
    } else {
        tx_fee_diff = actual_tx_fee - estimated_tx_fee;
        flag = true;
    }

    let mut tx_fee_diff_i64 = tx_fee_diff.as_usize() as i64;
    if flag {
        tx_fee_diff_i64 = -tx_fee_diff_i64;
    }

    let query = "INSERT INTO callback_transactions (network_id,customer_id,nonce,tx_hash,block_number,estimated_tx_fee,actual_tx_fee,tx_fee_diff) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)";
    match sqlx::query(query)
        .bind(network_id)
        .bind(customer_id)
        .bind(nonce as i64)
        .bind(format!("{:?}", tx_hash))
        .bind(block_number.as_usize() as i64)
        .bind(estimated_tx_fee.as_usize() as i64)
        .bind(actual_tx_fee.as_usize() as i64)
        .bind(tx_fee_diff_i64)
        .execute(pool)
        .await
    {
        Ok(_) => {}
        Err(err) => {
            error!("Error: Add data in callback_transactions nonce: {nonce} err : {err}")
        }
    };
}

/// Get callback transaction details by nonce
pub async fn get_callback_transaction_by_nonce(
    pool: &Pool<Postgres>,
    network_id: &i32,
    nonce: usize,
) -> Option<CallbackTransaction> {
    match sqlx::query("SELECT * from callback_transactions WHERE (network_id=$1 AND nonce=$2)")
        .bind(network_id)
        .bind(nonce as i64)
        .fetch_one(pool)
        .await
    {
        Ok(pg_row) => Some(get_cb_tx_pg_row(&pg_row)),
        Err(_) => None,
    }
}

/// Get unsettled callback transactions list (means refund is pending)
pub async fn get_unsettle_callback_transactions(
    pool: &Pool<Postgres>,
    network_id: &i32,
    customer_id: Option<i32>,
) -> Vec<RecoCusGroup> {
    let mut query =
        "SELECT customer_id, CAST(SUM(estimated_tx_fee) AS BIGINT) as estimated_tx_fee, CAST(SUM(actual_tx_fee) AS BIGINT) as actual_tx_fee, CAST(SUM(tx_fee_diff) AS BIGINT) as tx_fee_diff from callback_transactions WHERE (network_id=$1 AND settlement_status=false) GROUP BY customer_id"
            .to_string();
    if let Some(customer_id) = customer_id {
        query.push_str(&format!(" AND customer_id={customer_id}"));
    }

    match sqlx::query(&query).bind(network_id).fetch_all(pool).await {
        Ok(data) => {
            let result = data
                .iter()
                .map(get_cb_tx_group)
                .collect::<Vec<RecoCusGroup>>();
            result
        }
        Err(err) => {
            warn!("Error - get unsettled callback_transactions : {err}");
            vec![]
        }
    }
}

/// Update callback_transactions "settlement_status" status to true
pub async fn update_callback_settlement(
    pool: &Pool<Postgres>,
    network_id: &i32,
    customer_id: &i32,
) {
    let query = "UPDATE callback_transactions SET settlement_status=true WHERE (network_id=$1 AND customer_id=$2)";
    match sqlx::query(query)
        .bind(network_id)
        .bind(customer_id)
        .execute(pool)
        .await
    {
        Ok(_) => {}
        Err(err) => {
            error!(
                "Error - Update settlement_status in callback_transactions customer : {customer_id} err : {err}"
            )
        }
    }
}

/// Insert reconciliation data into table
pub async fn insert_reconciliation_data(
    pool: &Pool<Postgres>,
    network_id: &i32,
    customer_id: &i32,
    start_block: u64,
    end_block: u64,
    estimated_tx_fee: i64,
    actual_tx_fee: i64,
    tx_fee_diff: i64,
) {
    let query = "INSERT INTO reconciliations (network_id,customer_id,start_block,end_block,total_estimated_fee,total_actual_fee,total_tx_fee) VALUES ($1,$2,$3,$4,$5,$6,$7)";
    match sqlx::query(query)
        .bind(network_id)
        .bind(customer_id)
        .bind(start_block as i64)
        .bind(end_block as i64)
        .bind(estimated_tx_fee)
        .bind(actual_tx_fee)
        .bind(tx_fee_diff)
        .execute(pool)
        .await
    {
        Ok(_) => {}
        Err(err) => {
            error!("Error - Add data in reconciliation customer : {customer_id} err : {err}")
        }
    };
}

// update reconciliation status to true
pub async fn update_reconciliation_status(
    pool: &Pool<Postgres>,
    reco_ids: &[i32],
    tx_hash: &H256,
    email_status: bool,
) -> Result<PgQueryResult, Error> {
    let reco_ids = reco_ids.iter().join(",");
    let query =
        &"UPDATE reconciliations SET reco_status=true,email_status=$1,updated_at=$2,tx_hash=$3 WHERE reco_id IN ($4)"
            .replace("$4", &reco_ids);
    sqlx::query(query)
        .bind(email_status)
        .bind(chrono::Utc::now())
        .bind(format!("{:?}", tx_hash))
        .execute(pool)
        .await
}

/// Get unpaid="reco_status+false" reconciliation data
pub async fn get_unpaid_reconciliations(
    pool: &Pool<Postgres>,
    network_id: &i32,
    customer_id: Option<i32>,
) -> Vec<Reconciliation> {
    let mut query =
        "SELECT * from reconciliations WHERE reco_status=false AND network_id=$1".to_string();
    if let Some(customer_id) = customer_id {
        query.push_str(&format!(" AND customer_id={customer_id}"));
    }

    match sqlx::query(&query).bind(network_id).fetch_all(pool).await {
        Ok(data) => {
            let result = data
                .iter()
                .map(get_reco_from_pg_row)
                .collect::<Vec<Reconciliation>>();
            result
        }
        Err(err) => {
            warn!("Error - get reconciliations list : {err}");
            vec![]
        }
    }
}

fn get_reco_from_pg_row(pg_rpw: &PgRow) -> Reconciliation {
    Reconciliation {
        reco_id: pg_rpw.get("reco_id"),
        network_id: pg_rpw.get("network_id"),
        customer_id: pg_rpw.get("customer_id"),
        start_block: pg_rpw.get("start_block"),
        end_block: pg_rpw.get("end_block"),
        total_estimated_fee: pg_rpw.get("total_estimated_fee"),
        total_actual_fee: pg_rpw.get("total_actual_fee"),
        total_tx_fee: pg_rpw.get("total_tx_fee"),
        reco_status: pg_rpw.get("reco_status"),
        email_status: pg_rpw.get("email_status"),
        tx_hash: pg_rpw.get("tx_hash"),
    }
}

fn get_cb_tx_group(pg_row: &PgRow) -> RecoCusGroup {
    RecoCusGroup {
        customer_id: pg_row.get("customer_id"),
        total_estimated_fee: pg_row.get("estimated_tx_fee"),
        total_actual_fee: pg_row.get("actual_tx_fee"),
        total_tx_fee: pg_row.get("tx_fee_diff"),
    }
}

fn get_cb_tx_pg_row(pg_row: &PgRow) -> CallbackTransaction {
    CallbackTransaction {
        cb_tx_ud: pg_row.get("cb_tx_id"),
        network_id: pg_row.get("network_id"),
        customer_id: pg_row.get("customer_id"),
        nonce: pg_row.get("nonce"),
        tx_hash: pg_row.get("tx_hash"),
        block_number: pg_row.get("block_number"),
        estimated_tx_fee: pg_row.get("estimated_tx_fee"),
        actual_tx_fee: pg_row.get("actual_tx_fee"),
        tx_fee_diff: pg_row.get("tx_fee_diff"),
        settlement_status: pg_row.get("settlement_status"),
    }
}
