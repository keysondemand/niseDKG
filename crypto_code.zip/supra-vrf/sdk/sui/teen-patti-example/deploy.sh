#!/bin/bash

sui client publish --abi --gas-budget 30000000 --skip-dependency-verification