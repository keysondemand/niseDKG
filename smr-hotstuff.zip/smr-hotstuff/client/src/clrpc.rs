use crate::DkgEventData;
use crate::ElGamalPrivateKey;
use crate::SmrClientError;
use rpc::client::RPCClient;
use smrcommon::PublishTxPayload;
use smrcommon::SmrTransactionSubtype;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::config::DkgConfig;
use sodkg::state::DkgEvent;
use sodkg::state::DkgEventType;
use soruntime::state::Action;
use soruntime::state::EventProcessor;
use sosmr::SmrBlock;
use sosmr::SmrDkgType;
use sosmr::SmrTransactionProtocol;
use sosmr::{SmrBatch, SmrTransaction, TxExecutionStatus};
use std::net::SocketAddr;
use tokio::sync::mpsc;

#[derive(Clone, Debug)]
pub struct SmrRpcClient {
    client: RPCClient,
    rpc_access: Vec<SocketAddr>,
}

impl SmrRpcClient {
    pub async fn with_rpc_access(rpc_access: Vec<SocketAddr>) -> SmrRpcClient {
        let client = crate::search_for_access(&rpc_access)
            .await
            .unwrap_or_else(|| RPCClient::new(rpc_access[0]));
        SmrRpcClient { client, rpc_access }
    }

    pub async fn get_batch(&self, key: Vec<u8>) -> Result<Option<SmrBatch>, SmrClientError> {
        match self.client.get_batch(key.to_vec()).await {
            Ok(batch) => Ok(batch),
            Err(err) => {
                let client = crate::search_for_access(&self.rpc_access)
                    .await
                    .ok_or(err)
                    .map_err(SmrClientError::from)?;
                client.get_batch(key).await.map_err(|err| err.into())
            }
        }
    }

    pub async fn get_key(&self, key: Vec<u8>) -> Result<Option<Vec<u8>>, SmrClientError> {
        match self.client.get_key(key.to_vec()).await {
            Ok(key) => Ok(key.map(|b| b.to_vec())),
            Err(err) => {
                let client = crate::search_for_access(&self.rpc_access)
                    .await
                    .ok_or(err)
                    .map_err(SmrClientError::from)?;
                client
                    .get_key(key)
                    .await
                    .map(|b| b.map(|b| b.to_vec()))
                    .map_err(|err| err.into())
            }
        }
    }

    pub async fn send_tx(&self, tx: SmrTransaction) -> Result<(), SmrClientError> {
        match self.client.send_tx(tx.clone()).await {
            Ok(key) => Ok(key),
            Err(err) => {
                let client = crate::search_for_access(&self.rpc_access)
                    .await
                    .ok_or(err)
                    .map_err(SmrClientError::from)?;
                client.send_tx(tx).await.map_err(|err| err.into())
            }
        }
    }
}
