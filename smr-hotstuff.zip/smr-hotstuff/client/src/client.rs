use crate::DkgEventData;
use crate::ElGamalPrivateKey;
use crate::SmrClientError;
use rpc::client::RPCClient;
use rpc::client::WsClient;
use smrcommon::PublishTxPayload;
use smrcommon::SmrTransactionSubtype;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::config::DkgConfig;
use sodkg::state::DkgEvent;
use sodkg::state::DkgEventType;
use soruntime::state::Action;
use soruntime::state::EventProcessor;
use sosmr::SmrBlock;
use sosmr::SmrDkgType;
use sosmr::SmrTransactionProtocol;
use sosmr::{SmrBatch, SmrTransaction, TxExecutionStatus};
use std::net::SocketAddr;
use tokio::sync::mpsc;
use tokio::sync::oneshot;

pub struct HotstuffSmrClient {
    rpc_client: RPCClient,
    rpc_access: Vec<SocketAddr>,
    close_sender: Option<tokio::sync::oneshot::Sender<()>>,
}

impl HotstuffSmrClient {
    pub fn new(smr_node_address: SocketAddr) -> HotstuffSmrClient {
        HotstuffSmrClient {
            rpc_client: RPCClient::new(smr_node_address),
            rpc_access: vec![smr_node_address],
            close_sender: None,
        }
    }
    pub async fn with_rpc_access(rpc_access: Vec<SocketAddr>) -> HotstuffSmrClient {
        let rpc_client = crate::search_for_access(&rpc_access)
            .await
            .unwrap_or_else(|| RPCClient::new(rpc_access[0]));
        HotstuffSmrClient {
            rpc_client,
            rpc_access,
            close_sender: None,
        }
    }

    //no use since the batch tx type has been added to the block.
    // #[deprecated]
    // pub async fn subscribe_full_blocks(&self) -> mpsc::Receiver<(SmrBlock, Vec<SmrBatch>)> {
    //     let (block_tx, block_rx) = mpsc::channel(100);
    //     let smr_addr = self.rpc_access[0];
    //     log::trace!(
    //         "HotstuffSmrClient subscribe_full_blocks smr_addr:{}",
    //         smr_addr
    //     );
    //     tokio::spawn(async move {
    //         let wsclient = RPCClient::new(smr_addr);
    //         let client = RPCClient::<SmrBlock, SendError<SmrBlock>, _, _>::new(smr_addr);
    //         let handle = wsclient
    //             .subscribe(move |block| async move {
    //                 let mut batch_list = vec![];
    //                 for (_, key) in &block.payload {
    //                     match client.get_batch(key.0.to_vec()).await {
    //                         Ok(Some(batch)) => batch_list.push(batch),
    //                         val => log::error!("receive batch error:{:?}", val),
    //                     }
    //                 }
    //                 block_tx.send((block, batch_list)).await
    //             })
    //             .await;
    //         handle.await.unwrap();
    //         //tokio::join!(async { handle.await.unwrap() });
    //         log::trace!("HotstuffSmrClient subscribe_full_blocks end subscription");
    //     });
    //     block_rx
    // }

    pub async fn subscribe_blocks(&mut self) -> Result<mpsc::Receiver<SmrBlock>, SmrClientError> {
        if self.close_sender.is_some() {
            Err(SmrClientError::WSSubExistError)
        } else {
            let (block_tx, block_rx) = mpsc::channel(100);
            let smr_addr = self.rpc_access[0];
            let (close_sender, rx) = oneshot::channel();
            tokio::spawn(async move {
                let wsclient = WsClient::subscribe(smr_addr, move |block| async move {
                    block_tx.send(block).await
                })
                .await;
                let _ = rx.await; //wait the close signal
                wsclient.close_subscription().await;
                log::info!("HotstuffSmrClient end wsclient loop.");
            });
            self.close_sender = Some(close_sender);
            Ok(block_rx)
        }
    }

    pub async fn close_subscription(&mut self) {
        if let Some(tx) = self.close_sender.take() {
            let _ = tx.send(());
        };
    }

    pub async fn get_batch(&self, key: Vec<u8>) -> Result<Option<SmrBatch>, SmrClientError> {
        match self.rpc_client.get_batch(key.to_vec()).await {
            Ok(batch) => Ok(batch),
            Err(err) => {
                let client = crate::search_for_access(&self.rpc_access)
                    .await
                    .ok_or(err)
                    .map_err(SmrClientError::from)?;
                client.get_batch(key).await.map_err(|err| err.into())
            }
        }
    }

    pub async fn get_key(&self, key: Vec<u8>) -> Result<Option<Vec<u8>>, SmrClientError> {
        match self.rpc_client.get_key(key.to_vec()).await {
            Ok(key) => Ok(key.map(|b| b.to_vec())),
            Err(err) => {
                let client = crate::search_for_access(&self.rpc_access)
                    .await
                    .ok_or(err)
                    .map_err(SmrClientError::from)?;
                client
                    .get_key(key)
                    .await
                    .map(|b| b.map(|b| b.to_vec()))
                    .map_err(|err| err.into())
            }
        }
    }

    pub async fn send_tx(&self, tx: SmrTransaction) -> Result<(), SmrClientError> {
        match self.rpc_client.send_tx(tx.clone()).await {
            Ok(key) => Ok(key),
            Err(err) => {
                let client = crate::search_for_access(&self.rpc_access)
                    .await
                    .ok_or(err)
                    .map_err(SmrClientError::from)?;
                client.send_tx(tx).await.map_err(|err| err.into())
            }
        }
    }

    pub async fn send_ask_publish_tx(
        &self,
        secret_key: &SecretKey,
        dkg_type: SmrDkgType,
    ) -> Result<(), SmrClientError> {
        let tx = smrcommon::create_ask_publish_tx(secret_key, dkg_type).map_err(|err| {
            SmrClientError::GeneralError(format!("error during create_ask_publish_tx :{}", err))
        })?;
        self.send_tx(tx).await
    }

    pub async fn fetch_batch_for_protocol(
        &self,
        block: &SmrBlock,
        protocol: SmrTransactionProtocol,
    ) -> Result<Vec<SmrBatch>, SmrClientError> {
        let mut ret = vec![];
        for (proto, batch_key) in &block.payload {
            if *proto == protocol {
                if let Some(batch) = self.get_batch(batch_key.0.to_vec()).await? {
                    ret.push(batch)
                }
            }
        }
        Ok(ret)
    }

    //return none if the AskPublish doesn't execute correctly or a timeout occurs.
    pub async fn ask_publish_tx(
        &self,
        node_priv_key: &SecretKey,
        dkg_type: SmrDkgType,
        block_sub: &mut mpsc::Receiver<SmrBlock>,
    ) -> Result<Option<(PublishTxPayload, u64, Vec<DkgEvent>)>, SmrClientError> {
        let ask_tx = smrcommon::create_ask_publish_tx(node_priv_key, dkg_type).map_err(|err| {
            SmrClientError::GeneralError(format!("ask_publish_tx error during creation:{}.", err))
        })?;
        if let Err(err) = self.send_tx(ask_tx).await {
            return Err(SmrClientError::GeneralError(format!(
                "ask_publish_tx Can't send Smr ask tx cause:{}.",
                err
            )));
        }
        let node_identity = PublicKey::try_from(node_priv_key).unwrap(); //should not panic other the node should stop.
        let mut found_publish_payload = None;
        let mut see_ask_tx = false;
        let mut dkg_events = vec![];
        loop {
            if let Some(mut block) = block_sub.recv().await {
                //sort batch list with smr first.
                block.payload.sort_unstable_by_key(|(p, _)| {
                    if *p == SmrTransactionProtocol::Smr {
                        0
                    } else {
                        1
                    }
                });
                //process smr of dkg batch only
                let batch_iter = block.payload.into_iter().filter(|(p, _)| {
                    *p == SmrTransactionProtocol::Dkg(dkg_type) || *p == SmrTransactionProtocol::Smr
                });
                for (protocol, batch_id) in batch_iter {
                    if let Some(batch) = self.get_batch(batch_id.0.to_vec()).await? {
                        match protocol {
                            SmrTransactionProtocol::Smr => {
                                //manage Ask tx and publish Tx for the node
                                for (_, tx) in batch
                                    .into_iter_tx()
                                    .filter(|(status, _)| *status == TxExecutionStatus::Success)
                                {
                                    let tx_sub_type: SmrTransactionSubtype = tx.tx_sub_type.into();
                                    match tx_sub_type {
                                        SmrTransactionSubtype::Publish
                                            if found_publish_payload.is_none() =>
                                        {
                                            match PublishTxPayload::try_from(tx.payload) {
                                                Ok(payload)
                                                    if payload.sender == node_identity
                                                        && payload.committee_name == dkg_type =>
                                                {
                                                    found_publish_payload =
                                                        Some((payload, block.round))
                                                }
                                                Err(err) => {
                                                    log::error!(
                                                        "dkg error during Publish Tx payload deserialization:{}.",
                                                        err
                                                    );
                                                }
                                                Ok(_) => (),
                                            };
                                        }
                                        SmrTransactionSubtype::AskPublish
                                            if tx.sender == node_identity =>
                                        {
                                            see_ask_tx = true
                                        }
                                        _ => (),
                                    }
                                }
                            }
                            SmrTransactionProtocol::Dkg(_) if see_ask_tx => {
                                //add Tx to action if Ask Tx has been received
                                dkg_events = batch
                                    .into_iter_tx()
                                    .filter_map(|(status, tx)| {
                                        (status == TxExecutionStatus::Success).then_some(tx)
                                    })
                                    .filter_map(|tx| {
                                        log::trace!(
                                            "ask_publish_tx  DKG tx with for round:{} type:{:?}",
                                            block.round,
                                            tx.tx_sub_type,
                                        );
                                        match sodkg::transaction::convert_received_smrtx_to_event(
                                            &tx,
                                            block.round,
                                        ) {
                                            Ok(event) => Some(event),
                                            Err(err) => {
                                                log::warn!(
                                                    "error during smr tx convertion in event:{err}"
                                                );
                                                None
                                            }
                                        }
                                    })
                                    .collect::<Vec<DkgEvent>>();
                            }
                            _ => (),
                        }
                    } else {
                        log::error!(
                            "ask_publish_tx get_batch:{} from SMR not found. Tx are missing",
                            batch_id
                        );
                    }
                }

                // let batches = self
                //     .fetch_batch_for_protocol(&block, SmrTransactionProtocol::Smr)
                //     .await?;

                // let last_publish_tx = batches
                //     .into_iter()
                //     .rev()
                //     .flat_map(|batch| batch.into_iter_tx())
                //     //we get the last publish tx of the batch to have the most recent committee
                //     .fold(
                //         Ok::<Option<PublishTxPayload>, SmrClientError>(None),
                //         |mut last_tx, (status, tx)| {
                //             let tx_sub_type: SmrTransactionSubtype = tx.tx_sub_type.into();
                //             if status == TxExecutionStatus::Success
                //                 && SmrTransactionSubtype::Publish == tx_sub_type
                //             {
                //                 let payload =
                //                     PublishTxPayload::try_from(tx.payload).map_err(|err| {
                //                         SmrClientError::GeneralError(format!(
                //                         "dkg error during Publish Tx payload deserialization:{}.",
                //                         err
                //                     ))
                //                     })?;
                //                 if payload.committee_name == dkg_type {
                //                     last_tx = Ok(Some((payload, block.round)));
                //                 }
                //             }
                //             last_tx
                //         },
                //     )?;
                // if let Some(payload) = last_publish_tx {
                //     if payload.committee_name == dkg_type {
                //         //process other DKG tx in the same block (contains several batch).
                //         let dkg_batches = self
                //             .fetch_batch_for_protocol(&block, SmrTransactionProtocol::Dkg(dkg_type))
                //             .await?;

                //         let dkg_events = dkg_batches.into_iter().flat_map(|batch| batch.into_iter_tx())
                //             .filter_map(|(status, tx)| (status == TxExecutionStatus::Success).then_some(tx))
                //                  .filter_map(|tx| {
                //                      log::trace!("ask_publish_tx load publish tx received DKG tx with for round:{} type:{:?}"
                //                          , block.round, tx.tx_sub_type,);
                //                          match sodkg::transaction::convert_received_smrtx_to_event(&tx, block.round) {
                //                              Ok(event) => Some(event),
                //                              Err(err) => {
                //                                  log::warn!("ask_publish_tx load publish tx, error during smr tx convertion in event:{err}");
                //                                  None
                //                              },
                //                          }
                //                  }).collect::<Vec<DkgEvent>>();

                //         return Ok(Some((payload, block.round, dkg_events)));
                //     }
                // }
            }

            if found_publish_payload.is_some() {
                return Ok(
                    found_publish_payload.map(|(processor, round)| (processor, round, dkg_events))
                );
            }
        }
    }

    pub async fn bottstrap_dkg(
        &self,
        node_priv_key: &SecretKey,
        node_elgamal_secret_key: &ElGamalPrivateKey,
        dkg_type: SmrDkgType,
        dkgconfig: DkgConfig,
        block_sub: &mut mpsc::Receiver<SmrBlock>,
    ) -> Result<
        (
            EventProcessor<DkgEventData, DkgEvent, DkgEventType>,
            Vec<Action<DkgEventData, DkgEventType>>,
        ),
        SmrClientError,
    > {
        //wait publish tx
        log::trace!("DKG run_loop start waiting for Publish Tx.");
        match self
            .ask_publish_tx(node_priv_key, dkg_type, block_sub)
            .await?
        {
            Some((payload, round, dkg_events)) => {
                let (mut new_event_processos, mut actions) =
                    smrcommon::dkg::generate_dkg_state_with_publish_tx(
                        payload,
                        node_priv_key,
                        node_elgamal_secret_key,
                        dkg_type,
                        dkgconfig,
                        round,
                    )
                    .map_err(|err| {
                        SmrClientError::GeneralError(format!(
                            "bottstrap_dkg error during bootstrap:{}.",
                            err
                        ))
                    })?;

                //apply dkg events
                dkg_events.into_iter().for_each(|event| {
                    let mut new_actions = new_event_processos.process_event(Box::new(event));
                    actions.append(&mut new_actions);
                });
                log::trace!("SMR client bottstrap_dkg.");
                Ok((new_event_processos, actions))
            }
            None => Err(SmrClientError::GeneralError(
                "Error, Ask public Tx doesn't execute correclty, no Tx published".to_string(),
            )),
        }
    }
}
