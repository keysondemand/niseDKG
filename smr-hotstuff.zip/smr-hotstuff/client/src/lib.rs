use rpc::client::RPCClient;
use rpc::RPCError;
use sodkg::state::DkgEventData;
use sodkg::ElGamalPrivateKey;
use std::net::SocketAddr;
use thiserror::Error;

mod client;
//mod clrpc;

//pub use clrpc::SmrRpcClient;

pub use client::HotstuffSmrClient;

#[derive(Error, Debug)]
pub enum SmrClientError {
    #[error("General error: {0}")]
    GeneralError(String),

    #[error("RPC connection error : {0}")]
    RPCError(#[from] RPCError),

    #[error("WebSocket subscription already open. Close before subscribe")]
    WSSubExistError,
}

pub(crate) async fn search_for_access(access_list: &[SocketAddr]) -> Option<RPCClient> {
    for addr in access_list {
        let client = RPCClient::new(*addr);
        if let Ok(()) = client.ping().await {
            return Some(client);
        }
    }
    None
}
