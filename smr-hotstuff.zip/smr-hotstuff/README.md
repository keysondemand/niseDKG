# smr_hotstuff

SMR integration using hotsuff concensus.

The repo contains:
 * demo_smr: contains Hotstuff SMR integration demo that start a commitee in one process (nodes). Use client to simulate Tx send.
 * client: a client to connect to the SMR to send tx and be notified by commited blocks.
 * node: a SMR node main prg. See readme file for more info.
