use socrypto::PublicKey;
use socrypto::PUBLIC_KEY_LENGTH;
use sodkg::BlsPublicKey;
use sodkg::ElGamalPubKey;
use sodkg::BLS_PUBKEY_LEN;
use sodkg::ELGAMAL_PUBLICKEY_LEN;
use sosmr::{SmrDkgType, SmrError, SMR_TRANSACTION_DKGTYPE_LENGTH};
use std::cmp::Ordering;
use std::collections::BTreeMap;
use std::collections::HashMap;

#[derive(Debug, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct SmrDkgCommitteeName {
    pub name: SmrDkgType,
    pub done: bool,
}

impl SmrDkgCommitteeName {
    pub fn new(dkg_type: SmrDkgType) -> SmrDkgCommitteeName {
        SmrDkgCommitteeName {
            name: dkg_type,
            done: false,
        }
    }

    pub fn to_bytes(&self) -> Vec<u8> {
        let mut buffer = Vec::with_capacity(SMR_TRANSACTION_DKGTYPE_LENGTH + 1);
        let dkg_type_bytes: [u8; SMR_TRANSACTION_DKGTYPE_LENGTH] = self.name.into();
        let b = u8::from(self.done);
        buffer.push(b);
        buffer.extend(dkg_type_bytes);
        buffer
    }

    pub fn bytes_len() -> usize {
        SMR_TRANSACTION_DKGTYPE_LENGTH + 1
    }
}

impl TryFrom<Vec<u8>> for SmrDkgCommitteeName {
    type Error = SmrError;

    fn try_from(vec: Vec<u8>) -> Result<Self, Self::Error> {
        SmrDkgCommitteeName::try_from(&vec[..])
    }
}

impl TryFrom<&[u8]> for SmrDkgCommitteeName {
    type Error = SmrError;

    fn try_from(bytes: &[u8]) -> Result<Self, Self::Error> {
        if bytes.len() < SmrDkgCommitteeName::bytes_len() {
            return Err(SmrError::GeneralError(
                "SmrDkgCommitteeName try_from buffer to small".to_string(),
            ));
        }
        let done = bytes[0] == 1;
        let dkg_type_bytes = [
            bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7], bytes[8],
            bytes[9],
        ];
        Ok(SmrDkgCommitteeName {
            name: SmrDkgType::try_from(&dkg_type_bytes)?,
            done,
        })
    }
}

#[derive(Clone, Debug)]
pub struct SmrDkgCommitteeNode {
    pub identity: PublicKey,
    pub elgamal_publickey: ElGamalPubKey,
    pub dealing_order: u8,
    pub init_dkg_payload: Vec<u8>,
    pub public_share_payload: Vec<u8>,
    pub dealing_payload: Option<Vec<u8>>,
    pub partial_sign_payload: Vec<u8>,
    pub threshold_sign_payload: Vec<u8>,
    pub publish_committee_pubkey: Option<BlsPublicKey>,
}

impl SmrDkgCommitteeNode {
    pub fn new(identity: PublicKey, elgamal_publickey: ElGamalPubKey) -> Self {
        SmrDkgCommitteeNode {
            identity,
            elgamal_publickey,
            dealing_order: 0,
            init_dkg_payload: vec![],
            public_share_payload: vec![],
            dealing_payload: None,
            partial_sign_payload: vec![],
            threshold_sign_payload: vec![],
            publish_committee_pubkey: None,
        }
    }

    pub fn to_bytes(&self) -> Vec<u8> {
        let mut buffer = Vec::with_capacity(self.bytes_len());
        buffer.push(self.dealing_order);
        buffer.extend(self.identity.as_bytes());
        buffer.extend(self.elgamal_publickey.into_bytes());
        //add payloads:
        let len_bytes = (self.init_dkg_payload.len() as u32).to_le_bytes();
        buffer.extend(len_bytes);
        buffer.extend(&self.init_dkg_payload);
        let len_bytes = (self.public_share_payload.len() as u32).to_le_bytes();
        buffer.extend(len_bytes);
        buffer.extend(&self.public_share_payload);
        let len_bytes = (self.partial_sign_payload.len() as u32).to_le_bytes();
        buffer.extend(len_bytes);
        buffer.extend(&self.partial_sign_payload);
        let len_bytes = (self.threshold_sign_payload.len() as u32).to_le_bytes();
        buffer.extend(len_bytes);
        buffer.extend(&self.threshold_sign_payload);
        if let Some(dealing) = &self.dealing_payload {
            buffer.push(1);
            let len_bytes = (dealing.len() as u32).to_le_bytes();
            buffer.extend(len_bytes);
            buffer.extend(dealing);
        } else {
            buffer.push(0);
        }
        if let Some(pubkey) = &self.publish_committee_pubkey {
            buffer.push(1);
            buffer.extend(pubkey.into_bytes());
        } else {
            buffer.push(0);
        }
        buffer
    }

    fn bytes_len(&self) -> usize {
        PUBLIC_KEY_LENGTH
            + ELGAMAL_PUBLICKEY_LEN
            + 4
            + 1 //dealing_order
            + self.init_dkg_payload.len()
            + 4
            + self.public_share_payload.len()
            + 4
            + self.partial_sign_payload.len()
            + 4
            + self.threshold_sign_payload.len()
            + 1
            + self
                .dealing_payload
                .as_ref()
                .map(|d| 4 + d.len())
                .unwrap_or(0)
            + 1
            + self
                .publish_committee_pubkey
                .as_ref()
                .map(|_| BLS_PUBKEY_LEN)
                .unwrap_or(0)
    }
}

impl PartialOrd for SmrDkgCommitteeNode {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.identity.cmp(&other.identity))
    }
}
impl PartialEq for SmrDkgCommitteeNode {
    fn eq(&self, other: &Self) -> bool {
        self.identity == other.identity
    }
}

impl Ord for SmrDkgCommitteeNode {
    fn cmp(&self, other: &Self) -> Ordering {
        self.identity.cmp(&other.identity)
    }
}

impl Eq for SmrDkgCommitteeNode {}

// impl Borrow<PublicKey> for SmrDkgCommitteeNode {
//     fn borrow(&self) -> &PublicKey {
//         &self.identity
//     }
// }

impl TryFrom<Vec<u8>> for SmrDkgCommitteeNode {
    type Error = SmrError;

    fn try_from(vec: Vec<u8>) -> Result<Self, Self::Error> {
        SmrDkgCommitteeNode::try_from(&vec[..])
    }
}

impl TryFrom<&[u8]> for SmrDkgCommitteeNode {
    type Error = SmrError;

    fn try_from(bytes: &[u8]) -> Result<Self, Self::Error> {
        let buffer_length = bytes.len();
        if buffer_length < PUBLIC_KEY_LENGTH + 4 + 1 + ELGAMAL_PUBLICKEY_LEN {
            return Err(SmrError::GeneralError(
                "SmrDkgCommitteeNode try_from buffer to small for identity".to_string(),
            ));
        }

        let dealing_order = bytes[0];
        let identity: [u8; PUBLIC_KEY_LENGTH] = (&bytes[1..PUBLIC_KEY_LENGTH + 1])
            .try_into()
            .map_err(|err| {
                SmrError::GeneralError(format!(
                    "could not extract elgamal pubkey from slice: {:?}",
                    err
                ))
            })?;
        let mut start = PUBLIC_KEY_LENGTH + 1;

        let elgamal_bytes: &[u8] = &bytes[start..start + ELGAMAL_PUBLICKEY_LEN];
        let elgamal_publickey = ElGamalPubKey::try_from(elgamal_bytes).map_err(|err| {
            SmrError::GeneralError(format!(
                "could not extract ElGamalPubKey from slice: {:?}",
                err
            ))
        })?;
        start += ELGAMAL_PUBLICKEY_LEN;

        let length = u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
        start += 4;
        if buffer_length < start + length + 4 {
            return Err(SmrError::GeneralError(
                "SmrDkgCommitteeNode try_from buffer to small for init_dkg_payload".to_string(),
            ));
        }
        let init_dkg_payload: Vec<u8> = (&bytes[start..start + length]).into();
        start += length;

        let length = u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
        start += 4;
        if buffer_length < start + length + 1 {
            return Err(SmrError::GeneralError(
                "SmrDkgCommitteeNode try_from buffer to small for public_share_payload".to_string(),
            ));
        }
        let public_share_payload: Vec<u8> = (&bytes[start..start + length]).into();
        start += length;

        let length = u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
        start += 4;
        if buffer_length < start + length + 1 {
            return Err(SmrError::GeneralError(
                "SmrDkgCommitteeNode try_from buffer to small for partial_sign_payload".to_string(),
            ));
        }
        let partial_sign_payload: Vec<u8> = (&bytes[start..start + length]).into();
        start += length;

        let length = u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
        start += 4;
        if buffer_length < start + length + 1 {
            return Err(SmrError::GeneralError(
                "SmrDkgCommitteeNode try_from buffer to small for threshold_sign_payload"
                    .to_string(),
            ));
        }
        let threshold_sign_payload: Vec<u8> = (&bytes[start..start + length]).into();
        start += length;

        let dealing_payload = if bytes[start] == 1 {
            start += 1;
            let length = u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
            start += 4;
            if buffer_length < start + length {
                return Err(SmrError::GeneralError(
                    "SmrDkgCommitteeNode try_from buffer to small for dealing".to_string(),
                ));
            }
            let dealing: Vec<u8> = (&bytes[start..start + length]).into();
            start += length;

            Some(dealing)
        } else {
            start += 1;
            None
        };
        let publish_committee_pubkey = if bytes[start] == 1 {
            if bytes.len() < start + BLS_PUBKEY_LEN {
                return Err(SmrError::GeneralError(
                    "SmrDkgCommittee try_from buffer to small for publish_committee_pubkey"
                        .to_string(),
                ));
            }
            start += 1;
            let pubkey =
                BlsPublicKey::try_from(&bytes[start..start + BLS_PUBKEY_LEN]).map_err(|err| {
                    SmrError::GeneralError(format!(
                    "error during SmrDkgCommittee committee BlsPublicKey deserialisation :{err}"
                ))
                })?;
            Some(pubkey)
        } else {
            None
        };
        Ok(SmrDkgCommitteeNode {
            identity: PublicKey(identity),
            elgamal_publickey,
            init_dkg_payload,
            dealing_order,
            public_share_payload,
            dealing_payload,
            partial_sign_payload,
            threshold_sign_payload,
            publish_committee_pubkey,
        })
    }
}

#[derive(Clone, Debug)]
pub struct SmrDkgCommittee {
    pub smrkey: SmrDkgCommitteeName,
    pub threshold_pubkey: Option<BlsPublicKey>,
    pub committee: HashMap<PublicKey, SmrDkgCommitteeNode>,
}

impl SmrDkgCommittee {
    pub fn new(smrkey: SmrDkgCommitteeName, members: Vec<(PublicKey, ElGamalPubKey)>) -> Self {
        let committee = members
            .into_iter()
            .map(|(pk, ekp)| (pk, SmrDkgCommitteeNode::new(pk, ekp)))
            .collect();
        SmrDkgCommittee {
            smrkey,
            threshold_pubkey: None,
            committee,
        }
    }

    pub fn is_started(&self) -> bool {
        !self.committee.is_empty()
            && self
                .committee
                .values()
                .next()
                .map(|c| !c.init_dkg_payload.is_empty())
                .unwrap_or(false)
    }

    pub fn has_enougth_committee_publickey(&self, threshold: usize) -> Option<BlsPublicKey> {
        if self.committee.is_empty() {
            return None;
        }
        let mut key_list: Vec<&BlsPublicKey> = self
            .committee
            .values()
            .filter_map(|n| n.publish_committee_pubkey.as_ref())
            .collect();
        key_list.sort_unstable();

        let accumulated = key_list
            .into_iter()
            .fold(BTreeMap::new(), |mut store, newkey| {
                let counter = store.entry(newkey).or_insert(0);
                *counter += 1;
                store
            });
        log::info!("smrcommittee has_enougth_committee_publickey threshold:{threshold} accumulated:{accumulated:?}");
        accumulated
            .into_iter()
            .filter_map(|(pk, count)| (count >= threshold).then(|| pk.clone()))
            .next()
    }

    pub fn to_bytes(&self) -> Vec<u8> {
        let mut buffer = Vec::with_capacity(
            ((PUBLIC_KEY_LENGTH + 16) * self.committee.len())
                + 4
                + 1
                + SmrDkgCommitteeName::bytes_len()
                + BLS_PUBKEY_LEN,
        );
        let len_bytes = (self.committee.len() as u32).to_le_bytes();
        buffer.extend(len_bytes);
        for node in self.committee.values() {
            buffer.extend(node.to_bytes());
        }

        buffer.extend(self.smrkey.to_bytes());
        if let Some(pks) = &self.threshold_pubkey {
            buffer.push(1);
            buffer.extend(pks.into_bytes());
        } else {
            buffer.push(0);
        }
        buffer
    }
}

impl TryFrom<Vec<u8>> for SmrDkgCommittee {
    type Error = SmrError;

    fn try_from(vec: Vec<u8>) -> Result<Self, Self::Error> {
        SmrDkgCommittee::try_from(&vec[..])
    }
}

impl TryFrom<&[u8]> for SmrDkgCommittee {
    type Error = SmrError;

    fn try_from(bytes: &[u8]) -> Result<Self, Self::Error> {
        if bytes.len() < 4
        //array len
        {
            return Err(SmrError::GeneralError(
                "SmrDkgCommittee try_from buffer to small".to_string(),
            ));
        }
        let mut committee = HashMap::new();
        let mut start = 4;

        let vec_len = u32::from_le_bytes(bytes[..4].try_into()?) as usize;
        for _ in 0..vec_len {
            let node = SmrDkgCommitteeNode::try_from(&bytes[start..])?;
            start += node.bytes_len();
            committee.insert(node.identity, node);
        }

        if bytes.len() < start + SmrDkgCommitteeName::bytes_len() {
            return Err(SmrError::GeneralError(
                "SmrDkgCommittee try_from buffer to small for smrkey".to_string(),
            ));
        }
        let smrkey =
            SmrDkgCommitteeName::try_from(&bytes[start..start + SmrDkgCommitteeName::bytes_len()])?;
        start += SmrDkgCommitteeName::bytes_len();

        let threshold_pubkey = if bytes[start] == 1 {
            if bytes.len() < start + BLS_PUBKEY_LEN {
                return Err(SmrError::GeneralError(
                    "SmrDkgCommittee try_from buffer to small for bls pubkey".to_string(),
                ));
            }
            start += 1;
            let sign =
                BlsPublicKey::try_from(&bytes[start..start + BLS_PUBKEY_LEN]).map_err(|err| {
                    SmrError::GeneralError(format!(
                    "error during SmrDkgCommittee committee BlsPublicKey deserialisation :{err}"
                ))
                })?;
            Some(sign)
        } else {
            None
        };

        Ok(SmrDkgCommittee {
            smrkey,
            threshold_pubkey,
            committee,
        })
    }
}
