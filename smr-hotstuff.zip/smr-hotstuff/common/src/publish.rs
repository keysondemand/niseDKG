use crate::SmrDkgCommittee;
use crate::SmrDkgType;
use crate::SmrError;
use crate::PUBLIC_KEY_LENGTH;
use socrypto::PublicKey;
use sosmr::SMR_TRANSACTION_DKGTYPE_LENGTH;

#[derive(Clone, Debug)]
pub struct PublishTxPayload {
    pub sender: PublicKey,
    pub committee_name: SmrDkgType,
    pub committee: SmrDkgCommittee,
}

impl PublishTxPayload {
    pub fn to_bytes(&self) -> Vec<u8> {
        let committee_bytes = self.committee.to_bytes();
        let mut buffer = Vec::with_capacity(
            PUBLIC_KEY_LENGTH + SMR_TRANSACTION_DKGTYPE_LENGTH + 4 + committee_bytes.len(),
        );

        buffer.extend(self.sender.to_bytes());
        let dkg_type_bytes: [u8; SMR_TRANSACTION_DKGTYPE_LENGTH] = self.committee_name.into();
        buffer.extend(dkg_type_bytes);

        let len_bytes = (committee_bytes.len() as u32).to_le_bytes();
        buffer.extend(len_bytes);
        buffer.extend(committee_bytes);

        buffer
    }
}

impl TryFrom<Vec<u8>> for PublishTxPayload {
    type Error = SmrError;

    fn try_from(vec: Vec<u8>) -> Result<Self, Self::Error> {
        PublishTxPayload::try_from(&vec[..])
    }
}

impl TryFrom<&[u8]> for PublishTxPayload {
    type Error = SmrError;

    fn try_from(bytes: &[u8]) -> Result<Self, Self::Error> {
        if bytes.len() < PUBLIC_KEY_LENGTH + SMR_TRANSACTION_DKGTYPE_LENGTH + 1 {
            return Err(SmrError::GeneralError(format!(
                "PublishTxPayload try_from buffer to small byte len:{} less than :{}",
                bytes.len(),
                PUBLIC_KEY_LENGTH + SMR_TRANSACTION_DKGTYPE_LENGTH + 1
            )));
        }

        let sender: [u8; PUBLIC_KEY_LENGTH] =
            (&bytes[0..PUBLIC_KEY_LENGTH]).try_into().map_err(|err| {
                SmrError::GeneralError(format!(
                    "could not extract PublishTxPayload sender from slice: {:?}",
                    err
                ))
            })?;

        let mut start = PUBLIC_KEY_LENGTH;
        let committee_name = [
            bytes[start],
            bytes[start + 1],
            bytes[start + 2],
            bytes[start + 3],
            bytes[start + 4],
            bytes[start + 5],
            bytes[start + 6],
            bytes[start + 7],
            bytes[start + 8],
        ];

        start += SMR_TRANSACTION_DKGTYPE_LENGTH;

        let length = u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize;
        start += 4;
        if bytes.len() < start + length {
            return Err(SmrError::GeneralError(
                "PublishTxPayload try_from buffer to small for SmrDkgCommittee".to_string(),
            ));
        }
        let committee = SmrDkgCommittee::try_from(&bytes[start..start + length])?;

        Ok(PublishTxPayload {
            sender: socrypto::PublicKey(sender),
            committee_name: SmrDkgType::try_from(&committee_name)?,
            committee,
        })
    }
}
