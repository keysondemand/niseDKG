use crate::PublishTxPayload;
use crate::SmrDkgCommittee;
use crate::SmrDkgCommitteeDefinition;
use crate::SmrDkgCommitteeNode;
use crate::SmrDkgType;
use crate::DKG_DEFINITION_FILE_NAME;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::config::DkgConfig;
use sodkg::errors::DkgError;
use sodkg::state::DkgEvent;
use sodkg::state::DkgEventData;
use sodkg::state::DkgEventType;
use sodkg::BlsPartialSignature;
use sodkg::BlsPublicKey;
use sodkg::BlsSignature;
use sodkg::DLEqProof;
use sodkg::BLS_PUBKEY_LEN;
use sodkg::{Dealing, ElGamalPrivateKey, ElGamalPubKey};
use soruntime::state::Action;
use soruntime::state::EventProcessor;
use sosmr::SmrError;
use std::fs::OpenOptions;
use std::path::Path;

pub fn read_dkg_definition() -> Result<Vec<SmrDkgCommitteeDefinition>, SmrError> {
    let text = std::fs::read_to_string(DKG_DEFINITION_FILE_NAME)
        .map_err(|err| SmrError::GeneralError(format!("read_dkg_definition file error:{}", err)))?;
    serde_json::from_str::<Vec<SmrDkgCommitteeDefinition>>(&text).map_err(|err| {
        SmrError::GeneralError(format!(
            "read_dkg_definition parse json content error:{}",
            err
        ))
    })
}

pub fn save_dkg_definition(definition: &[SmrDkgCommitteeDefinition]) -> Result<(), SmrError> {
    save_dkg_definition_target_dir(Path::new("."), definition)
}

pub fn save_dkg_definition_target_dir(
    target_dir: &Path,
    definition: &[SmrDkgCommitteeDefinition],
) -> Result<(), SmrError> {
    let path = target_dir.join(DKG_DEFINITION_FILE_NAME);
    let file = OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(true)
        .open(path)
        .map_err(|err| SmrError::GeneralError(format!("read_dkg_definition file error:{}", err)))?;
    // serde_json::from_str::<DkgCommitteeDefinition>(&text).map_err(|err| {
    //     SmrError::GeneralError(format!(
    //         "save_dkg_definition can't open file:{} error:{}", DKG_DEFINITION_FILE_NAME,
    //         err
    //     ));
    //f.write_all(b"hello workes sdsdsd1r").expect("Failed to write");
    serde_json::to_writer(&file, definition).map_err(|err| {
        SmrError::GeneralError(format!(
            "save_dkg_definition can't open save json defintion:{} error:{}",
            DKG_DEFINITION_FILE_NAME, err
        ))
    })
}

#[allow(clippy::type_complexity)]
pub fn generate_dkg_state_with_publish_tx(
    tx_payload: PublishTxPayload,
    secret_key: &SecretKey,
    elgamal_secret_key: &ElGamalPrivateKey,
    dkg_type: SmrDkgType,
    dkgconfig: DkgConfig,
    round: u64,
) -> Result<
    (
        EventProcessor<DkgEventData, DkgEvent, DkgEventType>,
        Vec<Action<DkgEventData, DkgEventType>>,
    ),
    DkgError,
> {
    log::trace!("Init DKG from publish Tx");
    let smr_committee = tx_payload.committee;

    dkg_recreate_events(
        secret_key,
        elgamal_secret_key,
        smr_committee,
        dkg_type,
        dkgconfig,
        round,
        false,
    )
}

#[allow(clippy::type_complexity)]
pub fn dkg_recreate_events(
    secret_key: &SecretKey,
    elgamal_secret_key: &ElGamalPrivateKey,
    mut smr_committee: SmrDkgCommittee,
    dkg_type: SmrDkgType,
    dkgconfig: DkgConfig,
    round: u64,
    synchronize_dkg: bool,
) -> Result<
    (
        EventProcessor<DkgEventData, DkgEvent, DkgEventType>,
        Vec<Action<DkgEventData, DkgEventType>>,
    ),
    DkgError,
> {
    let members = smr_committee
        .committee
        .values()
        .map(|c| (c.identity, c.elgamal_publickey.clone()))
        .collect();
    //let threshold = dkgconfig.threshold_f;
    let dealer_threshold_g = dkgconfig.dealer_threshold_g;

    let mut event_processor = sodkg::state::init_states_for_dkg(
        secret_key.clone(),
        elgamal_secret_key.clone(),
        dkg_type,
        dkgconfig,
        members,
        synchronize_dkg,
    );

    let node_identity = PublicKey::try_from(secret_key).unwrap(); //should not panic other the node should stop.

    log::trace!(
        "DKG process_events, publish tx contains {} nodes, nodes:{}",
        smr_committee.committee.len(),
        smr_committee
            .committee
            .iter()
            .map(|n| format!("{}/{}, ", n.0, n.1.init_dkg_payload.len()))
            .collect::<String>()
    );

    let (is_peer_present, has_send_dealing, has_send_publicshare, has_threshold_sign, _has_sign) =
        smr_committee
            .committee
            .values()
            .find(|node| node.identity == node_identity)
            .map(|node| {
                (
                    true,
                    node.dealing_payload.is_some(),
                    !node.public_share_payload.is_empty(),
                    !node.threshold_sign_payload.is_empty(),
                    node.publish_committee_pubkey.is_some(),
                )
            })
            .unwrap_or((false, false, false, false, false));
    log::trace!("dkg_recreate_events is_peer_present:{is_peer_present} has_send_dealing:{has_send_dealing} has_send_publicshare:{has_send_publicshare}");

    //if hasn't participate add the node to the list.
    if !is_peer_present {
        let elgamal_publickey = ElGamalPubKey::try_from(elgamal_secret_key).unwrap(); //unwrap should never fail on normal node.;
        let init_dkg_payload = elgamal_publickey.into_bytes();
        let node = SmrDkgCommitteeNode {
            identity: node_identity,
            elgamal_publickey,
            dealing_order: 0,
            init_dkg_payload,
            public_share_payload: vec![],
            partial_sign_payload: vec![],
            dealing_payload: None,
            threshold_sign_payload: vec![],
            publish_committee_pubkey: None,
        };

        smr_committee.committee.insert(node_identity, node);
    }

    //first init DKG
    let event = DkgEvent::new_init_dkg();
    let mut init_dkg_actions = event_processor.process_event(Box::new(event));

    // //validate init is done correctly.
    // if event_processor.get_subscriber(1).is_none() {
    //     //return the public key action. Dkg not finished.
    //     log::trace!("End update_dkg_state_with_publish_tx DKG before init in tx publish");
    //     return Ok((event_processor, init_dkg_actions));
    // }

    log::trace!("Restart DKG from old published one.");

    //sort committee in the dealing order
    let mut sorted_committee: Vec<_> = smr_committee.committee.values().collect();
    sorted_committee.sort_unstable_by_key(|node| {
        //0 order are at the end.
        if node.dealing_order == 0 {
            u8::MAX
        } else {
            node.dealing_order
        }
    });

    //second init dkg
    for node in sorted_committee
        .iter()
        .filter(|node| !node.init_dkg_payload.is_empty())
    {
        let el_gamal_pub_key = ElGamalPubKey::try_from(&node.init_dkg_payload[..])?;
        let event = DkgEvent {
            event_type: DkgEventType::ReceiveNodeInit,
            data: DkgEventData::PubkeyPublished(node.identity, el_gamal_pub_key, round),
        };
        log::trace!(
            "DKG process_events, node:{} send PubkeyPublished",
            node.identity
        );
        let mut actions = event_processor.process_event(Box::new(event));
        if !has_send_dealing && !actions.is_empty() {
            init_dkg_actions.append(&mut actions);
        }
    }

    //validate enough pk has been published.
    // if event_processor.get_subscriber(2).is_none() {
    //     //return the public key action and dealing. Dkg not finished.
    //     log::info!("End update_dkg_state_with_publish_tx DKG before send dealing in tx publish");
    //     return Ok((event_processor, init_dkg_actions));
    // }

    //third add dealings
    for node in sorted_committee.iter() {
        if let Some(dealing) = node.dealing_payload.as_ref() {
            if node.dealing_order as usize <= dealer_threshold_g {
                let payload: &[u8] = dealing;
                let dealing = Dealing::try_from(payload)?;

                let event = DkgEvent {
                    event_type: DkgEventType::ReceivedealingEvent,
                    data: DkgEventData::ReceiveDealing(node.identity, Box::new(dealing)),
                };
                log::trace!(
                    "DKG process_events, node:{} send ReceivedealingEvent",
                    node.identity
                );
                let mut actions = event_processor.process_event(Box::new(event));
                log::trace!("dkg_recreate_events action.len:{}", actions.len());
                if !has_send_publicshare && !actions.is_empty() {
                    init_dkg_actions.append(&mut actions);
                }
            }
        }
    }

    //validate enough dealing has been published.
    // if event_processor.get_subscriber(3).is_none() {
    //     //return the delaing action. Dkg not finished.
    //     log::info!(
    //         "End update_dkg_state_with_publish_tx DKG before send public share in tx publish"
    //     );
    //     return Ok((event_processor, init_dkg_actions));
    // }

    //four send public share
    let mut send_publicshare_actions = vec![];
    for node in sorted_committee.iter() {
        if !node.public_share_payload.is_empty() {
            let bls_pubkey = BlsPublicKey::try_from(&node.public_share_payload[..BLS_PUBKEY_LEN])?;
            let bls_proof = DLEqProof::try_from(&node.public_share_payload[BLS_PUBKEY_LEN..])?;
            let event = DkgEvent {
                event_type: DkgEventType::ReceivePublicShare,
                data: DkgEventData::ReceivePublicShare(node.identity, bls_pubkey, bls_proof),
            };
            log::trace!(
                "DKG process_events, node:{} send ReceivePublicShare",
                node.identity
            );
            let actions = event_processor.process_event(Box::new(event));
            log::trace!(
                "DKG process_events, node:{} send ReceivePublicShare",
                node.identity
            );
            if !has_threshold_sign && !actions.is_empty() {
                send_publicshare_actions = actions;
            }
        }
    }

    //validate enough public share has been published.
    if event_processor.get_subscriber(4).is_none() {
        //return the public share action. Dkg not finished.
        log::info!("End update_dkg_state_with_publish_tx DKG before send partial sign tx publish");
        init_dkg_actions.append(&mut send_publicshare_actions);
        return Ok((event_processor, init_dkg_actions));
    }

    //four send ReceivePartialSignature
    let mut send_partialsign_actions = vec![];
    for node in sorted_committee.iter() {
        if !node.partial_sign_payload.is_empty() {
            let signature: BlsSignature = BlsSignature::try_from(&node.partial_sign_payload[..])?;
            log::trace!(
                "update_dkg_state_with_publish_tx node:{} partial signature:{}",
                node.identity,
                hex::encode(&signature.into_bytes())
            );
            let signature = BlsPartialSignature(signature);
            let event = DkgEvent {
                event_type: DkgEventType::ReceivePartialSignMsg,
                data: DkgEventData::ReceivePartialSignature(node.identity, signature),
            };
            let actions = event_processor.process_event(Box::new(event));
            if !has_threshold_sign && !actions.is_empty() {
                send_partialsign_actions = actions;
            }
        }
    }

    //validate enough public share has been published.
    if event_processor.get_subscriber(4).is_some() || smr_committee.threshold_pubkey.is_none() {
        //return the public share action. Dkg not finished.
        log::info!("End update_dkg_state_with_publish_tx DKG before send end dkg tx publish");
        init_dkg_actions.append(&mut send_partialsign_actions);
        return Ok((event_processor, init_dkg_actions));
    }

    //send EndLoad Dkg Tx
    log::info!("End update_dkg_state_with_publish_tx End DKG loading send End loading Tx",);

    let reloaddkg_tx = sodkg::transaction::create_reload_tx(
        secret_key,
        dkg_type,
        smr_committee.threshold_pubkey.as_ref().unwrap(),
    )
    .unwrap(); //TODO remove unwrap

    Ok((event_processor, vec![Action::SendSMRTx(reloaddkg_tx)]))
}
