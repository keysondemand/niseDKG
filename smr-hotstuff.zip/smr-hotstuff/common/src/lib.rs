use serde::{Deserialize, Serialize};
use socrypto::PublicKey;
use socrypto::SecretKey;
use socrypto::PUBLIC_KEY_LENGTH;
use sodkg::ElGamalPubKey;
use sosmr::SmrError;
use sosmr::{SmrDkgType, SmrTransaction, SmrTransactionProtocol};

pub mod config;
pub mod dkg;
mod smrcommittee;

mod publish;
pub use publish::PublishTxPayload;

pub use smrcommittee::{SmrDkgCommittee, SmrDkgCommitteeName, SmrDkgCommitteeNode};

// Dkg committee definition is save has a json file.
// The file is read at each DKG init.
pub const DKG_DEFINITION_FILE_NAME: &str = "dkgs_definition.json";

pub fn create_ask_publish_tx(
    secret_key: &SecretKey,
    dkg_type: SmrDkgType,
) -> Result<SmrTransaction, SmrError> {
    SmrTransaction::sign(
        secret_key,
        SmrTransactionSubtype::AskPublish.into(),
        SmrTransactionProtocol::Smr,
        dkg_type.to_bytes(),
    )
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct SmrDkgCommitteeDefinition {
    pub dkg_type: SmrDkgType,
    pub committee: Vec<NodeDefinition>,
    pub threshold_f: usize,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct NodeDefinition {
    pub publickey: String,
    pub elgamal_pubkey: String,
}

impl TryFrom<(PublicKey, ElGamalPubKey)> for NodeDefinition {
    type Error = SmrError;

    fn try_from(data: (PublicKey, ElGamalPubKey)) -> Result<Self, Self::Error> {
        Ok(NodeDefinition {
            publickey: data.0.encode_hex(),
            elgamal_pubkey: hex::encode(data.1.into_bytes()),
        })
    }
}

impl TryFrom<NodeDefinition> for (PublicKey, ElGamalPubKey) {
    type Error = SmrError;

    fn try_from(def: NodeDefinition) -> Result<Self, Self::Error> {
        (&def).try_into()
    }
}

impl TryFrom<&NodeDefinition> for (PublicKey, ElGamalPubKey) {
    type Error = SmrError;

    fn try_from(def: &NodeDefinition) -> Result<Self, Self::Error> {
        let pubkey = PublicKey::decode_hex(&def.publickey).map_err(|err| {
            SmrError::GeneralError(format!(
                "NodeDefinition try_from public key decoding error:{}",
                err
            ))
        })?;
        let bytes = hex::decode(&def.elgamal_pubkey).map_err(|err| {
            SmrError::GeneralError(format!(
                "NodeDefinition try_from ElGamalPubKey decoding error:{}",
                err
            ))
        })?;
        let elgamal_key = ElGamalPubKey::try_from(bytes).map_err(|err| {
            SmrError::GeneralError(format!(
                "NodeDefinition try_from ElGamalPubKey creation from bytes error:{}",
                err
            ))
        })?;
        if !sodkg::DKG::verify_elgamal_pubkey(&elgamal_key) {
            Err(SmrError::GeneralError(format!(
                "Node:{} Elgamal publickey verification fail.",
                pubkey
            )))
        } else {
            Ok((pubkey, elgamal_key))
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
#[repr(u8)]
pub enum SmrTransactionSubtype {
    AskPublish,
    Publish,
    NoType,
}

impl From<u8> for SmrTransactionSubtype {
    fn from(v: u8) -> Self {
        match v {
            1 => SmrTransactionSubtype::AskPublish,
            2 => SmrTransactionSubtype::Publish,
            _ => SmrTransactionSubtype::NoType,
        }
    }
}

impl From<SmrTransactionSubtype> for u8 {
    fn from(v: SmrTransactionSubtype) -> Self {
        match v {
            SmrTransactionSubtype::AskPublish => 1,
            SmrTransactionSubtype::Publish => 2,
            SmrTransactionSubtype::NoType => 100,
        }
    }
}
