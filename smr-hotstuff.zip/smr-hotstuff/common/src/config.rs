use crate::SmrDkgCommitteeDefinition;
use socrypto::PublicKey;
use sodkg::ElGamalPubKey;
use sosmr::SmrDkgType;
use sosmr::SmrError;

#[derive(Clone, Debug)]
pub struct SmrCommitteeConfig {
    pub committee_list: Vec<CommmitteeConfig>,
}

impl TryFrom<Vec<SmrDkgCommitteeDefinition>> for SmrCommitteeConfig {
    type Error = SmrError;

    fn try_from(defs: Vec<SmrDkgCommitteeDefinition>) -> Result<Self, Self::Error> {
        let committee_list = defs
            .into_iter()
            .map(|def| {
                let member_list = def
                    .committee
                    .into_iter()
                    .map(|m| {
                        let (id, elgamal_pubkey): (PublicKey, ElGamalPubKey) = m.try_into()?;
                        Ok(NodeConfig { id, elgamal_pubkey })
                    })
                    .collect::<Result<Vec<NodeConfig>, SmrError>>()?;
                Ok(CommmitteeConfig {
                    name: def.dkg_type,
                    //f+1 value
                    threshold_f: def.threshold_f,
                    member_list,
                })
            })
            .collect::<Result<Vec<CommmitteeConfig>, SmrError>>()?;
        Ok(SmrCommitteeConfig { committee_list })
    }
}

impl SmrCommitteeConfig {
    pub fn get_committee_config(&self, name: SmrDkgType) -> Option<&CommmitteeConfig> {
        self.committee_list.iter().find(|c| c.name == name)
    }
}

#[derive(Clone, Debug)]
pub struct CommmitteeConfig {
    pub name: SmrDkgType,
    //f+1 value
    pub threshold_f: usize,
    pub member_list: Vec<NodeConfig>,
}

impl CommmitteeConfig {
    pub fn is_node_belong_to_committee(&self, id: PublicKey) -> bool {
        self.member_list.iter().any(|n| n.id == id)
    }
}

#[derive(Clone, Debug)]
pub struct NodeConfig {
    pub id: PublicKey,
    pub elgamal_pubkey: ElGamalPubKey,
}
