use crate::consensus::Round;
use socrypto::{Hash, PublicKey, SupraCryptoError};
use store::StoreError;
use thiserror::Error;

#[macro_export]
macro_rules! bail {
    ($e:expr) => {
        return Err($e);
    };
}

#[macro_export(local_inner_macros)]
macro_rules! ensure {
    ($cond:expr, $e:expr) => {
        if !($cond) {
            bail!($e);
        }
    };
}

pub type ConsensusResult<T> = Result<T, ConsensusError>;

#[derive(Error, Debug)]
pub enum ConsensusError {
    #[error("Network error: {0}")]
    NetworkError(#[from] std::io::Error),

    #[error("Tokio task execution error: {0}")]
    TaskExecError(#[from] tokio::task::JoinError),

    #[error("Serialization error: {0}")]
    SerializationError(#[from] Box<bincode::ErrorKind>),

    #[error("Store error: {0}")]
    StoreError(#[from] StoreError),

    #[error("Node {0} is not in the committee")]
    NotInCommittee(PublicKey),

    #[error("Invalid signature")]
    InvalidSignature(#[from] SupraCryptoError),

    #[error("Received more than one vote from {0}")]
    AuthorityReuse(PublicKey),

    #[error("Received vote from unknown authority {0}")]
    UnknownAuthority(PublicKey),

    #[error("Received QC for round {0} without a quorum")]
    QCRequiresQuorum(Round),

    #[error("Received TC without a quorum")]
    TCRequiresQuorum,

    #[error("Malformed block {0}")]
    MalformedBlock(Hash),

    #[error("Parent of block {0} is not certified by the QC with the maximum sequence number included in the TC")]
    FallbackRecoveryBadParent(Hash),

    #[error(
        "TC of Fallback Recovery Proposal {0} has a QC with round {1} but qc_prime has round {2}"
    )]
    FallbackRecoveryBadQcPrime(Hash, Round, Round),

    #[error("Received a block {0} for round {1} with invalid justification")]
    BlockBadJustification(Hash, Round),
    #[error("Received a block {0} for round {1} with a QC for a higher round {2}")]
    BlockBadQC(Hash, Round, Round),

    #[error("Received a block {0} for round {1} with a TC for round {2}")]
    BlockBadTC(Hash, Round, Round),

    #[error("Received block {digest} from leader {leader} at round {round}")]
    WrongLeader {
        digest: Hash,
        leader: PublicKey,
        round: Round,
    },

    #[error("Invalid payload")]
    InvalidPayload,

    #[error("Message {0} (round {1}) too old")]
    TooOld(Hash, Round),

    #[error("Error during Smr data conversion {0}")]
    SmrStructConversionError(String),
    #[error("Error during vote signature aggregation {0}")]
    VoteThresholdSignError(String),
}
