use crate::config::{BftParameters, Committee};
use crate::core::Core;
use crate::helper::Helper;
use crate::leader::LeaderElector;
use crate::mempool::MempoolDriver;
use crate::messages::{Block, FallbackRecoveryProposal, Proposal, Timeout, Vote, QC};
use crate::proposer::Proposer;
use crate::synchronizer::Synchronizer;
use async_trait::async_trait;
use log::info;
use mempool::ConsensusMempoolMessage;
use peer::HotStuffMessage;
use peer::PeerMessageHandler;
use serde::{Deserialize, Serialize};
use sign::SignatureService;
use smrcommon::config::SmrCommitteeConfig;
use socrypto::Digest;
use socrypto::Hash;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerInfo;
use sosmr::DkgCommittee;
use sosmr::SmrBlock;
use sosmr::SmrTransaction;
use std::fmt;
use store::Store;
use tokio::sync::mpsc::{channel, Receiver, Sender};

#[cfg(test)]
#[path = "tests/consensus_tests.rs"]
pub mod consensus_tests;

/// The default channel capacity for each channel of the consensus.
pub const CHANNEL_CAPACITY: usize = 100;

/// The consensus round number.
pub type Round = u64;

#[derive(Serialize, Deserialize, Debug)]
pub enum ConsensusMessage {
    Propose(ProposalMessage),
    Vote(Vote),
    Timeout(Timeout),
    QC(QC),
    SyncRequest(Hash, PublicKey),
    SyncResponse(Block),
    DkgCommittee(DkgCommittee),
}

impl fmt::Display for ConsensusMessage {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let msg = match self {
            ConsensusMessage::Propose(_) => "Propose",
            ConsensusMessage::Vote(_) => "Vote",
            ConsensusMessage::Timeout(_) => "Timeout",
            ConsensusMessage::QC(_) => "TC",
            ConsensusMessage::SyncRequest(_, _) => "SyncRequest",
            ConsensusMessage::SyncResponse(_) => "SyncResponse",
            ConsensusMessage::DkgCommittee(_) => "DkgCommittee",
        };
        write!(f, "({})", msg)
    }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum ProposalMessage {
    Normal(Proposal),
    FallbackRecovery(FallbackRecoveryProposal),
}

impl Digest for ProposalMessage {
    fn digest(&self) -> Hash {
        match self {
            ProposalMessage::Normal(proposal) => proposal.digest(),
            ProposalMessage::FallbackRecovery(fallback) => fallback.digest(),
        }
    }
}

impl fmt::Display for ProposalMessage {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        let mess = match self {
            ProposalMessage::Normal(proposal) => proposal.to_string(),
            ProposalMessage::FallbackRecovery(fallback) => fallback.to_string(),
        };
        write!(f, "Proposal Message {}", mess)
    }
}

pub struct Consensus;

impl Consensus {
    #[allow(clippy::too_many_arguments)]
    pub fn spawn(
        name: PublicKey,
        secret_key: SecretKey,
        committee: Committee,
        parameters: BftParameters,
        signature_service: SignatureService,
        store: Store,
        ledger: execution::Ledger,
        rx_mempool: Receiver<Hash>,
        tx_mempool: Sender<ConsensusMempoolMessage>,
        tx_output: Sender<SmrBlock>,
        network: &NetWorkManagerAsync,
        concensus_receiver: NetworkEventReceiver,
        proposerack_receiver: NetworkEventReceiver,
        committee_config: SmrCommitteeConfig,
        tx_sender: Sender<SmrTransaction>,
    ) -> Sender<ConsensusMessage> {
        // NOTE: This log entry is used to compute performance.
        parameters.log();

        let (tx_consensus, rx_consensus) = channel(CHANNEL_CAPACITY);
        let (tx_proposer_core, rx_proposer_core) = channel(CHANNEL_CAPACITY);
        let (tx_sync_core, rx_sync_core) = channel(CHANNEL_CAPACITY);
        let (tx_mempool_core, rx_mempool_core) = channel(CHANNEL_CAPACITY);
        let (tx_proposer, rx_proposer) = channel(CHANNEL_CAPACITY);
        let (tx_helper, rx_helper) = channel(CHANNEL_CAPACITY);
        //        let (tx_commit, rx_commit) = channel(CHANNEL_CAPACITY);
        //        let (tx_mempool_copy, rx_mempool_copy) = channel(CHANNEL_CAPACITY);

        // Spawn the network receiver.
        crate::network::spawn_concensusreceiver_message_receiver(
            concensus_receiver,
            ConsensusReceiverHandler {
                tx_consensus: tx_consensus.clone(),
                tx_helper,
                network_sender: crate::network::ProposerBlockAckSender::new(network),
            },
        );
        let address = committee
            .peer(&name)
            .expect("Our public key is not in the committee");
        info!(
            "Node {} listening to consensus messages on {}",
            name, address
        );

        // Make the leader election module.
        let leader_elector = LeaderElector::new(committee.clone());

        // Make the mempool driver.
        let mempool_driver = MempoolDriver::new(store.clone(), tx_mempool, tx_mempool_core);

        // Make the synchronizer.
        let synchronizer = Synchronizer::new(
            name,
            committee.clone(),
            store.clone(),
            tx_sync_core,
            parameters.sync_retry_delay,
            network,
        );

        // Spawn the consensus core.
        Core::spawn(
            name,
            secret_key,
            committee.clone(),
            signature_service.clone(),
            store.clone(),
            ledger,
            leader_elector,
            mempool_driver,
            synchronizer,
            parameters.timeout_delay,
            rx_mempool_core,
            rx_consensus,
            rx_proposer_core,
            rx_sync_core,
            tx_proposer,
            tx_output,
            network,
            committee_config,
            tx_sender,
        );

        // Commits the mempool certificates and their sub-dag.
        //rmove use tx mempool
        // Committer::spawn(
        //     committee.clone(),
        //     store.clone(),
        //     parameters.gc_depth,
        //     rx_mempool_copy,
        //     rx_commit,
        // );

        // Spawn the block proposer.
        Proposer::spawn(
            name,
            committee.clone(),
            parameters.max_block_size,
            signature_service,
            rx_mempool,
            /* rx_message */ rx_proposer,
            tx_proposer_core,
            network,
            proposerack_receiver,
        );

        // Spawn the helper module.
        Helper::spawn(committee, store, /* rx_requests */ rx_helper, network);

        tx_consensus
    }
}

/// Defines how the network receiver handles incoming primary messages.
#[derive(Clone)]
struct ConsensusReceiverHandler {
    tx_consensus: Sender<ConsensusMessage>,
    tx_helper: Sender<(Hash, PublicKey)>,
    network_sender: crate::network::ProposerBlockAckSender,
}

#[async_trait]
impl PeerMessageHandler for ConsensusReceiverHandler {
    async fn dispatch(&mut self, peer_info: PeerInfo, message: HotStuffMessage) {
        if let HotStuffMessage::ConsensusMessage(bytes) = message {
            // Deserialize and parse the message.
            // Deserialize and parse the message.
            match bincode::deserialize(&bytes) {
                Ok(ConsensusMessage::SyncRequest(missing, origin)) => self
                    .tx_helper
                    .send((missing, origin))
                    .await
                    .expect("Failed to send consensus message"),
                Ok(ConsensusMessage::Propose(block)) => {
                    //log::trace!("Consensus dispatch receive ConsensusMessage::Propose block");
                    //Ack the reception.
                    self.network_sender
                        .send_proposerblockack_message(peer_info, block.digest().0, 1) //1 is stack of Hotstuff.
                        .await;
                    // Pass the message to the consensus core.
                    self.tx_consensus
                        .send(ConsensusMessage::Propose(block))
                        .await
                        .expect("Failed to consensus message")
                }
                Ok(message) => {
                    // debug!("Received message from peer: {:?}", message);
                    self.tx_consensus
                        .send(message)
                        .await
                        .expect("Failed to consensus message")
                }
                Err(e) => log::warn!("Consensus receive message Serialization error: {}", e),
            }
        }
    }
}
