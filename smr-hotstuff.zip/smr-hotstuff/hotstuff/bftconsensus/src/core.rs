use crate::aggregator::Aggregator;
use crate::config::Committee;
use crate::consensus::{ConsensusMessage, ProposalMessage, Round};
use crate::error::{ConsensusError, ConsensusResult};
use crate::leader::LeaderElector;
use crate::mempool::MempoolDriver;
use crate::messages::Justification;
use crate::messages::{Block, FallbackRecoveryProposal, Proposal, Timeout, Vote, QC, TC};
use crate::network::ConsensusMessageSender;
use crate::proposer::EmptyBlockStatus;
use crate::proposer::ProposerMessage;
use crate::synchronizer::Synchronizer;
use crate::timer::Timer;
use async_recursion::async_recursion;
use log::{debug, error, warn};
use sign::SignatureService;
use smrcommon::config::CommmitteeConfig;
use smrcommon::config::SmrCommitteeConfig;
use socrypto::PublicKey;
use socrypto::SecretKey;
use socrypto::{Digest, Hash};
use sop2p::NetWorkManagerAsync;
use sosmr::DkgCommittee;
use sosmr::SmrBlock;
use sosmr::SmrDkgType;
use sosmr::SmrTransaction;
use std::cmp::max;
use std::collections::{HashMap, HashSet};
use store::Store;
use tokio::sync::mpsc::{Receiver, Sender};
use tokio::time::Instant;

#[cfg(test)]
#[path = "tests/core_tests.rs"]
pub mod core_tests;

pub struct Core {
    aggregator: Aggregator,
    committee: Committee,
    committable_blocks: HashMap<Hash, Round>,
    committee_config: SmrCommitteeConfig,
    dkg_committee: Option<DkgCommittee>,
    // Task to notify when 2f+1 smr nodes have ended their DKG.
    // Allow to switch from Ed key to BLS with a 2f+1 committee.
    end_dkg_notifications: HashSet<PublicKey>,
    is_last_committed_block_empty: bool,
    is_locked_block_empty: bool,
    last_commit: Block,
    last_timeout: Round,
    last_vote: Round,
    leader_elector: LeaderElector,
    ledger: execution::Ledger,
    locked: QC,
    mempool_driver: MempoolDriver,
    name: PublicKey,
    networksender: ConsensusMessageSender,
    proposed: Round,
    qc_syncs: HashMap<PublicKey, Instant>,
    round: Round,
    round_justification: Justification,
    rx_mempool: Receiver<Block>,
    rx_message: Receiver<ConsensusMessage>,
    rx_proposer: Receiver<ProposalMessage>,
    rx_synchronizer: Receiver<Block>,
    secret_key: SecretKey,
    signature_service: SignatureService,
    store: Store,
    synchronizer: Synchronizer,
    sync_requests: HashSet<Hash>,
    timeout_delay: u64,
    timeout_syncs: HashSet<Round>,
    timer: Timer,
    tx_output: Sender<SmrBlock>,
    tx_proposer: Sender<ProposerMessage>,
    tx_sender: Sender<SmrTransaction>,
    // Index of uncommitted blocks by Digest.
    uncommitted_blocks_by_digest: HashMap<Hash, Block>, // TODO: Change Block to reference to save space
    // Index of uncommitted blocks by round.
    uncommitted_blocks_by_round: HashMap<Round, (Block, ProposalType)>,
    uncommitted_qcs: HashMap<Round, QC>,
    //Allow to switch from Ed key to BLS during the round change.
    waiting_dkg_committee: Option<DkgCommittee>,
}

#[derive(Eq, PartialEq, Hash, Clone)]
enum ProposalType {
    FallbackRecovery,
    Normal,
    Sync, // We have a QC for the block.
}

#[derive(Debug)]
enum ProposalTrigger {
    QC(QC),
    TC(TC),
    Block(Block),
}

// Identifier of the Genesis round.
const GENESIS: u64 = 0;

impl Core {
    #[allow(clippy::too_many_arguments)]
    pub fn spawn(
        name: PublicKey,
        secret_key: SecretKey,
        committee: Committee,
        signature_service: SignatureService,
        store: Store,
        ledger: execution::Ledger,
        leader_elector: LeaderElector,
        mempool_driver: MempoolDriver,
        synchronizer: Synchronizer,
        timeout_delay: u64,
        rx_mempool: Receiver<Block>,
        rx_message: Receiver<ConsensusMessage>,
        rx_proposer: Receiver<ProposalMessage>,
        rx_synchronizer: Receiver<Block>,
        tx_proposer: Sender<ProposerMessage>,
        tx_output: Sender<SmrBlock>,
        network: &NetWorkManagerAsync,
        committee_config: SmrCommitteeConfig,
        tx_sender: Sender<SmrTransaction>,
    ) {
        let networksender = ConsensusMessageSender::new(network);
        tokio::spawn(async move {
            let mut uncommitted_blocks_by_digest = HashMap::new();
            let mut uncommitted_blocks_by_round = HashMap::new();
            let mut uncommitted_qcs = HashMap::new();
            let genesis_block = Block::genesis();
            let genesis_qc = QC::genesis();
            let digest = genesis_block.digest();

            uncommitted_blocks_by_round.insert(
                genesis_block.round,
                (genesis_block.clone(), ProposalType::Normal),
            );
            uncommitted_blocks_by_digest.insert(digest.clone(), genesis_block.clone());
            uncommitted_qcs.insert(genesis_block.round, genesis_qc.clone());

            Self {
                aggregator: Aggregator::new(committee.clone()),
                committee,
                committable_blocks: HashMap::new(),
                last_commit: genesis_block,
                last_timeout: GENESIS,
                last_vote: GENESIS,
                leader_elector,
                locked: QC::genesis(),
                mempool_driver,
                name,
                proposed: GENESIS,
                qc_syncs: HashMap::new(),
                round: 1,
                round_justification: Justification::QC(QC::genesis()),
                rx_mempool,
                rx_message,
                rx_proposer,
                rx_synchronizer,
                secret_key,
                signature_service,
                store,
                synchronizer,
                sync_requests: HashSet::new(),
                timeout_delay,
                timeout_syncs: HashSet::new(),
                timer: Timer::new(timeout_delay),
                tx_output,
                tx_proposer,
                uncommitted_blocks_by_round,
                uncommitted_blocks_by_digest,
                uncommitted_qcs,
                networksender,
                dkg_committee: None,
                end_dkg_notifications: HashSet::new(),
                waiting_dkg_committee: None,
                committee_config,
                ledger,
                tx_sender,
                is_last_committed_block_empty: false,
                is_locked_block_empty: false,
            }
            .run()
            .await
        });
    }

    // fn print_memoru_usage(&self) {
    //     log::info!("Core commitee.len:{}", self.committee.authorities.len());
    //     log::info!(
    //         "Core committable_blocks.len:{}",
    //         self.committable_blocks.len()
    //     );
    //     log::info!(
    //         "Core mem size last_commit:{}",
    //         std::mem::size_of_val(&self.last_commit)
    //     );
    //     log::info!(
    //         "Core uncommitted_blocks.len():{}",
    //         &self.uncommitted_qcs.len()
    //     );
    //     log::info!("Core uncommitted_qcs:{}", &self.uncommitted_qcs.len());
    //     log::info!(
    //         "Core mem size networksender:{}",
    //         std::mem::size_of_val(&self.networksender)
    //     );
    // }

    async fn get_block(&mut self, digest: Hash, round: Round) -> ConsensusResult<Option<Block>> {
        // This function should only ever be called with digests of certified blocks.
        assert!(self.uncommitted_qcs.contains_key(&round));

        if round > self.last_commit.round {
            let proposer = self.leader_elector.get_leader(round);

            // See if we have the corresponding block.
            if let Some((block, _)) = self.uncommitted_blocks_by_round.get(&round) {
                // Ensure it is not equivocal.
                if block.digest() == digest {
                    // Have the block.
                    Ok(Some(block.clone()))
                } else {
                    debug!("Syncing block for given digest. Equivocal block stored.");
                    // Currently have an equivocal block. Request the given one.
                    // We purge the equivocal block upon receiving the SyncResponse.
                    let maybe_b = self
                        .synchronizer
                        .get_block(&digest, &proposer, None)
                        .await?;
                    // Should not have an uncommitted block on-disk but not in-memory.
                    assert!(maybe_b.is_none());
                    self.sync_requests.insert(digest);
                    Ok(None)
                }
            } else {
                debug!("Syncing block for given digest");
                // Missing the block with the given digest.
                let maybe_b = self
                    .synchronizer
                    .get_block(&digest, &proposer, None)
                    .await?;
                // Should not have an uncommitted block on-disk but not in-memory.
                assert!(maybe_b.is_none());
                self.sync_requests.insert(digest);
                Ok(None)
            }
        } else {
            Ok(None)
        }
    }

    async fn have_all_ancestors(&mut self, block: Block) -> ConsensusResult<bool> {
        if block.round == GENESIS {
            // Genesis.
            return Ok(true);
        }

        // This function should only ever be called with uncommitted blocks.
        assert!(block.round > self.last_commit.round);
        // This function should only ever be called with blocks that directly
        // satisfy the commit rule (i.e. blocks that may be LDC).
        assert!(self.committable_blocks.contains_key(&block.digest()));

        let mut b = block.clone();

        // Trace the chain of ancestors back to our most recently committed block.
        loop {
            let maybe_parent =
                // Check the in-memory index to avoid IO.
                match self.uncommitted_blocks_by_digest.get(&b.parent)
                {
                    Some(parent) => Some(parent.clone()),
                    // Ensure we resume processing the given HML block once we have synchronised
                    // its missing ancestor. This ensures that we will be able to recursively
                    // sync all missing ancestors, even if we do not observe their QCs. It also
                    // ensures that we will commit the HML block once we have all of its ancestors.
                    None => self.synchronizer.get_block(
                            &b.parent,
                            // We do not know the proposer of b.parent at this stage, so we ask
                            // the proposer of b instead. This node may not have b.parent upon
                            // receiving our request if it proposed b on the basis of a QC or TC,
                            // however, if this is the case then we will eventually contact the
                            // rest of our peers and obtain it from them instead.
                            &b.author,
                            Some(block.clone())
                        ).await?
                };

            if let Some(parent) = maybe_parent {
                if parent.round == self.last_commit.round {
                    // Reached the last committed block.
                    return Ok(true);
                } else {
                    // Ensure that we maintain integrity/safety. Every committed block
                    // should be a descendant of our last committed block, and descendants
                    // should always have higher round numbers than their ancestors.
                    assert!(parent.round > self.last_commit.round);
                    b = parent;
                }
            } else {
                debug!("Syncing missing ancestor");
                // Missing an ancestor of the given block. Synchronizer will request it from our peers.
                // Make a note of the requested block so that we can authenticate it when it arrives.
                self.sync_requests.insert(b.parent.clone());
                return Ok(false);
            }
        }
    }

    async fn try_commit_or_sync_ancestor(&mut self, block: &Block) -> ConsensusResult<()> {
        // Should only ever call this function with recent blocks.
        assert!(block.round > self.last_commit.round);

        if self.committable_blocks.contains_key(&block.digest()) {
            // Have the QC for this block and its immediate successor by round number.
            if self.have_all_ancestors(block.clone()).await? {
                // This block and all of its uncommitted ancestors are safe to commit.
                debug!("Late commit");
                self.commit(block.clone()).await?;
            }
        }
        Ok(())
    }

    async fn observe_payload(&mut self, block: &Block) -> ConsensusResult<()> {
        log::debug!("Core observe_payload {}", block.round);
        self.tx_proposer
            .send(ProposerMessage::Observed(
                block.payload.clone(),
                block.round,
            ))
            .await
            .expect("Failed to send message to proposer");
        Ok(())
    }

    async fn store_block_or_sync_payload(
        &mut self,
        block: &Block,
        kind: ProposalType,
    ) -> ConsensusResult<bool> {
        // Should only ever call this function with recent blocks.
        assert!(block.round > self.last_commit.round);

        // Tell the Proposer not to re-propose any of the batches included in the block's payload.
        self.observe_payload(block).await?;

        // Ensure that we have the batches referenced in the block payload.
        if self.mempool_driver.verify(block).await? {
            // We have the payload, which is valid, so we can store the block.
            self.store_block(block, kind).await;
            Ok(true)
        } else {
            // Mempool will sync the missing batches for us and then send the block back to us.
            Ok(false)
        }
    }

    async fn store_block(&mut self, block: &Block, kind: ProposalType) {
        // Should only be called by store_block_or_sync_payload.

        // Store in-memory.
        self.uncommitted_blocks_by_round
            .insert(block.round, (block.clone(), kind));
        self.uncommitted_blocks_by_digest
            .insert(block.digest(), block.clone());
        // Write to disk
        let key = block.digest().to_vec();
        let value = bincode::serialize(block).expect("Failed to serialize block");
        self.store.write(key, value).await;

        log::trace!("core store_block round:{}", block.round);
    }

    // Unicasts self.locked to the given peer to allow it to enter self.locked.round + 2.
    // Triggered when we see a Timeout from round lower than self.locked.round + 1.
    async fn sync_peer(&mut self, recipient: &PublicKey) {
        // Ensure our network bandwidth cannot be consumed by Byzantine nodes that spam us
        // with Timeouts for old rounds.
        let rate_limited = match self.qc_syncs.get(recipient) {
            // We expect to receive at most one Timeout message per timeout_delay per peer.
            Some(synced_at) => synced_at.elapsed().as_millis() < self.timeout_delay.into(),
            None => false,
        };

        if rate_limited {
            debug!("Rate-limited peer {:?} for QC Sync", recipient);
        } else {
            debug!(
                "Syncing peer {:?} with locked QC {:?}",
                recipient, self.locked
            );

            let address = match self.committee.peer(recipient) {
                Some(peer) => peer,
                None => {
                    warn!("QC Sync requested by unknown peer {:?}", recipient);
                    return;
                }
            };

            let m = ConsensusMessage::QC(self.locked.clone());
            self.networksender
                .send_consensus_message_to_peer(address, m)
                .await;
            // Note the time that we served this peer so that we can rate-limit it.
            self.qc_syncs.insert(recipient.clone(), Instant::now());
        }
    }

    async fn commit(&mut self, block: Block) -> ConsensusResult<()> {
        if block.round == GENESIS {
            // Ignore the Genesis block.
            return Ok(());
        }

        assert!(block.round > self.last_commit.round);

        let committing_round = block.round;
        // Stack of blocks to be committed, with the newest block (i.e. the one this function
        // was invoked with) at the base and the oldest ancestor (i.e. the child of the last
        // committed block) at the top.
        let mut to_commit = Vec::new();
        let mut ancestor = block.clone();

        // Identify all uncommitted blocks that can be committed now that
        // their descendent has satisfied the commit rule.
        loop {
            // We should always terminate this loop at our last committed block.
            // If we go back to a lower round then the chain has been compromised.
            assert!(ancestor.round > self.last_commit.round);
            let ancestor_parent = ancestor.parent.clone();
            to_commit.push(ancestor);

            if ancestor_parent == self.last_commit.digest() {
                break;
            } else {
                ancestor = self
                    .uncommitted_blocks_by_digest
                    .remove(&ancestor_parent)
                    .expect("Missing ancestor detected during commit.");
            }
        }

        // Committed payloads to be deleted from the Proposer and Mempool.
        let mut payloads: HashMap<Round, Vec<Hash>> = HashMap::new();

        // Commit loop.
        while let Some(committing) = to_commit.pop() {
            log::info!("Committing {:?}", committing);

            log::debug!(
                "COMMIT BLOCK has tc:{:?} Committed {:?}",
                committing.tc.is_some(),
                committing,
            );

            payloads.insert(committing.round, committing.payload.clone());

            let smr_block = match committing
                .convert_to_supra_types(&mut self.store, &mut self.signature_service)
                .await
            {
                Ok(b) => b,
                Err(err) => {
                    //this error should never occurs with SMR processed blocks.
                    log::error!("Error during message block convertion to sosmr :{}", err);
                    continue;
                }
            };
            execution::execute_block(
                &smr_block,
                &mut self.store,
                &mut self.ledger,
                &self.committee_config,
                &self.tx_sender,
                &self.secret_key,
                &mut self.end_dkg_notifications,
            )
            .await;

            // Output the block to the top-level application.
            //for test only send before DKG
            if let Err(e) = self.tx_output.send(smr_block).await {
                warn!("Failed to send block through the output channel: {}", e);
            }

            // Clean up the mempool.
            // TODO: Ensure that this also cleans up payloads for blocks from
            // previous rounds that can never be committed.
            // TODO: Remove from loop like Proposer cleanup.
            self.mempool_driver.cleanup(self.round).await;
        }

        // Delete all committed batch hashes from the Proposer and Mempool.
        log::debug!("Core cleanup_payload {}", block.round);
        self.tx_proposer
            .send(ProposerMessage::Cleanup(payloads, committing_round))
            .await
            .expect("Failed to send message to proposer");

        // Record the last commit to assist with validation of future blocks.
        self.is_last_committed_block_empty = block.is_empty();
        self.last_commit = block;
        // Clean up in-memory storage.
        self.committable_blocks.retain(|_, r| *r > committing_round);
        self.uncommitted_blocks_by_round
            .retain(|_, (b, _)| b.round > committing_round);
        self.uncommitted_blocks_by_digest
            .retain(|_, b| b.round > committing_round);
        self.uncommitted_qcs
            .retain(|_, qc| qc.round > committing_round);

        // TODO: Remove uncommittable blocks from disk.
        Ok(())
    }

    async fn schedule_commit(&mut self, qc: QC) -> ConsensusResult<()> {
        // Schedule the related block for commit once we have it and all of its ancestors.
        self.committable_blocks.insert(qc.hash.clone(), qc.round);

        if let Some(block) = self.uncommitted_blocks_by_digest.get(&qc.hash).cloned() {
            if self.have_all_ancestors(block.clone()).await? {
                debug!("Immediate commit");
                // Have all uncommitted ancestors of this block.
                self.commit(block).await?;
            } else {
                // Will have requested in call to have_all_ancestors.
                debug!("Missing ancestor for commit-scheduled {:?}", qc);
            }
        } else {
            // Will have requested in call to get_block.
            debug!("Missing block for commit-scheduled {:?}", qc);
        }
        Ok(())
    }

    async fn try_lock_and_commit(&mut self, qc: &QC) -> ConsensusResult<()> {
        // Sync Case: Update locked QC and try to commit.
        if qc.round > self.locked.round {
            // Check if we can commit our locked block.
            if qc.round == self.locked.round + 1 && qc.parent == self.locked.hash {
                debug!("Normal schedule commit {:?}", qc);
                // Schedule the block for commit once we have it and all of its ancestors.
                self.schedule_commit(self.locked.clone()).await?;
            }

            debug!("Locked {:?}", qc);
            self.locked = qc.clone();

            if let Some(b) = self.uncommitted_blocks_by_digest.get(&qc.hash) {
                // Have the block corresponding to this QC. Check if it is empty so
                // we can stop producing blocks when the network is not receiving txs.
                self.is_locked_block_empty = b.is_empty();
            } else {
                // We do not have the related block yet. We have to assume that it
                // has a payload until we receive it so that we do not halt the chain
                // while there are still transactions undergoing consensus.
                self.is_locked_block_empty = false;
            }

            // The QC Sync path in the handle_timeout ensures that all honest nodes will
            // eventually receive this QC and so will be able to enter qc.round, so we can
            // now safely remove all Timeout messages for prior rounds.
            self.aggregator.cleanup_timeouts(&qc.round);
        } else {
            // Async Case: First time processing this QC. We missed it earlier.
            // No need to lock, but need to check to see if it gives us anything to commit.

            if let Some(maybe_child) = self.uncommitted_qcs.get(&(qc.round + 1)) {
                if maybe_child.parent == qc.hash {
                    debug!("Late schedule commit 1 {:?}", qc);
                    // Already received and locked a QC that would have committed this one.
                    // Add its block hash to the set of blocks scheduled for commit.
                    self.schedule_commit(qc.clone()).await?;
                }
            }

            if let Some(maybe_parent) = self.uncommitted_qcs.get(&(qc.round - 1)) {
                if qc.parent == maybe_parent.hash {
                    debug!("Late schedule commit 2 {:?}", qc);
                    // Already received and locked a QC that this QC should have committed, but
                    // we first locked another QC with a higher round number than this one.
                    // Add the block hash from the QC that should have been committed to the
                    // set of blocks scheduled for commit.
                    self.schedule_commit(maybe_parent.clone()).await?;
                }
            }
        }
        Ok(())
    }

    fn can_vote(&self, block: &Block) -> bool {
        // Have not yet sent a Timeout message for the related round or higher
        self.last_timeout < block.round
            // In the correct round to vote for this block
            && block.round == self.round - 1
            // Have not yet voted in this round
            && block.round > self.last_vote
            // Also locked on the parent
            && block.parent == self.locked.hash
    }

    async fn try_vote_and_propose(&mut self) -> ConsensusResult<()> {
        // Whether we receive a proposal for r whilst in r depends on the order in which
        // we observe this proposal and the QC for r-1. These two events effectively
        // represent a race, so we need to handle both cases. In both cases, we cannot
        // vote or propose a new block unless we are in r+1.

        // TODO: Remove
        log::trace!(
            "try_vote_and_propose self.uncommitted_blocks.len:{} node:{}",
            self.uncommitted_blocks_by_round.len(),
            self.name,
        );

        if let Some((b, t)) = self
            .uncommitted_blocks_by_round
            .get(&(self.round - 1))
            .cloned()
        {
            if t == ProposalType::Sync {
                // Should never reach this path since we never call this function
                // with certified blocks.
                return Ok(())
            }

            if self.can_vote(&b) {
                // Try to propose first, in case our vote triggers a QC and
                // causes us to move to the next round.
                self.propose_if_leader(ProposalTrigger::Block(b.clone()))
                    .await;
                self.send_vote(&b).await?;
            }
        }
        Ok(())
    }

    async fn advance_to_round(
        &mut self,
        round: Round,
        justification: Justification,
    ) -> ConsensusResult<()> {
        if round > self.round {
            self.round = round;
            self.round_justification = justification;
            self.timer.reset();

            // TODO: Remove
            log::debug!("Moved to round {} self.waiting_dkg_committee.is_some():{} self.end_dkg_notifications.len():{} self.committable_blocks:{} self.uncommitted_qcs:{}"
                , self.round
                , self.waiting_dkg_committee.is_some()
                , self.end_dkg_notifications.len()
                , self.committable_blocks.len()
                , self.uncommitted_qcs.len()
            );

            // self.print_memoru_usage();

            // Remove all Prepare messages for rounds before self.round - 1.
            self.aggregator.cleanup_prepares(&(self.round - 2));

            // Try to vote and propose.
            // Covers the case where we receive the proposal for r before the QC for r-1.
            self.try_vote_and_propose().await?;

            // Switch keys when 2f+1 DKG confirmations have arrived.
            if self.waiting_dkg_committee.is_some()
                // TODO: REVERT BACK TO 2f+1 CONFIRMATIONS. WAITING FOR N CONFIRMATIONS IS NOT BFT.
                && self.end_dkg_notifications.len() >= self.committee.authorities.len()
            {
                log::info!("Core switch to committee sign at round:{}", self.round);

                self.dkg_committee = self.waiting_dkg_committee.take();
                self.end_dkg_notifications.clear();
            } else if self.waiting_dkg_committee.is_some() {
                log::info!(
                    "Core committee present and waiting for end dkg. Current tx cound:{}",
                    self.end_dkg_notifications.len()
                );
            }
        }

        Ok(())
    }

    async fn send_vote(&mut self, block: &Block) -> ConsensusResult<()> {
        let vote = match &self.dkg_committee {
            Some(committee) => Vote::new_committee_signed(block, self.name, &committee.bls_privkey),
            None => Vote::new(block, self.name, self.signature_service.clone()).await,
        };

        debug!("Created {:?}", vote);
        self.last_vote = block.round;
        self.handle_vote(&vote).await?;
        self.networksender
            .broadcast_others_consensus_message(ConsensusMessage::Vote(vote))
            .await;
        Ok(())
    }

    async fn send_timeout(&mut self, round: Round) -> ConsensusResult<()> {
        let timeout = Timeout::new(
            self.locked.clone(),
            round,
            self.name,
            self.signature_service.clone(),
        )
        .await;
        debug!("Created {:?}", timeout);
        // Ensure last_timeout tracks the highest round we have sent a Timeout for.
        self.last_timeout = max(round, self.last_timeout);
        // Ensure that we trigger Timeout Sync for r at most once every timeout_delay.
        self.timeout_syncs.insert(round);
        self.timer.reset();
        self.handle_timeout(&timeout).await?;
        self.networksender
            .broadcast_others_consensus_message(ConsensusMessage::Timeout(timeout))
            .await;
        Ok(())
    }

    async fn local_timeout_round(&mut self) -> ConsensusResult<()> {
        log::info!(
            "Timeout reached for round {} in round {}",
            self.round - 1,
            self.round
        );
        // Failed to form a QC this round (for self.round - 1).
        // Allow Timeout Sync to be triggered (again) for rounds between
        // self.locked.round+1 and self.round-1.
        self.timeout_syncs.clear();
        self.send_timeout(self.round - 1).await
    }

    fn get_smr_dkg_committee(&self) -> Option<&CommmitteeConfig> {
        self.committee_config.get_committee_config(SmrDkgType::Smr)
    }

    // TODO: IMPLEMENT THRESHOLD SIGS ON ROUND NUMBERS TO MITIGATE DOS VIA VOTE AND TIMEOUT.

    #[async_recursion]
    async fn handle_vote(&mut self, vote: &Vote) -> ConsensusResult<()> {
        debug!("Received {:?}", vote);
        if vote.round >= self.round - 1 {
            debug!("Processing {:?}", vote);

            let dkg_threshold_f = self
                .get_smr_dkg_committee()
                .map(|c| c.threshold_f)
                .unwrap_or(0);

            // Add the new vote to our aggregator and see if we have a quorum.
            // Validation is done inside the aggregator.
            if let Some(qc) = self
                .aggregator
                .add_vote(vote.clone(), self.dkg_committee.as_ref(), dkg_threshold_f)
                .await?
            {
                debug!("Assembled {:?}", qc);
                self.handle_qc(&qc).await?;
            }
        }
        Ok(())
    }

    #[async_recursion]
    async fn handle_timeout(&mut self, timeout: &Timeout) -> ConsensusResult<()> {
        // The sender claims to be stuck in timeout.round.
        debug!("Processing {:?}", timeout);
        let r = timeout.round;

        if r <= self.locked.round {
            // QC Sync: We have a QC for r or higher.
            if timeout.author_is_authorised(&self.committee)? {
                // TODO: Pass DKGCommittee too if necessary.
                // Send our locked QC to our peer to allow it to enter a new round.
                self.sync_peer(&timeout.author).await;
            }
            // else: Spam message from a node outside the validator set.
        } else {
            // We cannot sync our peer to a higher round. We may be in a higher round than r as a
            // result of observing successive TCs, in which case we want to help our peer construct
            // the TC for r. Alternatively, we might be in r or lower and have yet to observe this
            // TC ourself.
            let (votes, maybe_tc) = self
                .aggregator
                .add_timeout(timeout.clone(), self.dkg_committee.as_ref())?;
            if votes >= self.committee.validity_threshold() && !self.timeout_syncs.contains(&r) {
                // Timeout Sync: We have observed at least f+1 Timeouts for r.
                // We also have not triggered this path since the last time our round timer expired.
                debug!("Timeout Sync for round {}", r);
                self.send_timeout(r).await?;
            }

            self.handle_qc(&timeout.high_qc).await?;

            if r > self.round - 2 {
                // Timeout was sent by a node in our round or higher. Check if we have a new TC.
                if let Some(tc) = maybe_tc {
                    debug!("Assembled {:?}", tc);
                    self.process_tc(&tc).await?
                }
            }
        }
        Ok(())
    }

    async fn propose_if_leader(&mut self, trigger: ProposalTrigger) {
        // TODO: Remove
        log::trace!("propose_if_leader self.proposed:{}, self.round:{}, self.name:{} self.leader_elector.get_leader(self.round):{}", self.proposed, self.round,self.name, self.leader_elector.get_leader(self.round));

        if self.proposed < self.round && self.name == self.leader_elector.get_leader(self.round) {
            debug!("Proposing. Trigger: {:?}", trigger);

            let (parent, maybe_qc_prime, parent_is_empty) = match trigger {
                ProposalTrigger::Block(b) => (b.digest(), None, b.is_empty()),
                // Will have locked this QC but will not have the related block yet. Must assume
                // that it has a payload.
                ProposalTrigger::QC(qc) => (qc.hash, None, false),
                ProposalTrigger::TC(tc) => {
                    // We could be locked on a higher QC than the max QC of the TC if we did not
                    // send a Timeout message of our own. Otherwise, we should be locked on the
                    // highest QC of the TC since we process each QC we get via a Timeout.
                    assert!(self.locked.round >= tc.max_qc().round);
                    (
                        self.locked.hash.clone(),
                        Some(self.locked.clone()),
                        self.is_locked_block_empty,
                    )
                }
            };

            let empty_status = EmptyBlockStatus {
                committed: self.is_last_committed_block_empty,
                locked: self.is_locked_block_empty,
                voted: parent_is_empty,
            };

            self.tx_proposer
                .send(ProposerMessage::Make(
                    self.round,
                    self.round_justification.clone(),
                    parent,
                    maybe_qc_prime,
                    empty_status,
                ))
                .await
                .expect("Failed to send message to proposer");

            // Used to ensure that each leader sends at most one proposal per round.
            self.proposed = self.round;
        }
    }

    async fn handle_qc(&mut self, qc: &QC) -> ConsensusResult<()> {
        debug!("Received QC {:?}", qc);
        if qc.round > self.last_commit.round && !self.uncommitted_qcs.contains_key(&qc.round) {
            // Ensure QC is valid (has a quorum). This is a relatively expensive check.
            qc.is_well_formed(&self.committee, self.dkg_committee.as_ref())?;

            debug!("Processing new QC {:?}", qc);
            self.uncommitted_qcs.insert(qc.round, qc.clone());
            self.last_vote = max(qc.round, self.last_vote);

            if qc.round == self.round - 1 {
                // Will only successfully propose here if we have not received the related
                // block yet. Could mean that we were censored by a Byzantine leader.
                self.propose_if_leader(ProposalTrigger::QC(qc.clone()))
                    .await;
            }

            // See if we have the related block and request it from our peers if we do not.
            self.get_block(qc.hash.clone(), qc.round).await?;
            self.try_lock_and_commit(qc).await?;
            self.networksender
                .broadcast_others_consensus_message(ConsensusMessage::QC(qc.clone()))
                .await;
            self.advance_to_round(qc.round + 2, Justification::QC(qc.clone()))
                .await?;
        }
        Ok(())
    }

    async fn process_tc(&mut self, tc: &TC) -> ConsensusResult<()> {
        debug!("Received TC {:?}", tc);
        if tc.round >= self.round - 2 {
            // Ensure TC is valid (has a quorum).
            tc.is_well_formed(&self.committee)?;
            debug!("Processing new TC {:?}", tc);
            self.advance_to_round(tc.round + 2, Justification::TC(tc.clone()))
                .await?;
            // Will only propose here if we did not do so during advance_to_round. We would have
            // created a Normal Proposal during advance_to_round if the round before tc.round
            // also produced a TC and we have a valid Fallback Recovery Proposal justified by
            // that TC. Otherwise, we will create our own Fallback Recovery Proposal now.
            self.propose_if_leader(ProposalTrigger::TC(tc.clone()))
                .await;
        }
        Ok(())
    }

    async fn process_normal_proposal(&mut self, p: Proposal) -> ConsensusResult<()> {
        debug!("Received Normal Proposal {:?}", p);
        let block = &p.block;

        // Ensure the embedded certificate is valid and process it if we have not yet seen it.
        match &p.justification {
            Justification::QC(qc) => self.handle_qc(qc).await?,
            Justification::TC(tc) => self.process_tc(tc).await?,
        };

        if self.process_block(block).await? {
            // Ensure:
            //   1. Proposer has voting rights.
            //   2. Proposal includes a valid certificate for p.block.round - 2.
            //   3. Block is signed by the proposer.
            p.is_well_formed(&self.committee)?;

            if self
                .store_block_or_sync_payload(block, ProposalType::Normal)
                .await?
            {
                self.try_commit_or_sync_ancestor(block).await?;
                // Try to vote and propose. Covers the case where we get B_r after QC_{r-1}.
                self.try_vote_and_propose().await?;
            }
            // else: We are missing part of the payload of the block or some of the txs in the
            // payload were invalid. If we were just missing batches then the Mempool will
            // send us this block again once it has synchronized them.
        }
        Ok(())
    }

    async fn process_fallback_recovery_proposal(
        &mut self,
        p: FallbackRecoveryProposal,
    ) -> ConsensusResult<()> {
        debug!("Received Fallback Recovery Proposal {:?}", p);
        let block = &p.proposal.block;

        match &p.proposal.justification {
            // Honest proposals will never trigger this case, but we allow it anyway
            // in case the Byzantine proposer includes a QC that we are missing.
            Justification::QC(qc) => self.handle_qc(qc).await?,
            // Normal case. Enforced in is_well_formed.
            Justification::TC(tc) => self.process_tc(tc).await?,
        };

        if self.process_block(block).await? {
            // Ensure qc_prime is valid and process it if we have not seen it before.
            self.handle_qc(&p.qc_prime).await?;
            // Ensure:
            //   1. Proposer has voting rights.
            //   2. Proposal includes a valid certificate for p.block.round - 2.
            //   3. Block is signed by the proposer.
            //   4. The included justification certificate is a TC.
            //   5. qc_prime is for a round greater or equal to that of the QC with
            //      the highest round included in the included TC.
            //   6. The parent of the included block is the block certified by qc_prime.
            p.is_well_formed(&self.committee)?;

            if self
                .store_block_or_sync_payload(block, ProposalType::FallbackRecovery)
                .await?
            {
                self.try_commit_or_sync_ancestor(block).await?;
                self.try_vote_and_propose().await?;

                // TODO: Ensure that the adversary cannot use this optimisation to break
                //       liveness using Timeout Sync.
                //
                // Justification is guaranteed to be a TC for block.round - 2.
                match self.uncommitted_blocks_by_round.get(&(block.round - 1)) {
                    // We have a well-formed Normal Proposal for the round before the round of this
                    // Fallback Recovery Proposal. We know that this Fallback Recovery Proposal is
                    // valid, so we can conclude that (except in special cases caused by asynchrony
                    // or very precise censoring) the block proposed two rounds ago is not going to
                    // achieve a QC and therefore neither can the aforementioned Normal Proposal.
                    // Consequently, we send a Timeout message for the corresponding round to avoid
                    // having to wait another \tau (timeout delay) for the next TC to form (at least
                    // in the normal case).
                    Some((_, ProposalType::Normal)) => self.send_timeout(block.round - 1).await?,
                    None => {
                        // Do not have a Proposal for the previous round or one for the round prior.
                        // We can assume that the leader before last failed to propose and thus that
                        // the leader after it will never be able to propose.
                        if !self
                            .uncommitted_blocks_by_round
                            .contains_key(&(block.round - 2))
                        {
                            self.send_timeout(block.round - 1).await?
                        }
                        // else: A proposal from the previous leader might still be in transit and
                        // might succeed if it is Fallback Recovery.
                    }
                    // Have a Fallback Recovery Proposal for the previous round, which should
                    // achieve a QC quickly, or had to sync this block. In the former case, we
                    // wait to avoid accidentally causing a TC for a proposal that might succeed.
                    // In the latter case, we know that the proposal has already succeeded.
                    _ => (),
                }
            }
            // else: We are missing part of the payload of the block or some of the txs in the
            // payload were invalid. If we were just missing batches then the Mempool will
            // send us this block again once it has synchronized them.
        }
        Ok(())
    }

    async fn process_block(&mut self, block: &Block) -> ConsensusResult<bool> {
        debug!("Received Block {:?}", block);
        let digest = block.digest();

        if block.round <= self.last_commit.round {
            debug!("Received old proposal {:?}", block);
            return Ok(false);
        }

        if block.digest() == self.locked.hash {
            // Locked the QC for this block before receiving the block itself. Check if
            // the block is empty so that we can stop producing blocks when the network
            // is not receiving txs.
            self.is_locked_block_empty = block.is_empty();
        }

        if self.sync_requests.remove(&digest) {
            // Already received a QC for this block. It is guaranteed to be valid.
            return Ok(true);
        }

        // Ensure that the block proposer is the leader of block.round.
        ensure!(
            block.author == self.leader_elector.get_leader(block.round),
            ConsensusError::WrongLeader {
                digest,
                leader: block.author,
                round: block.round
            }
        );

        if let Some((accepted, _)) = self.uncommitted_blocks_by_round.get(&block.round) {
            // Already received and validated a block for this round.
            if accepted.digest() == digest {
                debug!("Received duplicate proposal {:?}", block);
                return Ok(false);
            } else {
                // Reject the equivocal proposal. If the Block that we have already
                // accepted is not the one to become certified then we will sync the
                // certified block upon receiving its QC.
                debug!("Received equivocal proposal {:?}", block);
                return Ok(false);
            }
        }
        Ok(true)
    }

    async fn handle_proposal(&mut self, proposal: ProposalMessage) -> ConsensusResult<()> {
        log::trace!("handle_proposal :{}", proposal);
        match proposal {
            ProposalMessage::FallbackRecovery(f) => {
                self.process_fallback_recovery_proposal(f).await
            }
            ProposalMessage::Normal(n) => self.process_normal_proposal(n).await,
        }
    }

    async fn handle_sync_response(&mut self, block: Block) -> ConsensusResult<()> {
        debug!(
            "Received SyncResponse from peer containing block {:?}",
            block
        );
        let digest = block.digest();
        // Ensure that we were waiting for this block and have not already received
        // it via another channel (e.g. a late Proposal).
        if self.sync_requests.remove(&digest)
            && block.round > self.last_commit.round
            && self
                .store_block_or_sync_payload(&block, ProposalType::Sync)
                .await?
        {
            // Stored the block.
            //
            // If we requested this block via have_all_ancestors then this will trigger the
            // Synchronizer to send the latest HML descendent of this block to us again via
            // the loopback channel so we can resume searching for missing ancestors.
            //
            // If we requested this block via get_block then we will start recursively syncing
            // ancestors if it is LDC. If this block (B) may be LDC but we are already in the process
            // of syncing the ancestors of a higher LDC block (B'), then we will replace B with
            // B' as the block to yield upon receiving any subsequently-requested missing ancestor
            // (B_a) when the Synchronizer sends B' to us via loopback, which will trigger a
            // second SyncRequest for B_a (unless we get B_a before making this second request,
            // which should not happen when network latency is non-trivial).
            self.try_commit_or_sync_ancestor(&block).await?;
        }
        Ok(())
    }

    async fn handle_synchronizer_loopback(&mut self, block: Block) -> ConsensusResult<()> {
        debug!(
            "Reprocessing of block {:?} triggered by Synchronizer",
            block
        );
        // The Synchronizer will only ever send us certified blocks that satisfy the commit
        // rule (i.e. blocks that may be LDC) because we only ever request a loopback when we
        // are syncing blocks as a part of have_all_ancestors, which we only ever call with
        // HML blocks. We will have already stored this block when we first received it.
        // We now re-process it to check if the chain of ancestors in now complete, as
        // long as we have not already committed it.
        if block.round > self.last_commit.round {
            self.try_commit_or_sync_ancestor(&block).await?;
        }
        Ok(())
    }

    async fn handle_mempool_loopback(&mut self, block: Block) -> ConsensusResult<()> {
        debug!("Reprocessing of block {:?} triggered by Mempool", block);

        if block.round > self.last_commit.round {
            let t = if block.tc.is_some() {
                ProposalType::FallbackRecovery
            } else {
                ProposalType::Normal
            };
    
            // The Mempool sends us blocks for which we were missing part of the payload
            // when we initially tried to verify it. We attempt this verification after
            // validating the related Proposal (or already having a QC for the block), so
            // there is no need to re-validate the block.
            if self.store_block_or_sync_payload(&block, t).await? {
                self.try_commit_or_sync_ancestor(&block).await?;
                self.try_vote_and_propose().await?;
            }
            // else: Block payload contains invalid batches.
        } else {
            // We should not be able to commit blocks for which we are missing payloads.
            // Not panicking here since this is not a critical error. Normally, this would
            // indicate an error in the MempoolDriver/PayloadWaiter logic, but I cannot rule
            // out the possibility of a race condition also being the cause.
            warn!(
                "Mempool triggered reprocessing of block with round less than last committed \
                    block. Received: {:?}. Last Commit: {:?}.",
                block,
                self.last_commit
            );
        }
                
        Ok(())
    }

    pub async fn run(&mut self) {
        // Upon booting, generate the very first block (if we are the leader).
        // Also, schedule a timer in case we don't hear from the leader.
        self.timer.reset();
        if self.name == self.leader_elector.get_leader(self.round) {
            self.propose_if_leader(ProposalTrigger::Block(Block::genesis()))
                .await;
        }
        // Already start with the QC for the genesis block, so advance to
        // round 2 immediately after making the proposal for round 1.
        self.round = 2;

        // This is the main loop: it processes incoming blocks, votes and QCs,
        // and receives timeout notifications from our Timeout Manager.
        loop {
            let result = tokio::select! {
                Some(block) = self.rx_mempool.recv() => self.handle_mempool_loopback(block).await,
                Some(message) = self.rx_message.recv() => match message {
                    ConsensusMessage::Propose(proposal) => self.handle_proposal(proposal).await,
                    ConsensusMessage::QC(qc) => self.handle_qc(&qc).await,
                    ConsensusMessage::SyncResponse(block) => self.handle_sync_response(block).await,
                    ConsensusMessage::Timeout(timeout) => self.handle_timeout(&timeout).await,
                    ConsensusMessage::Vote(vote) => self.handle_vote(&vote).await,
                    ConsensusMessage::DkgCommittee(committee) => {
                        log::info!("Core loop receive DkgCommittee at round:{}", self.round);
                        // Switch must be done during round change.
                        self.waiting_dkg_committee = Some(committee);
                        Ok(())
                    },
                    _ => panic!("Unexpected protocol message")
                },
                Some(proposal) = self.rx_proposer.recv() => self.handle_proposal(proposal).await,
                Some(block) = self.rx_synchronizer.recv() => self.handle_synchronizer_loopback(block).await,
                () = &mut self.timer => self.local_timeout_round().await,
            };
            match result {
                Ok(()) => (),
                Err(ConsensusError::StoreError(e)) => error!("{}", e),
                Err(ConsensusError::SerializationError(e)) => error!("Store corrupted. {}", e),
                Err(e) => warn!("{}", e),
            }
        }
    }
}
