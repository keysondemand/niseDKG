use crate::consensus::ConsensusMessage;
use bytes::Bytes;
use log::trace;
use peer::HotStuffMessage;
use peer::PeerMessageHandler;
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerCommand;
use sop2p::PeerInfo;

pub struct ConsensusMessageSender {
    cmd_sender: sop2p::NetworkCommandSender,
}

impl ConsensusMessageSender {
    pub fn new(network: &NetWorkManagerAsync) -> ConsensusMessageSender {
        ConsensusMessageSender {
            cmd_sender: network.get_command_sender(),
        }
    }

    pub async fn broadcast_others_consensus_message(&self, message: ConsensusMessage) {
        let peers = self.cmd_sender.get_peers().await.unwrap();
        log::trace!(
            "broadcast_consensus_message:{message} send to peers:{:?}",
            peers
                .iter()
                .map(|p| format!("{},", p.pubkey))
                .collect::<Vec<String>>()
        );
        let bytes =
            sop2p::serialize::serialize(peer::HotStuffMessage::create_from_consensus(Bytes::from(
                bincode::serialize(&message).expect("Failed to serialize ConsensusMessage"),
            )));
        self.cmd_sender
            .send_command(PeerCommand::SendMessage(bytes))
            .await;
    }

    pub async fn send_consensus_message_to_peer(&self, peer: PeerInfo, message: ConsensusMessage) {
        let hmes = peer::HotStuffMessage::create_from_consensus(Bytes::from(
            bincode::serialize(&message).expect("Failed to serialize ConsensusMessage"),
        ));
        peer::send_message_to_peer(&self.cmd_sender, peer, hmes).await;
    }
}

#[derive(Clone)]
pub struct ProposerBlockAckSender {
    cmd_sender: sop2p::NetworkCommandSender,
}
impl ProposerBlockAckSender {
    pub fn new(network: &NetWorkManagerAsync) -> ProposerBlockAckSender {
        ProposerBlockAckSender {
            cmd_sender: network.get_command_sender(),
        }
    }

    pub async fn send_proposerblockack_message(
        &self,
        peer_info: PeerInfo,
        digest: [u8; 32],
        stake: u32,
    ) {
        trace!(
            "ProposerMessage send_proposerblockack_message stake:{stake} ack " //for digest:{digest:?}
        );

        let bytes = sop2p::serialize::serialize(
            peer::HotStuffMessage::create_from_proposeblockack(digest, stake),
        );

        self.cmd_sender
            .send_command(PeerCommand::SendMessageTo(peer_info, bytes))
            .await;
    }
}

pub fn spawn_concensusreceiver_message_receiver<Handler: PeerMessageHandler>(
    network_receiver: NetworkEventReceiver,
    handler: Handler,
) {
    peer::spawn_peer_message_receiver(
        "concensus receiver".to_string(),
        network_receiver,
        handler,
        concensusreceiver_filter_message,
    );
}

fn concensusreceiver_filter_message(message: &HotStuffMessage) -> bool {
    message.is_consensus_message()
}

pub fn spawn_proposeblockack_message_receiver<Handler: PeerMessageHandler>(
    network_receiver: NetworkEventReceiver,
    handler: Handler,
) {
    peer::spawn_peer_message_receiver(
        "block proposer ack".to_string(),
        network_receiver,
        handler,
        proposeblockackr_filter_message,
    );
}

fn proposeblockackr_filter_message(message: &HotStuffMessage) -> bool {
    message.is_proposeblockack_message()
}
