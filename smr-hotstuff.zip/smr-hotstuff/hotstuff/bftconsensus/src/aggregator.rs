use crate::config::{Committee, Stake};
use crate::consensus::Round;
use crate::error::ConsensusResult;
use crate::messages::VoteSignature;
use crate::messages::{Timeout, Vote, QC, TC};
use socrypto::Digest as _;
use socrypto::{Hash, PublicKey, Signature};
use sosmr::DkgCommittee;
use std::collections::{HashMap, HashSet};
use std::fmt;

#[cfg(test)]
#[path = "tests/aggregator_tests.rs"]
pub mod aggregator_tests;

pub struct Aggregator {
    committee: Committee,
    // Round, sequence number, block digest and parent must agree for all votes.
    votes_aggregators: HashMap<(Round, Hash, Hash), HashMap<Hash, Box<QCMaker>>>,
    timeouts_aggregators: HashMap<Round, Box<TCMaker>>,
}

impl Aggregator {
    pub fn new(committee: Committee) -> Self {
        Self {
            committee,
            votes_aggregators: HashMap::new(),
            timeouts_aggregators: HashMap::new(),
        }
    }

    pub async fn add_vote(
        &mut self,
        vote: Vote,
        dkg_committee: Option<&DkgCommittee>,
        threshold_f: usize,
    ) -> ConsensusResult<Option<QC>> {
        // TODO [issue #7]: A bad node may make us run out of memory by sending many votes
        // with different round numbers or different digests.
        // Add the new vote to our aggregator and see if we have a QC.
        self.votes_aggregators
            .entry((vote.round, vote.hash, vote.parent))
            .or_insert_with(HashMap::new)
            .entry(vote.digest())
            .or_insert_with(|| Box::new(QCMaker::new()))
            .append(vote, &self.committee, dkg_committee, threshold_f)
            .await
    }

    pub fn add_timeout(
        &mut self, 
        timeout: Timeout, 
        dkg_committee: Option<&DkgCommittee>
    ) -> ConsensusResult<(Stake, Option<TC>)> {
        // TODO: A bad node may make us run out of memory by sending many timeouts
        // with different round numbers.

        // Add the new timeout to our aggregator and see if we have a TC.
        self.timeouts_aggregators
            .entry(timeout.round)
            .or_insert_with(|| Box::new(TCMaker::new()))
            .append(timeout, &self.committee, dkg_committee)
    }

    pub fn cleanup_prepares(&mut self, round: &Round) {
        self.votes_aggregators.retain(|(k, _, _), _| k > round);
    }

    pub fn cleanup_timeouts(&mut self, round: &Round) {
        self.timeouts_aggregators.retain(|k, _| k > round);
    }
}

impl fmt::Display for Aggregator {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(
            f,
            "Aggregator votes:{} tc:{}",
            self.votes_aggregators.len(),
            self.timeouts_aggregators.len()
        )
    }
}

struct QCMaker {
    weight: Stake,
    votes: Vec<(PublicKey, VoteSignature)>,
    used: HashSet<PublicKey>,
}

impl QCMaker {
    pub fn new() -> Self {
        Self {
            weight: 0,
            votes: Vec::new(),
            used: HashSet::new(),
        }
    }

    /// Try to append a signature to a (partial) quorum.
    pub async fn append(
        &mut self,
        vote: Vote,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
        threshold_f: usize,
    ) -> ConsensusResult<Option<QC>> {
        let author = vote.author;

        if self.used.contains(&author) {
            log::debug!("Received duplicate vote from {}", author);
        } else {
            // Verify the signature and voting rights before storing to prevent DoS
            // by unauthorised nodes. Verification is done after membership check on
            // self.used to prevent authorised but Byzantine nodes from draining compute
            // by sending duplicate Votes (HashMap membership checks are cheap, sig
            // verification is more expensive).
            vote.is_well_formed(committee, dkg_committee)?;
            // Ensure we ignore duplicates.
            self.used.insert(author);
            self.votes.push((author, vote.signature));
            self.weight += committee.stake(&author);

            if self.weight >= committee.quorum_threshold() {
                // Ensures QC is only made once.
                self.weight = 0;
                // Create committee threshold signature.
                let qc_votes = self.votes.clone();
                // Cloned because spawn_blocking has static lifetime, scoped version.
                let c = dkg_committee.cloned();
                let qc = tokio::task::spawn_blocking(move || {
                    QC::sign_committee_votes(
                        vote.hash,
                        vote.round,
                        vote.parent,
                        qc_votes,
                        c.as_ref(),
                        threshold_f,
                    )
                })
                .await??;
                return Ok(Some(qc));
            }
        }

        Ok(None)
    }
}

struct TCMaker {
    weight: Stake,
    votes: Vec<(PublicKey, Signature, QC)>,
    used: HashSet<PublicKey>,
}

impl TCMaker {
    pub fn new() -> Self {
        Self {
            weight: 0,
            votes: Vec::new(),
            used: HashSet::new(),
        }
    }

    /// Try to append a signature to a (partial) quorum.
    pub fn append(
        &mut self,
        timeout: Timeout,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>
    ) -> ConsensusResult<(Stake, Option<TC>)> {
        let author = timeout.author;

        if ! self.used.contains(&author) {
            // Verify the signature and voting rights before storing to prevent DoS
            // by unauthorised nodes. Verification is done after membership check on
            // self.used to prevent authorised but Byzantine nodes from draining compute
            // by sending duplicate Timeouts (HashMap membership checks are cheap, sig
            // verification is more expensive).
            timeout.is_well_formed(committee, dkg_committee)?;
            // Ensure we ignore duplicates.
            self.used.insert(author);

            // Add the timeout to the accumulator.
            self.votes.push((author, timeout.signature, timeout.high_qc.clone()));
            self.weight += committee.stake(&author);

            if self.weight >= committee.quorum_threshold() {
                // We do not reset the weight after creating the TC because we might
                // still need to send Timeout messages for this round to our honest
                // peers in case they either were censored by the Byzantine nodes or
                // the network dropped some of the honest Timeouts en-route to them.
                return Ok(
                    (self.weight, Some(TC { round: timeout.round, votes: self.votes.clone()}))
                );
            }
        }

        Ok((self.weight, None))
    }
}
