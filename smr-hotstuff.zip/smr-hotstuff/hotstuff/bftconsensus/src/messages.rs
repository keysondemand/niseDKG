use crate::config::Committee;
use crate::consensus::Round;
use crate::error::{ConsensusError, ConsensusResult};
use serde::{Deserialize, Serialize};
use sha3::{Digest as Sha3Digest, Keccak256};
use sign::SignatureService;
use socrypto::SupraCryptoError;
use socrypto::{Digest, Hash, PublicKey, Signature};
use sodkg::BlsPrivateKey;
use sodkg::BlsSignature;
use sosmr::DkgCommittee;
use sosmr::SmrBatch;
use sosmr::SmrQCSignature;
use sosmr::SmrTransactionProtocol;
use sosmr::{SmrBlock, SmrQC, SmrTC};
use std::collections::HashSet;
use std::fmt;
use std::time::SystemTime;
use std::time::UNIX_EPOCH;

#[cfg(test)]
#[path = "tests/messages_tests.rs"]
pub mod messages_tests;

// Justification for a Proposal that proves that it is recent.
// Prevents DoS attacks that attempt to flood nodes with proposals for higher rounds.
#[derive(Serialize, Deserialize, Clone)]
pub enum Justification {
    QC(QC),
    TC(TC),
}

impl Justification {
    pub fn get_qc_tc(&self) -> (QC, Option<TC>) {
        match &self {
            Justification::QC(qc) => (qc.clone(), None),
            Justification::TC(tc) => (tc.max_qc(), Some(tc.clone())),
        }
    }
}

impl Default for Justification {
    fn default() -> Self {
        Justification::QC(QC::genesis())
    }
}

impl fmt::Debug for Justification {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        let disp = match self {
            Justification::QC(qc) => format!("{:?}", qc),
            Justification::TC(tc) => format!("{:?}", tc),
        };
        write!(f, "Justification {:?}", disp)
    }
}

#[derive(Serialize, Deserialize, Default, Clone)]
pub struct Block {
    pub qc: QC,
    pub tc: Option<TC>,
    pub author: PublicKey,
    pub parent: Hash,
    pub payload: Vec<Hash>,
    pub round: Round,
    pub timestamp: u128,
    pub signature: Signature,
}

impl Block {
    pub async fn new(
        author: PublicKey,
        parent: Hash,
        payload: Vec<Hash>,
        round: Round,
        qc: QC,
        tc: Option<TC>,
        signature_service: &mut SignatureService,
    ) -> Self {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis();

        let block = Self {
            qc,
            tc,
            author,
            parent,
            round,
            payload,
            timestamp,
            signature: Signature::default(),
        };
        let signature = signature_service.request_signature(block.digest()).await;
        Self { signature, ..block }
    }

    pub fn is_empty(&self) -> bool {
        self.payload.is_empty()
    }

    pub fn genesis() -> Self {
        Block::default()
    }

    pub fn is_well_formed(&self, committee: &Committee) -> ConsensusResult<()> {
        // Ensure the proposer has voting rights.
        let voting_rights = committee.stake(&self.author);
        ensure!(
            voting_rights > 0,
            ConsensusError::UnknownAuthority(self.author)
        );

        // Ensure the included signature is that of the author.
        Signature::verify(&self.digest(), &self.signature, &self.author)?;
        Ok(())
    }

    pub async fn convert_to_supra_types(
        self,
        store: &mut store::Store,
        signature_service: &mut SignatureService,
    ) -> Result<SmrBlock, ConsensusError> {
        //extract protocol from all batch
        //TODO optimize this part to avoid to get batch from store to retrieve the protocol.
        let mut smr_payload: Vec<(SmrTransactionProtocol, Hash)> = vec![];
        for key in self.payload.into_iter() {
            let batch = match store.read(key.to_vec()).await {
                Ok(Some(bytes)) => SmrBatch::try_from(bytes.to_vec()).map_err(|err| {
                    ConsensusError::SmrStructConversionError(format!(
                        "Error during deserializing batch from store err:{}",
                        err
                    ))
                })?,
                Ok(None)=> {
                    return Err(ConsensusError::SmrStructConversionError(
                        "Convert block to sosmr Error during get batch from store no batch found".to_string(),
                    ))
                }
                Err(err) => {
                    return Err(ConsensusError::SmrStructConversionError(
                        format!("Convert block to sosmr Error during get batch from store see store error:{err}"),
                    ))
                }
            };
            smr_payload.push((batch.protocol, key));
        }

        let block = SmrBlock {
            qc: self.qc.convert_to_supra_types(),
            tc: self.tc.map(|tc| tc.convert_to_supra_types()),
            author: self.author,
            round: self.round,
            payload: smr_payload,
            timestamp: self.timestamp,
            signature: Signature::default(),
        };
        let signature = signature_service.request_signature(block.digest()).await;
        Ok(SmrBlock { signature, ..block })
    }
}

impl Digest for Block {
    fn digest(&self) -> Hash {
        let mut block_hasher = Keccak256::new();

        block_hasher.update(self.round.to_be_bytes());
        block_hasher.update(self.timestamp.to_be_bytes());
        block_hasher.update(self.author.0);
        //parent not in the digest for now. defined in the QC
        //block_hasher.update(self.parent.clone());
        //binserialize and hash the QC or the TC if some.
        block_hasher.update(QC::digest(&self.qc).0);
        //add batch hash
        let mut batches_hasher = Keccak256::new();
        for batch in &self.payload {
            batches_hasher.update(batch);
        }
        let hash = <[u8; 32]>::from(batches_hasher.finalize());
        block_hasher.update(hash);

        socrypto::Hash(<[u8; 32]>::from(block_hasher.finalize()))
    }
}

impl fmt::Debug for Block {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(
            f,
            "{}: SupraBFT B(author {}, parent {}, round {}, qc {:?}, tc {:?}, timestamp {}, payload_len {}) batches:{}",
            self.digest(),
            self.author,
            self.parent,
            self.round,
            self.qc,
            self.tc,
            self.timestamp,
            self.payload.len(),
            self.payload
                .iter()
                .map(|p| hex::encode(p))
                .fold(String::new(), |s, p| { s + &format!("{}/", p) })
        )
    }
}

impl fmt::Display for Block {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "SupraBFT B{}", self.round)
    }
}

#[derive(Serialize, Deserialize, Default, Clone)]
pub struct Proposal {
    pub block: Block,
    // Proof that the leader entered the related round correctly.
    // Without this, Byzantine nodes could spam others with well-formed Proposals for
    // future rounds, which they would need to store until they enter block.round + 1
    // and become able to evaluate the validity of the related block.
    pub justification: Justification,
}

impl Proposal {
    pub async fn new(block: Block, justification: Justification) -> Self {
        Self {
            block,
            justification,
        }
    }

    pub fn genesis() -> Self {
        Self {
            block: Block::genesis(),
            justification: Justification::QC(QC::genesis()),
        }
    }

    pub fn is_well_formed(&self, committee: &Committee) -> ConsensusResult<()> {
        self.block.is_well_formed(committee)?;

        let recent_round = match &self.justification {
            Justification::QC(qc) => qc.round,
            Justification::TC(tc) => tc.round,
        };

        // Ensure the Justification certificate is for two rounds prior.
        // Quorum validity is checked during certificate processing.
        ensure!(
            // First Proposal.
            self.block.round == 1 && recent_round == 0
                // General case.
                || recent_round == self.block.round - 2,
            ConsensusError::BlockBadQC(self.digest(), self.block.round, recent_round)
        );
        Ok(())
    }
}

impl Digest for Proposal {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.block.digest());
        match &self.justification {
            Justification::QC(qc) => hasher.update(qc.digest()),
            Justification::TC(tc) => hasher.update(tc.digest()),
        };
        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))
    }
}

impl fmt::Debug for Proposal {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(
            f,
            "Proposal {}: Block {:?}, {:?})",
            self.digest(),
            self.block,
            self.justification
        )
    }
}

impl fmt::Display for Proposal {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "Proposal B:{}/{}", self.block.round, self.block.digest())
    }
}

// TODO: Simplify. We don't need this type now that TCs are included in the Block itself again.
#[derive(Serialize, Deserialize, Default, Clone)]
pub struct FallbackRecoveryProposal {
    pub proposal: Proposal,
    pub qc_prime: QC,
}

impl FallbackRecoveryProposal {
    pub fn new(proposal: Proposal, qc_prime: QC) -> Self {
        Self { proposal, qc_prime }
    }

    pub fn is_well_formed(&self, committee: &Committee) -> ConsensusResult<()> {
        // Verify the block signature and voting rights.
        self.proposal.is_well_formed(committee)?;

        let round = self.proposal.block.round;

        match &self.proposal.justification {
            Justification::QC(_) => {
                Err(ConsensusError::BlockBadJustification(self.digest(), round))
            }
            Justification::TC(tc) => {
                let max_qc = tc.max_qc();

                // Ensure qc_prime (embedded QC) has a round at least as great as max_qc.
                ensure!(
                    self.qc_prime.round >= max_qc.round,
                    ConsensusError::FallbackRecoveryBadQcPrime(
                        self.digest(),
                        round,
                        self.qc_prime.round
                    )
                );

                // Parent of the block must be certified by qc_prime.
                ensure!(
                    self.proposal.block.parent == self.qc_prime.hash,
                    ConsensusError::FallbackRecoveryBadParent(self.proposal.block.digest())
                );
                Ok(())
            }
        }
    }
}

impl Digest for FallbackRecoveryProposal {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.proposal.digest());
        hasher.update(self.qc_prime.digest());
        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))
    }
}

impl fmt::Debug for FallbackRecoveryProposal {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(
            f,
            "FRProposal {}: {:?}, {:?}",
            self.digest(),
            self.proposal,
            self.qc_prime
        )
    }
}

impl fmt::Display for FallbackRecoveryProposal {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(
            f,
            "FRProposal B:{}/{}",
            self.proposal.block.round,
            self.proposal.block.digest()
        )
    }
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub enum VoteSignature {
    Ed25519(Signature),
    Commitee(Box<BlsSignature>),
}

impl VoteSignature {
    pub fn is_bls_vote(&self) -> bool {
        match self {
            VoteSignature::Ed25519(_) => false,
            VoteSignature::Commitee(_) => true,
        }
    }

    pub fn get_ed25519_signature(&self) -> Option<&Signature> {
        match self {
            VoteSignature::Commitee(_) => None,
            VoteSignature::Ed25519(sign) => Some(sign),
        }
    }

    pub fn get_bls_signature(&self) -> Option<&BlsSignature> {
        match self {
            VoteSignature::Commitee(sign) => Some(sign),
            VoteSignature::Ed25519(_) => None,
        }
    }
    pub fn consume_bls_signature(self) -> Option<BlsSignature> {
        match self {
            VoteSignature::Commitee(sign) => Some(*sign),
            VoteSignature::Ed25519(_) => None,
        }
    }

    pub fn verify_sign(
        &self,
        author: PublicKey,
        message_digest: Hash,
        dkg_committee: Option<&DkgCommittee>,
    ) -> Result<(), SupraCryptoError> {
        // Check the signature.
        match self {
            VoteSignature::Ed25519(signature) => {
                //log::info!("vote verify_sign Ed25519");
                Signature::verify(&message_digest, signature, &author)?
            }
            VoteSignature::Commitee(blssignature) => {
                //log::info!("vote verify_sign blssignature");
                dkg_committee
                    .and_then(|committee| committee.get_member(author))
                    .and_then(|n| n.public_share.as_ref())
                    .map(|pks| {
                        pks.verify_chain(&message_digest.into_bytes(), blssignature)
                            .then_some(())
                    })
                    .ok_or(SupraCryptoError::VerifySignError(author))?;
            }
        };
        Ok(())
    }
}

impl Default for VoteSignature {
    fn default() -> Self {
        VoteSignature::Ed25519(Signature::default())
    }
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Vote {
    pub hash: Hash,
    pub parent: Hash,
    pub round: Round,
    pub author: PublicKey,
    pub signature: VoteSignature,
}

impl Vote {
    pub async fn new(
        block: &Block,
        author: PublicKey,
        mut signature_service: SignatureService,
    ) -> Self {
        let vote = Self {
            hash: block.digest(),
            parent: block.parent,
            round: block.round,
            author,
            signature: VoteSignature::default(),
        };
        let signature =
            VoteSignature::Ed25519(signature_service.request_signature(vote.digest()).await);
        Self { signature, ..vote }
    }

    pub fn new_committee_signed(
        block: &Block,
        author: PublicKey,
        secret_share: &BlsPrivateKey,
    ) -> Self {
        let vote = Self {
            hash: block.digest(),
            round: block.round,
            parent: block.parent,
            author,
            signature: VoteSignature::default(),
        };
        let signature = VoteSignature::Commitee(Box::new(
            secret_share.sign_chain(&vote.digest().into_bytes()),
        ));
        Self { signature, ..vote }
    }

    // pub async fn new_from_qc(
    //     qc: &QC,
    //     author: PublicKey,
    //     mut signature_service: SignatureService,
    // ) -> Self {
    //     let vote = Self {
    //         hash: qc.hash.clone(),
    //         parent: qc.parent.clone(),
    //         round: qc.round,
    //         author,
    //         signature: Signature::default(),
    //     };
    //     let signature = signature_service.request_signature(vote.digest()).await;
    //     Self { signature, ..vote }
    // }

    pub fn is_well_formed(
        &self,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
    ) -> ConsensusResult<()> {
        // Ensure the authority has voting rights.
        ensure!(
            committee.stake(&self.author) > 0,
            ConsensusError::UnknownAuthority(self.author)
        );

        // Check the signature.
        self.signature
            .verify_sign(self.author, self.digest(), dkg_committee)?;
        Ok(())
    }
}

impl Digest for Vote {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.hash);
        //no parent in the current impl
        //hasher.update(&self.parent);
        hasher.update(self.round.to_le_bytes());
        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))
    }
}

impl fmt::Debug for Vote {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "V({}, {}, {})", self.author, self.round, self.hash)
    }
}

#[derive(Clone, Serialize, Deserialize, Default)]
pub struct QC {
    pub hash: Hash,
    pub parent: Hash,
    pub round: Round,
    pub signature: SmrQCSignature,
    //    pub votes: Vec<(PublicKey, Signature)>,
}

impl QC {
    pub fn genesis() -> Self {
        QC {
            hash: Block::genesis().digest(),
            parent: Hash::default(),
            round: 0,
            signature: SmrQCSignature::default(),
        }
    }

    pub fn timeout(&self) -> bool {
        self.hash == Hash::default() && self.round != 0
    }

    pub fn is_well_formed(
        &self,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
    ) -> ConsensusResult<()> {
        // Ensure the QC has a quorum.
        let mut weight = 0;
        let mut used = HashSet::new();
        //build node list and stake to verify vote volume.
        let votes: Vec<(PublicKey, u32)> = match &self.signature {
            SmrQCSignature::Ed25519Vote(pk_list) => pk_list
                .iter()
                .map(|(pk, _)| (*pk, committee.stake(pk)))
                .collect(),
            SmrQCSignature::BlsThresholdSignature(_, nodes) => {
                nodes.iter().map(|pk| (*pk, committee.stake(pk))).collect()
            }
        };

        for (name, voting_rights) in votes {
            ensure!(!used.contains(&name), ConsensusError::AuthorityReuse(name));
            ensure!(voting_rights > 0, ConsensusError::UnknownAuthority(name));
            used.insert(name);
            weight += voting_rights;
        }

        ensure!(
            self.round == 0 || weight >= committee.quorum_threshold(),
            ConsensusError::QCRequiresQuorum(self.round)
        );

        // Check the signatures.
        self.signature
            .verify_signature(
                self.digest(),
                dkg_committee.as_ref().map(|c| &c.threshold_pubkey),
            )
            .map_err(ConsensusError::from)

        //        Signature::verify_batch(&self.digest(), &self.votes).map_err(ConsensusError::from)
    }

    pub fn sign_committee_votes(
        hash: Hash,
        round: Round,
        parent: Hash,
        votes: Vec<(PublicKey, VoteSignature)>,
        dkg_committee: Option<&DkgCommittee>,
        threshold_f: usize,
    ) -> ConsensusResult<QC> {
        if votes.is_empty() {
            return Ok(QC::genesis());
        }

        log::trace!(
            "QC sign_committee_votes dkg_committee:{} vote:{}",
            dkg_committee.is_some(),
            votes[0].1.is_bls_vote()
        );

        //if committee is present with BLS vote
        //Committee are updated and vote arrive one block after.
        let signature = match (dkg_committee, votes[0].1.is_bls_vote()) {
            (Some(committee), true) => {
                let nodes = votes.iter().map(|(pk, _)| *pk).collect();
                let pk_signs: Vec<(PublicKey, BlsSignature)> = votes
                    .into_iter()
                    .filter_map(|(pk, vote)| vote.consume_bls_signature().map(|s| (pk, s)))
                    .collect();
                let bls = committee
                    .create_committeesign_with_partial_sign(pk_signs, threshold_f)
                    .map_err(|err| ConsensusError::VoteThresholdSignError(err.to_string()))?;
                SmrQCSignature::BlsThresholdSignature(bls, nodes)
            }
            (_, _) => {
                let votes = votes
                    .into_iter()
                    .filter_map(|(pk, vote)| match vote {
                        VoteSignature::Ed25519(sign) => Some((pk, sign)),
                        VoteSignature::Commitee(_) => None,
                    })
                    .collect();
                SmrQCSignature::Ed25519Vote(votes)
            }
        };

        Ok(QC {
            hash,
            round,
            parent,
            signature,
        })
    }

    pub fn convert_to_supra_types(self) -> SmrQC {
        SmrQC {
            hash: self.hash,
            round: self.round,
            signature: self.signature,
        }
    }
}

impl Digest for QC {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.hash);
        //no parent in current version.
        //hasher.update(&self.parent);
        hasher.update(self.round.to_le_bytes());
        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))
    }
}

impl fmt::Debug for QC {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        let signtype = match self.signature {
            SmrQCSignature::Ed25519Vote(_) => "Ed25519Vote",
            SmrQCSignature::BlsThresholdSignature(_, _) => "BlsThresholdSignature",
        };
        write!(
            f,
            "QC({}, {}, {}, {})",
            self.hash, self.parent, self.round, signtype
        )
    }
}

impl PartialEq for QC {
    fn eq(&self, other: &Self) -> bool {
        self.hash == other.hash && self.round == other.round
    }
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Timeout {
    pub high_qc: QC,
    pub round: Round,
    pub author: PublicKey,
    pub signature: Signature,
}

impl Timeout {
    pub async fn new(
        high_qc: QC,
        round: Round,
        author: PublicKey,
        mut signature_service: SignatureService,
    ) -> Self {
        let timeout = Self {
            high_qc,
            round,
            author,
            signature: Signature::default(),
        };
        let signature = signature_service.request_signature(timeout.digest()).await;
        Self {
            signature,
            ..timeout
        }
    }

    pub fn author_is_authorised(&self, committee: &Committee) -> ConsensusResult<bool> {
        // Ensure the author has voting rights.
        ensure!(
            committee.stake(&self.author) > 0,
            ConsensusError::UnknownAuthority(self.author)
        );
        Ok(true)
    }

    pub fn is_well_formed(
        &self,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
    ) -> ConsensusResult<()> {
        // Ensure the authority has voting rights.
        ensure!(
            committee.stake(&self.author) > 0,
            ConsensusError::UnknownAuthority(self.author)
        );

        // Check the signature.
        Signature::verify(&self.digest(), &self.signature, &self.author)?;

        // Check the embedded QC.
        if self.high_qc != QC::genesis() {
            self.high_qc.is_well_formed(committee, dkg_committee)?;
        }
        Ok(())
    }
}

impl Digest for Timeout {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.high_qc.digest());
        hasher.update(self.round.to_le_bytes());
        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))
    }
}

impl fmt::Debug for Timeout {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "TV({}, {}, {:?})", self.author, self.round, self.high_qc)
    }
}

#[derive(Clone, Serialize, Deserialize, Default)]
pub struct TC {
    pub round: Round,
    pub votes: Vec<(PublicKey, Signature, QC)>,
}

impl TC {
    pub fn is_well_formed(&self, committee: &Committee) -> ConsensusResult<()> {
        // Ensure the TC has a quorum.
        let mut weight = 0;
        let mut used = HashSet::new();
        for (name, _, _) in self.votes.iter() {
            ensure!(!used.contains(name), ConsensusError::AuthorityReuse(*name));
            let voting_rights = committee.stake(name);
            ensure!(voting_rights > 0, ConsensusError::UnknownAuthority(*name));
            used.insert(*name);
            weight += voting_rights;
        }
        ensure!(
            weight >= committee.quorum_threshold(),
            ConsensusError::TCRequiresQuorum
        );

        // Check the signatures.
        for (author, signature, high_qc) in &self.votes {
            let mut hasher = Keccak256::new();
            hasher.update(high_qc.digest());
            hasher.update(self.round.to_le_bytes());
            let digest = socrypto::Hash(<[u8; 32]>::from(hasher.finalize()));
            Signature::verify(&digest, signature, author)?;
        }
        Ok(())
    }

    pub fn high_qcs(&self) -> Vec<&QC> {
        self.votes.iter().map(|(_, _, qc)| qc).collect()
    }

    pub fn high_qc_rounds(&self) -> Vec<&Round> {
        self.high_qcs().iter().map(|qc| &qc.round).collect()
    }

    pub fn max_qc(&self) -> QC {
        let high_qcs = self.high_qcs();
        // Ensure that we never return the Genesis QC unless
        // it is actually contained in the TC. This function
        // should never be called on a TC with no votes.
        assert!(!high_qcs.is_empty());

        let def = QC::genesis();
        let mut max = &def;

        for qc in high_qcs {
            if qc.round > max.round {
                max = qc;
            }
        }

        if max.round > def.round {
            max.clone()
        } else {
            def
        }
    }

    pub fn convert_to_supra_types(self) -> SmrTC {
        SmrTC {
            round: self.round,
            votes: self
                .votes
                .into_iter()
                .map(|(pk, sign, qc)| (pk, sign, qc.round))
                .collect(),
        }
    }
}

impl Digest for TC {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.round.to_le_bytes());

        for qc in self.high_qcs() {
            hasher.update(qc.digest());
        }

        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))
    }
}

impl fmt::Debug for TC {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "TC({}, {:?})", self.round, self.high_qc_rounds())
    }
}
