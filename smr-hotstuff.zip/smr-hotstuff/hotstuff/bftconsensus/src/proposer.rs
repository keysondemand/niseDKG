use crate::config::{Committee, Stake};
use crate::consensus::{ConsensusMessage, ProposalMessage, Round};
use crate::messages::Justification;
use crate::messages::{Block, FallbackRecoveryProposal, Proposal, QC};
use crate::network::ConsensusMessageSender;
use async_trait::async_trait;
use log::warn;
use peer::HotStuffMessage;
use peer::PeerMessageHandler;
use sign::SignatureService;
use socrypto::Digest;
use socrypto::Hash;
use socrypto::PublicKey;
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerInfo;
use std::collections::HashSet;
use std::collections::{HashMap, VecDeque};
use std::sync::Arc;
use tokio::sync::mpsc::{Receiver, Sender};
use tokio::sync::Mutex;
use tokio::sync::Notify;

//manage propose block Ack
#[derive(Clone)]
struct ProposeBlockAckReceiverHandler {
    name: PublicKey,
    committee: Committee,
    #[allow(clippy::type_complexity)]
    waiting_block_list: Arc<Mutex<HashMap<Hash, (Stake, Arc<Notify>)>>>,
}

#[async_trait]
impl PeerMessageHandler for ProposeBlockAckReceiverHandler {
    async fn dispatch(&mut self, _peer_info: PeerInfo, message: HotStuffMessage) {
        if let HotStuffMessage::ProposeBlockAckMessage(digest, stake) = message {
            log::trace!(
                "node:{} ProposerMessage receive from:{_peer_info} stake:{stake} ack",
                self.name
            );

            let mut waiting_block_list = self.waiting_block_list.lock().await;
            log::trace!(
                "consensus proposer ProposeBlockAckReceiverHandler waiting_block_list.len:{} digest:{}",
                waiting_block_list.len(), Hash::new(digest)
            );
            if let Some((total_stake, _)) = waiting_block_list.get_mut(&Hash(digest)) {
                *total_stake += stake;

                // log::info!(
                //     "consensus proposer ProposeBlockAckReceiverHandler total_stake:{total_stake} notify:{notify:?} self.committee.quorum_threshold():{}"
                //     , self.committee.quorum_threshold()
                // );

                if *total_stake >= self.committee.quorum_threshold() {
                    let (_, notify) = waiting_block_list.remove(&Hash(digest)).unwrap(); // unwrap tested before
                    log::trace!("consensus proposer ProposeBlockAckReceiverHandler quorum threshold reached for digest:{digest:?}");
                    notify.notify_one();
                }
            };
        }
    }
}

#[derive(Debug)]
pub struct EmptyBlockStatus {
    // true iff the block most recently committed by the Core was empty.
    pub committed: bool,
    // true iff the block most recently locked by the Core was empty.
    pub locked: bool,
    // true iff the block most recently received and validated by the Core was empty.
    pub voted: bool,
}

#[derive(Debug)]
pub enum ProposerMessage {
    // Map of payloads included in the most recent sub-chain of blocks to be committed, indexed
    // by the round of the block in which they were contained, paired with the round of the most
    // recently committed block.
    Cleanup(HashMap<Round, Vec<Hash>>, Round),
    // Hashes of batches included in blocks that we have validated but not yet committed.
    Observed(Vec<Hash>, Round),
    // Request for a new block proposal.
    Make(Round, Justification, Hash, Option<QC>, EmptyBlockStatus),
}

pub struct Proposer {
    max_block_size: usize,
    name: PublicKey,
    networksender: ConsensusMessageSender,
    // Queue of hashes of batches that have been distributed by the mempool but have yet to be
    // committed and are not included in blocks that are currently undergoing consensus. Sorted
    // (approximately) from oldest to newest w.r.t. the time that they were received from the mempool.
    proposable: VecDeque<Hash>,
    // Payloads that have been proposed but have yet to be finalised. Disjoint with 'proposable'.
    proposed: HashMap<Round, Vec<Hash>>,
    proposal_request: Option<(Round, Justification, Hash, Option<QC>, EmptyBlockStatus)>,
    rx_mempool: Receiver<Hash>,
    rx_message: Receiver<ProposerMessage>,
    signature_service: SignatureService,
    tx_proposer_core: Sender<ProposalMessage>,
    #[allow(clippy::type_complexity)]
    waiting_block_list: Arc<Mutex<HashMap<Hash, (Stake, Arc<Notify>)>>>,
}

impl Proposer {
    pub fn spawn(
        name: PublicKey,
        committee: Committee,
        max_block_size: usize,
        signature_service: SignatureService,
        rx_mempool: Receiver<Hash>,
        rx_message: Receiver<ProposerMessage>,
        tx_proposer_core: Sender<ProposalMessage>,
        network: &NetWorkManagerAsync,
        proposerack_receiver: NetworkEventReceiver,
    ) {
        let waiting_block_list = Arc::new(Mutex::new(HashMap::new()));
        crate::network::spawn_proposeblockack_message_receiver(
            proposerack_receiver,
            ProposeBlockAckReceiverHandler {
                name,
                committee,
                waiting_block_list: waiting_block_list.clone(),
            },
        );

        let networksender = ConsensusMessageSender::new(network);
        tokio::spawn(async move {
            Self {
                max_block_size,
                name,
                networksender,
                proposable: VecDeque::new(),
                proposal_request: None,
                proposed: HashMap::new(),
                rx_mempool,
                rx_message,
                signature_service,
                tx_proposer_core,
                waiting_block_list,
            }
            .run()
            .await;
        });
    }

    fn get_payload(&mut self) -> Vec<Hash> {
        if self.proposable.len() < self.max_block_size {
            self.proposable.drain(..).collect()
        } else {
            self.proposable.drain(0..self.max_block_size).collect()
        }
    }

    async fn send_proposal(&mut self, proposal: ProposalMessage) {
        let proposal_digest = proposal.digest();
        log::trace!("send_proposal Proposing {proposal_digest}");

        // Control system: Wait for 2f+1 nodes to acknowledge our block before continuing.
        let notify = Arc::new(Notify::new());
        let wait = notify.clone();
        {
            self.waiting_block_list
                .lock()
                .await
                .insert(proposal_digest, (0, notify));
        } //release self.waiting_block_list.lock()

        self.networksender
            .broadcast_others_consensus_message(ConsensusMessage::Propose(proposal))
            .await;

        wait.notified().await;
    }

    async fn propose(
        &mut self,
        round: Round,
        justification: Justification,
        parent: Hash,
        maybe_qc_prime: Option<QC>,
    ) {
        // Generate a new Proposal.
        let payload = self.get_payload();
        log::debug!(
            "proposer propose add batch list:{:?}",
            payload
                .iter()
                .map(|b| format!("{}/", b))
                .collect::<Vec<String>>()
        );

        let (mut qc, tc) = justification.get_qc_tc();
        if let Some(qc_prime) = maybe_qc_prime.clone() {
            // qc_prime will be greater than tc.max_qc if we were locked on a higher
            // QC at the time of making this proposal request.
            qc = qc_prime;
        }

        let block = Block::new(
            self.name,
            parent,
            payload,
            round,
            qc,
            tc,
            &mut self.signature_service,
        )
        .await;
        log::debug!("propose Created {}", block.digest());

        let proposal = Proposal::new(block, justification).await;
        let message: ProposalMessage;

        if let Some(qc_prime) = maybe_qc_prime {
            // Fallback Recovery
            let fr_proposal = FallbackRecoveryProposal::new(proposal, qc_prime);
            message = ProposalMessage::FallbackRecovery(fr_proposal);
        } else {
            message = ProposalMessage::Normal(proposal);
        }

        // Send the Proposal to the core for local processing.
        self.tx_proposer_core
            .send(message.clone())
            .await
            .expect("Failed to send block");

        self.send_proposal(message).await;
    }

    async fn run(&mut self) {
        loop {
            // Check if we can propose a new block.
            let have_payload = !self.proposable.is_empty();

            let send_proposal = if let Some((
                _round,
                _justification,
                _parent,
                _maybe_qc_prime,
                empty_block_status,
            )) = &self.proposal_request
            {
                // Have new batches to propose.
                have_payload
                    // At least one of our last committed block, our currently locked block or
                    // the last block that we voted for has a non-empty payload.
                    || !(empty_block_status.committed
                            && empty_block_status.locked
                            && empty_block_status.voted)
            } else {
                false
            };

            if send_proposal {
                // Make a new block.
                if let Some((round, justification, parent, maybe_qc_prime, _empty_block_status)) =
                    self.proposal_request.take()
                {
                    self.propose(round, justification, parent, maybe_qc_prime)
                        .await;
                }
            }

            tokio::select! {
                Some(digest) = self.rx_mempool.recv() => {
                    log::trace!("Proposer RECEIVE FROM MEMPOOL.");

                    let is_proposable = self.proposed.values()
                        .map(|payload| payload.contains(&digest))
                        .all(|x| x == false);

                    if is_proposable && ! self.proposable.contains(&digest) {
                        // Add the batch to the back of the queue.
                        self.proposable.push_back(digest);
                    }
                    // else: Someone else has already proposed this batch.
                    // or the Mempool sent it to us more than once.
                },
                 Some(message) = self.rx_message.recv() => match message {
                    ProposerMessage::Make(round, justification, parent, maybe_qc_prime, empty_block_status) => {
                        log::trace!("Proposer {} LOOP RECEIVE a proposal.", self.name);
                        self.proposal_request = Some((round, justification, parent, maybe_qc_prime, empty_block_status));
                    },
                    ProposerMessage::Cleanup(payloads, last_commit) => {
                        // Rounds of blocks that were committed.
                        let mut committed_rounds : Vec<Round> = payloads.keys()
                            .cloned()
                            .collect();
                        // Sort in ascending order so that we capture older rounds first.
                        committed_rounds.sort();

                        // Batches contained in blocks that will never be committed due to being
                        // either equivocal or superseded by a block for the same height and a
                        // higher round. Ordered from oldest to newest.
                        let mut failed_batches = Vec::new();

                        for round in committed_rounds {
                            let payload = payloads.get(&round)
                                .expect("Fatal: get failed for valid key.");

                            if payload.is_empty() {
                                continue;
                            }

                            // We committed these payloads so we must have received the related blocks
                            // and so should already have moved all included batches from 'proposable'
                            // to 'proposed'.
                            let expected_payload = self.proposed.remove(&round)
                                .expect("Committed unexpected payload.");

                            let payload_set : HashSet<_> = payload.iter().collect();
                            let expected_payload_set : HashSet<_> = expected_payload
                                .iter()
                                .collect();

                            // Note: The following invariants that should be helpful when debugging
                            // and regression testing. They do not need to be active in production.
                            //
                            // The only time when payload != expected_payload should be when we
                            // received multiple (equivocal) blocks for the same round, and in
                            // this case payload \subset expected_payload should be true.
                            assert!(payload_set.is_subset(&expected_payload_set));
                            // Ensure none of the blocks contained in the committed payload are
                            // still scheduled for proposal.
                            assert!(
                                payload.iter()
                                    .map(|batch_id| self.proposable.contains(batch_id))
                                    .all(|x| x == false)
                            );

                            // Select the batches that were contained in equivocal blocks that
                            // failed to become committed. This selection does not preserve the
                            // order of the original batch/es.
                            expected_payload_set
                                .difference(&payload_set)
                                .for_each(|failed_batch|
                                    failed_batches.push(**failed_batch)
                                );
                            // Drop the remainder; i.e. the committed payload.
                        }

                        // Rounds of blocks that failed to become committed.
                        let mut failed_rounds = Vec::new();
                        // Set of all batch ids that are still undergoing consensus.
                        let mut pending = HashSet::new();

                        for round in self.proposed.keys().cloned() {
                            if round < last_commit {
                                // Successful rounds have been removed so only failed remain.
                                failed_rounds.push(round);
                            } else {
                                // round > last_commit since last_commit has been removed.
                                self.proposed.get(&round)
                                    .expect("Fatal: get failed for valid key.")
                                    .iter()
                                    .for_each(|batch_id| {
                                        pending.insert(batch_id.clone()); return
                                    });
                            }
                        }

                        // Sort in ascending order so that we capture older rounds first.
                        failed_rounds.sort();

                        // Select the batches contained in the blocks of failed rounds.
                        for round in failed_rounds {
                            let failed_payload = self.proposed.remove(&round)
                                .expect("Fatal: get failed for valid key.");

                            if ! failed_payload.is_empty() {
                                for batch_id in failed_payload {
                                    failed_batches.push(batch_id);
                                }
                            }
                        }

                        // Order the candidates for rescheduling from (approximately) oldest to
                        // newest to ensure that we prepend the oldest batches to the queue last.
                        failed_batches.reverse();

                        // Insert all failed batches back into the front of the queue.
                        for batch_id in failed_batches {
                            // Ensure that we only reschedule unique digests that are not already
                            // undergoing consensus.
                            if ! self.proposable.contains(&batch_id)
                                && ! pending.contains(&batch_id)
                            {
                                self.proposable.push_front(batch_id);
                            }
                        }
                    },
                    ProposerMessage::Observed(mut payload, round) => {
                        if ! payload.is_empty() {
                            // Ensure that we do not try to re-propose these batches while they
                            // are undergoing consensus.
                            self.proposable.retain(|batch_id| ! payload.contains(batch_id));
                            // Ensure we keep track of these batches until they either are committed
                            // or become available for re-proposal.
                            self.proposed.entry(round)
                                .and_modify(
                                    |equivocal_payload| {
                                        // Should only ever receive one block per round so should only
                                        // store one payload per round.
                                        warn!("Detected equivocal proposal for round {round}");
                                        // Add the batches in the newly received equivocal payload
                                        // into the set of batches proposed for this round. Only a
                                        // subset of these batches will succeed. We will re-schedule
                                        // those that do not for proposal when a block for this round
                                        // or greater gets committed.
                                        equivocal_payload.append(payload.as_mut());
                                    }
                                ).or_insert(payload);
                        }
                    }
                },
            }
        }
    }
}
