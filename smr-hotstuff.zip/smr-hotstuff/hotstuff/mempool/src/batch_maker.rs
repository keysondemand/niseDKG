use crate::quorum_waiter::QuorumWaiterMessage;
use sha3::{Digest as Sha3Digest, Keccak256};
use socrypto::Digest;
use socrypto::Hash;
use socrypto::PublicKey;
use sosmr::SmrTransactionProtocol;
use sosmr::{SmrBatch, SmrTransaction};
use std::collections::HashMap;
use tokio::sync::mpsc::{Receiver, Sender};
use tokio::time::{sleep, Duration, Instant};

// #[cfg(test)]
// #[path = "tests/batch_maker_tests.rs"]
// pub mod batch_maker_tests;

//pub type Transaction = Vec<u8>;
//pub type Batch = Vec<SmrTransaction>;

/// Assemble clients transactions into batches.
pub struct BatchMaker {
    node_pub_key: PublicKey,
    /// The preferred batch size (in bytes).
    batch_size: usize,
    /// The maximum delay after which to seal the batch (in ms).
    max_batch_delay: u64,
    /// Channel to receive transactions from the network.
    rx_transaction: Receiver<SmrTransaction>,
    /// Output channel to deliver sealed batches to the `QuorumWaiter`.
    tx_message: Sender<QuorumWaiterMessage>,
    /// The network addresses of the other mempools.
    // mempool_addresses: Vec<(PublicKey, SocketAddr)>,
    /// Holds the current batches. Only one type of tx can be found in a batch.
    current_batches: HashMap<SmrTransactionProtocol, SmrBatch>, //SmrBatch,
}

impl BatchMaker {
    pub fn spawn(
        node_pub_key: PublicKey,
        batch_size: usize,
        max_batch_delay: u64,
        rx_transaction: Receiver<SmrTransaction>,
        tx_message: Sender<QuorumWaiterMessage>,
        //mempool_addresses: Vec<(PublicKey, SocketAddr)>,
    ) {
        tokio::spawn(async move {
            Self {
                node_pub_key,
                batch_size,
                max_batch_delay,
                rx_transaction,
                tx_message,
                //  mempool_addresses,
                current_batches: HashMap::new(),
                //SmrBatch::with_capacity(batch_size / 100), //estimation of Size in nb tx
            }
            .run()
            .await;
        });
    }

    /// Main loop receiving incoming transactions and creating batches.
    async fn run(&mut self) {
        log::trace!(
            "Batch maker self.max_batch_delay:{} self.batch_size:{}",
            self.max_batch_delay,
            self.batch_size
        );
        let timer = sleep(Duration::from_millis(self.max_batch_delay));
        tokio::pin!(timer);

        loop {
            tokio::select! {
                // Assemble client transactions into batches of preset size.
                msg = self.rx_transaction.recv() => {

                    match msg {
                        Some(mut transaction) => {
                            log::trace!("batch_maker run current_batches.len:{} new tx:{}"
                                , self.current_batches.len()
                                , transaction.signature
                            );
                            let protocol = transaction.protocol;
                            let batch_len = match self.current_batches.entry(protocol) {
                                std::collections::hash_map::Entry::Occupied(mut entry) => {
                                    let batch = entry.get_mut();
                                    if !batch.contains_tx_signature(&transaction) {
                                        //build smr tx unique id
                                        let smr_id = Self::get_tx_smr_id(self.node_pub_key, &transaction);
                                        transaction.update_smr_id(smr_id);
                                        batch.push_tx(transaction);
                                    }
                                    batch.len()
                                }
                                std::collections::hash_map::Entry::Vacant(entry) => {
                                        let smr_id = Self::get_tx_smr_id(self.node_pub_key, &transaction);
                                        transaction.update_smr_id(smr_id);
                                    let batch =
                                        //self.batch_size / 100 use the define the default batch Tx vec capacity.
                                        entry.insert(SmrBatch::with_capacity(self.batch_size / 100, transaction));
                                    batch.len()
                                }
                            };
                            if batch_len >= self.batch_size {
                                log::debug!("Batch size:{batch_len} > max batch_size");
                                let toseal_batch = self.current_batches.remove(&protocol).unwrap(); //unwrap tested before.
                                BatchMaker::seal(&mut self.tx_message, toseal_batch).await;
                                //if all batch has been processed reset the timer.
                                if self.current_batches.is_empty() {
                                    timer
                                        .as_mut()
                                        .reset(Instant::now() + Duration::from_millis(self.max_batch_delay));
                                }
                            }
                        }

                        None  => {
                            log::error!("Batch maker Tx channel closed");
                            break;
                        }
                    }
                },

                // If the timer triggers, seal the batch even if it contains few transactions.
                () = &mut timer => {
                    if !self.current_batches.is_empty() {
                        for (_,batch) in self.current_batches.drain() {
                            log::debug!("Batch timer fire");
                            BatchMaker::seal(&mut self.tx_message, batch).await;
                        }

                    }
                    timer.as_mut().reset(Instant::now() + Duration::from_millis(self.max_batch_delay));
                }
            }

            // Give the change to schedule other tasks.
            tokio::task::yield_now().await;
        }
    }

    fn get_tx_smr_id(node_pub_key: PublicKey, transaction: &SmrTransaction) -> Hash {
        let mut id_hasher = Keccak256::new();
        id_hasher.update(transaction.get_signature().flatten());
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or(std::time::Duration::new(0, 0))
            .as_nanos();
        id_hasher.update(now.to_be_bytes());
        id_hasher.update(node_pub_key);
        let arr = <[u8; 32]>::from(id_hasher.finalize());
        Hash::new(arr)
    }

    /// Seal and broadcast the current batch.
    async fn seal(tx_message: &mut Sender<QuorumWaiterMessage>, batch: SmrBatch) {
        // Serialize the batch.
        let digest = batch.digest();
        log::debug!("seal batch {digest} with nb tx:{}", batch.get_nb_tx());

        // Send the batch through the deliver channel for further processing.
        tx_message
            .send(QuorumWaiterMessage { batch, digest })
            .await
            .expect("Failed to deliver batch");
    }
}
