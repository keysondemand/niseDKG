use crate::config::{Committee, Stake};
use async_trait::async_trait;
use peer::HotStuffMessage;
use peer::PeerMessageHandler;
use socrypto::Hash;
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerInfo;
use sosmr::SmrBatch;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::Mutex;
//use network::CancelHandler;
use crate::mempool::MempoolMessage;
use crate::network::MempoolMessageSender;
use bytes::Bytes;
use tokio::sync::mpsc::{Receiver, Sender};

// #[cfg(test)]
// #[path = "tests/quorum_waiter_tests.rs"]
// pub mod quorum_waiter_tests;

#[derive(Debug)]
pub struct QuorumWaiterMessage {
    /// A serialized `MempoolMessage::Batch` message.
    pub batch: SmrBatch,
    pub digest: Hash,
    // The cancel handlers to receive the acknowledgements of our broadcast.
    //pub handlers: Vec<(PublicKey, CancelHandler)>,
}

//manage quorum QuorumWaiterMessage Ack.
#[derive(Clone)]
struct QuorumwaiterReceiverHandler {
    /// The committee information.
    committee: Committee,
    /// Channel to deliver batches for which we have enough acknowledgements.
    tx_batch: Sender<SmrBatch>,
    #[allow(clippy::type_complexity)]
    waiting_batch_list: Arc<Mutex<HashMap<Hash, (Stake, SmrBatch)>>>,
}

#[async_trait]
impl PeerMessageHandler for QuorumwaiterReceiverHandler {
    async fn dispatch(&mut self, _peer_info: PeerInfo, message: HotStuffMessage) {
        if let HotStuffMessage::QuotumWaiterMessage(digest, stake) = message {
            let mut waiting_batch_list = self.waiting_batch_list.lock().await;
            if let Some((total_stake, _)) = waiting_batch_list.get_mut(&Hash(digest)) {
                *total_stake += stake;
                if *total_stake >= self.committee.quorum_threshold() {
                    let (_, batch) = waiting_batch_list.remove(&Hash(digest)).unwrap();
                    self.tx_batch
                        .send(batch)
                        .await
                        .expect("Failed to deliver batch");
                }
            }
        }
    }
}

/// The QuorumWaiter waits for 2f authorities to acknowledge reception of a batch.
pub struct QuorumWaiter {
    /// The stake of this authority.
    //    stake: Stake,
    /// Input Channel to receive commands.
    rx_message: Receiver<QuorumWaiterMessage>,
    ///current batch waiting corrum
    #[allow(clippy::type_complexity)]
    waiting_batch_list: Arc<Mutex<HashMap<Hash, (Stake, SmrBatch)>>>,
    /// A network sender to broadcast the batches to the other mempools.
    networksender: MempoolMessageSender,
}

impl QuorumWaiter {
    /// Spawn a new QuorumWaiter.
    pub fn spawn(
        committee: Committee,
        //stake: Stake,
        rx_message: Receiver<QuorumWaiterMessage>,
        tx_batch: Sender<SmrBatch>,
        network_receiver: NetworkEventReceiver,
        network: &NetWorkManagerAsync,
    ) {
        let networksender = MempoolMessageSender::new(network);
        let waiting_batch_list = Arc::new(Mutex::new(HashMap::new()));
        crate::network::spawn_quorumwaiter_message_receiver(
            network_receiver,
            QuorumwaiterReceiverHandler {
                committee,
                tx_batch,
                waiting_batch_list: waiting_batch_list.clone(),
            },
        );

        tokio::spawn(async move {
            Self {
                //                stake,
                rx_message,
                waiting_batch_list,
                networksender,
            }
            .run()
            .await;
        });
    }

    /// Main loop.
    async fn run(&mut self) {
        while let Some(QuorumWaiterMessage { batch, digest }) = self.rx_message.recv().await {
            {
                log::debug!(
                    "Mempool quorum_waiter waiting_batch_list.len:{} send for digest:{}",
                    self.waiting_batch_list.lock().await.len(),
                    digest,
                );
            }

            {
                self.waiting_batch_list
                    .lock()
                    .await
                    .insert(digest, (1, batch.clone()));
            } //release self.waiting_batch_list.lock()

            //broadcast batch for vote.
            let message = MempoolMessage::Batch(batch);
            let serialized = message.into_bytes();
            let bytes = Bytes::from(serialized);
            self.networksender.broadcast_mempool_message(bytes).await;
        }
    }
}
