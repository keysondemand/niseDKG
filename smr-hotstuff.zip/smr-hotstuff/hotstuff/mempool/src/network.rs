use bytes::Bytes;
use peer::{HotStuffMessage, PeerMessageHandler};
use rand::prelude::SliceRandom as _;
use rand::rngs::SmallRng;
use rand::SeedableRng as _;
use sop2p::PeerInfo;
use sop2p::{NetWorkManagerAsync, NetworkEventReceiver, PeerCommand};

pub struct MempoolMessageSender {
    cmd_sender: sop2p::NetworkCommandSender,
}

impl MempoolMessageSender {
    pub fn new(network: &NetWorkManagerAsync) -> MempoolMessageSender {
        MempoolMessageSender {
            cmd_sender: network.get_command_sender(),
        }
    }

    pub async fn broadcast_mempool_message(&self, mem_message: Bytes) {
        let bytes =
            sop2p::serialize::serialize(peer::HotStuffMessage::create_from_mempool(mem_message));
        self.cmd_sender
            .send_command(PeerCommand::SendMessage(bytes))
            .await;
    }

    pub async fn send_mempool_message_to_peer(&self, peer: PeerInfo, mem_message: Bytes) {
        peer::send_message_to_peer(
            &self.cmd_sender,
            peer,
            peer::HotStuffMessage::create_from_mempool(mem_message),
        )
        .await;
    }

    /// Pick a few addresses at random (specified by `nodes`) and try (best-effort) to send the
    /// message only to them. This is useful to pick nodes with whom to sync.
    pub async fn lucky_broadcast(
        &mut self,
        mut addresses: Vec<PeerInfo>,
        data: Bytes,
        nodes: usize,
    ) {
        let mut rng = SmallRng::from_entropy();
        addresses.shuffle(&mut rng);
        addresses.truncate(nodes);
        peer::send_message_to_some_peers(
            &self.cmd_sender,
            addresses,
            peer::HotStuffMessage::create_from_mempool(data),
        )
        .await
    }
}

#[derive(Clone)]
pub struct QuorumWaiterSender {
    cmd_sender: sop2p::NetworkCommandSender,
}
impl QuorumWaiterSender {
    pub fn new(network: &NetWorkManagerAsync) -> QuorumWaiterSender {
        QuorumWaiterSender {
            cmd_sender: network.get_command_sender(),
        }
    }

    pub async fn send_quorumwaiter_message(
        &self,
        peer_info: PeerInfo,
        digest: [u8; 32],
        stake: u32,
    ) {
        let bytes = sop2p::serialize::serialize(peer::HotStuffMessage::create_from_quotumwaiter(
            digest, stake,
        ));
        self.cmd_sender
            .send_command(PeerCommand::SendMessageTo(peer_info, bytes))
            .await;
    }
}

pub fn spawn_mempool_message_receiver<Handler: PeerMessageHandler>(
    network_receiver: NetworkEventReceiver,
    handler: Handler,
) {
    peer::spawn_peer_message_receiver(
        "Mempool".to_string(),
        network_receiver,
        handler,
        mempool_filter_message,
    );
}

fn mempool_filter_message(message: &HotStuffMessage) -> bool {
    message.is_mempool_message()
}

pub fn spawn_quorumwaiter_message_receiver<Handler: PeerMessageHandler>(
    network_receiver: NetworkEventReceiver,
    handler: Handler,
) {
    peer::spawn_peer_message_receiver(
        "quorumwaiter".to_string(),
        network_receiver,
        handler,
        quorumwaiter_filter_message,
    );
}

fn quorumwaiter_filter_message(message: &HotStuffMessage) -> bool {
    message.is_quorumwaiter_message()
}
