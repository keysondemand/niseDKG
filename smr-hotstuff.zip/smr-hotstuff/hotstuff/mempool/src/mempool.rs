use crate::batch_maker::BatchMaker;
use crate::config::Stake;
use crate::config::{Committee, Parameters};
use crate::helper::Helper;
use crate::network::QuorumWaiterSender;
use crate::processor::Processor;
use crate::quorum_waiter::QuorumWaiter;
use crate::synchronizer::Synchronizer;
use async_trait::async_trait;
use log::{info, warn};
use peer::{HotStuffMessage, PeerMessageHandler};
use serde::{Deserialize, Serialize};
use socrypto::Digest;
use socrypto::HASH_LENGTH;
use socrypto::PUBLIC_KEY_LENGTH;
use socrypto::{Hash, PublicKey};
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerInfo;
use sosmr::SmrError;
use sosmr::{SmrBatch, SmrTransaction};
use store::Store;
use tokio::sync::mpsc::{channel, Receiver, Sender};

// #[cfg(test)]
// #[path = "tests/mempool_tests.rs"]
// pub mod mempool_tests;

/// The default channel capacity for each channel of the mempool.
pub const CHANNEL_CAPACITY: usize = 1_000;

/// The consensus round number.
pub type Round = u64;

/// The message exchanged between the nodes' mempool.
#[derive(Debug)] //, Serialize, Deserialize
pub enum MempoolMessage {
    Batch(SmrBatch),
    BatchRequest(Vec<Hash>, /* origin */ PublicKey),
}

impl MempoolMessage {
    pub fn into_bytes(self) -> Vec<u8> {
        match self {
            MempoolMessage::Batch(batch) => {
                let bytes = batch.into_bytes();
                let mut res = Vec::with_capacity(1 + bytes.len());
                res.push(0);
                res.extend(bytes);
                res
            }
            MempoolMessage::BatchRequest(hash_list, pubkey) => {
                let mut bytes =
                    Vec::with_capacity(1 + hash_list.len() * HASH_LENGTH + PUBLIC_KEY_LENGTH);
                bytes.push(1);
                bytes.extend(pubkey.0);
                for hash in hash_list {
                    bytes.extend(hash.0);
                }
                bytes
            }
        }
    }
}

impl TryFrom<Vec<u8>> for MempoolMessage {
    type Error = String;

    fn try_from(vec: Vec<u8>) -> Result<Self, Self::Error> {
        let bytes = &vec[..];
        MempoolMessage::try_from(bytes)
    }
}

impl TryFrom<&[u8]> for MempoolMessage {
    type Error = String;

    fn try_from(bytes: &[u8]) -> Result<Self, Self::Error> {
        if bytes.len() < 1 {
            return Err("MempoolMessage try_from slice empty".to_string());
        }
        match bytes[0] {
            0 => {
                let batch = SmrBatch::try_from(bytes[1..].to_vec())
                    .map_err(|err| format!("could not extract array from slice: {:?}", err))?;
                Ok(MempoolMessage::Batch(batch))
            }
            1 => {
                if bytes.len() < 1 + PUBLIC_KEY_LENGTH {
                    return Err(
                        "MempoolMessage could not extract PUBLIC_KEY_LENGTH slice too small"
                            .to_string(),
                    );
                }
                let pubkey = PublicKey::try_from(&bytes[1..1 + PUBLIC_KEY_LENGTH])
                    .map_err(|err| format!("could not extract pubkey from slice: {:?}", err))?;
                let mut start = 1;
                let mut hash_list = vec![];
                while start < bytes.len() {
                    if bytes.len() < start + HASH_LENGTH {
                        return Err(
                            "MempoolMessage could not extract HASH slice too small".to_string()
                        );
                    }
                    let hb: [u8; HASH_LENGTH] = bytes[start..start + HASH_LENGTH]
                        .try_into()
                        .map_err(|err| format!("could not extract hash from slice: {:?}", err))?;
                    hash_list.push(Hash::new(hb));
                    start += HASH_LENGTH;
                }
                Ok(MempoolMessage::BatchRequest(hash_list, pubkey))
            }
            _ => Err("MempoolMessage can't deserialize, unknown header".to_string()),
        }
    }
}

/// The messages sent by the consensus and the mempool.
#[derive(Debug, Serialize, Deserialize)]
pub enum ConsensusMempoolMessage {
    /// The consensus notifies the mempool that it need to sync the target missing batches.
    Synchronize(Vec<Hash>, /* target */ PublicKey),
    /// The consensus notifies the mempool of a round update.
    Cleanup(Round),
}

pub struct Mempool {
    /// The public key of this authority.
    name: PublicKey,
    /// The committee information.
    committee: Committee,
    /// The configuration parameters.
    parameters: Parameters,
    /// The persistent storage.
    store: Store,
    /// Send messages to consensus.
    tx_consensus: Sender<Hash>,
}

impl Mempool {
    #[allow(clippy::too_many_arguments)]
    pub fn spawn(
        name: PublicKey,
        committee: Committee,
        parameters: Parameters,
        store: Store,
        ledger: execution::LedgerAccess,
        rx_consensus: Receiver<ConsensusMempoolMessage>,
        tx_consensus: Sender<Hash>,
        network: &NetWorkManagerAsync,
        mempool_receiver: NetworkEventReceiver,
        quorumwaiter_receiver: NetworkEventReceiver,
    ) -> Sender<SmrTransaction> {
        // NOTE: This log entry is used to compute performance.
        parameters.log();

        // Define a mempool instance.
        let mempool = Self {
            name,
            committee,
            parameters,
            store,
            tx_consensus,
        };

        // Spawn all mempool tasks.
        mempool.handle_consensus_messages(rx_consensus, network);
        let tx_sender = mempool.handle_clients_transactions(name, network, quorumwaiter_receiver);
        mempool.handle_mempool_messages(network, name, mempool_receiver, ledger);

        info!(
            "Mempool successfully booted on {}",
            mempool
                .committee
                .mempool_peer(&mempool.name)
                .expect("Our public key is not in the committee")
        );
        tx_sender
    }

    /// Spawn all tasks responsible to handle messages from the consensus.
    fn handle_consensus_messages(
        &self,
        rx_consensus: Receiver<ConsensusMempoolMessage>,
        network: &NetWorkManagerAsync,
    ) {
        // The `Synchronizer` is responsible to keep the mempool in sync with the others. It handles the commands
        // it receives from the consensus (which are mainly notifications that we are out of sync).
        Synchronizer::spawn(
            self.name,
            self.committee.clone(),
            self.store.clone(),
            self.parameters.gc_depth,
            self.parameters.sync_retry_delay,
            self.parameters.sync_retry_nodes,
            /* rx_message */ rx_consensus,
            network,
        );
    }

    /// Spawn all tasks responsible to handle clients transactions.
    fn handle_clients_transactions(
        &self,
        node_pub_key: PublicKey,
        network: &NetWorkManagerAsync,
        network_receiver: NetworkEventReceiver,
    ) -> Sender<SmrTransaction> {
        let (tx_transaction, rx_transaction) = channel(CHANNEL_CAPACITY);
        let (tx_quorum_waiter, rx_quorum_waiter) = channel(CHANNEL_CAPACITY);
        let (tx_batch, rx_batch) = channel(CHANNEL_CAPACITY);

        // // We first receive clients' transactions from the network.
        // transactions_address.set_ip("0.0.0.0".parse().unwrap());
        // info!("Open RPC TX port to:{}", transactions_address);
        // //Start Tx RPC interface
        // RpcReceiver::spawn(
        //     transactions_address,
        //     /* handler */ TxReceiverHandler { tx_batch_maker },
        // );

        // The transactions are sent to the `BatchMaker` that assembles them into batches. It then broadcasts
        // (in a reliable manner) the batches to all other mempools that share the same `id` as us. Finally,
        // it gathers the 'cancel handlers' of the messages and send them to the `QuorumWaiter`.
        BatchMaker::spawn(
            node_pub_key,
            self.parameters.batch_size,
            self.parameters.max_batch_delay,
            rx_transaction,
            /* tx_message */
            tx_quorum_waiter,
            /* mempool_addresses */
            //self.committee.broadcast_addresses(&self.name),
        );

        // The `QuorumWaiter` waits for 2f authorities to acknowledge reception of the batch. It then forwards
        // the batch to the `Processor`.
        QuorumWaiter::spawn(
            self.committee.clone(),
            //        /* stake */ self.committee.stake(&self.name),
            /* rx_message */
            rx_quorum_waiter,
            tx_batch,
            network_receiver,
            network,
        );

        // The `Processor` hashes and stores the batch. It then forwards the batch's digest to the consensus.
        Processor::spawn(self.store.clone(), rx_batch, self.tx_consensus.clone());
        tx_transaction
    }

    /// Spawn all tasks responsible to handle messages from other mempools.
    fn handle_mempool_messages(
        &self,
        network: &NetWorkManagerAsync,
        name: PublicKey,
        network_receiver: NetworkEventReceiver,
        ledger: execution::LedgerAccess,
    ) {
        let (tx_helper, rx_helper) = channel(CHANNEL_CAPACITY);
        let (tx_processor, rx_processor) = channel(CHANNEL_CAPACITY);

        // Receive incoming messages from other mempools.
        // let mut address = self
        //     .committee
        //     .mempool_address(&self.name)
        //     .expect("Our public key is not in the committee");
        // address.set_ip("0.0.0.0".parse().unwrap());
        // NetworkReceiver::spawn(
        //     address,
        //     /* handler */
        //     MempoolReceiverHandler {
        //         tx_helper,
        //         tx_processor,
        //     },
        // );

        let stake = self.committee.stake(&name);

        crate::network::spawn_mempool_message_receiver(
            network_receiver,
            MempoolReceiverHandler {
                tx_helper,
                tx_processor,
                stake,
                network_sender: QuorumWaiterSender::new(network),
                ledger,
            },
        );

        // The `Helper` is dedicated to reply to batch requests from other mempools.
        Helper::spawn(
            self.committee.clone(),
            self.store.clone(),
            /* rx_request */ rx_helper,
            network,
        );

        // This `Processor` hashes and stores the batches we receive from the other mempools. It then forwards the
        // batch's digest to the consensus.
        Processor::spawn(
            self.store.clone(),
            /* rx_batch */ rx_processor,
            /* tx_digest */ self.tx_consensus.clone(),
        );

        info!("Mempool listening to mempool messages");
    }
}

/// Defines how the network receiver handles incoming transactions.
// #[derive(Clone)]
// struct TxReceiverHandler {
//     tx_batch_maker: Sender<Transaction>,
// }

// #[async_trait]
// impl RpcMessageHandler for TxReceiverHandler {
//     async fn dispatch(
//         &self,
//         _writer: &mut RpcWriter,
//         message: Bytes,
//     ) -> Result<(), Box<dyn Error>> {
//         // Send the transaction to the batch maker.
//         self.tx_batch_maker
//             .send(message.to_vec())
//             .await
//             .expect("Failed to send transaction");

//         // Give the change to schedule other tasks.
//         tokio::task::yield_now().await;
//         Ok(())
//     }
// }

/// Defines how the network receiver handles incoming mempool messages.
#[derive(Clone)]
struct MempoolReceiverHandler {
    tx_helper: Sender<(Vec<Hash>, PublicKey)>,
    tx_processor: Sender<SmrBatch>,
    network_sender: crate::network::QuorumWaiterSender,
    stake: Stake,
    ledger: execution::LedgerAccess,
}

#[async_trait]
impl PeerMessageHandler for MempoolReceiverHandler {
    async fn dispatch(&mut self, peer_info: PeerInfo, message: HotStuffMessage) {
        // Reply with an ACK.
        //        let _ = writer.send(Bytes::from("Ack")).await;

        if let HotStuffMessage::MemPoolMessage(bytes) = message {
            // Deserialize and parse the message.
            match MempoolMessage::try_from(&bytes[..]) {
                Ok(MempoolMessage::Batch(batch)) => {
                    //verify batch
                    let (batch, verify_batch) = match self
                        .ledger
                        .get_stored_done_committee(batch.protocol.into())
                        .await
                        .map_err(|err| {
                            SmrError::GeneralError(format!("read_dkg_from store error:{}", err))
                        }) {
                        Ok(c) => tokio::task::spawn_blocking(move || {
                            let r = batch
                                .verify_batch(c.as_ref().and_then(|c| c.threshold_pubkey.as_ref()));
                            (batch, r)
                        })
                        .await
                        .unwrap(),
                        Err(err) => (batch, Err(err)),
                    };

                    if let Err(err) = verify_batch {
                        log::warn!(
                            "Mempool Error during received batch verification :{} . Skip batch.",
                            err
                        );
                        return;
                    }

                    //remove the first byte of MempoolMessage enum.

                    let digest = batch.digest();

                    self.tx_processor
                        .send(batch)
                        .await
                        .expect("Failed to send batch");

                    //Send acknowledgmenet back.
                    //For test add some timing when sending the batch to similate a network lattency.
                    // use tinyrand::{Rand, StdRand};
                    // let mut rand = StdRand::default();
                    // let num = rand.next_u64();
                    // if num % 11 == 0 {
                    //     return;
                    // }
                    // if num % 3 == 0 {
                    //     tokio::time::sleep(tokio::time::Duration::from_millis(1000)).await;
                    // }
                    //tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;

                    self.network_sender
                        .send_quorumwaiter_message(peer_info, digest.0, self.stake)
                        .await;
                }
                Ok(MempoolMessage::BatchRequest(missing, requestor)) => self
                    .tx_helper
                    .send((missing, requestor))
                    .await
                    .expect("Failed to send batch request"),
                Err(e) => warn!(
                    "Mempool receive a mempool massage Serialization error: {}",
                    e
                ),
            }
        }
    }
}
