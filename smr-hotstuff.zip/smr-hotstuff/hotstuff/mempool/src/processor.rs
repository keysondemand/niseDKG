use socrypto::Digest;
use socrypto::Hash;
use sosmr::SmrBatch;
use store::Store;
use tokio::sync::mpsc::{Receiver, Sender};

#[cfg(test)]
#[path = "tests/processor_tests.rs"]
pub mod processor_tests;

/// Indicates a serialized `MempoolMessage::Batch` message.
//pub type SerializedBatchMessage = Vec<u8>;

/// Hashes and stores batches, it then outputs the batch's digest.
pub struct Processor;

impl Processor {
    pub fn spawn(
        // The persistent storage.
        mut store: Store,
        // Input channel to receive batches.
        mut rx_batch: Receiver<SmrBatch>,
        // Output channel to send out batches' digests.
        tx_digest: Sender<Hash>,
    ) {
        tokio::spawn(async move {
            while let Some(batch) = rx_batch.recv().await {
                //TODO ADD send a batch receive Ack message to the sender.
                // Hash the batch.
                //let digest = Hash(Sha512::digest(&batch).as_slice()[..32].try_into().unwrap());
                let digest = batch.digest();

                // Store the batch.
                store.write(digest.0.to_vec(), batch.into_bytes()).await;

                tx_digest.send(digest).await.expect("Failed to send digest");
            }
        });
    }
}
