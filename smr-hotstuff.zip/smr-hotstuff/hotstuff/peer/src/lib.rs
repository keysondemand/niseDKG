use async_trait::async_trait;
use bytes::BufMut;
use bytes::Bytes;
use bytes::BytesMut;
use log::{error, info};
use socrypto::SecretKey;
use sop2p::serialize::extract_array;
use sop2p::serialize::is_buffer_large_enough;
use sop2p::NetworkEventReceiver;
use sop2p::PeerCommand;
use sop2p::PeerInfo;
use sop2p::{
    serialize::{FromBytes, IntoBytes},
    P2PError, PeerEvent,
};
use std::fmt;
use std::net::SocketAddr;

#[async_trait]
pub trait PeerMessageHandler: Send + Sync + 'static + Clone {
    async fn dispatch(&mut self, peer_info: PeerInfo, message: HotStuffMessage);
}

#[derive(Eq, PartialEq, Ord, PartialOrd, Clone, Debug)]
pub enum HotStuffMessage {
    MemPoolMessage(Bytes),
    ConsensusMessage(Bytes),
    //contain batch digest of quorum wait and the peer stacking vote.
    QuotumWaiterMessage([u8; 32], u32),
    //contain the block digest and the peer stacking vote.
    ProposeBlockAckMessage([u8; 32], u32),
    InternalDKGMessage(Bytes),
}

impl fmt::Display for HotStuffMessage {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let msg = match self {
            HotStuffMessage::MemPoolMessage(_) => "MemPoolMessage",
            HotStuffMessage::ConsensusMessage(_) => "ConsensusMessage",
            HotStuffMessage::QuotumWaiterMessage(_, _) => "QuotumWaiterMessage",
            HotStuffMessage::ProposeBlockAckMessage(_, _) => "ProposeBlockAckMessage",
            HotStuffMessage::InternalDKGMessage(_) => "InternalDKGMessage",
        };

        write!(f, "({})", msg)
    }
}

impl HotStuffMessage {
    pub fn create_from_mempool(bytes: Bytes) -> HotStuffMessage {
        HotStuffMessage::MemPoolMessage(bytes)
    }
    pub fn create_from_consensus(bytes: Bytes) -> HotStuffMessage {
        HotStuffMessage::ConsensusMessage(bytes)
    }
    pub fn create_from_quotumwaiter(digest: [u8; 32], stacking: u32) -> HotStuffMessage {
        HotStuffMessage::QuotumWaiterMessage(digest, stacking)
    }
    pub fn create_from_proposeblockack(digest: [u8; 32], stacking: u32) -> HotStuffMessage {
        HotStuffMessage::ProposeBlockAckMessage(digest, stacking)
    }

    pub fn is_mempool_message(&self) -> bool {
        matches!(self, HotStuffMessage::MemPoolMessage(_))
    }

    pub fn is_dkg_message(&self) -> bool {
        matches!(self, HotStuffMessage::InternalDKGMessage(_))
    }

    pub fn is_consensus_message(&self) -> bool {
        matches!(self, HotStuffMessage::ConsensusMessage(_))
    }

    pub fn is_quorumwaiter_message(&self) -> bool {
        matches!(self, HotStuffMessage::QuotumWaiterMessage(_, _))
    }

    pub fn is_proposeblockack_message(&self) -> bool {
        matches!(self, HotStuffMessage::ProposeBlockAckMessage(_, _))
    }
}

impl FromBytes for HotStuffMessage {
    fn from_bytes(buffer: &Bytes, mut start: usize) -> Result<(Self, usize), P2PError> {
        is_buffer_large_enough(buffer, start + 1 + 4)?;
        let header = buffer[start];
        start += 1;
        let len = u32::from_le_bytes(extract_array(&buffer[start..start + 4])?) as usize;
        is_buffer_large_enough(buffer, start + 4 + len)?;
        let bytes = &buffer[start + 4..start + 4 + len];
        let val = match header {
            1 => Ok(HotStuffMessage::MemPoolMessage(bytes.to_vec().into())),
            2 => {
                let stake = u32::from_le_bytes(extract_array(&bytes[..4])?);
                let digest: [u8; 32] = <[u8; 32]>::try_from(&bytes[4..]).map_err(|err| {
                    P2PError::DeserializeError(format!(
                        "error during QuotumWaiterMessage deserialisation :{err}"
                    ))
                })?;
                Ok(HotStuffMessage::QuotumWaiterMessage(digest, stake))
            }
            3 => Ok(HotStuffMessage::ConsensusMessage(bytes.to_vec().into())),
            4 => {
                let stake = u32::from_le_bytes(extract_array(&bytes[..4])?);
                let digest: [u8; 32] = <[u8; 32]>::try_from(&bytes[4..]).map_err(|err| {
                    P2PError::DeserializeError(format!(
                        "error during QuotumWaiterMessage deserialisation :{err}"
                    ))
                })?;
                Ok(HotStuffMessage::ProposeBlockAckMessage(digest, stake))
            }
            5 => Ok(HotStuffMessage::InternalDKGMessage(bytes.to_vec().into())),
            _ => Err(P2PError::DeserializeError(format!(
                "HotStuffMessage from_bytes error, unknown message type:{header}"
            ))),
        }?;
        Ok((val, 4 + 1 + len))
    }
}

impl IntoBytes for HotStuffMessage {
    fn into_bytes(self, buffer: &mut BytesMut) {
        let (header, bytes): (u8, _) = match self {
            HotStuffMessage::MemPoolMessage(bytes) => (1, bytes),
            HotStuffMessage::ConsensusMessage(bytes) => (3, bytes),
            HotStuffMessage::QuotumWaiterMessage(digest, st) => {
                let mut buff = vec![];
                buff.append(&mut st.to_le_bytes().to_vec());
                buff.append(&mut digest.to_vec());
                (2, buff.into())
            }
            HotStuffMessage::ProposeBlockAckMessage(digest, st) => {
                let mut buff = vec![];
                buff.append(&mut st.to_le_bytes().to_vec());
                buff.append(&mut digest.to_vec());
                (4, buff.into())
            }
            HotStuffMessage::InternalDKGMessage(bytes) => (5, bytes),
        };
        buffer.put_u8(header);

        let len_bytes = (bytes.len() as u32).to_le_bytes();
        buffer.extend(len_bytes);
        buffer.extend(&bytes);
    }

    fn bytes_len(&self) -> usize {
        (match self {
            HotStuffMessage::MemPoolMessage(bytes) => bytes.len(),
            HotStuffMessage::ConsensusMessage(bytes) => bytes.len(),
            HotStuffMessage::QuotumWaiterMessage(_, _) => 4 + 32,
            HotStuffMessage::ProposeBlockAckMessage(_, _) => 4 + 32,
            HotStuffMessage::InternalDKGMessage(_) => 4 + sodkg::BLS_SIGNATURE_LEN,
        }) + 4
            + 1
    }
}

pub async fn send_message_to_peer(
    cmd_sender: &sop2p::NetworkCommandSender,
    peer: PeerInfo,
    message: HotStuffMessage,
) {
    let bytes = sop2p::serialize::serialize(message);
    cmd_sender
        .send_command(PeerCommand::SendMessageTo(peer, bytes))
        .await;
}

pub async fn send_message_to_some_peers(
    cmd_sender: &sop2p::NetworkCommandSender,
    peers: Vec<PeerInfo>,
    message: HotStuffMessage,
) {
    let bytes = sop2p::serialize::serialize(message);
    cmd_sender
        .send_command(PeerCommand::SendMessageToSome(peers, bytes))
        .await;
}

pub async fn start_newtork(
    secret_key: SecretKey,
    bind_addr: SocketAddr,
    node_addr: SocketAddr,
    bootstrap: Option<SocketAddr>,
) -> sop2p::NetWorkManagerAsync {
    info!("Start  node bind: {bind_addr} pub addr:{node_addr}");
    sop2p::new_async(bind_addr, node_addr, secret_key, bootstrap)
        .await
        .unwrap()
}

pub fn spawn_peer_message_receiver<Handler: PeerMessageHandler, F>(
    name: String,
    mut network_receiver: NetworkEventReceiver,
    handler: Handler,
    filter: F,
) where
    F: Fn(&HotStuffMessage) -> bool + std::marker::Send + 'static,
{
    tokio::spawn(async move {
        loop {
            match network_receiver.recv().await {
                Ok(msg) => {
                    //log::info!("peer rev msg name:{name}");
                    match msg {
                        PeerEvent::NewPeerConnected(_) => (),
                        PeerEvent::MessageReceived(peerinfo, bytes) => {
                            match sop2p::serialize::deserialize::<HotStuffMessage>(&bytes) {
                                Ok(message) => {
                                    log::trace!(
                                        "p2p spawn_peer_message_receiver from:{} MessageReceived from:{} message:{message}",
                                        name,
                                        peerinfo.pubkey
                                    );
                                    if filter(&message) {
                                        log::trace!(
                                            "p2p spawn_peer_message_receiver dispatch from:{}",
                                            peerinfo.pubkey
                                        );
                                        let mut h = handler.clone();
                                        tokio::task::spawn(async move {
                                            h.dispatch(peerinfo, message).await;
                                        });
                                    }
                                }
                                Err(err) => {
                                    error!(
                                        "Error during HotStuffMessage message deserialization :{err}"
                                    );
                                }
                            }
                        }
                        PeerEvent::PeerConnectionError(addr) => {
                            log::warn!("Error in p2p connection for peer:{}", addr)
                        }
                        PeerEvent::PeerUnreachable(addr) => {
                            log::warn!("Error in p2p peer unreachable:{}", addr)
                        }
                    }
                }
                Err(err) => {
                    println!("Main Node error during receiving message:{:?}", err);
                    break;
                }
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hotstuff_message_serialization() {
        let bytes = 24_i32.to_le_bytes();
        let message = HotStuffMessage::MemPoolMessage(bytes.to_vec().into());
        let ser = sop2p::serialize::serialize(message.clone());
        let de: HotStuffMessage = sop2p::serialize::deserialize(&ser).unwrap();
        assert_eq!(message, de);
    }
}
