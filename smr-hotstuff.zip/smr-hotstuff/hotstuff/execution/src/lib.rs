use crate::error::ExecutionError;
use smrcommon::config::SmrCommitteeConfig;
use smrcommon::SmrDkgCommittee;
use smrcommon::SmrDkgCommitteeName;
use smrcommon::{PublishTxPayload, SmrTransactionSubtype};
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::BlsPublicKey;
use sodkg::BLS_PUBKEY_LEN;
use sosmr::Round;
use sosmr::SmrBatch;
use sosmr::{
    SmrBlock, SmrDkgType, SmrTransaction, SmrTransactionProtocol, TxExecutionStatus,
    SMR_TRANSACTION_DKGTYPE_LENGTH,
};
use std::collections::HashSet;
use store::Store;
use tokio::sync::mpsc::Sender;

pub mod error;
mod ledger;

pub use ledger::{Ledger, LedgerAccess};

pub async fn execute_block(
    block: &SmrBlock,
    store: &mut Store,
    ledger: &mut ledger::Ledger,
    committee_config: &SmrCommitteeConfig,
    tx_sender: &Sender<SmrTransaction>,
    secret_key: &SecretKey,
    end_dkg_notifications: &mut HashSet<PublicKey>,
) {
    if !block.payload.is_empty() {
        //        log::info!("Committed {:?}", block);
        //execute block before commit.
        for (_, key) in &block.payload {
            let bytes = match store.read(key.to_vec()).await {
                Ok(Some(bytes)) => bytes,
                Ok(None) => {
                    log::warn!("Tx exec block:{} batch not found in store", block.round);
                    continue;
                }
                Err(err) => {
                    log::warn!(
                        "Tx exec block:{} error during extract block from store. err:{}",
                        block.round,
                        err
                    );
                    continue;
                }
            };

            let mut batch = match SmrBatch::try_from(bytes) {
                Ok(batch) => batch,
                Err(err) => {
                    log::warn!(
                        "Tx exec block:{} error during deserialization block from store. err:{}",
                        block.round,
                        err
                    );
                    continue;
                }
            };

            batch.clear_tx_execution();

            let mut exec_tx_result: Vec<TxExecutionStatus> = Vec::with_capacity(batch.get_nb_tx());
            for (_, tx) in batch.iter_tx() {
                let exec = match execute_tx(
                    tx,
                    block.round,
                    ledger,
                    committee_config,
                    tx_sender,
                    secret_key,
                    end_dkg_notifications,
                )
                .await
                {
                    Ok(status) => status,
                    Err(err) => {
                        log::warn!(
                            "Tx exec block:{} error during preprocess_tx err:{}",
                            block.round,
                            err
                        );
                        TxExecutionStatus::Fail
                    }
                };
                log::trace!("tx exec result:{}", exec);
                exec_tx_result.push(exec);
            }
            //do it in 2 time cause of the borrow checker
            exec_tx_result
                .into_iter()
                .for_each(|st| batch.push_tx_status(st));
            //save modified with exec result batch
            let bytes = batch.into_bytes();
            store.write(key.to_vec(), bytes).await;
        }
    }
}

pub async fn execute_tx(
    tx: &SmrTransaction,
    round: Round,
    ledger: &mut ledger::Ledger,
    committee_config: &SmrCommitteeConfig,
    tx_sender: &Sender<SmrTransaction>,
    secret_key: &SecretKey,
    end_dkg_notifications: &mut HashSet<PublicKey>,
) -> Result<TxExecutionStatus, ExecutionError> {
    log::info!(
        "execute_tx protocol:{:?}, tx.tx_sub_type{} sender:{} sign:{}",
        tx.protocol,
        tx.tx_sub_type,
        tx.sender,
        tx.signature
    );

    if ledger.is_tx_already_executed(tx) {
        log::warn!(
            "Tx:{} re execution  in round:{}, smr id:{}",
            tx.signature,
            round,
            tx.smr_id
        );
        return Ok(TxExecutionStatus::Invalid);
    }

    match tx.protocol {
        SmrTransactionProtocol::Smr => {
            match tx.tx_sub_type {
                //SmrTransactionSubtype::AskPublish
                1 => {
                    log::info!("AskPublish before tx payload dkg_type :{:?}", tx.payload);
                    if tx.payload.len() < SMR_TRANSACTION_DKGTYPE_LENGTH {
                        return Err(ExecutionError::TxExecutionError(format!(
                            "Error during Smr Tx AskPublish Tx payload to small:{}",
                            tx.payload.len()
                        )));
                    }
                    let bytes: [u8; SMR_TRANSACTION_DKGTYPE_LENGTH] = tx.payload
                        [..SMR_TRANSACTION_DKGTYPE_LENGTH]
                        .try_into()
                        .map_err(|err| {
                            ExecutionError::TxExecutionError(format!(
                                "Error during Smr Tx AskPublish payload into byte convertion:{}",
                                err
                            ))
                        })?;

                    let dkg_type = SmrDkgType::try_from(&bytes).map_err(|err| {
                        ExecutionError::TxExecutionError(format!(
                            "Error during Smr Tx AskPublish from byte convertion:{}",
                            err
                        ))
                    })?;

                    log::info!("AskPublish before smrcommittee_name");
                    let mut smrcommittee_name = SmrDkgCommitteeName::new(dkg_type);
                    //TODO manage running DKG (done=false) and done DKG.
                    let current_committee_opt =
                        read_committee_from_store(&smrcommittee_name, committee_config, ledger)
                            .await?;
                    log::info!("AskPublish committee read from store");
                    smrcommittee_name.done = true;
                    let done_committee_opt =
                        read_committee_from_store(&smrcommittee_name, committee_config, ledger)
                            .await?;

                    let committee = done_committee_opt.or(current_committee_opt).unwrap(); //unwrap ok because current_committee_opt always some.

                    //Send publish Tx with committee
                    let publish_tx_payload = PublishTxPayload {
                        sender: tx.sender,
                        committee_name: dkg_type,
                        committee,
                    };
                    let payload_bytes = publish_tx_payload.to_bytes();
                    let publish_tx = SmrTransaction::sign(
                        secret_key,
                        SmrTransactionSubtype::Publish.into(),
                        SmrTransactionProtocol::Smr,
                        payload_bytes,
                    )
                    .map_err(|err| {
                        ExecutionError::TxExecutionError(format!(
                            "Error during publish_tx sign:{}",
                            err
                        ))
                    })?;
                    log::info!("AskPublish publish tx signed");

                    match tx_sender.send(publish_tx).await {
                        Ok(_) => Ok(TxExecutionStatus::Success),
                        Err(err) => Err(ExecutionError::TxExecutionError(format!(
                            "Error during Smr Tx AskPublish to send Tx:{}",
                            err
                        ))),
                    }
                }
                //SmrTransactionSubtype::Publish
                2 => Ok(TxExecutionStatus::Success),
                _ => {
                    log::warn!(
                        "execute_tx SMR Tx, Unknown Tx subtype:{:?}.",
                        tx.tx_sub_type
                    );
                    Ok(TxExecutionStatus::Invalid)
                }
            }
        }
        SmrTransactionProtocol::Dkg(dkg_type) => {
            match tx.tx_sub_type {
                1 => {
                    //DkgTransactionSubtype::InitDkg
                    log::debug!("LOOK HERE DkgTransactionSubtype::InitDkg for dkg:{dkg_type:?} from node:{}", tx.sender);
                    let committee_name = SmrDkgCommitteeName::new(dkg_type);
                    //get the DKG committee config
                    let mut committee =
                        read_committee_from_store(&committee_name, committee_config, ledger)
                            .await?
                            .unwrap(); //created during read_committee_from_store
                    if committee.committee.contains_key(&tx.sender) {
                        //verify the node is inside committee config
                        if committee_config
                            .get_committee_config(committee_name.name)
                            .and_then(|committee| {
                                committee
                                    .is_node_belong_to_committee(tx.sender)
                                    .then_some(())
                            })
                            .is_none()
                        {
                            log::trace!(
                                "execute_tx DKG InitDkg node:{} not in committee_name:{committee_name:?} for DKG definition {:?}",
                                tx.sender,
                                committee_config
                            );
                            return Ok(TxExecutionStatus::Invalid);
                        }

                        let node = committee.committee.get_mut(&tx.sender).unwrap(); //unwrap tested before
                        node.init_dkg_payload = tx.payload.to_vec();

                        let value = committee.to_bytes();

                        log::trace!("execute_tx DKG InitDkg from node:{} Done", tx.sender);
                        let key = committee_name.to_bytes();
                        ledger.write(key, value).await?;

                        Ok(TxExecutionStatus::Success)
                    } else {
                        log::warn!("DkgTransactionSubtype::InitDkg sender not in the committee");
                        Ok(TxExecutionStatus::Invalid)
                    }
                }
                2 => {
                    //DkgTransactionSubtype::Dealing
                    log::debug!("LOOK HERE DkgTransactionSubtype::Dealing for dkg:{dkg_type:?} from node:{}", tx.sender);
                    let committee_name = SmrDkgCommitteeName::new(dkg_type);
                    let mut committee =
                        read_committee_from_store(&committee_name, committee_config, ledger)
                            .await?
                            .ok_or_else(|| {
                                ExecutionError::TxExecutionError(format!(
                                    "Error Committee for name:{:?} not created in Dkg dealing Tx",
                                    committee_name
                                ))
                            })?;
                    //define dealing order
                    let nb_dealing: u8 = committee
                        .committee
                        .values()
                        .filter(|c| c.dealing_order != 0)
                        .count() as u8;
                    if let Some(node) = committee.committee.get_mut(&tx.sender) {
                        if node.dealing_payload.is_none() {
                            node.dealing_order = nb_dealing + 1;
                            node.dealing_payload = Some(tx.payload.to_vec());
                            log::trace!(
                                "execute_tx DKG Dealing from node:{} dealing_order:{} Done",
                                tx.sender,
                                node.dealing_order,
                            );
                            let key = committee_name.to_bytes();
                            let value = committee.to_bytes();
                            ledger.write(key, value).await?;
                            Ok(TxExecutionStatus::Success)
                        } else {
                            Ok(TxExecutionStatus::Invalid)
                        }
                    } else {
                        Ok(TxExecutionStatus::Invalid)
                    }
                }
                3 => {
                    //DkgTransactionSubtype::PublicShare
                    log::debug!("LOOK HERE DkgTransactionSubtype::PublicShare for dkg :{dkg_type:?} from node:{}", tx.sender);
                    let committee_name = SmrDkgCommitteeName::new(dkg_type);
                    let mut committee =
                        read_committee_from_store(&committee_name, committee_config, ledger)
                            .await?
                            .ok_or_else(|| {
                                ExecutionError::TxExecutionError(format!(
                                "Error Committee for name:{:?} not created in Dkg PublicShare Tx",
                                committee_name
                            ))
                            })?;
                    if let Some(node) = committee.committee.get_mut(&tx.sender) {
                        if node.public_share_payload.is_empty() {
                            node.public_share_payload = tx.payload.to_vec();
                            log::trace!("execute_tx DKG from node:{} PublicShare Done", tx.sender);
                            let key = committee_name.to_bytes();
                            let value = committee.to_bytes();
                            ledger.write(key, value).await?;
                            Ok(TxExecutionStatus::Success)
                        } else {
                            Ok(TxExecutionStatus::Invalid)
                        }
                    } else {
                        Ok(TxExecutionStatus::Invalid)
                    }
                }
                4 => {
                    //DkgTransactionSubtype::ThresholdSignature
                    let committee_name = SmrDkgCommitteeName::new(dkg_type);
                    let mut committee =
                        read_committee_from_store(&committee_name, committee_config, ledger).await?.ok_or_else(|| {
                            ExecutionError::TxExecutionError(format!(
                                "Error Committee for name:{:?} not created in Dkg ThresholdSignature Tx",
                                committee_name
                            ))
                        })?;
                    //DKG end already done
                    if !committee.is_started() {
                        log::trace!(
                            "execute_tx DKG from node:{} ThresholdSignature End dkg done. Do nothing",
                            tx.sender
                        );
                        return Ok(TxExecutionStatus::Success);
                    }
                    if let Some(node) = committee.committee.get_mut(&tx.sender) {
                        let bls_pubkey = BlsPublicKey::try_from(&tx.payload[..BLS_PUBKEY_LEN])
                            .map_err(|err| {
                                ExecutionError::TxExecutionError(format!(
                                    "Error during  DKG ThresholdSignature deserialization err:{}",
                                    err
                                ))
                            })?;

                        if node.publish_committee_pubkey.is_none() {
                            //save committee pubkey to get f+1 to validate that f=1 node generate the same.
                            node.publish_committee_pubkey = Some(bls_pubkey);
                            node.threshold_sign_payload = tx.payload.to_vec();

                            log::info!(
                                "execute_tx DKG new ThresholdSignature of node:{}",
                                tx.sender
                            );

                            let config = committee_config
                                .get_committee_config(committee_name.name)
                                .ok_or_else(|| {
                                    ExecutionError::TxExecutionError(format!(
                                        "Error no committee config found for name:{:?}",
                                        committee_name.name
                                    ))
                                })?;
                            //update committe pub key with f+1.
                            if let Some(thpubkey) =
                                committee.has_enougth_committee_publickey(config.threshold_f)
                            {
                                let enddkg_tx = sodkg::transaction::create_enddkg_tx(
                                    secret_key,
                                    committee_name.name,
                                    &thpubkey,
                                )
                                .map_err(|err| {
                                    ExecutionError::TxExecutionError(format!(
                                        "Error fail during dkg done tx sign:{:?}",
                                        err
                                    ))
                                })?;

                                committee.threshold_pubkey = Some(thpubkey);

                                if let Err(err) = tx_sender.send(enddkg_tx).await {
                                    log::error!("Error during send End Dkg Tx to mempool :{}", err);
                                    return Ok(TxExecutionStatus::Fail);
                                }
                                //save finished dkg has finished.
                                committee.smrkey.done = true;

                                //Empty the current one for restart DKG.
                                let members = config
                                    .member_list
                                    .iter()
                                    .map(|c| (c.id, c.elgamal_pubkey.clone()))
                                    .collect();
                                let current_commitee =
                                    SmrDkgCommittee::new(committee_name, members);
                                let key = committee_name.to_bytes();
                                let value = current_commitee.to_bytes();
                                ledger.write(key, value).await?;

                                log::info!(
                                    "execute_tx EndDKG from node:{} DKG done and save committee:{:?} length:{}",
                                    tx.sender,
                                    committee.smrkey,
                                    committee.committee.len(),
                                );
                            }
                            let key = committee.smrkey.to_bytes();
                            let value = committee.to_bytes();
                            ledger.write(key, value).await?;
                            Ok(TxExecutionStatus::Success)
                        } else {
                            log::warn!(
                                "execute_tx DKG ThresholdSignature node:{} TxExecutionStatus::Invalid",
                                tx.sender
                            );
                            Ok(TxExecutionStatus::Invalid)
                        }
                    } else {
                        Ok(TxExecutionStatus::Invalid)
                    }
                }
                5 => {
                    //DkgTransactionSubtype::EndDkg
                    log::info!("execute_tx DKG EndDkg Tx at round:{}", round);
                    if dkg_type == SmrDkgType::Smr {
                        log::info!(
                            "execute_tx DKG EndDkg end_dkg_notifications.len():{}",
                            end_dkg_notifications.len()
                        );
                        end_dkg_notifications.insert(tx.sender);
                    }
                    Ok(TxExecutionStatus::Success)
                }
                6 => {
                    //DkgTransactionSubtype::PartialSign
                    let committee_name = SmrDkgCommitteeName::new(dkg_type);
                    let mut committee =
                        read_committee_from_store(&committee_name, committee_config, ledger)
                            .await?
                            .ok_or_else(|| {
                                ExecutionError::TxExecutionError(format!(
                                "Error Committee for name:{:?} not created in Dkg partial_sign_payload Tx",
                                committee_name
                            ))
                            })?;
                    if let Some(node) = committee.committee.get_mut(&tx.sender) {
                        if node.partial_sign_payload.is_empty() {
                            node.partial_sign_payload = tx.payload.to_vec();
                            let key = committee_name.to_bytes();
                            let value = committee.to_bytes();
                            ledger.write(key, value).await?;
                            Ok(TxExecutionStatus::Success)
                        } else {
                            Ok(TxExecutionStatus::Invalid)
                        }
                    } else {
                        Ok(TxExecutionStatus::Invalid)
                    }
                }
                7 => {
                    //DkgTransactionSubtype::ReloadEndDkg
                    log::info!("execute_tx DKG ReloadEndDkg Tx at round:{}", round);
                    if dkg_type == SmrDkgType::Smr {
                        end_dkg_notifications.insert(tx.sender);
                    }
                    Ok(TxExecutionStatus::Success)
                }
                _ => {
                    log::warn!(
                        "execute_tx DKG Tx, Unknown Tx subtype:{:?}.",
                        tx.tx_sub_type
                    );
                    Ok(TxExecutionStatus::Invalid)
                }
            }
        }
        _ => Ok(TxExecutionStatus::Success),
    }
}

async fn read_committee_from_store(
    committee_name: &SmrDkgCommitteeName,
    committee_config: &SmrCommitteeConfig,
    ledger: &mut ledger::Ledger,
) -> Result<Option<SmrDkgCommittee>, ExecutionError> {
    let config = committee_config
        .committee_list
        .iter()
        .find(|c| c.name == committee_name.name)
        .ok_or_else(|| {
            ExecutionError::TxExecutionError(format!(
                "Error Committee for name:{:?} not define in the configuration definition",
                committee_name
            ))
        })?;
    let key = committee_name.to_bytes();
    match ledger.read(key.to_vec()).await {
        Ok(Some(bytes)) => SmrDkgCommittee::try_from(&bytes[..])
            .map(Some)
            .map_err(|err| {
                ExecutionError::TxExecutionError(format!(
                    "Error during store committee deserialization err:{}",
                    err
                ))
            }),
        Ok(None) => {
            //if new dkg started create the default one with configuration
            if !committee_name.done {
                //create teh comitte with all defined nodes in the config.
                let members = config
                    .member_list
                    .iter()
                    .map(|c| (c.id, c.elgamal_pubkey.clone()))
                    .collect();
                let committee = SmrDkgCommittee::new(*committee_name, members);

                Ok(Some(committee))
            } else {
                Ok(None)
            }
        }
        Err(err) => {
            log::warn!(
                "ExecutionAction::UpdateCommittee dkg committee deserialization error:{}",
                err
            );
            Err(ExecutionError::TxExecutionError(format!(
                "Error during store committee read err:{}",
                err
            )))
        }
    }
}

#[cfg(test)]
mod tests {
    // Note this useful idiom: importing names from outer (for mod tests) scope.
    use super::*;
    use smrcommon::SmrDkgCommitteeNode;
    use socrypto::PublicKey;
    use socrypto::SecretKey;
    use sodkg::ElGamalPrivateKey;
    use sodkg::ElGamalPubKey;
    use std::collections::HashMap;

    const TEST_BLS_PUBKEY: &str = "02154550ef9cc852fbd7181af509afc40b88162cdc51eb260e746c5e1998d582951108f51ab16d96a11a7aa17f8de67202020667d9e76da97f2be2eee19efb8e46f5b9edc6bad43da5416dcb808364b14ebdb6a1f56a93c3ea174fbe442a055c1e95088cd47e8942fbc25bcce257115d5308424dc3d138738e96a09702877c5d8c73e97ed89b83ca15d64336553a26cb18f0022b75b38b3bb115b672d11db1dca8c802b6b779dd02d211551b55d0947d0e3d44020b4b1bb636dc0eb7917364a2d40f5053e90ffc519cfb16fc3217c5f429bfe5eb1e5ec1d21ee547085943cce8d7faec0eaf10c7cfe909d224aaef12753cb6932e";

    #[test]
    fn test_smr_dkg_committee_node_serialization() {
        let (mut node, node2) = get_nodes();

        let bytes = node.to_bytes();
        let new_node = SmrDkgCommitteeNode::try_from(&bytes[..]).unwrap();
        let new_bytes = new_node.to_bytes();
        assert_eq!(bytes, new_bytes);

        let public_share =
            BlsPublicKey::try_from(&hex::decode(TEST_BLS_PUBKEY).unwrap()[..]).unwrap();
        node.pushish_committee_pubkey = Some(public_share);
        let bytes = node.to_bytes();
        let new_node = SmrDkgCommitteeNode::try_from(&bytes[..]).unwrap();
        let new_bytes = new_node.to_bytes();
        assert_eq!(bytes, new_bytes);

        let bytes = node2.to_bytes();
        let new_node = SmrDkgCommitteeNode::try_from(&bytes[..]).unwrap();
        let new_bytes = new_node.to_bytes();
        assert_eq!(bytes, new_bytes);
    }

    #[test]
    fn test_smr_dkg_committee_serialization() {
        let name = SmrDkgCommitteeName {
            name: SmrDkgType::Vrf,
            done: false,
        }; //OracleCommittee(123)

        let bytes = name.to_bytes();
        let new_name = SmrDkgCommitteeName::try_from(&bytes[..]).unwrap();
        let new_bytes = new_name.to_bytes();
        assert_eq!(bytes, new_bytes);

        let (node, node2) = get_nodes();

        //empty
        let mut committee = SmrDkgCommittee {
            smrkey: name,
            threshold_pubkey: None,
            committee: HashMap::new(),
        };
        asset_committee(&committee);

        let public_share =
            BlsPublicKey::try_from(&hex::decode(TEST_BLS_PUBKEY).unwrap()[..]).unwrap();
        committee.threshold_pubkey = Some(public_share);
        asset_committee(&committee);

        committee.committee.insert(node.identity, node.clone());
        asset_committee(&committee);
        committee.committee.clear();
        committee.committee.insert(node2.identity, node2.clone());
        asset_committee(&committee);
        committee.committee.insert(node.identity, node.clone());
        //Do hand comparision because node insert is not deterministic. THe order can change in the HshMap
        let bytes = committee.to_bytes();
        let mut new_committee = SmrDkgCommittee::try_from(&bytes[..]).unwrap();
        assert!(new_committee.committee.len() == 2);
        let new_node = new_committee.committee.remove(&node.identity).unwrap();
        assert_eq!(node.to_bytes(), new_node.to_bytes());
        let new_node2 = new_committee.committee.remove(&node2.identity).unwrap();
        assert_eq!(node2.to_bytes(), new_node2.to_bytes());
        assert!(new_committee.committee.len() == 0);
        assert_eq!(
            committee
                .threshold_pubkey
                .as_ref()
                .map(|pk| pk.into_bytes()),
            new_committee
                .threshold_pubkey
                .as_ref()
                .map(|pk| pk.into_bytes())
        );

        assert_eq!(committee.smrkey, new_committee.smrkey);
    }

    fn get_nodes() -> (SmrDkgCommitteeNode, SmrDkgCommitteeNode) {
        let secret_key1 = SecretKey::generate();
        let pubkey1 = PublicKey::try_from(&secret_key1).unwrap();
        let elgamal_key1 = ElGamalPrivateKey::generate();
        let elgamal_pubkey1 = ElGamalPubKey::try_from(&elgamal_key1).unwrap();

        let node = SmrDkgCommitteeNode {
            identity: pubkey1,
            elgamal_publickey: elgamal_pubkey1,
            init_dkg_payload: vec![],
            public_share_payload: vec![],
            dealing_payload: None,
            publish_committee_pubkey: None,
            threshold_sign_payload: vec![],
            dealing_order: 18,
        };
        let secret_key2 = SecretKey::generate();
        let pubkey2 = PublicKey::try_from(&secret_key2).unwrap();
        let elgamal_key2 = ElGamalPrivateKey::generate();
        let elgamal_pubkey2 = ElGamalPubKey::try_from(&elgamal_key2).unwrap();
        let public_share =
            BlsPublicKey::try_from(&hex::decode(TEST_BLS_PUBKEY).unwrap()[..]).unwrap();
        let node2 = SmrDkgCommitteeNode {
            identity: pubkey2,
            elgamal_publickey: elgamal_pubkey2,
            init_dkg_payload: [1, 2, 3, 4, 5].to_vec(),
            public_share_payload: [8, 9, 10, 11, 15, 12].to_vec(),
            dealing_payload: Some([13, 14, 15, 16, 17, 18, 19].to_vec()),
            publish_committee_pubkey: Some(public_share),
            threshold_sign_payload: vec![],
            dealing_order: 18,
        };
        (node, node2)
    }

    fn asset_committee(committee: &SmrDkgCommittee) {
        println!("first committee{:?}", committee);
        let bytes = committee.to_bytes();
        let new_committee = SmrDkgCommittee::try_from(&bytes[..]).unwrap();
        println!("new_committee{:?}", new_committee);
        let new_bytes = new_committee.to_bytes();
        assert_eq!(bytes, new_bytes);
    }
}
