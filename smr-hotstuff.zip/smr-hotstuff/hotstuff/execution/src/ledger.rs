use crate::ExecutionError;
use lru::LruCache;
use persy::ByteVec;
use persy::PersyId;
use persy::ValueMode;
use persy::{Config, Persy};
use smrcommon::SmrDkgCommittee;
use smrcommon::SmrDkgCommitteeName;
use socrypto::Hash;
use sosmr::SmrDkgType;
use sosmr::SmrTransaction;
use std::num::NonZeroUsize;
use std::path::Path;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering;
use std::time::Duration;

pub type LedgerKey = Vec<u8>;
pub type LedgerValue = Vec<u8>;

//0 write occurs
//1 see one time
//2 see 2 time without write, do the backup
//more see same write and backup done
static DETECT_UPDATE: AtomicUsize = AtomicUsize::new(3); //no backup at start.

const PERSY_DB_LEDGER_SEGMENT: &str = "ledger";
const PERSY_DB_LEDGER_INDEX: &str = "ledger_index";
const LEDGER_DB_BACKUP_TIMEOUT: u64 = 30000;

#[derive(Clone)]
pub struct LedgerAccess {
    db: persy::Persy,
}

impl LedgerAccess {
    pub async fn read(&mut self, key: LedgerKey) -> Result<Option<LedgerValue>, ExecutionError> {
        read_from_db(&mut self.db, key).await
    }

    pub async fn get_stored_done_committee(
        &mut self,
        dkg_type: SmrDkgType,
    ) -> Result<Option<SmrDkgCommittee>, ExecutionError> {
        get_stored_done_committee_from_db(&mut self.db, dkg_type).await
    }
}

//#[derive(Clone)]
pub struct Ledger {
    db: persy::Persy,
    tx_cache: LruCache<Hash, bool>,
}

impl Ledger {
    pub fn get_ledger_access(&self) -> LedgerAccess {
        LedgerAccess {
            db: self.db.clone(),
        }
    }

    pub fn is_tx_already_executed(&mut self, tx: &SmrTransaction) -> bool {
        match self.tx_cache.get(&tx.smr_id) {
            Some(_) => true,
            None => {
                self.tx_cache.put(tx.smr_id, true);
                false
            }
        }
    }

    pub fn new(path: &str) -> Result<Self, ExecutionError> {
        let tx_cache = LruCache::new(NonZeroUsize::new(2000).unwrap());

        let str_db_path: String = format!("{}.persy", path);
        let db_path = Path::new(&str_db_path);
        let db = if !db_path.exists() {
            Persy::create(db_path).map_err(|e| e.persy_error())?;
            let mut db_config = Config::new();
            db_config.change_cache_size(32 * 1024 * 1024);
            db_config.change_cache_age_limit(Duration::from_secs(60 * 60 * 24)); //one hour
            let persy = Persy::open(db_path, db_config).map_err(|e| e.persy_error())?;
            let mut tx = persy.begin().map_err(|e| e.persy_error())?;
            tx.create_segment(PERSY_DB_LEDGER_SEGMENT)
                .map_err(|e| e.persy_error())?;
            tx.create_index::<ByteVec, PersyId>(PERSY_DB_LEDGER_INDEX, ValueMode::Replace)
                .map_err(|e| e.persy_error())?;
            tx.commit().map_err(|e| e.persy_error())?;
            persy
        } else {
            Persy::open(db_path, Config::new()).map_err(|e| e.persy_error())?
        };

        //start backup thread.
        let backup_db = db.clone();
        tokio::task::spawn(async move {
            let mut updatedb_timer =
                tokio::time::interval(tokio::time::Duration::from_millis(LEDGER_DB_BACKUP_TIMEOUT));
            //first tick do nothing.
            updatedb_timer.tick().await;
            loop {
                updatedb_timer.tick().await;
                //get last state and set to false.
                let update_done = DETECT_UPDATE
                    .fetch_update(Ordering::Acquire, Ordering::Relaxed, |x| Some(x + 1))
                    .unwrap_or(5);
                log::trace!("db backup timer with:{}", update_done);
                //if the ledger has been updated since last time create an new backup.
                if update_done == 2 {
                    match backup_db.snapshot() {
                        Ok(snapshot) => {
                            if let Err(err) = backup(snapshot).await {
                                log::error!("Error during ledger backup:{}", err);
                            }
                        }
                        Err(err) => {
                            log::error!("Error during db snapshot creation :{}", err);
                        }
                    }
                }
            }
        });

        Ok(Ledger { db, tx_cache })
    }

    pub async fn write(
        &mut self,
        key: LedgerKey,
        value: LedgerValue,
    ) -> Result<(), ExecutionError> {
        let write_persy = self.db.clone();
        DETECT_UPDATE.store(0, Ordering::Relaxed);
        tokio::task::spawn_blocking(move || {
            write_persy
                .begin()
                .map_err(|e| e.persy_error())
                .and_then(|mut tx| {
                    let id = tx
                        .insert(PERSY_DB_LEDGER_SEGMENT, &value)
                        .map_err(|e| e.persy_error())?;
                    Ok((tx, id))
                })
                .and_then(|(mut tx, id)| {
                    tx.put::<ByteVec, PersyId>(
                        PERSY_DB_LEDGER_INDEX,
                        ByteVec::new(key.to_vec()),
                        id,
                    )
                    .map_err(|e| e.persy_error())?;
                    Ok(tx)
                })
                .and_then(|tx| tx.prepare().map_err(|e| e.persy_error()))
                .and_then(|prepare| prepare.commit().map_err(|e| e.persy_error()))
        })
        .await
        .unwrap()?;
        Ok(())
    }

    pub async fn read(&mut self, key: LedgerKey) -> Result<Option<LedgerValue>, ExecutionError> {
        read_from_db(&mut self.db, key).await
    }

    pub async fn get_stored_done_committee(
        &mut self,
        dkg_type: SmrDkgType,
    ) -> Result<Option<SmrDkgCommittee>, ExecutionError> {
        get_stored_done_committee_from_db(&mut self.db, dkg_type).await
    }
}

async fn get_stored_done_committee_from_db(
    db: &mut Persy,
    dkg_type: SmrDkgType,
) -> Result<Option<SmrDkgCommittee>, ExecutionError> {
    let mut smrcommittee_name = SmrDkgCommitteeName::new(dkg_type);
    smrcommittee_name.done = true;
    let key = smrcommittee_name.to_bytes();
    let dkg = read_from_db(db, key.to_vec())
        .await?
        .map(|bytes| SmrDkgCommittee::try_from(&bytes[..]))
        .transpose()?;
    Ok(dkg)
}

async fn read_from_db(
    db: &mut Persy,
    key: LedgerKey,
) -> Result<Option<LedgerValue>, ExecutionError> {
    let read_persy = db.clone();
    let value = tokio::task::spawn_blocking(move || {
        read_persy
            .get::<ByteVec, PersyId>(PERSY_DB_LEDGER_INDEX, &ByteVec::new(key))
            .map_err(|e| e.persy_error())
            .and_then(|mut read_id| {
                read_id
                    .next()
                    .and_then(|id| {
                        read_persy
                            .read(PERSY_DB_LEDGER_SEGMENT, &id)
                            .map_err(|e| e.persy_error())
                            .transpose()
                    })
                    .transpose()
            })
    })
    .await
    .unwrap()?;
    Ok(value)
}

async fn backup(snapshot: persy::Snapshot) -> Result<(), ExecutionError> {
    tokio::task::spawn_blocking(move || {
        log::info!("Backuping the ledger db in ledger_backup.persy file");
        let str_db_path = "ledger_backup.tmp.persy";
        let db_path = Path::new(&str_db_path);
        if db_path.exists() {
            if let Err(err) = std::fs::remove_file(db_path) {
                log::error!("Error during removing old ledger backup:{}", err);
            }
        }

        Persy::create(db_path).map_err(|e| e.persy_error())?;
        let backup_persy = Persy::open(db_path, Config::new()).map_err(|e| e.persy_error())?;

        let export_iter = persy_expimp::export_from_snapshot(&snapshot).map_err(|err| {
            ExecutionError::LedgerBackupError(format!("Error during ledger db export:{:?}", err))
        })?;
        persy_expimp::import(&backup_persy, export_iter).map_err(|err| {
            ExecutionError::LedgerBackupError(format!(
                "Error during ledger db backup import:{:?}",
                err
            ))
        })?;

        std::fs::remove_file("ledger_backup.persy").unwrap_or(());
        if let Err(err) = std::fs::rename(str_db_path, "ledger_backup.persy") {
            log::warn!("Error during ledger db backup file rename:{}", err);
        }

        Ok(())
    })
    .await
    .unwrap()
}
