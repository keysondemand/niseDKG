use thiserror::Error;

#[derive(Error, Debug)]
pub enum ExecutionError {
    #[error("Execution general error: {0}")]
    GeneralError(#[from] std::io::Error),

    #[error("Error during Tx execution {0}")]
    TxExecutionError(String),

    #[error("Error during vote signature aggregation {0}")]
    VoteThresholdSignError(String),

    #[error("Error ledger storage {0}")]
    LedgerStorageError(#[from] persy::PersyError),

    #[error("Error value serialization error {0}")]
    ValueSerializationError(#[from] sosmr::SmrError),

    #[error("Error ledger backup storage {0}")]
    LedgerBackupError(String),
}
