use async_trait::async_trait;
use futures::stream::FuturesOrdered;
use futures::stream::FuturesUnordered;
use smrcommon::SmrDkgCommittee;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::config::DkgConfig;
use sodkg::errors::DkgError;
use sodkg::state::DkgEvent;
use sodkg::state::DkgEventData;
use sodkg::state::DkgEventType;
use sodkg::ElGamalPrivateKey;
use sodkg::ElGamalPubKey;
use soruntime::state::Action;
use soruntime::state::Event;
use soruntime::state::EventProcessor;
use sosmr::DkgCommittee;
use sosmr::SmrBatch;
use sosmr::SmrBlock;
use sosmr::SmrDkgType;
use sosmr::SmrTransaction;
use sosmr::SmrTransactionProtocol;
use sosmr::TxExecutionStatus;
use std::fs::OpenOptions;
use tokio::sync::mpsc;
use tokio::task::JoinHandle;
use tokio_stream::StreamExt;

const SMR_DKG_STORE_FILE_NAME: &str = "smr_dkg_data.json";

#[async_trait]
pub trait SendNewDkgCommittee {
    async fn send_committee(&self, committee: DkgCommittee) -> Result<(), String>;
}

pub struct DKGRunner;

impl DKGRunner {
    #[allow(clippy::too_many_arguments)]
    pub fn spawn(
        node_priv_key: SecretKey,
        node_elgamal_secret_key: ElGamalPrivateKey,
        dkg_config: DkgConfig,
        tx_sender: mpsc::Sender<SmrTransaction>,
        block_receiver: mpsc::Receiver<SmrBlock>,
        store: store::Store,
        committee: Option<SmrDkgCommittee>,
        tx_consensus: impl SendNewDkgCommittee + Sync + Send + 'static,
        dkg_members: Vec<(PublicKey, ElGamalPubKey)>,
    ) -> JoinHandle<()> {
        tokio::spawn(async move {
            Self.run(
                node_priv_key,
                node_elgamal_secret_key,
                dkg_config,
                tx_sender,
                block_receiver,
                store,
                committee,
                tx_consensus,
                dkg_members,
            )
            .await;
        })
    }

    /// Main loop responsible to accept incoming connections .
    #[allow(clippy::too_many_arguments)]
    async fn run(
        &self,
        node_priv_key: SecretKey,
        node_elgamal_secret_key: ElGamalPrivateKey,
        dkg_config: DkgConfig,
        tx_sender: mpsc::Sender<SmrTransaction>,
        mut block_receiver: mpsc::Receiver<SmrBlock>,
        mut store: store::Store,
        committee: Option<SmrDkgCommittee>,
        tx_consensus: impl SendNewDkgCommittee,
        dkg_members: Vec<(PublicKey, ElGamalPubKey)>,
    ) {
        let node_public_key = PublicKey::try_from(&node_priv_key).unwrap(); //should not panic other the node should stop.
        let mut event_process_futures = FuturesOrdered::new();
        let mut action_exec_futures = FuturesUnordered::new();

        //DKG committee generated after the DKG
        //let mut dkg_committee: std::option::Option<DkgCommittee> = None;

        //Get SRM DKG status
        let (mut event_processor, dkg_actions) = bootstrap_dkg(
            committee,
            &node_priv_key,
            &node_elgamal_secret_key,
            dkg_config,
            dkg_members,
        )
        .await
        .expect("Erreor during DKG init. Node can't bootstrap");

        //        log::info!("Bootstrap dkg actions:{:?}", dkg_actions.len());

        if !dkg_actions.is_empty() {
            dkg_actions.into_iter().for_each(|action| {
                action_exec_futures.push(futures::future::ready(action));
            });
        }

        log::info!("Start SMR DKG loop");

        //start loop
        loop {
            tokio::select! {
                //SMR Tx processing
                Some(block) = block_receiver.recv() => {
                    //log::trace!("receive block round:{}",block.round);
                    let block_round = block.round;
                    match iterate_block_tx_for_protocol(&block, SmrTransactionProtocol::Dkg(SmrDkgType::Smr), &mut store).await {
                        Ok(tx_iter) => {
                            for tx  in tx_iter.filter_map(|(status, tx)| {
                                (status == TxExecutionStatus::Success).then_some(tx)
                            }) {
                                log::trace!("Run_loop:{} Proceed received tx for round:{} type:{:?}", node_public_key, block_round, tx.tx_sub_type,);
                                match sodkg::transaction::convert_received_smrtx_to_event(&tx, block_round) {
                                    Ok(event) => {
                                        event_process_futures.push_back(futures::future::ready(event))
                                    },
                                    Err(err) => log::warn!("Error during smr tx conversion in event:{err}"),
                                };

                            }                        }
                        Err(err) => log::warn!("Error during batch tx read:{err}"),
                    }

                }
                //process receive event future
                Some(event) = event_process_futures.next() => {
                    log::trace!("Run_loop:{} Proceed event:{}", node_public_key, event.event_type());
                    let actions = event_processor.process_event(Box::new(event));
                    if !actions.is_empty() {
                        actions.into_iter().for_each(|action| {
                            action_exec_futures.push(futures::future::ready(action));
                        });
                    }

                }
                //execute action future
                Some(action) = action_exec_futures.next() => {
                    log::trace!("Run_loop:{} Proceed action", node_public_key);
                    log::trace!("DKG Run_loop Proceed action");
                    if let Action::SendEventOut(event) = action {
                        let event_data = event.data();
                        if let sodkg::state::DkgEventData::Committee(dkgdata) = event_data {
                            if let Err(err) = tx_consensus.send_committee(dkgdata.clone()).await {
                                log::error!("DKG  SMR EndDkg Tx, fail to send new committee data error:{} .", err);
                            }
                            log::info!("SMR run_loop new DKG committee set bls publickey:{:?}", dkgdata.bls_privkey.public_key());
                            //dkg_committee = Some(dkgdata.clone());
                        }


                    } else if let Action::SendSMRTx(tx)  = action {
                        log::info!(
                            "manage_action send tx sender:{} type:{:?}",
                            tx.sender,
                            tx.tx_sub_type,
                        );
                        if let Err(err) = tx_sender.send(tx).await{
                            log::warn!("Error during Tx send to memepool:{}", err);
                        }
                    } else if let Action::Store(key, value)  = action {
                        store_committee(key, value);
                    }
                }
            }
        }
    }
}

//This bootstrap work if the DKG has never been done or already finished.
// DKG catch up can fail with this method
//The DKG state is read from Node DB, so we suppose that it's the same as the other SMR nodes.
async fn bootstrap_dkg(
    committee: Option<SmrDkgCommittee>,
    secret_key: &SecretKey,
    elgamal_secret_key: &ElGamalPrivateKey,
    dkgconfig: DkgConfig,
    dkg_members: Vec<(PublicKey, ElGamalPubKey)>,
) -> Result<
    (
        EventProcessor<DkgEventData, DkgEvent, DkgEventType>,
        Vec<Action<DkgEventData, DkgEventType>>,
    ),
    DkgError,
> {
    //    log::info!("Restart DKG with committee:{:?}", committee);
    match committee {
        Some(smr_committee) => smrcommon::dkg::dkg_recreate_events(
            secret_key,
            elgamal_secret_key,
            smr_committee,
            SmrDkgType::Smr,
            dkgconfig,
            0,
            true,
        ),
        None => {
            let mut event_processor = sodkg::state::init_states(
                secret_key.clone(),
                elgamal_secret_key.clone(),
                SmrDkgType::Smr,
                dkgconfig,
                dkg_members,
            );
            let event = DkgEvent::new_init_dkg();
            let init_dkg_actions = event_processor.process_event(Box::new(event));

            Ok((event_processor, init_dkg_actions))
        }
    }
}

async fn iterate_block_tx_for_protocol(
    block: &SmrBlock,
    protocol: SmrTransactionProtocol,
    store: &mut store::Store,
) -> Result<impl Iterator<Item = (TxExecutionStatus, SmrTransaction)>, String> {
    let mut ret_list = vec![];
    for key in block
        .payload
        .iter()
        .filter_map(|(p, b)| (*p == protocol).then_some(b))
    {
        match store.read(key.to_vec()).await {
            Ok(Some(bytes)) => {
                let batch = match SmrBatch::try_from(bytes) {
                    Ok(b) => b,
                    Err(err) => {
                        return Err(format!("Error during store batch deserialization :{}", err));
                    }
                };
                let mut txs: Vec<(TxExecutionStatus, SmrTransaction)> =
                    batch.into_iter_tx().collect();
                ret_list.append(&mut txs);
            }
            Ok(None) => return Err("Block Smr batch not found in store".to_string()),
            Err(err) => return Err(format!("Can't deserialize SMR store smr batch :{}", err)),
        }
    }
    Ok(ret_list.into_iter())
}

pub fn store_committee(key: Vec<u8>, value: Vec<u8>) {
    let key_str = String::from_utf8(key).unwrap();

    if key_str == sodkg::state::DKG_DATA_KEY {
        let data: sodkg::persistence::DkgData = bincode::deserialize(&value[..]).unwrap();
        let file = OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)
            .open(SMR_DKG_STORE_FILE_NAME)
            .expect("read_dkg_definition file error");

        serde_json::to_writer(&file, &data).unwrap_or_else(|_| {
            panic!(
                "save_dkg_definition can't open save json defintion file:{}",
                SMR_DKG_STORE_FILE_NAME,
            )
        });
    }
}
