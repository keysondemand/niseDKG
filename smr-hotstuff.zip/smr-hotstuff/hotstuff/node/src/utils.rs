use futures::sink::SinkExt;
use futures::stream::StreamExt as _;
use futures::FutureExt;
use smrcommon::SmrDkgCommittee;
use smrcommon::SmrDkgCommitteeName;
use sosmr::SmrError;
use sosmr::SmrTransaction;
use sosmr::{SmrBlock, SmrDkgType};
use std::convert::TryFrom;
use std::net::SocketAddr;
use store::Store;
use tokio::sync::mpsc;
use tokio::task::JoinHandle;
use tokio_stream::wrappers::ReceiverStream;
use tokio_util::sync::PollSender;

pub fn start_rpc(
    tx_ip: SocketAddr,
    tx_sender: mpsc::Sender<SmrTransaction>,
    commit: mpsc::Receiver<SmrBlock>,
    store: Store,
    ledger: execution::LedgerAccess,
) -> (JoinHandle<()>, mpsc::Receiver<SmrBlock>) {
    let (rpc_tx, rpc_rx) = mpsc::channel(100);
    let (dkg_tx, dkg_rx) = mpsc::channel(100);
    let in_stream = ReceiverStream::new(commit); //.map(|block| block.convert_to_rpc_types());
    let out_rpc_sink = PollSender::new(rpc_tx);
    let out_dkg_sink = PollSender::new(dkg_tx);
    tokio::spawn(async move {
        in_stream
            .map(Ok)
            .forward(out_rpc_sink.fanout(out_dkg_sink))
            .map(|result| {
                if let Err(e) = result {
                    log::error!("error sending commit block to rpc: {}", e);
                }
            })
            .await;
    });
    (
        rpc::server::RPCServer::spawn(tx_ip, tx_sender, rpc_rx, store, ledger),
        dkg_rx,
    )
}

pub async fn load_db_committee(ledger: &mut execution::Ledger) -> Option<SmrDkgCommittee> {
    //read SMR DKG from file
    let mut committee_name = SmrDkgCommitteeName::new(SmrDkgType::Smr);
    //force to start from done DKG. Otherwise start DKG from zero.
    let key = committee_name.to_bytes();

    //read the db dkg. If running one bootstrap from it
    // Otherwise get the ebded one if exist.
    match ledger
        .read(key.to_vec())
        .await
        .map_err(|err| {
            SmrError::GeneralError(format!("SMR Node DKG Error during DB read :{}", err))
        })
        .and_then(|opt_committee| {
            opt_committee
                .map(|bytes| SmrDkgCommittee::try_from(&bytes[..]))
                .transpose()
                .map(|c| c.into_iter().find(|c| c.is_started()))
        })
        .expect("Error during loading Dkg from ledger db")
    {
        //get running DKG
        Some(c) => Some(c),
        //Try to get a finished DKG.
        None => {
            committee_name.done = true;
            let key = committee_name.to_bytes();
            ledger
                .read(key.to_vec())
                .await
                .map_err(|err| {
                    SmrError::GeneralError(format!("SMR Node DKG Error during DB read :{}", err))
                })
                .and_then(|bytes| {
                    bytes
                        .map(|bytes| SmrDkgCommittee::try_from(&bytes[..]))
                        .transpose()
                })
                .expect("Error during loading Dkg from ledger db")
        }
    }
}
