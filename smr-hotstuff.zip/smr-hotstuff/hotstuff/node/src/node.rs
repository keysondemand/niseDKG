use crate::config::Export as _;
use crate::config::{ConfigError, Parameters};
use crate::dkg::DKGRunner;
use async_trait::async_trait;
use consensus::Committee as ConsensusCommittee;
use consensus::Consensus;
use consensus::ConsensusMessage;
use log::info;
use mempool::Committee as MempoolCommittee;
use mempool::Mempool;
use sign::SignatureService;
use smrcommon::config::SmrCommitteeConfig;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::config::DkgConfig;
use sodkg::ElGamalPrivateKey;
use sodkg::ElGamalPubKey;
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerInfo;
use sosmr::DkgCommittee;
use sosmr::SmrDkgType;
use std::convert::TryFrom;
use std::net::SocketAddr;
use store::Store;
use tokio::sync::mpsc::channel;
use tokio::task::JoinHandle;

/// The default channel capacity for this module.
pub const CHANNEL_CAPACITY: usize = 1_000;

pub struct Node {
    pub network: NetWorkManagerAsync,
    pub rpc_task_handle: JoinHandle<()>,
}

impl Node {
    #[allow(clippy::too_many_arguments)]
    pub async fn new(
        peers: Vec<PeerInfo>,
        committee_config: SmrCommitteeConfig,
        store_path: &str,
        parameters: Option<String>,
        network: NetWorkManagerAsync,
        concensus_receiver: NetworkEventReceiver,
        proposerack_receiver: NetworkEventReceiver,
        mempool_receiver: NetworkEventReceiver,
        quorumwaiter_receiver: NetworkEventReceiver,
        tx_ip: SocketAddr,
        secret_key: SecretKey,
        node_elgamal_secret_key: ElGamalPrivateKey,
        dkg_config: DkgConfig,
        ledger_path: &str,
        prune_block_max_time: Option<u128>,
    ) -> Result<Self, ConfigError> {
        let name = PublicKey::try_from(&secret_key).unwrap();
        let epoch = 1;
        let init_peers: Vec<(PeerInfo, u32)> = peers
            .iter()
            .map(|peer| {
                let stake = 1;
                (peer.clone(), stake)
            })
            .collect();

        log::info!("Node start init_peers:{init_peers:?}");

        let mempool_committee = MempoolCommittee::new(init_peers.clone(), epoch);
        let consensus_committee = ConsensusCommittee::new(init_peers.clone(), epoch);

        let (tx_commit, rx_commit) = channel(CHANNEL_CAPACITY);
        let (tx_consensus_to_mempool, rx_consensus_to_mempool) = channel(CHANNEL_CAPACITY);
        let (tx_mempool_to_consensus, rx_mempool_to_consensus) = channel(CHANNEL_CAPACITY);

        // Load default parameters if none are specified.
        let parameters = match parameters {
            Some(filename) => Parameters::read(&filename)?,
            None => Parameters::default(),
        };

        // Make the data store.
        let store = Store::new(store_path, prune_block_max_time).expect("Failed to create store");
        let mut ledger = execution::Ledger::new(ledger_path).expect("Failed to open Ledger db");
        let rpc_ledger_access = ledger.get_ledger_access();

        // Run the signature service.
        let signature_service = SignatureService::new(secret_key.clone());

        // Make a new mempool.
        let tx_sender = Mempool::spawn(
            name,
            mempool_committee,
            parameters.mempool,
            store.clone(),
            ledger.get_ledger_access(),
            rx_consensus_to_mempool,
            tx_mempool_to_consensus,
            &network,
            mempool_receiver,
            quorumwaiter_receiver,
        );

        let smr_dkg_members = committee_config
            .committee_list
            .iter()
            .filter_map(|c| (c.name == SmrDkgType::Smr).then(|| c.member_list.to_vec()))
            .flatten()
            .map(|c| (c.id, c.elgamal_pubkey))
            .collect();

        //       log::info!("Node start smr_dkg_members:{smr_dkg_members:?}");
        //log::info!("Node start consensus_committee:{consensus_committee:?}");

        //load Db committee
        let commitee = crate::utils::load_db_committee(&mut ledger).await;

        // Run the consensus core.
        let tx_consensus = Consensus::spawn(
            name,
            secret_key.clone(),
            consensus_committee,
            committee_config,
            parameters.consensus,
            signature_service,
            store.clone(),
            ledger,
            rx_mempool_to_consensus,
            tx_consensus_to_mempool,
            tx_commit,
            tx_sender.clone(),
            &network,
            concensus_receiver,
            proposerack_receiver,
        );

        let (rpc_task_handle, dkg_rx_commit) = crate::utils::start_rpc(
            tx_ip,
            tx_sender.clone(),
            rx_commit,
            store.clone(),
            rpc_ledger_access,
        );

        let elgamal_publickey = ElGamalPubKey::try_from(&node_elgamal_secret_key).unwrap();
        let dkg_config_str = format!("dkg_conf:{:?}", dkg_config);

        let tx_consensus = DkgSender { tx_consensus };
        DKGRunner::spawn(
            secret_key,
            node_elgamal_secret_key,
            dkg_config,
            tx_sender,
            dkg_rx_commit,
            store,
            commitee,
            tx_consensus,
            smr_dkg_members,
        );

        info!(
            "Node {} successfully booted with elgamal key:{} {}",
            name,
            hex::encode(elgamal_publickey.into_bytes()),
            dkg_config_str,
        );

        Ok(Self {
            rpc_task_handle,
            network,
        })
    }
}

struct DkgSender {
    tx_consensus: tokio::sync::mpsc::Sender<ConsensusMessage>,
}

#[async_trait]
impl crate::dkg::SendNewDkgCommittee for DkgSender {
    async fn send_committee(&self, committee: DkgCommittee) -> Result<(), String> {
        self.tx_consensus
            .send(ConsensusMessage::DkgCommittee(committee))
            .await
            .map_err(|err| format!("{err}"))
    }
}
