use std::fmt::Debug;
use std::net::SocketAddr;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum RPCError {
    #[error("General erorr: {0}")]
    GeneralError(String),

    #[error("Failed to accept connection: {0}")]
    FailedToListen(#[from] std::io::Error),

    #[error("Failed to receive message from {0}: {1}")]
    FailedToReceiveMessage(SocketAddr, std::io::Error),

    #[error("RPC call fail: {0}")]
    RpcSend(#[from] reqwest::Error),

    #[error("RPC call return error status: {0}")]
    RpcErrorStatus(reqwest::StatusCode),

    #[error("Serailisation error : {0}")]
    SerilisationError(#[from] bincode::Error),
}
