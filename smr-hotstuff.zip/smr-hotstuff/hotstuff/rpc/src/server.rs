use futures::stream::StreamExt as _;
use sosmr::SmrBlock;
use sosmr::SmrTransaction;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::sync::mpsc;
use tokio::sync::Mutex;
use tokio::task::JoinHandle;
use warp::http::Response;
use warp::Filter;
use warp::Reply;

//Consensus RPC <--> Core channel exchange data.
// #[derive(Default, Clone, Debug)]
// pub enum RPCChannelData {
//     Transaction(SmrTransaction),
//     #[default]
//     HealthCheck,
// }

pub struct RPCServer {
    store: store::Store,
    ledger: execution::LedgerAccess,
    tx_sender: mpsc::Sender<SmrTransaction>,
}

impl RPCServer {
    pub fn spawn(
        bind_address: SocketAddr,
        tx_sender: mpsc::Sender<SmrTransaction>,
        block_receiver: mpsc::Receiver<SmrBlock>,
        store: store::Store,
        ledger: execution::LedgerAccess,
    ) -> JoinHandle<()> {
        tokio::spawn(async move {
            Self {
                store,
                ledger,
                tx_sender,
            }
            .run(bind_address, block_receiver)
            .await;
        })
    }

    /// Main loop responsible to accept incoming connections .
    async fn run(&self, bind_address: SocketAddr, mut block_receiver: mpsc::Receiver<SmrBlock>) {
        //TODO set a RwLock instead of a Mutex, only one writer.
        let ws_senders: Arc<Mutex<Vec<mpsc::Sender<SmrBlock>>>> = Arc::new(Mutex::new(vec![]));

        let rpc_store = self.store.clone();
        let ping_tx = warp::get()
            .and(warp::path("rpc"))
            .and(warp::path("v1"))
            .and(warp::path("ping"))
            .and(warp::path::end())
            .and(warp::body::content_length_limit(1024 * 512))
            .map(|| "ping".to_string());
        let health_check = warp::get()
            .and(warp::path("rpc"))
            .and(warp::path("v1"))
            .and(warp::path("check"))
            .and(warp::path::end())
            .and(warp::body::content_length_limit(1024 * 512))
            .and_then(handler::health_check);
        let get_tx = warp::post()
            .and(warp::path("rpc"))
            .and(warp::path("v1"))
            .and(warp::path("get_key"))
            .and(warp::path::end())
            .and(warp::body::content_length_limit(1024 * 512))
            .and(warp::body::bytes())
            .and_then(move |key: bytes::Bytes| handler::get_key(key, rpc_store.clone()));
        let rpc_tx_sender = self.tx_sender.clone();
        let send_tx_ledger = self.ledger.clone();
        let send_tx = warp::post()
            .and(warp::path("rpc"))
            .and(warp::path("v1"))
            .and(warp::path("send_tx"))
            .and(warp::path::end())
            .and(warp::body::content_length_limit(1024 * 512))
            .and(warp::body::bytes())
            .and(warp::any().map(move || rpc_tx_sender.clone()))
            .and_then(
                move |bytes: bytes::Bytes, tx_sender: mpsc::Sender<SmrTransaction>| {
                    handler::send_tx(bytes, tx_sender, send_tx_ledger.clone())
                },
            );

        let ws_senders_clone = ws_senders.clone();
        let ws_route = warp::path("ws")
            .and(warp::path("v1"))
            .and(warp::any().map(move || ws_senders_clone.clone()))
            .and(warp::ws())
            .map(
                |ws_sender: Arc<Mutex<Vec<mpsc::Sender<SmrBlock>>>>, ws: warp::ws::Ws| {
                    ws.on_upgrade(move |websocket| {
                        handler::send_block_notification(ws_sender, websocket)
                    })
                },
            );

        //forward incomming block to WS stream because mpcs::Receiver is not clone.
        //Convert to a clone struct.
        tokio::spawn(async move {
            while let Some(block) = block_receiver.recv().await {
                {
                    //log::info!("Rpc server receive one block");
                    let mut ws_sender_list = ws_senders.lock().await;
                    let mut new_sender_list = vec![];
                    for ws in ws_sender_list.drain(..) {
                        if ws.send(block.clone()).await.is_err() {
                            log::trace!("Ws subscription removed");
                        } else {
                            new_sender_list.push(ws);
                        }
                    }
                    *ws_sender_list = new_sender_list;
                }
            }
        });

        let routes = get_tx
            .or(ping_tx)
            .or(health_check)
            .or(send_tx)
            .or(ws_route)
            .with(warp::cors().allow_any_origin());

        warp::serve(routes).run(bind_address).await;
    }
}

mod handler {
    use super::*;
    use futures::FutureExt;
    use sosmr::SmrError;
    use std::convert::Infallible;
    use tokio_stream::wrappers::ReceiverStream;
    use warp::ws::WebSocket;

    pub async fn get_key(
        key: bytes::Bytes,
        mut store: store::Store,
    ) -> Result<impl Reply, Infallible> {
        let bytes = match store.read(key.to_vec()).await {
            Ok(Some(bytes)) => bytes,
            _ => vec![],
        };
        Ok(Response::builder()
            .status(200)
            .header("content-type", "application/octet-stream")
            .body(bytes))
    }

    pub async fn health_check() -> Result<impl Reply, Infallible> {
        Ok(Response::builder()
            .status(200)
            .header("content-type", "application/octet-stream")
            .body(String::new()))
    }

    pub async fn send_tx(
        bytes: bytes::Bytes,
        tx_sender: mpsc::Sender<SmrTransaction>,
        mut ledger: execution::LedgerAccess,
    ) -> Result<impl Reply, Infallible> {
        let tx = match SmrTransaction::try_from(bytes.to_vec()) {
            Ok(tx) => tx,
            Err(err) => {
                log::warn!("Rpc Error, error during tx deserialization:{:?}", err);
                return Ok(warp::reply::with_status(
                    warp::reply::json(&serde_json::json!({
                        "message": format!("error bad tx format : {:?}", err)
                    })),
                    warp::http::StatusCode::INTERNAL_SERVER_ERROR,
                )
                .into_response());
            }
        };
        //verify Tx signature
        //get Tx commitee DKG from store.
        let res = match ledger
            .get_stored_done_committee(tx.protocol.into())
            .await
            .map_err(|err| SmrError::GeneralError(err.to_string()))
        {
            Ok(c) => match tokio::task::spawn_blocking(move || {
                tx.verify_tx(c.as_ref().and_then(|c| c.threshold_pubkey.as_ref()))
                    .map(|_| tx)
            })
            .await
            .unwrap()
            {
                Ok(tx) => tx_sender
                    .send(tx)
                    .await
                    .map_err(|err| SmrError::GeneralError(err.to_string())),
                Err(err) => Err(err),
            },
            Err(err) => Err(err),
        };

        match res {
            Ok(_) => Ok(warp::reply().into_response()),
            Err(err) => {
                log::warn!("Error during tx verification:{:?}", err);
                Ok(warp::reply::with_status(
                    warp::reply::json(&serde_json::json!({
                        "message": format!("error during tx send : {:?}", err)
                    })),
                    warp::http::StatusCode::INTERNAL_SERVER_ERROR,
                )
                .into_response())
            }
        }
    }

    pub async fn send_block_notification(
        ws_sender: Arc<Mutex<Vec<mpsc::Sender<SmrBlock>>>>,
        websocket: WebSocket,
    ) {
        let (tx, rx) = mpsc::channel(100);
        ws_sender.lock().await.push(tx);
        let rx = ReceiverStream::new(rx);
        let stream = rx.map(|block| {
            warp::filters::ws::Message::binary(bincode::serialize(&block).unwrap_or_default())
        });
        let (ws_out, _) = websocket.split();
        stream
            .map(Ok)
            .forward(ws_out)
            .map(|result| {
                if let Err(e) = result {
                    eprintln!("error sending websocket msg: {}", e);
                }
            })
            .await;
    }
}
