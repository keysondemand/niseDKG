use crate::error::RPCError;
use async_trait::async_trait;
use bytes::Bytes;
use core::future::Future;
use ezsockets::Client;
use ezsockets::ClientConfig;
use reqwest::StatusCode;
use sosmr::SmrBlock;
use sosmr::{SmrBatch, SmrTransaction};
use std::error::Error;
use std::net::SocketAddr;
use tokio::sync::oneshot;
use url::Url;

// pub enum WsSubscription {
//     DIGEST,
//     BLOCK,
// }

// impl std::string::ToString for WsSubscription {
//     fn to_string(&self) -> String {
//         match self {
//             WsSubscription::DIGEST => "digest".to_string(),
//             WsSubscription::BLOCK => "block".to_string(),
//         }
//     }
// }

#[derive(Clone)]
pub struct RPCClient {
    client: reqwest::Client,
    server_addr: SocketAddr,
}

impl RPCClient {
    pub fn new(server_addr: SocketAddr) -> Self {
        let client = reqwest::Client::new();
        RPCClient {
            client,
            server_addr,
        }
    }

    pub async fn get_batch(&self, key: Vec<u8>) -> Result<Option<SmrBatch>, RPCError> {
        self.get_key(key).await.and_then(|b| {
            b.map(|bytes| {
                SmrBatch::try_from(bytes.to_vec()).map_err(|err| {
                    RPCError::GeneralError(format!("error during SmrBatch deserialisation :{err}"))
                })
            })
            .transpose()
        })
    }

    pub async fn get_key(&self, key: Vec<u8>) -> Result<Option<Bytes>, RPCError> {
        let resp = self
            .client
            .post(format!("http://{}/rpc/v1/get_key", self.server_addr))
            .body(key)
            .send()
            .await?;
        if resp.status() == StatusCode::OK {
            let bytes = resp.bytes().await?;
            if bytes.is_empty() {
                Ok(None)
            } else {
                Ok(Some(bytes))
            }
        } else {
            Err(RPCError::RpcErrorStatus(resp.status()))
        }
    }

    pub async fn ping(&self) -> Result<(), RPCError> {
        let resp = self
            .client
            .get(format!("http://{}/rpc/v1/ping", self.server_addr))
            .send()
            .await?;
        if resp.status() == StatusCode::OK {
            Ok(())
        } else {
            Err(RPCError::RpcErrorStatus(resp.status()))
        }
    }

    pub async fn send_tx(&self, tx: SmrTransaction) -> Result<(), RPCError> {
        let resp = self
            .client
            .post(format!("http://{}/rpc/v1/send_tx", self.server_addr))
            .body(tx.to_bytes())
            .send()
            .await?;
        if resp.status() == StatusCode::OK {
            Ok(())
        } else {
            Err(RPCError::RpcErrorStatus(resp.status()))
        }
    }
}

pub struct WsClient<T, Er, F, Fut>
where
    F: FnOnce(SmrBlock) -> Fut
        + std::marker::Send
        + 'static
        + std::marker::Sync
        + std::clone::Clone,
    Fut: Future<Output = Result<T, Er>> + 'static + std::marker::Send,
    Er: Error + std::marker::Send + std::marker::Sync + 'static,
{
    subscription: Client<EzWsClient<T, Er, F, Fut>>,
    close_sender: tokio::sync::oneshot::Sender<()>,
}

impl<T: 'static, Er, F, Fut> WsClient<T, Er, F, Fut>
where
    F: FnOnce(SmrBlock) -> Fut
        + std::marker::Send
        + 'static
        + std::marker::Sync
        + std::clone::Clone,
    Fut: Future<Output = Result<T, Er>> + 'static + std::marker::Send,
    Er: Error + std::marker::Send + std::marker::Sync + 'static,
{
    pub async fn subscribe(server_addr: SocketAddr, callback: F) -> WsClient<T, Er, F, Fut> {
        let url = Url::parse(&format!("ws://{}/ws/v1", server_addr,)).unwrap();
        let config = ClientConfig::new(url);
        let (handle, future) = ezsockets::connect(|_client| EzWsClient { callback }, config).await;
        let (close_sender, rx) = oneshot::channel();
        tokio::spawn(async move {
            tokio::select! {
                res = future => {
                    if let Err(err) = res {
                        log::error!("Rpc Client WS connection handle return an error:{err}");
                    }
                }
                _ = rx => {
                    log::info!("WsClient End ezsocket future execution.");
                }
            };
        });
        WsClient {
            subscription: handle,
            close_sender,
        }
    }

    pub async fn close_subscription(self) {
        self.subscription.close(None).await;
        let _ = self.close_sender.send(());
    }
}

struct EzWsClient<T, Er, F, Fut>
where
    F: FnOnce(SmrBlock) -> Fut + std::marker::Send + 'static,
    Fut: Future<Output = Result<T, Er>> + 'static,
    Er: Error,
{
    callback: F,
}

#[async_trait]
impl<T, Er, F, Fut> ezsockets::ClientExt for EzWsClient<T, Er, F, Fut>
where
    F: FnOnce(SmrBlock) -> Fut + std::marker::Send + 'static + std::marker::Sync + Clone,
    Fut: Future<Output = Result<T, Er>> + 'static + std::marker::Send,
    Er: Error + std::marker::Send + std::marker::Sync + 'static,
{
    type Call = ();

    async fn on_text(&mut self, text: String) -> Result<(), ezsockets::Error> {
        log::info!("received message: {text}");
        Ok(())
    }

    async fn on_binary(&mut self, bytes: Vec<u8>) -> Result<(), ezsockets::Error> {
        match bincode::deserialize::<SmrBlock>(&bytes[..]) {
            Ok(block) => {
                (self.callback.clone())(block).await?;
            }
            Err(err) => {
                log::error!("RPC client receive bad block data could not deserialize: {err}")
            }
        };
        Ok(())
    }

    async fn on_call(&mut self, call: Self::Call) -> Result<(), ezsockets::Error> {
        let () = call;
        Ok(())
    }
}
