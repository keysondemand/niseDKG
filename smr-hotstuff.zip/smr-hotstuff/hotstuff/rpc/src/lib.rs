pub mod client;
mod error;
pub mod server;

pub use error::RPCError;
