//! Utlities for caching DB timestamps and keys.

use std::collections::btree_map::{BTreeMap, Range};
use std::ops::RangeBounds;

use anyhow::Result;
use persy::ValueMode as PersyValueMode;

/// A cache. 
pub trait Cache<K: Ord, V> {
    type R;
    fn read(&self, k: &K) -> Option<&Self::R>;
    fn read_range(&self, r: impl RangeBounds<K>) -> Range<K, Self::R>;
    fn write(&mut self, k: K, v: V) -> Result<Option<Self::R>>;
    fn remove(&mut  self, k: &K) -> Option<Self::R>;
    fn split_off(&mut self, k: &K) -> Self;
    fn len(&self) -> usize;
}

/// A `Cache` which replaces existing values when a duplicate key is inserted.
pub struct ReplaceCache<K: Ord, V> {
    cache: BTreeMap<K, V>,
}

impl<K: Ord, V> ReplaceCache<K, V> where K: Ord {
    /// Create a new replace cache.
    #[allow(unused)]
    pub fn new() -> Self {
        ReplaceCache {
            cache: BTreeMap::new(),
        }
    }

}
impl<K: Ord, V> Cache<K, V> for ReplaceCache<K, V> {
    type R = V;

    /// Returns the value associated with `&k`, if it exists.
    fn read(&self, k: &K) -> Option<&Self::R> {
        self.cache.get(k)
    }

    /// Returns an iterator of values associated with provided range.
    fn read_range(&self, r: impl RangeBounds<K>) -> Range<K, Self::R> {
        self.cache.range(r)
    }

    /// Writes a new value to the cache.
    /// 
    /// If `k` existed, the prior value is replaced and returned.
    /// This implementation never returns `Err`.
    fn write(&mut self, k: K, v: V) -> Result<Option<Self::R>> {
        Ok(self.cache.insert(k, v))
    }

    /// Remove a single element from the cache.
    /// 
    /// If `k` exists, the value is returned.
    fn remove(&mut  self, k: &K) -> Option<Self::R> {
        self.cache.remove(k)
    }

    /// Splits the cache in two at the given key.
    /// 
    /// Returns a cache with everything after the given key, including the key.
    fn split_off(&mut self, k: &K) -> ReplaceCache<K, V> { 
        let cache = self.cache.split_off(k);
        ReplaceCache { cache }
    }

    /// Returns the number of elements in the cache.
    fn len(&self) -> usize { 
        self.cache.len()
    }

}

/// Dictates how to handle duplicate values for a single cache key.
pub enum ValueMode {
    /// Errors on duplicate keys.
    Exclusive,
    /// Stores non-duplicate values in a collection.
    Cluster,
    /// Replaces the old value.
    Replace,
}
impl From<PersyValueMode> for ValueMode {
    fn from(value: PersyValueMode) -> Self {
        use PersyValueMode::*;
        match value {
            Exclusive => ValueMode::Exclusive,
            Cluster => ValueMode::Cluster,
            Replace => ValueMode::Replace,
        }
    }
}

/// A `Cache` which stores a key's values in a collection.
pub struct ClusterCache<K: Ord, V> {
    // ideally this would be generic on the collection itself (HashSet, Vec, etc.) but not now
    cache: BTreeMap<K, Vec<V>>,
}
impl<K: Ord, V> ClusterCache<K, V> where K: Ord {
    #[allow(unused)]
    pub fn new() -> Self {
        Self { cache: BTreeMap::new() }
    }
}
impl<K: Ord, V> Cache<K, V> for ClusterCache<K, V> {
    type R = Vec<V>;

    /// Returns the values associated with `&k`, if they exist.
    fn read(&self, k: &K) -> Option<&Self::R> {
        self.cache.get(k)
    }

    /// Returns an iterator of values associated with provided range.
    fn read_range(&self, r: impl RangeBounds<K>) -> Range<K, Self::R> {
        self.cache.range(r)
    }

    /// Writes a new value to the cache.
    /// 
    /// If `k` already has an entry, the new value is appended to the collection storing it. 
    fn write(&mut self, k: K, v: V) -> Result<Option<Self::R>> {
        if let Some(vs) = self.cache.get_mut(&k) {
            vs.push(v);
        } else {
            self.cache.insert(k, vec![v]);
        }
        Ok(None)
    }

    /// Remove the collection pertaining to `k` from the cache.
    /// 
    /// If `k` exists, the collection is returned.
    fn remove(&mut  self, k: &K) -> Option<Self::R> {
        self.cache.remove(k)
    }

    /// Splits the cache in two at the given key.
    /// 
    /// Returns a cache with everything after the given key, including the key.
    fn split_off(&mut self, k: &K) -> ClusterCache<K, V> { 
        let cache = self.cache.split_off(k);
        ClusterCache { cache }
    }

    /// Returns the number of elements in the cache.
    fn len(&self) -> usize { 
        self.cache.len()
    }
}

/// A `Cache` which does not allow a key's value to be updated.
pub struct ExclusiveCache {}
impl ExclusiveCache {
    #[allow(unused)]
    fn new() -> Self { unimplemented!() }
}
impl<K: Ord, V> Cache<K, V> for ExclusiveCache {
    type R = V;
    fn read(&self, _k: &K) -> Option<&Self::R> { unimplemented!()}
    fn read_range(&self, _r: impl RangeBounds<K>) -> Range<K, Self::R> { unimplemented!() }
    fn write(&mut self, _k: K, _v: V) -> Result<Option<Self::R>> { unimplemented!() }
    fn remove(&mut  self, _k: &K) -> Option<Self::R> { unimplemented!() }
    fn split_off(&mut self, _k: &K) -> Self { unimplemented!() }
    fn len(&self) -> usize { unimplemented!() } 
}

#[cfg(test)]
mod tests {
    use super::*;
    use persy::PersyId;

    #[test]
    fn cache_new_returns_new_cache() {
        // should typecheck with timestamp and ID types
        let _c = ReplaceCache::<u128, PersyId>::new();
    }

    #[test]
    fn cache_write_saves_new_entry() {
        let mut c = ReplaceCache::new();
        let k = 1;
        let v = 10;

        // write should succeed with no prior value
        assert!(c.write(k, v).unwrap().is_none());
        assert!(matches!(c.cache.get(&k), Some(&10)));
    }

    #[test]
    fn cache_write_saves_multiple_entries() {
        let mut c = ReplaceCache::new();
        for i in 0..1000 {
            assert!(c.write(i, i.to_string()).unwrap().is_none());
        }
        for i in 0..1000 {
            assert!(matches!(c.cache.get(&i), Some(v) if v == &*i.to_string()));
        }
    }

    #[test]
    fn cache_read_returns_existing_entry() {
        let mut c = ReplaceCache::new();
        let k = 1;
        let v = 10;

        c.write(k, v).unwrap();
        assert_eq!(c.read(&k), Some(&10));
    }

    #[test]
    fn cache_read_range_returns_multiple_entries() {
        let mut c = ReplaceCache::new();
        for i in 200_000..400_000 {
            assert!(c.write(i, i.to_string()).unwrap().is_none());
        }

        let entries: BTreeMap<_, _> = c.read_range(200_000..400_000).collect();
        // check all elements are present
        for i in 200_000..400_000 {
            assert!(entries.get(&i).is_some());
        }
        // check no extra elements are present
        assert_eq!(entries.len(), 200_000);
    }

    #[test]
    fn cache_remove_removes_existing_entry() {
        let mut c = ReplaceCache::new();
        let k = "ten";
        let v = 10;

        c.write(k, v).unwrap();
        assert_eq!(c.remove(&k).unwrap(), 10);
    }

    #[test]
    fn cache_remove_removes_multiple_entries() {
        let mut c = ReplaceCache::new();

        for i in 1234..5678 {
            assert!(c.write(i, i.to_string()).unwrap().is_none());
        }

        for i in 1234..5678 {
            assert_eq!(c.remove(&i).unwrap(), i.to_string());
        }

        assert!(c.cache.is_empty());
    }

    #[test]
    fn cache_split_off_removes_entries_after_cutoff() {
        let mut c = ReplaceCache::new();
        c.write(1, "one").unwrap();
        c.write(2, "two").unwrap();
        c.write(5, "five").unwrap();

        let five_c = c.split_off(&3);
        assert_eq!(c.cache.len(), 2);
        assert_eq!(five_c.cache.len(), 1);
    }

}
