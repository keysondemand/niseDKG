use crate::StoreCommand;
use std::thread;
use std::time::{Duration, Instant};
use strategy::PruneStrategy;
use tokio::sync::mpsc::Sender as MpscSender;
use tokio::sync::oneshot as tokio_oneshot;

/// Time in milliseconds to wait before pruning cycle
const PRUNE_TIMER_MILLIS: u64 = 4000;

pub fn start_pruning<T>(storage_sender: MpscSender<StoreCommand<T>>, strat: PruneStrategy<T>)
where
    T: Send + 'static,
{
    log::trace!("Store pruning before start_pruning loop");
    thread::spawn(move || {
        let prunedb_timer = Duration::from_millis(PRUNE_TIMER_MILLIS);
        let mut elapsed = Duration::from_secs(0);
        loop {
            thread::sleep(prunedb_timer.saturating_sub(elapsed));
            log::trace!("Store start pruning");
            let start = Instant::now();

            let (temp_sender, temp_receiver) = tokio_oneshot::channel();
            if let Err(err) = storage_sender.blocking_send(StoreCommand::GetOldRecords(temp_sender))
            {
                log::error!("Failed to send GetOldRecords command to store: {}", err);
                continue;
            }
            let old_records = temp_receiver
                .blocking_recv()
                .expect("Failed to receive reply to GetOldRecords command from store");
            log::trace!(
                "Store Prune block get {} blocks to prune",
                old_records.len()
            );
            if !old_records.is_empty() {
                strat(old_records, storage_sender.clone());
                log::info!("store prune end pruning at: {}", get_timestamp());
            }
            elapsed = start.elapsed();
        }
    });
}

fn get_timestamp() -> u128 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_millis()
}

pub mod strategy {
    //! Different strategies for pruning the database.

    use std::thread;
    use std::time::Duration;
    use tokio::sync::mpsc::Sender as MpscSender;

    use super::PRUNE_TIMER_MILLIS;
    use crate::StoreCommand;

    /// Represents a pruning strategy.
    pub type PruneStrategy<T> = Box<dyn Fn(Vec<T>, MpscSender<StoreCommand<T>>) + Send>;

    /// Sends the entire record collection to the pruner.
    #[allow(unused)]
    pub fn all_together<T>(records: Vec<T>, sender: MpscSender<StoreCommand<T>>) {
        let num_recs = records.len();
        if let Err(err) = sender.blocking_send(StoreCommand::PruneRecords(records)) {
            log::error!("sending {num_recs} pruning records failed: {err}");
        }
    }

    /// Splits the record collection into chunks. Chunks are sent to the pruner over the duration `PRUNE_TIMER_MILLIS`.
    pub fn incremental<T: Clone>(records: Vec<T>, sender: MpscSender<StoreCommand<T>>) {
        const CHUNK_SIZE: usize = 10;
        let chunks: Vec<Vec<_>> = records.chunks(CHUNK_SIZE).map(|r| r.into()).collect();

        // we'll spread sending the chunks across this interval
        let delay = Duration::from_millis(PRUNE_TIMER_MILLIS / chunks.len() as u64);
        for chunk in chunks {
            if let Err(err) = sender.blocking_send(StoreCommand::PruneRecords(chunk)) {
                log::error!("sending pruning chunk failed: {err}");
            }
            thread::sleep(delay);
        }
    }
}
