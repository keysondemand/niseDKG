use cache::Cache;
use lru::LruCache;
use parking_lot::RwLock;
use persy::ByteVec;
use persy::PersyError;
use persy::PersyId;
use persy::ValueMode;
use persy::{Config, Persy};
use prune::strategy;
use rayon::ThreadPoolBuilder;
use std::collections::{HashMap, VecDeque};
use std::io::{Error as IoError, ErrorKind};
use std::num::NonZeroUsize;
use std::path::Path;
use std::sync::Arc;
use std::thread;
use std::time::Duration;
use std::time::Instant;
use std::time::SystemTime;
use std::time::UNIX_EPOCH;
use tokio::sync::mpsc::{self, Sender};
use tokio::sync::oneshot;

use crate::cache::ClusterCache;
// use std::num::NonZeroUsize;

// #[cfg(test)]
// #[path = "tests/store_tests.rs"]
// pub mod store_tests;

mod cache;
mod prune;

const PERSY_DB_BLOCK_SEGMENT: &str = "blocks";
const PERSY_DB_BLOCK_INDEX: &str = "blocks_index";
const PERSY_DB_TIMESTAMP_INDEX: &str = "ts_index";
const PERSY_DB_KEY_INDEX: &str = "key_index";

pub type StoreError = persy::PersyError;
type StoreResult<T> = Result<T, StoreError>;

pub type Key = Vec<u8>;
pub type Value = Vec<u8>;

/// Commands sent to the DB thread.
///
/// `T` is whatever type the pruning cache returns (dependent on persy's ValueMode).
pub enum StoreCommand<T> {
    Write(Key, Value),
    Read(Key, oneshot::Sender<StoreResult<Option<Value>>>),
    NotifyRead(Key, oneshot::Sender<StoreResult<Value>>),
    //Prune record in 2 step to avoid to block the store loop
    // during the removal of all old block.
    GetOldRecords(oneshot::Sender<Vec<T>>),
    PruneRecords(Vec<T>),
}

#[derive(Clone, Debug)]
pub struct Store {
    pub channel: Sender<StoreCommand<(u128, Vec<PersyId>)>>,
    // last_prune_ts: u128,
}

impl Store {
    pub fn new(path: &str, max_record_time_millis_opt: Option<u128>) -> StoreResult<Self> {
        let str_db_path: String = format!("{}.persy", path);
        let db_path = Path::new(&str_db_path);
        let mut db_config = Config::new();
        db_config.change_cache_size(64 * 1024); //cache the last few block. Avoid to use too much memory
        db_config.change_cache_age_limit(Duration::from_secs(60 * 60)); //1 hour
        let persy = if !db_path.exists() {
            Persy::create(db_path).map_err(|e| e.persy_error())?;
            let persy = Persy::open(db_path, db_config).map_err(|e| e.persy_error())?;
            let mut tx = persy.begin().map_err(|e| e.persy_error())?;
            tx.create_segment(PERSY_DB_BLOCK_SEGMENT)
                .map_err(|e| e.persy_error())?;
            tx.create_index::<ByteVec, PersyId>(PERSY_DB_BLOCK_INDEX, ValueMode::Replace)
                .map_err(|e| e.persy_error())?;
            //use to block key key index.
            tx.create_index::<PersyId, ByteVec>(PERSY_DB_KEY_INDEX, ValueMode::Replace)
                .map_err(|e| e.persy_error())?;
            tx.create_index::<u128, PersyId>(PERSY_DB_TIMESTAMP_INDEX, ValueMode::Cluster)
                .map_err(|e| e.persy_error())?;
            tx.commit().map_err(|e| e.persy_error())?;
            persy
        } else {
            Persy::open(db_path, db_config).map_err(|e| e.persy_error())?
        };

        let mut obligations = HashMap::<_, VecDeque<oneshot::Sender<_>>>::new();
        let (tx, mut rx) = mpsc::channel(100);
        let worker_pool = ThreadPoolBuilder::new()
            .num_threads(1)
            .build()
            .map_err(|e| IoError::new(ErrorKind::Other, e))?;
        log::debug!(
            "Store threadpool running with {}",
            worker_pool.current_num_threads()
        );
        let prune_tx = tx.clone();
        let max_record_time_millis = max_record_time_millis_opt.unwrap_or(60 * 10 * 1000); //default 10mn but not use because prube not activated.
        let value_mode = get_value_mode(&persy, PERSY_DB_TIMESTAMP_INDEX)?;
        assert!(
            value_mode == ValueMode::Cluster,
            "timestamp cache is intended to be used with ValueMode::Cluster"
        );
        let pruning_cache = Arc::new(RwLock::new(ClusterCache::new()));

        thread::spawn(move || {
            let mut last_prune_query_time = 0u128;
            //cache last write data to avoid db access
            let mut cache: LruCache<Key, Value, _> = LruCache::new(NonZeroUsize::new(400).unwrap());

            //put a default value but not use because if None pruning is not started.
            while let Some(command) = rx.blocking_recv() {
                match command {
                    StoreCommand::Write(key, value) => {
                        cache.put(key.clone(), value.clone());
                        let write_persy = persy.clone();
                        let maybe_senders = obligations.remove(&key);
                        let pruning_cache = pruning_cache.clone();
                        worker_pool.spawn(move || {
                            let start_time = Instant::now();
                            write_persy
                                .begin()
                                .map_err(|e| e.persy_error())
                                .and_then(|mut tx| {
                                    let id = tx
                                        .insert(PERSY_DB_BLOCK_SEGMENT, &value)
                                        .map_err(|e| e.persy_error())?;
                                    Ok((tx, id))
                                })
                                .and_then(|(mut tx, id)| {
                                    log::trace!(
                                        "write block with persiId:{} ts:{}",
                                        id,
                                        get_timestamp()
                                    );
                                    tx.put::<ByteVec, PersyId>(
                                        PERSY_DB_BLOCK_INDEX,
                                        ByteVec::new(key.to_vec()),
                                        id,
                                    )
                                    .and_then(|_| {
                                        tx.put::<PersyId, ByteVec>(
                                            PERSY_DB_KEY_INDEX,
                                            id,
                                            ByteVec::new(key.to_vec()),
                                        )
                                    })
                                    .and_then(|_| {
                                        let timestamp = get_timestamp();
                                        //log::info!("Store write ts:{}", timestamp);
                                        #[allow(clippy::let_unit_value)]
                                        let res = tx.put::<u128, PersyId>(
                                            PERSY_DB_TIMESTAMP_INDEX,
                                            timestamp,
                                            id,
                                        )?;
                                        if let Err(e) =  pruning_cache.write().write(timestamp, id) {
                                            log::error!("error writing k: {timestamp} v: {id} to cache: {e}");
                                        }
                                        Ok(res)
                                    })
                                    .map_err(|e| e.persy_error())?;
                                    Ok(tx)
                                })
                                .and_then(|tx| tx.prepare().map_err(|e| e.persy_error()))
                                .and_then(|prepare| prepare.commit().map_err(|e| e.persy_error()))
                                .expect("persy write error");

                            let write_time = start_time.elapsed().as_millis();
                            if write_time > 500 {
                                log::warn!("Store Write elapse more than 500ms");
                            }
                            if let Some(mut senders) = maybe_senders {
                                while let Some(s) = senders.pop_front() {
                                    let _ = s.send(Ok(value.clone()));
                                }
                            }
                        });
                    }
                    StoreCommand::Read(key, sender) => {
                        let response = cache.get(&key);
                        let response = if response.is_some() {
                            Ok(response.cloned())
                        } else {
                            let start_time = Instant::now();
                            let read_persy = persy.clone();
                            let response = read_persy
                                .get::<ByteVec, PersyId>(PERSY_DB_BLOCK_INDEX, &ByteVec::new(key))
                                .map_err(|e| {
                                    log::error!("Store Read Persy PERSY_DB_BLOCK_INDEX error:{e}");
                                    e.persy_error()
                                })
                                .and_then(|mut read_id| {
                                    read_id
                                        .next()
                                        .and_then(|id| {
                                            read_persy
                                                .read(PERSY_DB_BLOCK_SEGMENT, &id)
                                                .map_err(|e| {
                                                    log::error!("Store Read PERSY_DB_BLOCK_SEGMENT for id:{id} error:{e}");
                                                    e.persy_error()
                                                })
                                                .transpose()
                                        })
                                        .transpose()
                                });
                            let read_time = start_time.elapsed().as_millis();
                            if read_time > 400 {
                                log::warn!("Store Read elapse more than 400ms");
                            }
                            response
                        };

                        if let Err(err) = sender.send(response) {
                            log::warn!("Store read sender callback channel closed err:{err:?}");
                        }
                    }
                    StoreCommand::NotifyRead(key, sender) => {
                        let response = cache.get(&key);

                        let (response, key) = if response.is_some() {
                            (Ok(response.cloned()), key)
                        } else {
                            let start_time = Instant::now();
                            let read_persy = persy.clone();
                            let response = read_persy
                                .get::<ByteVec, PersyId>(
                                    PERSY_DB_BLOCK_INDEX,
                                    &ByteVec::new(key.to_vec()),
                                )
                                .map_err(|e| e.persy_error())
                                .and_then(|mut read_id| {
                                    read_id
                                        .next()
                                        .and_then(|id| {
                                            read_persy
                                                .read(PERSY_DB_BLOCK_SEGMENT, &id)
                                                .map_err(|e| e.persy_error())
                                                .transpose()
                                        })
                                        .transpose()
                                });
                            let read_time = start_time.elapsed().as_millis();
                            if read_time > 400 {
                                log::warn!("Store Read elapse more than 400ms");
                            }
                            (response, key)
                        };

                        match response {
                            Ok(None) => {
                                obligations
                                    .entry(key)
                                    .or_insert_with(VecDeque::new)
                                    .push_back(sender);
                            }
                            _ => {
                                if let Err(e) = sender.send(response.transpose().unwrap()) {
                                    log::warn!(
                                        "Store read sender callback channel closed err:{e:?}"
                                    );
                                }
                            }
                        }
                    }
                    StoreCommand::GetOldRecords(tmp_sender) => {
                        let timestamp = get_timestamp();
                        let query_window =
                            timestamp - max_record_time_millis - last_prune_query_time;
                        let start_query = Instant::now();

                        let mut num_recs = 0;
                        let cache_rec_list: Vec<_> = {
                            let rlock = pruning_cache.read();
                            let range = rlock.read_range(0..=(timestamp - max_record_time_millis));
                            // Deref/copy to emulate the DB behavior, but in one of the
                            // next issues I'd like to make pruning more or less atomic
                            range
                                .map(|(ts, ids)| {
                                    num_recs += ids.len();
                                    (*ts, ids.clone())
                                })
                                .collect::<Vec<_>>()
                        };

                        let query_elapsed = start_query.elapsed().as_millis();
                        let num_stamps = cache_rec_list.len();
                        if tmp_sender.send(cache_rec_list).is_err() {
                            log::error!("Failed to send PruneRecord command to store");
                        }

                        log::debug!(
                            "{}-query start_timestamp:{} window:{} elapsed:{} num_records:{} num_stamps: {}",
                            str_db_path,
                            timestamp,
                            query_window,
                            query_elapsed,
                            num_recs,
                            num_stamps
                        );
                        last_prune_query_time = timestamp - max_record_time_millis;
                    }
                    StoreCommand::PruneRecords(old_records) => {
                        let write_persy = persy.clone();
                        let start_timestamp = get_timestamp();
                        let start_prune = Instant::now();
                        let ts_cutoff = old_records.last().unwrap().0 + 1; // +1 to ensure .last() is removed
                        let num_recs = old_records.len();
                        //log::info!("Store: Prune block for ts:{ts}");
                        log::debug!("{}-cache size: {}", str_db_path, pruning_cache.read().len());

                        if let Err(err) =
                            write_persy
                                .begin()
                                .map_err(|e| e.persy_error())
                                .and_then(|mut tx| {
                                    //remove from db and block id index
                                    for (ts, rec_vec) in old_records.iter() {
                                        for rec_id in rec_vec {
                                            log::trace!("delete block with persiId:{}", rec_id);
                                            tx.delete(PERSY_DB_BLOCK_SEGMENT, rec_id)
                                                .map_err(|e| e.persy_error())?;
                                            //get block key
                                            tx.get::<PersyId, ByteVec>(PERSY_DB_KEY_INDEX, rec_id)
                                                .map_err(|e| e.persy_error())
                                                .and_then(|mut key| {
                                                    key.next().ok_or(PersyError::NotExists)
                                                })
                                                .and_then(|key| {
                                                    tx.remove::<ByteVec, PersyId>(
                                                        PERSY_DB_BLOCK_INDEX,
                                                        ByteVec::new(key.to_vec()),
                                                        None,
                                                    )
                                                    .map_err(|e| e.persy_error())
                                                })?;
                                        }

                                        //remove from timestamp index.
                                        tx.remove::<u128, PersyId>(
                                            PERSY_DB_TIMESTAMP_INDEX,
                                            *ts,
                                            None,
                                        )
                                        .map_err(|e| e.persy_error())?;
                                    }

                                    //commit
                                    tx.prepare()
                                        .map_err(|e| e.persy_error())?
                                        .commit()
                                        .map_err(|e| e.persy_error())?;

                                    // prune old timestamps from cache. cache assumes ALL records are removed per TS when using ClusterCache
                                    let mut wlock = pruning_cache.write();
                                    let valid_stamps = wlock.split_off(&ts_cutoff);
                                    *wlock = valid_stamps;
                                    Ok(())
                                })
                        {
                            log::error!("Storage, error during pruning blocks:{}", err);
                        }
                        let prune_elapsed = start_prune.elapsed().as_millis();
                        log::debug!(
                            "{}-cache pruned size: {}",
                            str_db_path,
                            pruning_cache.read().len()
                        );
                        log::debug!(
                            "{}-prune start_timestamp:{} elapsed:{} num_records: {}",
                            str_db_path,
                            start_timestamp,
                            prune_elapsed,
                            num_recs
                        );
                    }
                }
            }
        });
        if max_record_time_millis_opt.is_some() {
            prune::start_pruning(prune_tx, Box::new(strategy::incremental));
        }
        Ok(Self { channel: tx })
    }

    pub async fn write(&mut self, key: Key, value: Value) {
        if let Err(e) = self.channel.send(StoreCommand::Write(key, value)).await {
            panic!("Failed to send Write command to store: {}", e);
        }
    }

    pub async fn read(&mut self, key: Key) -> StoreResult<Option<Value>> {
        let (sender, receiver) = oneshot::channel();
        if let Err(e) = self.channel.send(StoreCommand::Read(key, sender)).await {
            panic!("Failed to send Read command to store: {}", e);
        }
        receiver
            .await
            .expect("Failed to receive reply to Read command from store")
    }

    pub async fn notify_read(&mut self, key: Key) -> StoreResult<Value> {
        let (sender, receiver) = oneshot::channel();
        if let Err(e) = self
            .channel
            .send(StoreCommand::NotifyRead(key, sender))
            .await
        {
            panic!("Failed to send NotifyRead command to store: {}", e);
        }
        receiver
            .await
            .expect("Failed to receive reply to NotifyRead command from store")
    }
}

fn get_timestamp() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_millis()
}

/// Returns the value mode of the specified index, if the index exists.
fn get_value_mode(db: &Persy, index: &str) -> Result<ValueMode, StoreError> {
    let index_list = db.list_indexes().map_err(|e| e.persy_error())?;
    for (name, info) in index_list {
        if name == index {
            let vm = info.value_mode;
            return Ok(vm);
        }
    }

    Err(PersyError::IndexNotFound)
}

//Memry db code for test
// let mut cache = LruCache::new(NonZeroUsize::new(100).unwrap());
// let (tx, mut rx) = channel(50);
// tokio::spawn(async move {
//     let mut obligations = HashMap::<_, VecDeque<oneshot::Sender<_>>>::new();

//     while let Some(command) = rx.recv().await {
//         match command {
//             StoreCommand::Write(key, value) => {
//                 if let Some(mut senders) = obligations.remove(&key) {
//                     while let Some(s) = senders.pop_front() {
//                         let _ = s.send(Ok(value.clone()));
//                     }
//                 }
//                 cache.put(key, value);
//             }
//             StoreCommand::Read(key, sender) => {
//                 let response = cache.get(&key);
//                 if let Err(err) = sender.send(Ok(response.cloned())) {
//                     log::warn!("Store read sender callback channel closed err:{err:?}");
//                 }
//             }

//             StoreCommand::NotifyRead(key, sender) => {
//                 let response = cache.get(&key);
//                 match response {
//                     None => {
//                         obligations
//                             .entry(key)
//                             .or_insert_with(VecDeque::new)
//                             .push_back(sender);
//                     }
//                     Some(response) => sender.send(Ok(response.to_vec())).unwrap(),
//                 };
//             }
//             StoreCommand::GetOldRecords(_) => {
//                 //do nothing no pruning
//             }
//             StoreCommand::PruneRecords(_, _) => {
//                 //do nothing no pruning
//             }
//         }
//     }
// });
// Ok(Self { channel: tx })
