use crate::config::{Committee, Stake};
use crate::consensus::Round;
use crate::error::{ConsensusError, ConsensusResult};
use crate::messages::VoteSignature;
use crate::messages::{Timeout, Vote, QC, TC};
use socrypto::Digest as _;
use socrypto::Signature;
use socrypto::{Hash, PublicKey};
use sosmr::DkgCommittee;
use std::collections::{HashMap, HashSet};

// #[cfg(test)]
// #[path = "tests/aggregator_tests.rs"]
// pub mod aggregator_tests;

pub struct Aggregator {
    committee: Committee,
    votes_aggregators: HashMap<Round, HashMap<Hash, Box<QCMaker>>>,
    timeouts_aggregators: HashMap<Round, Box<TCMaker>>,
}

impl Aggregator {
    pub fn new(committee: Committee) -> Self {
        Self {
            committee,
            votes_aggregators: HashMap::new(),
            timeouts_aggregators: HashMap::new(),
        }
    }

    pub async fn add_vote(
        &mut self,
        vote: Vote,
        dkg_committee: Option<&DkgCommittee>,
        threshold_f: usize,
    ) -> ConsensusResult<Option<QC>> {
        // TODO [issue #7]: A bad node may make us run out of memory by sending many votes
        // with different round numbers or different digests.
        log::trace!("Aggregator add_vote vote round:{:?}", vote.round);

        // Add the new vote to our aggregator and see if we have a QC.
        self.votes_aggregators
            .entry(vote.round)
            .or_insert_with(HashMap::new)
            .entry(vote.digest())
            .or_insert_with(|| Box::new(QCMaker::new()))
            .append(vote, &self.committee, dkg_committee, threshold_f)
            .await
    }

    pub fn add_timeout(&mut self, timeout: Timeout) -> ConsensusResult<Option<TC>> {
        // TODO: A bad node may make us run out of memory by sending many timeouts
        // with different round numbers.
        log::trace!("Aggregator add_timeout vote round:{:?}", timeout.round);

        // Add the new timeout to our aggregator and see if we have a TC.
        self.timeouts_aggregators
            .entry(timeout.round)
            .or_insert_with(|| Box::new(TCMaker::new()))
            .append(timeout, &self.committee)
    }

    pub fn cleanup(&mut self, round: &Round) {
        self.votes_aggregators.retain(|k, _| k >= round);
        self.timeouts_aggregators.retain(|k, _| k >= round);
    }
}

struct QCMaker {
    weight: Stake,
    votes: Vec<(PublicKey, VoteSignature)>,
    used: HashSet<PublicKey>,
}

impl QCMaker {
    pub fn new() -> Self {
        Self {
            weight: 0,
            votes: Vec::new(),
            used: HashSet::new(),
        }
    }

    /// Try to append a signature to a (partial) quorum.
    pub async fn append(
        &mut self,
        vote: Vote,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
        threshold_f: usize,
    ) -> ConsensusResult<Option<QC>> {
        let author = vote.author;
        log::trace!("Aggregator QCMaker append round:{:?}", vote.round);

        // Ensure it is the first time this authority votes.
        ensure!(
            self.used.insert(author),
            ConsensusError::AuthorityReuse(author)
        );

        self.votes.push((author, vote.signature));
        self.weight += committee.stake(&author);
        if self.weight >= committee.quorum_threshold() {
            self.weight = 0; // Ensures QC is only made once.
                             //create committee threshold signature
            let qc_votes = self.votes.clone();
            let c = dkg_committee.cloned(); //clone because spawn_blocking has static lifetime, scoped version
            let dkg_committee = tokio::task::spawn_blocking(move || {
                QC::sign_committee_votes(vote.hash, vote.round, qc_votes, c.as_ref(), threshold_f)
            })
            .await
            .unwrap()?;
            return Ok(Some(dkg_committee));
        }
        Ok(None)
    }
}

struct TCMaker {
    weight: Stake,
    votes: Vec<(PublicKey, Signature, Round)>,
    used: HashSet<PublicKey>,
}

impl TCMaker {
    pub fn new() -> Self {
        Self {
            weight: 0,
            votes: Vec::new(),
            used: HashSet::new(),
        }
    }

    /// Try to append a signature to a (partial) quorum.
    pub fn append(
        &mut self,
        timeout: Timeout,
        committee: &Committee,
    ) -> ConsensusResult<Option<TC>> {
        let author = timeout.author;

        log::trace!("Aggregator TCMaker append round:{:?}", timeout.round);

        // Ensure it is the first time this authority votes.
        ensure!(
            self.used.insert(author),
            ConsensusError::AuthorityReuse(author)
        );

        // Add the timeout to the accumulator.
        self.votes
            .push((author, timeout.signature, timeout.high_qc.round));
        self.weight += committee.stake(&author);
        if self.weight >= committee.quorum_threshold() {
            self.weight = 0; // Ensures TC is only created once.
            return Ok(Some(TC {
                round: timeout.round,
                votes: self.votes.clone(),
            }));
        }
        Ok(None)
    }
}
