use crate::config::Stake;
use crate::config::{Committee, Parameters};
use crate::core::Core;
use crate::helper::Helper;
use crate::leader::LeaderElector;
use crate::mempool::MempoolDriver;
use crate::messages::{BlockMsg, Timeout, Vote, TC};
use crate::proposer::Proposer;
use crate::synchronizer::Synchronizer;
use async_trait::async_trait;
use log::{info, warn};
use mempool::ConsensusMempoolMessage;
use peer::{HotStuffMessage, PeerMessageHandler};
use serde::{Deserialize, Serialize};
use sign::SignatureService;
use smrcommon::config::SmrCommitteeConfig;
use socrypto::Digest;
use socrypto::SecretKey;
use socrypto::{Hash, PublicKey};
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerInfo;
use sosmr::DkgCommittee;
use sosmr::SmrBlock;
use sosmr::SmrTransaction;
use std::fmt;
use store::Store;
use tokio::sync::mpsc::{channel, Receiver, Sender};

// #[cfg(test)]
// #[path = "tests/consensus_tests.rs"]
// pub mod consensus_tests;

/// The default channel capacity for each channel of the consensus.
pub const CHANNEL_CAPACITY: usize = 1_000;

/// The consensus round number.
pub type Round = u64;

#[derive(Serialize, Deserialize, Debug)]
pub enum ConsensusMessage {
    Propose(BlockMsg),
    Vote(Vote),
    Timeout(Timeout),
    TC(TC),
    SyncRequest(Hash, PublicKey),
    DkgCommittee(DkgCommittee),
}

impl fmt::Display for ConsensusMessage {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let msg = match self {
            ConsensusMessage::Propose(_) => "Propose",
            ConsensusMessage::Vote(_) => "Vote",
            ConsensusMessage::Timeout(_) => "Timeout",
            ConsensusMessage::TC(_) => "TC",
            ConsensusMessage::SyncRequest(_, _) => "SyncRequest",
            ConsensusMessage::DkgCommittee(_) => "DkgCommittee",
        };
        write!(f, "({})", msg)
    }
}

pub struct Consensus;

impl Consensus {
    #[allow(clippy::too_many_arguments)]
    pub fn spawn(
        name: PublicKey,
        secret_key: SecretKey,
        committee: Committee,
        committee_config: SmrCommitteeConfig,
        parameters: Parameters,
        signature_service: SignatureService,
        store: Store,
        ledger: execution::Ledger,
        rx_mempool: Receiver<Hash>,
        tx_mempool: Sender<ConsensusMempoolMessage>,
        tx_commit: Sender<SmrBlock>,
        tx_sender: Sender<SmrTransaction>,
        network: &NetWorkManagerAsync,
        concensus_receiver: NetworkEventReceiver,
        proposerack_receiver: NetworkEventReceiver,
    ) -> Sender<ConsensusMessage> {
        // NOTE: This log entry is used to compute performance.
        parameters.log();

        let (tx_consensus, rx_consensus) = channel(CHANNEL_CAPACITY);
        let (tx_loopback, rx_loopback) = channel(CHANNEL_CAPACITY);
        let (tx_proposer, rx_proposer) = channel(CHANNEL_CAPACITY);
        let (tx_helper, rx_helper) = channel(CHANNEL_CAPACITY);

        // Spawn the network receiver.
        let address = committee
            .peer(&name)
            .expect("Our public key is not in the committee");
        // address.set_ip("0.0.0.0".parse().unwrap());
        // NetworkReceiver::spawn(
        //     address,
        //      handler
        //     ConsensusReceiverHandler {
        //         tx_consensus,
        //         tx_helper,
        //     },
        // );
        let stake = committee.stake(&name);
        crate::network::spawn_concensusreceiver_message_receiver(
            concensus_receiver,
            ConsensusReceiverHandler {
                tx_consensus: tx_consensus.clone(),
                tx_helper,
                stake,
                network_sender: crate::network::ProposerBlockAckSender::new(network),
            },
        );
        info!(
            "Node {} listening to consensus messages on {}",
            name, address
        );

        // Make the leader election module.
        let leader_elector = LeaderElector::new(committee.clone());

        // Make the mempool driver.
        let mempool_driver = MempoolDriver::new(store.clone(), tx_mempool, tx_loopback.clone());

        // Make the synchronizer.
        let synchronizer = Synchronizer::new(
            name,
            //           committee.clone(),
            store.clone(),
            tx_loopback.clone(),
            parameters.sync_retry_delay,
            network,
        );

        // Spawn the consensus core.
        Core::spawn(
            name,
            secret_key,
            committee.clone(),
            committee_config,
            signature_service.clone(),
            store.clone(),
            ledger,
            leader_elector,
            mempool_driver,
            synchronizer,
            parameters.timeout_delay,
            /* rx_message */ rx_consensus,
            rx_loopback,
            tx_proposer,
            tx_commit,
            tx_sender,
            network,
        );

        // Spawn the block proposer.
        Proposer::spawn(
            name,
            committee.clone(),
            signature_service,
            rx_mempool,
            /* rx_message */ rx_proposer,
            tx_loopback,
            network,
            proposerack_receiver,
        );

        // Spawn the helper module.
        Helper::spawn(committee, store, /* rx_requests */ rx_helper, network);
        tx_consensus
    }
}

/// Defines how the network receiver handles incoming primary messages.
#[derive(Clone)]
struct ConsensusReceiverHandler {
    tx_consensus: Sender<ConsensusMessage>,
    tx_helper: Sender<(Hash, PublicKey)>,
    network_sender: crate::network::ProposerBlockAckSender,
    stake: Stake,
}

#[async_trait]
impl PeerMessageHandler for ConsensusReceiverHandler {
    async fn dispatch(&mut self, _peer_info: PeerInfo, message: HotStuffMessage) {
        if let HotStuffMessage::ConsensusMessage(bytes) = message {
            let cons_msg = bincode::deserialize(&bytes);
            log::trace!(
                "Consensus dispatch receive msg:{}",
                cons_msg.as_ref().unwrap()
            );
            // Deserialize and parse the message.
            match cons_msg {
                Ok(ConsensusMessage::SyncRequest(missing, origin)) => self
                    .tx_helper
                    .send((missing, origin))
                    .await
                    .expect("Failed to send consensus message"),
                Ok(ConsensusMessage::Propose(block)) => {
                    log::trace!("Consensus dispatch receive ConsensusMessage::Propose block");
                    // Reply with an ACK.
                    self.network_sender
                        .send_proposerblockack_message(block.digest().0, self.stake)
                        .await;
                    //let _ = writer.send(Bytes::from("Ack")).await;

                    // Pass the message to the consensus core.
                    self.tx_consensus
                        .send(ConsensusMessage::Propose(block))
                        .await
                        .expect("Failed to consensus message")
                }
                Ok(message) => self
                    .tx_consensus
                    .send(message)
                    .await
                    .expect("Failed to consensus message"),
                Err(e) => warn!("Consensus receive message Serialization error: {}", e),
            }
        }
    }
}
