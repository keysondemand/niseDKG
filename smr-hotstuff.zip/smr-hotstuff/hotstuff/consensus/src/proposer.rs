use crate::config::{Committee, Stake};
use crate::consensus::{ConsensusMessage, Round};
use crate::messages::{BlockMsg, QC, TC};
use crate::network::ConsensusMessageSender;
use async_trait::async_trait;
use log::{debug, info, trace};
use peer::HotStuffMessage;
use peer::PeerMessageHandler;
use sign::SignatureService;
use socrypto::Hash;
use socrypto::{Digest, PublicKey};
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerInfo;
use std::collections::{hash_map, HashMap, HashSet};
use std::sync::Arc;
use tokio::sync::mpsc::{Receiver, Sender};
use tokio::sync::Mutex;
use tokio::sync::Notify;

//manage propose block Ack
#[derive(Clone)]
struct ProposeBlockAckReceiverHandler {
    name: PublicKey,
    committee: Committee,
    #[allow(clippy::type_complexity)]
    waiting_block_list: Arc<Mutex<HashMap<Hash, (Stake, Option<Arc<Notify>>)>>>,
}

#[async_trait]
impl PeerMessageHandler for ProposeBlockAckReceiverHandler {
    async fn dispatch(&mut self, _peer_info: PeerInfo, message: HotStuffMessage) {
        if let HotStuffMessage::ProposeBlockAckMessage(digest, stake) = message {
            trace!(
                "node:{} ProposerMessage receive from:{_peer_info} stake:{stake} ack",
                self.name
            );
            let mut waiting_block_list = self.waiting_block_list.lock().await;
            let (total_stake, notify) = waiting_block_list.entry(Hash(digest)).or_insert((0, None));
            *total_stake += stake;
            if *total_stake >= self.committee.quorum_threshold() && notify.is_some() {
                let (_, notify) = waiting_block_list.remove(&Hash(digest)).unwrap(); // unwrap tested before
                trace!("ProposerMessage quorum threshold reached for digest:{digest:?}");
                notify.unwrap().notify_one(); // unwrap tested before
            }
        }
    }
}

#[derive(Debug)]
pub enum ProposerMessage {
    Make(Round, Box<QC>, Option<TC>),
    Cleanup(Vec<Hash>),
}

pub struct Proposer {
    name: PublicKey,
    signature_service: SignatureService,
    rx_mempool: Receiver<Hash>,
    rx_message: Receiver<ProposerMessage>,
    tx_loopback: Sender<BlockMsg>,
    buffer: HashSet<Hash>,
    #[allow(clippy::type_complexity)]
    waiting_block_list: Arc<Mutex<HashMap<Hash, (Stake, Option<Arc<Notify>>)>>>,
    networksender: ConsensusMessageSender,
}

impl Proposer {
    #[allow(clippy::too_many_arguments)]
    pub fn spawn(
        name: PublicKey,
        committee: Committee,
        signature_service: SignatureService,
        rx_mempool: Receiver<Hash>,
        rx_message: Receiver<ProposerMessage>,
        tx_loopback: Sender<BlockMsg>,
        network: &NetWorkManagerAsync,
        proposerack_receiver: NetworkEventReceiver,
    ) {
        info!("consensus Proposer start :{name}");
        let waiting_block_list = Arc::new(Mutex::new(HashMap::new()));
        crate::network::spawn_proposeblockack_message_receiver(
            proposerack_receiver,
            ProposeBlockAckReceiverHandler {
                name,
                committee,
                waiting_block_list: waiting_block_list.clone(),
            },
        );

        let networksender = ConsensusMessageSender::new(network);
        tokio::spawn(async move {
            Self {
                name,
                signature_service,
                rx_mempool,
                rx_message,
                tx_loopback,
                buffer: HashSet::new(),
                waiting_block_list,
                networksender,
            }
            .run()
            .await;
        });
    }

    /// Helper function. It waits for a future to complete and then delivers a value.
    // async fn waiter(wait_for: CancelHandler, deliver: Stake) -> Stake {
    //     let _ = wait_for.await;
    //     deliver
    // }

    async fn make_block(&mut self, round: Round, qc: QC, tc: Option<TC>) {
        log::trace!("Proposer make_block  round:{:?}", round);
        // Generate a new block.
        let block = BlockMsg::new(
            qc,
            tc,
            self.name,
            round,
            /* payload */ self.buffer.drain().collect(),
            self.signature_service.clone(),
        )
        .await;

        debug!("Created {:?}", block);

        // Broadcast our new block.
        debug!(
            "Node:{} Broadcasting ConsensusMessage::Propose block {:?}",
            self.name, block
        );
        self.networksender
            .broadcast_consensus_message(ConsensusMessage::Propose(block.clone()))
            .await;

        let block_digest = block.digest();

        // Send our block to the core for processing.
        self.tx_loopback
            .send(block)
            .await
            .expect("Failed to send block");

        // Control system: Wait for 2f+1 nodes to acknowledge our block before continuing.
        let notify = Arc::new(Notify::new());
        let wait = notify.clone();
        {
            match self.waiting_block_list.lock().await.entry(block_digest) {
                hash_map::Entry::Occupied(mut o) => {
                    let (_, opt) = o.get_mut();
                    opt.replace(notify);
                }
                hash_map::Entry::Vacant(entry) => {
                    entry.insert((0, Some(notify)));
                }
            }
        } //release self.waiting_block_list.lock()

        wait.notified().await;
    }

    async fn run(&mut self) {
        loop {
            tokio::select! {
                Some(digest) = self.rx_mempool.recv() => {
                    //if self.buffer.len() < 155 {
                        self.buffer.insert(digest);
                    //}
                },
                Some(message) = self.rx_message.recv() => match message {
                    ProposerMessage::Make(round, qc, tc) => self.make_block(round, *qc, tc).await,
                    ProposerMessage::Cleanup(digests) => {
                        log::trace!("Proposer Cleanup  digests.len:{:?}", digests.len());
                        for x in &digests {
                            self.buffer.remove(x);
                        }
                    }
                }
            }
        }
    }
}
