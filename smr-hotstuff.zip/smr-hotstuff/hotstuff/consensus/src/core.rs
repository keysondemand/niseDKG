use crate::aggregator::Aggregator;
use crate::config::Committee;
use crate::consensus::{ConsensusMessage, Round};
use crate::error::{ConsensusError, ConsensusResult};
use crate::leader::LeaderElector;
use crate::mempool::MempoolDriver;
use crate::messages::{BlockMsg, Timeout, Vote, QC, TC};
use crate::network::ConsensusMessageSender;
use crate::proposer::ProposerMessage;
use crate::synchronizer::Synchronizer;
use crate::timer::Timer;
use async_recursion::async_recursion;
use log::{debug, error, warn};
use sign::SignatureService;
use smrcommon::config::CommmitteeConfig;
use smrcommon::config::SmrCommitteeConfig;
use socrypto::Digest as SoDigest;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sop2p::NetWorkManagerAsync;
use sosmr::DkgCommittee;
use sosmr::SmrBlock;
use sosmr::SmrDkgType;
use sosmr::SmrTransaction;
use std::cmp::max;
use std::collections::HashSet;
use std::collections::VecDeque;
use store::Store;
use tokio::sync::mpsc::{Receiver, Sender};

// #[cfg(test)]
// #[path = "tests/core_tests.rs"]
// pub mod core_tests;

pub struct Core {
    name: PublicKey,
    secret_key: SecretKey,
    dkg_committee: Option<DkgCommittee>,
    //Hask to notify when f+1 smr nodes has ended their DKG.
    //Allow to switch from Ed key to BLS with a f+1 committee.
    end_dkg_notifications: HashSet<PublicKey>,
    //Allow to switch from Ed key to BLS during the round change.
    waiting_dkg_committee: Option<DkgCommittee>,
    committee: Committee,
    committee_config: SmrCommitteeConfig,
    store: Store,
    ledger: execution::Ledger,
    signature_service: SignatureService,
    leader_elector: LeaderElector,
    mempool_driver: MempoolDriver,
    synchronizer: Synchronizer,
    rx_message: Receiver<ConsensusMessage>,
    rx_loopback: Receiver<BlockMsg>,
    tx_proposer: Sender<ProposerMessage>,
    tx_commit: Sender<SmrBlock>,
    tx_sender: Sender<SmrTransaction>,
    round: Round,
    last_voted_round: Round,
    last_committed_round: Round,
    high_qc: QC,
    timer: Timer,
    aggregator: Aggregator,
    networksender: ConsensusMessageSender,
}

impl Core {
    #[allow(clippy::too_many_arguments)]
    pub fn spawn(
        name: PublicKey,
        secret_key: SecretKey,
        committee: Committee,
        committee_config: SmrCommitteeConfig,
        signature_service: SignatureService,
        store: Store,
        ledger: execution::Ledger,
        leader_elector: LeaderElector,
        mempool_driver: MempoolDriver,
        synchronizer: Synchronizer,
        timeout_delay: u64,
        rx_message: Receiver<ConsensusMessage>,
        rx_loopback: Receiver<BlockMsg>,
        tx_proposer: Sender<ProposerMessage>,
        tx_commit: Sender<SmrBlock>,
        tx_sender: Sender<SmrTransaction>,
        network: &NetWorkManagerAsync,
    ) {
        let networksender = ConsensusMessageSender::new(network);

        tokio::spawn(async move {
            Self {
                name,
                secret_key,
                dkg_committee: None,
                end_dkg_notifications: HashSet::new(),
                waiting_dkg_committee: None,
                committee: committee.clone(),
                committee_config,
                signature_service,
                store,
                ledger,
                leader_elector,
                mempool_driver,
                synchronizer,
                rx_message,
                rx_loopback,
                tx_proposer,
                tx_commit,
                tx_sender,
                round: 1,
                last_voted_round: 0,
                last_committed_round: 0,
                high_qc: QC::genesis(),
                timer: Timer::new(timeout_delay),
                aggregator: Aggregator::new(committee),
                networksender,
            }
            .run()
            .await
        });
    }

    async fn store_msg_block(&mut self, block: &BlockMsg) {
        let key = block.digest().to_vec();
        let value = bincode::serialize(block).expect("Failed to serialize block");
        self.store.write(key, value).await;
    }

    async fn store_smr_block(&mut self, block: &SmrBlock) {
        let key = block.digest().to_vec();
        let value = bincode::serialize(block).expect("Failed to serialize block");
        self.store.write(key, value).await;
    }

    fn increase_last_voted_round(&mut self, target: Round) {
        self.last_voted_round = max(self.last_voted_round, target);
    }

    fn get_smr_dkg_committee(&self) -> Option<&CommmitteeConfig> {
        self.committee_config.get_committee_config(SmrDkgType::Smr)
    }

    async fn make_vote(&mut self, block: &BlockMsg) -> Option<Vote> {
        // Check if we can vote for this block.
        log::trace!("make_vote start round:{}", block.round);
        let safety_rule_1 = block.round > self.last_voted_round;
        let mut safety_rule_2 = block.qc.round + 1 == block.round;
        if let Some(ref tc) = block.tc {
            let mut can_extend = tc.round + 1 == block.round;
            can_extend &= block.qc.round >= *tc.high_qc_rounds().iter().max().expect("Empty TC");
            safety_rule_2 |= can_extend;
        }
        //       log::info!("make_vote {safety_rule_1} {safety_rule_2}");
        if !(safety_rule_1 && safety_rule_2) {
            return None;
        }

        log::trace!("make_vote VOTE for round:{}", block.round);
        // Ensure we won't vote for contradicting blocks.
        self.increase_last_voted_round(block.round);
        // TODO [issue #15]: Write to storage preferred_round and last_voted_round.
        match &self.dkg_committee {
            Some(committee) => Some(Vote::new_committee_signed(
                block,
                self.name,
                &committee.bls_privkey,
            )),
            None => Some(Vote::new(block, self.name, self.signature_service.clone()).await),
        }
    }

    async fn commit(&mut self, block: BlockMsg) -> ConsensusResult<()> {
        debug!("Core commit round:{:?}", block.round);
        if self.last_committed_round >= block.round {
            // warn!(
            //     "Core commit self.last_committed_round:{} >= block.round :{}",
            //     self.last_committed_round, block.round
            // );
            return Ok(());
        }

        // Ensure we commit the entire chain. This is needed after view-change.
        let mut to_commit = VecDeque::new();
        let mut parent = block.clone();
        while self.last_committed_round + 1 < parent.round {
            let ancestor = self
                .synchronizer
                .get_parent_block(&parent)
                .await?
                .expect("We should have all the ancestors by now");
            to_commit.push_front(ancestor.clone());
            parent = ancestor;
        }
        to_commit.push_front(block.clone());

        // Save the last committed block.
        self.last_committed_round = block.round;

        // Send all the newly committed blocks to the node's application layer.
        while let Some(block) = to_commit.pop_back() {
            let smr_block = match block.convert_to_supra_types(&mut self.store).await {
                Ok(b) => b,
                Err(err) => {
                    //this error should never occurs with SMR processed blocks.
                    log::error!("Error during message block convertion to sosmr :{}", err);
                    continue;
                }
            };
            execution::execute_block(
                &smr_block,
                &mut self.store,
                &mut self.ledger,
                &self.committee_config,
                &self.tx_sender,
                &self.secret_key,
                &mut self.end_dkg_notifications,
            )
            .await;
            debug!("commit block Committed {:?}", smr_block);
            // if smr_block.qc.bls_signature.is_some() {
            //     log::info!("block hash {}", hex::encode(smr_block.qc.digest().0));
            //     log::info!(
            //         "block signature {}",
            //         smr_block
            //             .qc
            //             .bls_signature
            //             .as_ref()
            //             .map(|sign| hex::encode(sign.into_bytes()))
            //             .unwrap_or(String::new())
            //     );
            // }
            //update bloc in the store to be retrieve from rpc layer.
            self.store_smr_block(&smr_block).await;
            if let Err(e) = self.tx_commit.send(smr_block).await {
                warn!("Failed to send block through the commit channel: {}", e);
            }
            //debug!("commit end ");
        }
        Ok(())
    }

    fn update_high_qc(&mut self, qc: &QC) {
        if qc.round > self.high_qc.round {
            self.high_qc = qc.clone();
        }
    }

    async fn local_timeout_round(&mut self) -> ConsensusResult<()> {
        warn!(
            "local_timeout_round Timeout reached for round {} node:{}",
            self.round, self.name
        );

        // Increase the last voted round.
        self.increase_last_voted_round(self.round);

        // Make a timeout message.
        let timeout = Timeout::new(
            self.high_qc.clone(),
            self.round,
            self.name,
            self.signature_service.clone(),
        )
        .await;

        // Make a timeout message.
        // let timeout = Timeout::new(
        //     self.high_qc.clone(),
        //     self.round,
        //     self.name,
        //     self.signature_service.clone(),
        // )
        // .await;
        debug!("Created timeout{:?}", timeout);

        // Reset the timer.
        self.timer.reset();

        // Broadcast the timeout message.
        debug!("Core Broadcasting Timeout {:?}", timeout);

        self.networksender
            .broadcast_consensus_message(ConsensusMessage::Timeout(timeout.clone()))
            .await;

        // Process our message.
        self.handle_timeout(&timeout).await
    }

    #[async_recursion]
    async fn handle_vote(&mut self, vote: &Vote) -> ConsensusResult<()> {
        debug!("Core handle_vote Processing {:?}", vote);
        if vote.round < self.round {
            // warn!(
            //     "Core handle_vote vote.round:{} < self.round:{} ",
            //     vote.round, self.round
            // );
            return Ok(());
        }

        // Ensure the vote is well formed.
        vote.verify_vote(&self.committee, self.dkg_committee.as_ref())?;

        // Add the new vote to our aggregator and see if we have a quorum.
        let dkg_threshold_f = self
            .get_smr_dkg_committee()
            .map(|c| c.threshold_f)
            .unwrap_or(0);
        if let Some(qc) = self
            .aggregator
            .add_vote(vote.clone(), self.dkg_committee.as_ref(), dkg_threshold_f)
            .await?
        {
            debug!("Assembled {:?}", qc);

            // Process the QC.
            self.process_qc(&qc).await;

            // Make a new block if we are the next leader.
            if self.name == self.leader_elector.get_leader(self.round) {
                self.generate_proposal(None).await;
            }
        }
        Ok(())
    }

    async fn handle_timeout(&mut self, timeout: &Timeout) -> ConsensusResult<()> {
        log::info!(
            "Core handle_timeout Processing {:?} current round:{}",
            timeout,
            self.round
        );
        if timeout.round < self.round {
            // warn!(
            //     "Core handle_timeout timeout.round:{} < self.round:{} ",
            //     timeout.round, self.round
            // );
            return Ok(());
        }

        // Ensure the timeout is well formed.
        timeout.verify(&self.committee, self.dkg_committee.as_ref())?;

        // Process the QC embedded in the timeout.
        self.process_qc(&timeout.high_qc).await;

        // Add the new vote to our aggregator and see if we have a quorum.
        if let Some(tc) = self.aggregator.add_timeout(timeout.clone())? {
            debug!("Assembled {:?}", tc);

            // Try to advance the round.
            self.advance_round(tc.round).await;

            // Broadcast the TC.
            debug!("Broadcasting {:?}", tc);
            self.networksender
                .broadcast_consensus_message(ConsensusMessage::TC(tc.clone()))
                .await;

            // Make a new block if we are the next leader.
            if self.name == self.leader_elector.get_leader(self.round) {
                self.generate_proposal(Some(tc)).await;
            }
        }
        Ok(())
    }

    #[async_recursion]
    async fn advance_round(&mut self, round: Round) {
        if round < self.round {
            // warn!(
            //     "Core advance_round round:{} < self.round:{} ",
            //     round, self.round
            // );
            return;
        }
        // Reset the timer and advance round.
        self.timer.reset();
        self.round = round + 1;
        debug!("Moved to round {}", self.round);

        // Cleanup the vote aggregator.
        self.aggregator.cleanup(&self.round);

        //switch keys when the f+1 DKG confirmation has arrived.
        if self.waiting_dkg_committee.is_some()
        //TODO desactivate for test
        //&& self.end_dkg_notifications.len() >= self.committee.quorum_threshold() as usize
        //as sr node don't manage timeout recovery, wait that all node ready to switch
        && self.end_dkg_notifications.len() >= self.committee.authorities.len()
        {
            log::info!("Core switch to committee sign at round:{}", self.round);
            self.dkg_committee = self.waiting_dkg_committee.take();
            self.end_dkg_notifications.clear();
        }
    }

    #[async_recursion]
    async fn generate_proposal(&mut self, tc: Option<TC>) {
        log::debug!("Core generate_proposal round");
        self.tx_proposer
            .send(ProposerMessage::Make(
                self.round,
                Box::new(self.high_qc.clone()),
                tc,
            ))
            .await
            .expect("Failed to send message to proposer");
    }

    async fn cleanup_proposer(&mut self, b0: &BlockMsg, b1: &BlockMsg, block: &BlockMsg) {
        log::debug!(
            "Core cleanup_proposer b0:{} b1:{} block:{}",
            b0.round,
            b1.round,
            block.round
        );
        let digests = b0
            .payload
            .iter()
            .cloned()
            .chain(b1.payload.iter().cloned())
            .chain(block.payload.iter().cloned())
            .collect();
        self.tx_proposer
            .send(ProposerMessage::Cleanup(digests))
            .await
            .expect("Failed to send message to proposer");
    }

    async fn process_qc(&mut self, qc: &QC) {
        log::debug!("Core process_qc qc round:{}", qc.round);
        self.advance_round(qc.round).await;
        self.update_high_qc(qc);
    }

    #[async_recursion]
    async fn process_block(&mut self, block: &BlockMsg) -> ConsensusResult<()> {
        //tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;
        log::trace!(
            "Core process_block Make proposal for block round{:?}",
            block.round
        );

        // Let's see if we have the last three ancestors of the block, that is:
        //      b0 <- |qc0; b1| <- |qc1; block|
        // If we don't, the synchronizer asks for them to other nodes. It will
        // then ensure we process both ancestors in the correct order, and
        // finally make us resume processing this block.
        let (b0, b1) = match self.synchronizer.get_ancestors(block).await? {
            Some(ancestors) => ancestors,
            None => {
                debug!("Processing of {} suspended: missing parent", block.digest());
                return Ok(());
            }
        };

        // Store the block only if we have already processed all its ancestors.
        self.store_msg_block(block).await;

        self.cleanup_proposer(&b0, &b1, block).await;

        // Check if we can commit the head of the 2-chain.
        // Note that we commit blocks only if we have all its ancestors.
        if b0.round + 1 == b1.round {
            self.mempool_driver.cleanup(b0.round).await;
            self.commit(b0).await?;
        }

        // Ensure the block's round is as expected.
        // This check is important: it prevents bad leaders from producing blocks
        // far in the future that may cause overflow on the round number.
        if block.round != self.round {
            return Ok(());
        }

        // See if we can vote for this block.
        if let Some(vote) = self.make_vote(block).await {
            debug!("Created  vote {:?}", vote);
            let next_leader = self.leader_elector.get_leader(self.round + 1);
            if next_leader == self.name {
                self.handle_vote(&vote).await?;
            } else {
                debug!("Sending {:?} to {}", vote, next_leader);
                self.networksender
                    .broadcast_consensus_message(ConsensusMessage::Vote(vote))
                    .await;
            }
        }
        Ok(())
    }

    async fn handle_proposal(&mut self, block: &BlockMsg) -> ConsensusResult<()> {
        log::trace!("Core handle_proposal block round:{:?}", block.round);
        let digest = block.digest();

        // Ensure the block proposer is the right leader for the round.
        ensure!(
            block.author == self.leader_elector.get_leader(block.round),
            ConsensusError::WrongLeader {
                digest,
                leader: block.author,
                round: block.round
            }
        );

        // Check the block is correctly formed.
        block.verify(&self.committee, self.dkg_committee.as_ref())?;

        // Process the QC. This may allow us to advance round.
        self.process_qc(&block.qc).await;

        // Process the TC (if any). This may also allow us to advance round.
        if let Some(ref tc) = block.tc {
            self.advance_round(tc.round).await;
        }

        // Let's see if we have the block's data. If we don't, the mempool
        // will get it and then make us resume processing this block.
        if !self.mempool_driver.verify(block.clone()).await? {
            warn!("Processing of {} suspended: missing payload", digest);
            return Ok(());
        }

        // All check pass, we can process this block.
        self.process_block(block).await
    }

    async fn handle_tc(&mut self, tc: TC) -> ConsensusResult<()> {
        self.advance_round(tc.round).await;
        if self.name == self.leader_elector.get_leader(self.round) {
            self.generate_proposal(Some(tc)).await;
        }
        Ok(())
    }

    pub async fn run(&mut self) {
        // Upon booting, generate the very first block (if we are the leader).
        // Also, schedule a timer in case we don't hear from the leader.
        self.timer.reset();
        if self.name == self.leader_elector.get_leader(self.round) {
            self.generate_proposal(None).await;
        }

        // This is the main loop: it processes incoming blocks and votes,
        // and receive timeout notifications from our Timeout Manager.
        loop {
            let result = tokio::select! {
                Some(message) = self.rx_message.recv() => {
                    log::debug!("Core loop receive msg:{message:?}");
                        match message {
                            ConsensusMessage::Propose(block) => self.handle_proposal(&block).await,
                            ConsensusMessage::Vote(vote) => self.handle_vote(&vote).await,
                            ConsensusMessage::Timeout(timeout) => self.handle_timeout(&timeout).await,
                            ConsensusMessage::TC(tc) => self.handle_tc(tc).await,
                            ConsensusMessage::DkgCommittee(committee) => {
                                log::info!("Core loop receive DkgCommittee at round:{}", self.round);
                                self.waiting_dkg_committee = Some(committee); //switch must be done during round change.
                                Ok(())
                            },
                            _ => panic!("Unexpected protocol message")
                        }
                    },
                Some(block) = self.rx_loopback.recv() => {
                    log::debug!("Core loop process_block :{}", block.round);
                    self.process_block(&block).await
                },
                () = &mut self.timer => self.local_timeout_round().await,
            };
            match result {
                Ok(()) => (),
                Err(ConsensusError::StoreError(e)) => error!("{}", e),
                Err(ConsensusError::SerializationError(e)) => error!("Store corrupted. {}", e),
                Err(e) => warn!(" Core: {}", e),
            }
            tokio::time::sleep(core::time::Duration::from_millis(10)).await;
        }
    }
}
