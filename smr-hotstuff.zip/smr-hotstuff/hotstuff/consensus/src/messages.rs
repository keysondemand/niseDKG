use crate::config::Committee;
use crate::consensus::Round;
use crate::error::{ConsensusError, ConsensusResult};
use serde::{Deserialize, Serialize};
use sha3::{Digest as Sha3Digest, Keccak256};
use sign::SignatureService;
use socrypto::SupraCryptoError;
use socrypto::{Digest as SoDigest, Hash, PublicKey, Signature};
use sodkg::BlsPrivateKey;
use sodkg::BlsSignature;
use sosmr::DkgCommittee;
use sosmr::SmrBatch;
use sosmr::SmrQCSignature;
use sosmr::SmrTransactionProtocol;
use sosmr::{SmrBlock, SmrQC, SmrTC};
use std::collections::HashSet;
use std::fmt;
use std::time::{SystemTime, UNIX_EPOCH};

// #[cfg(test)]
// #[path = "tests/messages_tests.rs"]
// pub mod messages_tests;

#[derive(Serialize, Deserialize, Default, Clone)]
pub struct BlockMsg {
    pub qc: QC,
    pub tc: Option<TC>,
    pub author: PublicKey,
    pub round: Round,
    pub payload: Vec<Hash>,
    pub signature: Signature,
    pub timestamp: u128,
}

impl BlockMsg {
    pub async fn new(
        qc: QC,
        tc: Option<TC>,
        author: PublicKey,
        round: Round,
        payload: Vec<Hash>,
        mut signature_service: SignatureService,
    ) -> Self {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis();
        let block = Self {
            qc,
            tc,
            author,
            round,
            payload,
            timestamp,
            signature: Signature::default(),
        };
        let signature = signature_service.request_signature(block.digest()).await;
        Self { signature, ..block }
    }

    pub fn genesis() -> Self {
        BlockMsg::default()
    }

    pub fn parent(&self) -> Hash {
        self.qc.hash
    }

    pub fn verify(
        &self,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
    ) -> ConsensusResult<()> {
        // Ensure the authority has voting rights.
        let voting_rights = committee.stake(&self.author);

        if voting_rights == 0 {
            log::warn!("Core UnknownAuthority error voting_rights == 0 during verify. committee:{committee:?} dkg_committee:{dkg_committee:?}");
        }
        ensure!(
            voting_rights > 0,
            ConsensusError::UnknownAuthority(self.author)
        );

        // Check the signature.
        Signature::verify(&self.digest(), &self.signature, &self.author)?;

        // Check the embedded QC.
        if self.qc != QC::genesis() {
            self.qc.verify(committee, dkg_committee)?;
        }

        // Check the TC embedded in the block (if any).
        if let Some(ref tc) = self.tc {
            tc.verify(committee)?;
        }
        Ok(())
    }

    pub async fn convert_to_supra_types(
        self,
        store: &mut store::Store,
    ) -> Result<SmrBlock, ConsensusError> {
        //extract protocol from all batch
        //TODO optimize this part to avoid to get batch from store to retrieve the protocol.
        let mut smr_payload: Vec<(SmrTransactionProtocol, Hash)> = vec![];
        for key in self.payload.into_iter() {
            let batch = match store.read(key.to_vec()).await {
                Ok(Some(bytes)) => SmrBatch::try_from(bytes.to_vec()).map_err(|err| {
                    ConsensusError::SmrStructConversionError(format!(
                        "Error during deserializing batch from store err:{}",
                        err
                    ))
                })?,
                _ => {
                    return Err(ConsensusError::SmrStructConversionError(
                        "Error during get batch from store err:{}".to_string(),
                    ))
                }
            };
            smr_payload.push((batch.protocol, key));
        }

        Ok(SmrBlock {
            qc: self.qc.convert_to_supra_types(),
            tc: self.tc.map(|tc| tc.convert_to_supra_types()),
            author: self.author,
            round: self.round,
            payload: smr_payload,
            timestamp: self.timestamp,
            signature: self.signature,
        })
    }
}

impl SoDigest for BlockMsg {
    fn digest(&self) -> Hash {
        let mut block_hasher = Keccak256::new();

        block_hasher.update(self.round.to_be_bytes());
        block_hasher.update(self.timestamp.to_be_bytes());
        block_hasher.update(self.author.0);
        //binserialize and hash the QC or the TC if some.
        block_hasher.update(QC::digest(&self.qc).0);
        //add batch hash
        let mut batches_hasher = Keccak256::new();
        for batch in &self.payload {
            batches_hasher.update(batch);
        }
        let hash = <[u8; 32]>::from(batches_hasher.finalize());
        block_hasher.update(hash);

        socrypto::Hash(<[u8; 32]>::from(block_hasher.finalize()))

        // let mut hasher = Sha512::new();
        // hasher.update(self.author.0);
        // hasher.update(self.round.to_le_bytes());
        // for x in &self.payload {
        //     hasher.update(x);
        // }
        // hasher.update(&self.qc.hash);
        // Hash(hasher.finalize().as_slice()[..32].try_into().unwrap())
    }
}

impl fmt::Debug for BlockMsg {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(
            f,
            "{}: B({}, {}, {:?}, {})",
            self.digest(),
            self.author,
            self.round,
            self.qc,
            self.payload.iter().map(|x| x.size()).sum::<usize>(),
        )
    }
}

impl fmt::Display for BlockMsg {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "B{}", self.round)
    }
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub enum VoteSignature {
    Ed25519(Signature),
    Commitee(Box<BlsSignature>),
}

impl VoteSignature {
    pub fn is_bls_vote(&self) -> bool {
        match self {
            VoteSignature::Ed25519(_) => false,
            VoteSignature::Commitee(_) => true,
        }
    }

    pub fn get_ed25519_signature(&self) -> Option<&Signature> {
        match self {
            VoteSignature::Commitee(_) => None,
            VoteSignature::Ed25519(sign) => Some(sign),
        }
    }

    pub fn get_bls_signature(&self) -> Option<&BlsSignature> {
        match self {
            VoteSignature::Commitee(sign) => Some(sign),
            VoteSignature::Ed25519(_) => None,
        }
    }
    pub fn consume_bls_signature(self) -> Option<BlsSignature> {
        match self {
            VoteSignature::Commitee(sign) => Some(*sign),
            VoteSignature::Ed25519(_) => None,
        }
    }

    pub fn verify_sign(
        &self,
        author: PublicKey,
        message_digest: Hash,
        dkg_committee: Option<&DkgCommittee>,
    ) -> Result<(), SupraCryptoError> {
        // Check the signature.
        match self {
            VoteSignature::Ed25519(signature) => {
                //log::info!("vote verify_sign Ed25519");
                Signature::verify(&message_digest, signature, &author)?
            }
            VoteSignature::Commitee(blssignature) => {
                //log::info!("vote verify_sign blssignature");
                dkg_committee
                    .and_then(|committee| committee.get_member(author))
                    .and_then(|n| n.public_share.as_ref())
                    .map(|pks| {
                        pks.verify_chain(&message_digest.into_bytes(), blssignature)
                            .then_some(())
                    })
                    .ok_or(SupraCryptoError::VerifySignError(author))?;
            }
        };
        Ok(())
    }
}

impl Default for VoteSignature {
    fn default() -> Self {
        VoteSignature::Ed25519(Signature::default())
    }
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Vote {
    pub hash: Hash,
    pub round: Round,
    pub author: PublicKey,
    pub signature: VoteSignature,
}

impl Vote {
    pub async fn new(
        block: &BlockMsg,
        author: PublicKey,
        mut signature_service: SignatureService,
    ) -> Self {
        let vote = Self {
            hash: block.digest(),
            round: block.round,
            author,
            signature: VoteSignature::default(),
        };
        let signature =
            VoteSignature::Ed25519(signature_service.request_signature(vote.digest()).await);
        Self { signature, ..vote }
    }

    pub fn new_committee_signed(
        block: &BlockMsg,
        author: PublicKey,
        secret_share: &BlsPrivateKey,
    ) -> Self {
        let vote = Self {
            hash: block.digest(),
            round: block.round,
            author,
            signature: VoteSignature::default(),
        };
        let signature = VoteSignature::Commitee(Box::new(
            secret_share.sign_chain(&vote.digest().into_bytes()),
        ));
        Self { signature, ..vote }
    }

    pub fn verify_vote(
        &self,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
    ) -> ConsensusResult<()> {
        // Ensure the authority has voting rights.
        ensure!(
            committee.stake(&self.author) > 0,
            ConsensusError::UnknownAuthority(self.author)
        );

        self.signature
            .verify_sign(self.author, self.digest(), dkg_committee)?;
        Ok(())
    }
}

impl SoDigest for Vote {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.hash);
        hasher.update(self.round.to_le_bytes());
        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))

        // let mut hasher = Sha512::new();
        // hasher.update(&self.hash);
        // hasher.update(self.round.to_le_bytes());
        // Hash(hasher.finalize().as_slice()[..32].try_into().unwrap())
    }
}

impl fmt::Debug for Vote {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "V({}, {}, {})", self.author, self.round, self.hash)
    }
}

#[derive(Clone, Serialize, Deserialize, Default)]
pub struct QC {
    hash: Hash,
    pub round: Round,
    pub signature: SmrQCSignature,
}

impl QC {
    pub fn genesis() -> Self {
        QC::default()
    }

    pub fn timeout(&self) -> bool {
        self.hash == Hash::default() && self.round != 0
    }

    pub fn verify(
        &self,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
    ) -> ConsensusResult<()> {
        // Ensure the QC has a quorum.
        let mut weight = 0;
        let mut used = HashSet::new();

        //build node list and stake to verify vote volume.
        let votes: Vec<(PublicKey, u32)> = match &self.signature {
            SmrQCSignature::Ed25519Vote(pk_list) => pk_list
                .iter()
                .map(|(pk, _)| (*pk, committee.stake(pk)))
                .collect(),
            SmrQCSignature::BlsThresholdSignature(_, nodes) => {
                nodes.iter().map(|pk| (*pk, 1)).collect()
            }
        };

        let votes_len = votes.len();
        for (name, voting_rights) in votes {
            ensure!(!used.contains(&name), ConsensusError::AuthorityReuse(name));
            ensure!(voting_rights > 0, ConsensusError::UnknownAuthority(name));
            used.insert(name);
            weight += voting_rights;
        }

        if weight < committee.quorum_threshold() {
            log::warn!("QCRequiresQuorum error weight:{weight} committee.quorum_threshold():{} votes.len:{}", committee.quorum_threshold(), votes_len);
        }
        ensure!(
            weight >= committee.quorum_threshold(),
            ConsensusError::QCRequiresQuorum
        );

        // Check the signatures.
        self.signature
            .verify_signature(
                self.digest(),
                dkg_committee.as_ref().map(|c| &c.threshold_pubkey),
            )
            .map_err(ConsensusError::from)
    }

    pub fn sign_committee_votes(
        hash: Hash,
        round: Round,
        votes: Vec<(PublicKey, VoteSignature)>,
        dkg_committee: Option<&DkgCommittee>,
        threshold_f: usize,
    ) -> ConsensusResult<QC> {
        if votes.is_empty() {
            return Ok(QC {
                hash,
                round,
                signature: SmrQCSignature::Ed25519Vote(vec![]),
            });
        }

        //if committee is present with BLS vote
        //Committee are updated and vote arrive one block after.
        let signature = match (dkg_committee, votes[0].1.is_bls_vote()) {
            (Some(committee), true) => {
                let nodes = votes.iter().map(|(pk, _)| *pk).collect();
                let pk_signs: Vec<(PublicKey, BlsSignature)> = votes
                    .into_iter()
                    .filter_map(|(pk, vote)| vote.consume_bls_signature().map(|s| (pk, s)))
                    .collect();
                let bls = committee
                    .create_committeesign_with_partial_sign(pk_signs, threshold_f)
                    .map_err(|err| ConsensusError::VoteThresholdSignError(err.to_string()))?;
                SmrQCSignature::BlsThresholdSignature(bls, nodes)
            }
            (_, _) => {
                let votes = votes
                    .into_iter()
                    .filter_map(|(pk, vote)| match vote {
                        VoteSignature::Ed25519(sign) => Some((pk, sign)),
                        VoteSignature::Commitee(_) => None,
                    })
                    .collect();
                SmrQCSignature::Ed25519Vote(votes)
            }
        };

        Ok(QC {
            hash,
            round,
            signature,
        })
    }

    pub fn convert_to_supra_types(self) -> SmrQC {
        SmrQC {
            hash: self.hash,
            round: self.round,
            signature: self.signature,
        }
    }
}

impl SoDigest for QC {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.hash);
        hasher.update(self.round.to_le_bytes());
        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))

        // let mut hasher = Sha512::new();
        // hasher.update(&self.hash);
        // hasher.update(self.round.to_le_bytes());
        // Hash(hasher.finalize().as_slice()[..32].try_into().unwrap())
    }
}

impl fmt::Debug for QC {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "QC({}, {})", self.hash, self.round)
    }
}

impl PartialEq for QC {
    fn eq(&self, other: &Self) -> bool {
        self.hash == other.hash && self.round == other.round
    }
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Timeout {
    pub high_qc: QC,
    pub round: Round,
    pub author: PublicKey,
    pub signature: Signature,
}

impl Timeout {
    pub async fn new(
        high_qc: QC,
        round: Round,
        author: PublicKey,
        mut signature_service: SignatureService,
    ) -> Self {
        let timeout = Self {
            high_qc,
            round,
            author,
            signature: Signature::default(),
        };
        let signature = signature_service.request_signature(timeout.digest()).await;
        Self {
            signature,
            ..timeout
        }
    }

    // pub fn new_committee_signed(
    //     high_qc: QC,
    //     round: Round,
    //     author: PublicKey,
    //     secret_share: &BlsPrivateKey,
    // ) -> Self {
    //     let timeout = Self {
    //         high_qc,
    //         round,
    //         author,
    //         signature: Signature::default(),
    //     };
    //     let signature =
    //         VoteSignature::Commitee(Box::new(secret_share.sign(&timeout.digest().into_bytes())));
    //     Self {
    //         signature,
    //         ..timeout
    //     }
    // }

    pub fn verify(
        &self,
        committee: &Committee,
        dkg_committee: Option<&DkgCommittee>,
    ) -> ConsensusResult<()> {
        // Ensure the authority has voting rights.
        ensure!(
            committee.stake(&self.author) > 0,
            ConsensusError::UnknownAuthority(self.author)
        );

        // Check the signature.
        Signature::verify(&self.digest(), &self.signature, &self.author)?;

        // Check the embedded QC.
        if self.high_qc != QC::genesis() {
            self.high_qc.verify(committee, dkg_committee)?;
        }
        Ok(())
    }
}

impl SoDigest for Timeout {
    fn digest(&self) -> Hash {
        let mut hasher = Keccak256::new();
        hasher.update(self.round.to_le_bytes());
        hasher.update(self.high_qc.round.to_le_bytes());
        socrypto::Hash(<[u8; 32]>::from(hasher.finalize()))
    }
}

impl fmt::Debug for Timeout {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "TV({}, {}, {:?})", self.author, self.round, self.high_qc)
    }
}

#[derive(Clone, Serialize, Deserialize)]
pub struct TC {
    pub round: Round,
    pub votes: Vec<(PublicKey, Signature, Round)>,
}

impl TC {
    pub fn verify(&self, committee: &Committee) -> ConsensusResult<()> {
        // Ensure the QC has a quorum.
        let mut weight = 0;
        let mut used = HashSet::new();
        for (name, _, _) in self.votes.iter() {
            ensure!(!used.contains(name), ConsensusError::AuthorityReuse(*name));
            let voting_rights = committee.stake(name);
            ensure!(voting_rights > 0, ConsensusError::UnknownAuthority(*name));
            used.insert(*name);
            weight += voting_rights;
        }
        ensure!(
            weight >= committee.quorum_threshold(),
            ConsensusError::TCRequiresQuorum
        );

        // Check the signatures.
        for (author, signature, high_qc_round) in &self.votes {
            let mut hasher = Keccak256::new();
            hasher.update(self.round.to_le_bytes());
            hasher.update(high_qc_round.to_le_bytes());
            let digest = socrypto::Hash(<[u8; 32]>::from(hasher.finalize()));
            Signature::verify(&digest, signature, author)?;
        }
        Ok(())
    }

    pub fn high_qc_rounds(&self) -> Vec<Round> {
        self.votes.iter().map(|(_, _, r)| r).cloned().collect()
    }

    pub fn convert_to_supra_types(self) -> SmrTC {
        SmrTC {
            round: self.round,
            votes: self.votes,
        }
    }
}

impl fmt::Debug for TC {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        write!(f, "TC({}, {:?})", self.round, self.high_qc_rounds())
    }
}
