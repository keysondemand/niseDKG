use crate::consensus::{ConsensusMessage, CHANNEL_CAPACITY};
use crate::error::ConsensusResult;
use crate::messages::{BlockMsg, QC};
use crate::network::ConsensusMessageSender;
use futures::stream::futures_unordered::FuturesUnordered;
use futures::stream::StreamExt as _;
use log::{debug, error};
use socrypto::Digest as _;
use socrypto::{Hash, PublicKey};
use sop2p::NetWorkManagerAsync;
use std::collections::{HashMap, HashSet};
use std::time::{SystemTime, UNIX_EPOCH};
use store::Store;
use tokio::sync::mpsc::{channel, Receiver, Sender};
use tokio::time::{sleep, Duration, Instant};

// #[cfg(test)]
// #[path = "tests/synchronizer_tests.rs"]
// pub mod synchronizer_tests;

const TIMER_ACCURACY: u64 = 5_000;

pub struct Synchronizer {
    store: Store,
    inner_channel: Sender<BlockMsg>,
}

impl Synchronizer {
    pub fn new(
        name: PublicKey,
        //        committee: Committee,
        store: Store,
        tx_loopback: Sender<BlockMsg>,
        sync_retry_delay: u64,
        network: &NetWorkManagerAsync,
    ) -> Self {
        let networksender = ConsensusMessageSender::new(network);
        let (tx_inner, mut rx_inner): (_, Receiver<BlockMsg>) = channel(CHANNEL_CAPACITY);

        let store_copy = store.clone();
        tokio::spawn(async move {
            let mut waiting = FuturesUnordered::new();
            let mut pending = HashSet::new();
            let mut requests = HashMap::new();

            let timer = sleep(Duration::from_millis(TIMER_ACCURACY));
            tokio::pin!(timer);
            loop {
                tokio::select! {
                    Some(block) = rx_inner.recv() => {
                        if pending.insert(block.digest()) {
                            let parent = block.parent();
                            let _author = block.author;
                            let fut = Self::waiter(store_copy.clone(), parent, block);
                            waiting.push(fut);

                            if let std::collections::hash_map::Entry::Vacant(e) = requests.entry(parent) {
                                 debug!("Requesting sync for block {}", parent);
                                 let now = SystemTime::now()
                                     .duration_since(UNIX_EPOCH)
                                     .expect("Failed to measure time")
                                     .as_millis();
                                 e.insert(now);
                                 let message = ConsensusMessage::SyncRequest(parent, name);
                                 networksender.broadcast_consensus_message( message).await;
                            }
                        }
                    },
                    Some(result) = waiting.next() => match result {
                        Ok(block) => {
                            let _ = pending.remove(&block.digest());
                            let _ = requests.remove(&block.parent());
                            if let Err(e) = tx_loopback.send(block).await {
                                panic!("Failed to send message through core channel: {}", e);
                            }
                        },
                        Err(e) => error!("{}", e)
                    },
                    () = &mut timer => {
                        // This implements the 'perfect point to point link' abstraction.
                        for (digest, timestamp) in &requests {
                            let now = SystemTime::now()
                                .duration_since(UNIX_EPOCH)
                                .expect("Failed to measure time")
                                .as_millis();
                            if timestamp + (sync_retry_delay as u128) < now {
                                debug!("Requesting sync for block {} (retry)", digest);
                                let message = ConsensusMessage::SyncRequest(*digest, name);
                                networksender.broadcast_consensus_message( message).await;
                            }
                        }
                        timer.as_mut().reset(Instant::now() + Duration::from_millis(TIMER_ACCURACY));
                    }
                }
            }
        });
        Self {
            store,
            inner_channel: tx_inner,
        }
    }

    async fn waiter(
        mut store: Store,
        wait_on: Hash,
        deliver: BlockMsg,
    ) -> ConsensusResult<BlockMsg> {
        let _ = store.notify_read(wait_on.to_vec()).await?;
        Ok(deliver)
    }

    pub async fn get_parent_block(
        &mut self,
        block: &BlockMsg,
    ) -> ConsensusResult<Option<BlockMsg>> {
        if block.qc == QC::genesis() {
            return Ok(Some(BlockMsg::genesis()));
        }
        let parent = block.parent();
        match self.store.read(parent.to_vec()).await? {
            Some(bytes) => Ok(Some(bincode::deserialize(&bytes)?)),
            None => {
                if let Err(e) = self.inner_channel.send(block.clone()).await {
                    panic!("Failed to send request to synchronizer: {}", e);
                }
                Ok(None)
            }
        }
    }

    pub async fn get_ancestors(
        &mut self,
        block: &BlockMsg,
    ) -> ConsensusResult<Option<(BlockMsg, BlockMsg)>> {
        let b1 = match self.get_parent_block(block).await? {
            Some(b) => b,
            None => return Ok(None),
        };
        let b0 = self
            .get_parent_block(&b1)
            .await?
            .unwrap_or_else(|| panic!("We should have all ancestors of delivered blocks for block parent round:{} timestamp:{}", b1.round, b1.timestamp));
        Ok(Some((b0, b1)))
    }
}
