use log::info;
use serde::{Deserialize, Serialize};
use socrypto::PublicKey;
use sop2p::PeerInfo;
use std::collections::HashMap;

pub type Stake = u32;
pub type EpochNumber = u128;

#[derive(Debug, Serialize, Deserialize)]
pub struct Parameters {
    pub timeout_delay: u64,
    pub sync_retry_delay: u64,
}

impl Default for Parameters {
    fn default() -> Self {
        Self {
            timeout_delay: 3_000,
            sync_retry_delay: 10_000,
        }
    }
}

impl Parameters {
    pub fn log(&self) {
        // NOTE: These log entries are used to compute performance.
        info!("Timeout delay set to {} rounds", self.timeout_delay);
        info!("Sync retry delay set to {} ms", self.sync_retry_delay);
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Authority {
    pub stake: Stake,
    pub peer: PeerInfo,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Committee {
    pub authorities: HashMap<PublicKey, Authority>,
    pub epoch: EpochNumber,
}

impl Committee {
    pub fn new(info: Vec<(PeerInfo, Stake)>, epoch: EpochNumber) -> Self {
        Self {
            authorities: info
                .into_iter()
                .map(|(peer, stake)| {
                    let htpubkey = PublicKey(peer.pubkey.0);
                    let authority = Authority { stake, peer };
                    (htpubkey, authority)
                })
                .collect(),
            epoch,
        }
    }

    pub fn size(&self) -> usize {
        self.authorities.len()
    }

    pub fn stake(&self, name: &PublicKey) -> Stake {
        self.authorities.get(name).map_or_else(|| 0, |x| x.stake)
    }

    pub fn quorum_threshold(&self) -> Stake {
        // If N = 3f + 1 + k (0 <= k < 3)
        // then (2 N + 3) / 3 = 2f + 1 + (2k + 2)/3 = 2f + 1 + k = N - f
        let total_votes: Stake = self.authorities.values().map(|x| x.stake).sum();
        2 * total_votes / 3 + 1
    }

    pub fn peer(&self, name: &PublicKey) -> Option<PeerInfo> {
        self.authorities.get(name).map(|x| x.peer.clone())
    }

    pub fn others_committee_peers(&self, myself: &PublicKey) -> Vec<PeerInfo> {
        self.authorities
            .iter()
            .filter(|(name, _)| name != &myself)
            .map(|(_, x)| x.peer.clone())
            .collect()
    }
}
