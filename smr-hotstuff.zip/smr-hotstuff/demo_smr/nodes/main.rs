//to run: RUST_BACKTRACE=1 RUST_LOG=info cargo run --release

use consensus::Committee as ConsensusCommittee;
use futures::future::join_all;
use log::error;
use mempool::Committee as MempoolCommittee;
use node::bftnode::BftNode;
//use node::node::Node;
use smrcommon::config::SmrCommitteeConfig;
use smrcommon::dkg::read_dkg_definition;
use smrcommon::NodeDefinition;
use smrcommon::SmrDkgCommitteeDefinition;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::ElGamalPrivateKey;
use sodkg::ElGamalPubKey;
use sop2p::NetWorkManagerAsync;
use sop2p::NetworkEventReceiver;
use sop2p::PeerInfo;
use sosmr::SmrDkgType;
//use std::alloc::System;
use std::fs;
use std::net::Ipv4Addr;
use std::net::SocketAddr;
use tokio::task::JoinHandle;

//use alloc_track::{AllocTrack, BacktraceMode};

const NB_CONNECTED_PEERS: usize = 5;
const THREASHOLD_FPLUS1: usize = 4;

// #[global_allocator]
// static GLOBAL_ALLOC: AllocTrack<System> = AllocTrack::new(System, BacktraceMode::Short);

// #[cfg(feature = "dhat-heap")]
// #[global_allocator]
// static ALLOC: dhat::Alloc = dhat::Alloc;

// fn main() {
//     #[cfg(feature = "dhat-heap")]
//     let profiler = dhat::Profiler::new_heap();

//     console_subscriber::init();

//     main2();
//     #[cfg(feature = "dhat-heap")]
//     drop(profiler);
//     std::process::exit(0x0100);
// }

#[tokio::main]
async fn main() {
    env_logger::init();

    let bind_ip = Ipv4Addr::new(127, 0, 0, 1); //Ipv4Addr::LOCALHOST
    let bootstrap_ip = SocketAddr::from((bind_ip, 25_100));

    let mut nodes_list = vec![];
    let mut nodes_definition_list = vec![];

    //add SMR committee definition
    for i in 0..NB_CONNECTED_PEERS {
        let secret_key = SecretKey::generate();
        let ip = SocketAddr::from((bind_ip, (25_100 + i) as u16));
        let publickey = PublicKey::try_from(&secret_key).unwrap(); //should not panic other the node should stop.
        let bootstrap = if i == 0 { None } else { Some(bootstrap_ip) };

        let elgamal_key = ElGamalPrivateKey::generate();
        // println!(
        //     "node:{publickey} elgamal_key private key:{}",
        //     hex::encode(elgamal_key.into_bytes())
        // );

        let elgamal_pubkey = ElGamalPubKey::try_from(&elgamal_key).unwrap();
        // println!(
        //     "node:{publickey} elgamal_key public key:{}",
        //     hex::encode(elgamal_pubkey.into_bytes())
        // );

        nodes_list.push((
            ip,
            SocketAddr::from((bind_ip, (25_000 + i) as u16)),
            secret_key,
            bootstrap,
            elgamal_key,
        ));
        //node definition

        let node_definition = NodeDefinition::try_from((publickey, elgamal_pubkey)).unwrap();
        //        log::info!("node definition:{:?}", node_definition);
        nodes_definition_list.push(node_definition);
    }

    // //Add test VRF definition
    // let public1 = "3910a434e1313322a44898d18ff793fdf733255dfea62e5b8d4837b10b48fcf0";
    // // let elgamal_priv_bytes1="00000000000000000000000000000000048210608fc07024ac709d55b6212d9643343cd213ce8172860d6fab7609f79a2d2a61fe35f3aa9630bcb0f770dc0929d1f31e01afee41a640ce200ff148e3f3";
    // //let bytes: &[u8] = &hex::decode(elgamal_priv_bytes1).unwrap();
    // //let elgamal_priv1 = ElGamalPrivateKey::try_from(bytes).unwrap();
    // //println!("elgamal_priv1 {}", elgamal_priv1.encode_base64());
    // let elgamal_public1 = "021380d4d4de6021f5bd8fbba009ec27efcbcf8d86115b75f0727b2ad3c6d61ac94b50be439fd7c221f720fbaa0a029bb4030f8b9f119ae546c1beb4494bef22b50ca2a5ff55137bdcc5956607976c387f1a735d4d89fe5f1c6fd4b208577d11e3a50000000000000000000000000000000035b0fdf3a960f3857ff806ad5e9f5fd26f8818440bfcd0e01e148b3695f9f09500000000000000000000000000000000699fdbbf6276b366f25b8b84687b429ccac040f952ef133bcc377023f27449110205264ef445dbf4538828f0490b4017592c56e514e3df0fd97ab7eb87c5f2f781030a35da16cc98beb50a7dc0ff46ce1ee52e6a8364b0cf9560a229b5c9a2a596b8012512dd5eff23cf8e14a720c55394d857b815ad1f5816fff3f395a94706b3ca089783b86742b3b2ffe0c0cecf8a2e9ffd0eb8255a45878e2604386696c6255a";
    // let node_definition1 = NodeDefinition {
    //     publickey: public1.to_string(),
    //     elgamal_pubkey: elgamal_public1.to_string(),
    // };

    // let public2 = "5d79a57b8d232721649d7b724d47a68a0fe6d1d834843d085362b93bd2890c97";
    // // let elgamal_priv_bytes2="0000000000000000000000000000000052dec391be7e0413fb2e25c453eec154069ffb808262e43d089c9749193ebf3800c1a96ead8949b363a6a95c4efead6c4c64b8f3eadb2f95537f68b39b24af93";
    // // let bytes: &[u8] = &hex::decode(elgamal_priv_bytes2).unwrap();
    // //let elgamal_priv2 = ElGamalPrivateKey::try_from(bytes).unwrap();
    // //println!("elgamal_priv2 {}", elgamal_priv2.encode_base64());
    // let elgamal_public2 = "021273b2f70905532715569fd66a21e610c3c7683f1a3723601992b93918565755e4175bf40696e16767ff96357ae884be0202d8d453f3d791af15917a0c5deb9a6e5b0121a541e2f6b10c040d0ba1699e871fa8ef13d66d403ad98abd798270f574000000000000000000000000000000004b6864d92dc03bc512cf240dcfaa2bbc4dea8cc69d8ea792a2099b41a02ac81a00000000000000000000000000000000062dea91b1d2ca0b6679d15d69b2fec516f626fff4b4ac6c535cdd720512e46603236820aeda6d20975c477cde3a682828380fc8c80a02c0378f2c1c281fbeaac7022b99e9627dfedf17c9ea9e2a0cee4c5fe0745bf1d1c7a888925ec3d54bba30051836f1f0c73a7567c66d72c14807661065eaaaa9c86e3a7fcef5e8af6bd2a0d310cbbd6d4c191d735136dedeb806eb65afdd464309e5ece73671083856ca23b9";
    // let node_definition2 = NodeDefinition {
    //     publickey: public2.to_string(),
    //     elgamal_pubkey: elgamal_public2.to_string(),
    // };

    // let public3 = "417ec4627e882981a8a865bda654350515067fe4b5c93cfe5accb39e74e17fe6";
    // // let elgamal_priv_bytes3="000000000000000000000000000000004f8006265aab8743335ccf5c607228d2aef96d07974b5e2de514f21ee7ab29c625a467779d334c7331be6e74ae65c56878953a61b8d06e0ff9a732a9dd788678";
    // // let bytes: &[u8] = &hex::decode(elgamal_priv_bytes3).unwrap();
    // // let elgamal_priv3 = ElGamalPrivateKey::try_from(bytes).unwrap();
    // //println!("elgamal_priv3 {}", elgamal_priv3.encode_base64());
    // let elgamal_public3 = "020038a8b65f0e36b0248f9b969eee195b8a9af831480dce3a39a257720d8afe78f83b7b894e48b57d8400d2a78af47cc103065fc76e6eac68e4702c1a7c6a116df684bce72052ef2f5849eeb4efea9543aba12936c0175e69e9a954e5b46b0eed15000000000000000000000000000000006a389ca287df4928fd227b7e1f6ef7a523d2040b26db8d26a34c6a14b2417cb9000000000000000000000000000000003b2e43936b61c0e660556727b94546eb5cc42499843d3de5f8d699f6adf8f024031a1bdafbf8c15b4767f8e92b90c223c43a018a81831a7443bb390d83041c5f4a0326096245405be8b44b2dfee91771bee1e576aebb7412b8e440fabbfe701bfcac1686b9724cc72b96c082e44123ad8c823a12b6894ec72f267097c1205cd156e51c161a1cef04e5d6733354228e03dc42d6f3009e7e8ab72ec0dd9d67a5c00d86";
    // let node_definition3 = NodeDefinition {
    //     publickey: public3.to_string(),
    //     elgamal_pubkey: elgamal_public3.to_string(),
    // };

    // let public4 = "19cf2cf5e6b9676aeb5a8605dcfe610aaa9e5bfb4c80d007d16d716a31a10559";
    // // let elgamal_priv_bytes4="0000000000000000000000000000000065bcfc65b8f26171d14045dab288b6c1feb7e166394c112d18a06f2cb46017b80e1fff2e0e30cbf5ea8793f1a650f93026b9e8495ecb534873c61fb8600b2291";
    // // let bytes: &[u8] = &hex::decode(elgamal_priv_bytes4).unwrap();
    // // let elgamal_priv4 = ElGamalPrivateKey::try_from(bytes).unwrap();
    // //println!("elgamal_priv4 {}", elgamal_priv4.encode_base64());
    // let elgamal_public4 = "0308877dd800cbc1b1b449cee0df848a6e6f7de8d38da90bcabd390e00710e9225586571a75b748bff28c40f77e9ec4dfc031436829d8057c4dc2bc85adccc30e2bfbfab9ccc8bbc67912f94e8d76e4c93d5a7f1f9b301eba455111a8f805db7793400000000000000000000000000000000097689f8bb09f0e607b1c71239fd099fced9160ac4e8f7e7034c22927b26e33e000000000000000000000000000000007252507ef3df09aa6053d1c81a7d30268cbe0c05dc21be4243d208a1885997780307692cc8610bd31a6042327722419fa39f5d3a3e26a263a7414a09e3fd4101fc030bfe52471d670fe7a8f24766628cbf2e4a9e8bd496d8282298a00bf5650d4d3c1dea9efe74e546f658a9a7621c3c74fd91245728e244e869dc3e709d2ce034f71954584e77357f51947bacccfaa37357dc319eb8368ba4ea83b424e0e33f92e4";
    // let node_definition4 = NodeDefinition {
    //     publickey: public4.to_string(),
    //     elgamal_pubkey: elgamal_public4.to_string(),
    // };

    // let vrf_node_list = vec![
    //     node_definition1,
    //     node_definition2,
    //     node_definition3,
    //     node_definition4,
    // ];

    //save definition for reuse
    let mut definitions = read_dkg_definition().unwrap();
    //remove old smr def
    definitions
        .iter()
        .position(|def| def.dkg_type == SmrDkgType::Smr)
        .map(|pos| definitions.remove(pos));
    definitions.push(SmrDkgCommitteeDefinition {
        dkg_type: SmrDkgType::Smr,
        threshold_f: THREASHOLD_FPLUS1,
        committee: nodes_definition_list,
    });

    // vec![
    //     SmrDkgCommitteeDefinition {
    //         dkg_type: SmrDkgType::Smr,
    //         threshold_f: THREASHOLD_FPLUS1,
    //         committee: nodes_definition_list,
    //     },
    //     SmrDkgCommitteeDefinition {
    //         dkg_type: SmrDkgType::Vrf,
    //         threshold_f: 3,
    //         committee: vrf_node_list,
    //     },
    // ];

    smrcommon::dkg::save_dkg_definition(&definitions).unwrap();

    //trace memory allocation for Alloc strack
    // tokio::spawn(async move {
    //     tokio::task::spawn_blocking(move || loop {
    //         std::thread::sleep(std::time::Duration::from_millis(40000));
    //         log::info!("Memeory report start");
    //         //let report = alloc_track::backtrace_report(|_, _| true);
    //         //println!("BACKTRACES\n{report}");
    //         let report = alloc_track::thread_report();
    //         println!("THREADS\n{report}");
    //         log::info!("Memeory report end");
    //     })
    //     .await
    //     .unwrap();
    // });

    //start the smr
    match start_smr_nodes(nodes_list, definitions).await {
        Ok(handles) => {
            let _ = join_all(handles).await;
            //tokio::time::sleep(tokio::time::Duration::from_millis(180000)).await;
            log::info!("end exec committee");
        }
        Err(e) => error!("Failed to deploy testbed: {}", e),
    }
}

pub async fn start_smr_nodes(
    nodes_list: Vec<(
        SocketAddr,
        SocketAddr,
        SecretKey,
        Option<SocketAddr>,
        ElGamalPrivateKey,
    )>,
    committee_definition: Vec<SmrDkgCommitteeDefinition>,
) -> Result<Vec<JoinHandle<()>>, Box<dyn std::error::Error>> {
    log::trace!("start_smr_nodes");

    let epoch = 1;
    let init_peers: Vec<(PeerInfo, u32)> = nodes_list
        .iter()
        .map(|(ip, _, sk, _, _)| {
            let stake = 1;
            (
                PeerInfo {
                    ip: *ip,
                    pubkey: PublicKey::try_from(sk).unwrap(),
                },
                stake,
            )
        })
        .collect();
    let peers: Vec<PeerInfo> = nodes_list
        .iter()
        .map(|(ip, _, sk, _, _)| PeerInfo {
            ip: *ip,
            pubkey: PublicKey::try_from(sk).unwrap(),
        })
        .collect();

    //build committee config from definition
    let committee_config: SmrCommitteeConfig = committee_definition
        .try_into()
        .expect("error during conversion of DKG definition in the config:{}");

    // let mut committee_config = SmrCommitteeConfig {
    //     committee_list: vec![],
    // };
    // //add SMR dkg config
    // let smr_nodes_config = peers
    //     .iter()
    //     .map(|peer| peer.pubkey)
    //     .map(|id| NodeConfig {
    //         id,
    //         key_pair_def: String::new(),
    //     })
    //     .collect();
    // let smrdkgconfig = CommmitteeConfig {
    //     name: sosmr::SmrDkgType::Smr,
    //     //f+1
    //     threshold_f: 3,
    //     member_list: smr_nodes_config,
    // };
    // committee_config.committee_list.push(smrdkgconfig);

    // let vrfdkgconfig = CommmitteeConfig {
    //     name: sosmr::SmrDkgType::Vrf,
    //     //f+1
    //     threshold_f: 3,
    //     member_list: vec![
    //         NodeConfig {
    //             id: PublicKey::decode_hex(
    //                 "3910a434e1313322a44898d18ff793fdf733255dfea62e5b8d4837b10b48fcf0",
    //             )
    //             .unwrap(),
    //             key_pair_def: String::new(),
    //         },
    //         NodeConfig {
    //             id: PublicKey::decode_hex(
    //                 "5d79a57b8d232721649d7b724d47a68a0fe6d1d834843d085362b93bd2890c97",
    //             )
    //             .unwrap(),
    //             key_pair_def: String::new(),
    //         },
    //         NodeConfig {
    //             id: PublicKey::decode_hex(
    //                 "417ec4627e882981a8a865bda654350515067fe4b5c93cfe5accb39e74e17fe6",
    //             )
    //             .unwrap(),
    //             key_pair_def: String::new(),
    //         },
    //         NodeConfig {
    //             id: PublicKey::decode_hex(
    //                 "19cf2cf5e6b9676aeb5a8605dcfe610aaa9e5bfb4c80d007d16d716a31a10559",
    //             )
    //             .unwrap(),
    //             key_pair_def: String::new(),
    //         },
    //     ],
    // };
    // committee_config.committee_list.push(vrfdkgconfig);

    MempoolCommittee::new(init_peers.clone(), epoch);
    ConsensusCommittee::new(init_peers.clone(), epoch);

    let nb_nodes = nodes_list.len();

    // Write the key files and spawn all nodes.
    let mut ret = vec![];
    for (i, (node_ip, tx_ip, secret, bootstrap, node_elgamal_secret_key)) in
        nodes_list.into_iter().enumerate()
    {
        let committee = peers.clone();

        let store_path = format!("db_{}", i);
        let ledger_path = format!("ledger_{}", i);
        let str_db_path = format!("{}.persy", store_path);
        let _ = fs::remove_file(&str_db_path);
        let str_db_path = format!("{}.persy", ledger_path);
        let _ = fs::remove_file(&str_db_path);

        //panic!("tutu:{}", str_db_path);

        log::trace!("start network bootstrap:{bootstrap:?}");
        let network = sop2p::new_async(node_ip, node_ip, secret.clone(), bootstrap)
            .await
            .unwrap();

        let start_receiver = network.subscribe_to_event();

        let concensus_receiver = network.subscribe_to_event();
        let proposerack_receiver = network.subscribe_to_event();
        let mempool_receiver = network.subscribe_to_event();
        let quorumwaiter_receiver = network.subscribe_to_event();

        let mut dkgconfig = sodkg::load_dkg_config();
        //for dkg nb node to be the same as SR
        dkgconfig.min_number_of_node = nb_nodes;
        let node_peer_info = PeerInfo {
            ip: tx_ip,
            pubkey: PublicKey::try_from(&secret).unwrap(),
        };
        let clone_conf = committee_config.clone();
        ret.push(tokio::spawn(async move {
            wait_allconnection(&network, start_receiver, node_peer_info, nb_nodes).await;
            match BftNode::new(
                committee,
                clone_conf,
                &store_path,
                None,
                network,
                concensus_receiver,
                proposerack_receiver,
                mempool_receiver,
                quorumwaiter_receiver,
                tx_ip,
                secret,
                node_elgamal_secret_key,
                dkgconfig,
                &ledger_path,
                Some(60_000), //Some(15000), //None, //no pruning in test
            )
            .await
            {
                Ok(node) => {
                    node.rpc_task_handle.await.unwrap();
                }
                Err(e) => log::error!("{}", e),
            }
        }));

        // Ok(tokio::spawn(async move {
        //     //TODO remove new with file and call new
        //     match Node::new_with_files(
        //         committee_file,
        //         &key_file,
        //         &store_path,
        //         None,
        //         network,
        //         concensus_receiver,
        //         proposerack_receiver,
        //         mempool_receiver,
        //         quorumwaiter_receiver,
        //         tx_ip,
        //     )
        //     .await
        //     {
        //         Ok(node) => {
        //             node.rpc_task_handle.await.unwrap();
        //         }
        //         Err(e) => error!("{}", e),
        //     }
        // }))
    }

    Ok(ret)
}

async fn wait_allconnection(
    smr_node_network_manager: &NetWorkManagerAsync,
    mut start_receiver: NetworkEventReceiver,
    node_peer_info: PeerInfo,
    number_of_smrnode: usize,
) -> Vec<PeerInfo> {
    log::info!("wait_allconnection");
    let p2p_sender = smr_node_network_manager.get_command_sender();

    let mut peer_counter = 0;
    loop {
        match start_receiver.recv().await {
            Ok(msg) => match msg {
                sop2p::PeerEvent::NewPeerConnected(peer) => {
                    log::info!("bootstrap node receive connection from peer:{peer}");
                    peer_counter += 1;
                    //wait when all peer connections are done.
                    if peer_counter == number_of_smrnode - 1 {
                        break;
                    }
                }
                sop2p::PeerEvent::MessageReceived(_, _) => (),
                sop2p::PeerEvent::PeerConnectionError(addr) => {
                    log::warn!("Error in p2p connection for peer:{}", addr)
                }
                sop2p::PeerEvent::PeerUnreachable(addr) => {
                    log::warn!("Error in p2p peer unreachable:{}", addr)
                }
            },
            Err(err) => {
                println!("Main Node error during receiving message:{:?}", err);
                break;
            }
        }
    }
    let mut committee = match p2p_sender.get_peers().await {
        Ok(peers) => peers,
        Err(err) => {
            log::error!("Can't get connected peer from p2p, exit. Cause :{}", err);
            return vec![];
        }
    };
    //add current node
    committee.push(node_peer_info);

    committee
}
