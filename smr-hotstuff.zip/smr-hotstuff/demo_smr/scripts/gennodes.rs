//to run: cargo run --bin gennodes
//to run with args: cargo run --bin gennodes -- committee_file=

// ---
// node_private_key: "aGF40iNva/KRVDYvZ6uLawVCzmSbpNT3CxHoQ3E7HGgTE74m95NniIHotAhP3hDl7SiIrU+weKtjVRu5XnaqxQ=="
// node_elgamal_private_key: "AAAAAAAAAAAAAAAAAAAAAFUVacbWEvYq7zc5eAm5iM0DWkuDTebP5WSqI0fItuR7BnEW/b9zauJiClgAef+Vh+FFgKTRR4pIlWROlfh0rSI="

// ---
// node_private_key: "ZJ86U8jtBnnHCTqB/NNWw2luihMtZ7WxSP1BQX+CwbVGwVHjENGYhDyTdZjn6ZptPwAHo5vkE3WwfmNJks2FEw=="
// node_elgamal_private_key: "AAAAAAAAAAAAAAAAAAAAAHAgCIZ8qTba7MbrBkqJScQ1myQOUxuwKul7qKNkXjOaILu3bECNtSaxX/8soLkhdAYJAnvFXUFl0ZOdX6/g5J8="
// bootstrap_node: "{{ hostvars['smr-devnet-1'].ansible_host }}"

// committee = [
// {committee_name: "smr", bootstrap_node: "smr-devnet-1", node_list = ["smr-devnet-2","smr-devnet-3","smr-devnet-4"], threshold: 3},
// {committee_name: "oracle_0", bootstrap_node: "oracle-testnet-1", node_list = ["oracle-testnet-2","oracle-testnet-3","oracle-testnet-4"]},
// ]

// output
// ->

use clap::Parser;
use serde::{Deserialize, Serialize};
use smrcommon::dkg::save_dkg_definition_target_dir;
use smrcommon::NodeDefinition;
use smrcommon::SmrDkgCommitteeDefinition;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::ElGamalPrivateKey;
use sodkg::ElGamalPubKey;
use sosmr::SmrDkgType;
use std::fs::OpenOptions;
use std::io::Write;
use std::path::Path;

#[derive(Parser, Debug)]
struct Args {
    #[clap(short, long, default_value = "./committee_def.json")]
    committee_file: String,
    #[clap(short, long, default_value = ".")]
    target_dir: String,
}

fn main() {
    env_logger::init();
    let args = Args::parse();

    let committees = match read_committee_file(&args.committee_file) {
        Ok(c) => c,
        Err(err) => {
            log::error!(
                "Can't read committee definition file:{} cause:{err}",
                args.committee_file
            );
            return;
        }
    };

    let target_path = Path::new(&args.target_dir);

    let definitions: Vec<SmrDkgCommitteeDefinition> = committees
        .committee
        .into_iter()
        .map(|c| {
            //manage other nodes
            let mut committee: Vec<NodeDefinition> = c
                .node_list
                .into_iter()
                .map(|n| manage_node_name(target_path, n, Some(&c.bootstrap_node)))
                .collect();
            //manage bootstrap node
            committee.push(manage_node_name(target_path, c.bootstrap_node, None));
            // let dkg_type = serde_json::from_str::<SmrDkgType>(&c.committee_name).expect(&format!(
            //     "committee_name not a Json DKGType:{} ",
            //     c.committee_name
            // ));
            SmrDkgCommitteeDefinition {
                dkg_type: c.committee_name,
                committee,
                threshold_f: c.threshold,
            }
        })
        .collect();
    save_dkg_definition_target_dir(target_path, &definitions)
        .expect("Error during dkg_definition file save.");
}

#[derive(Serialize, Deserialize, Default, Clone)]
struct GenCommitteeList {
    committee: Vec<GenCommittee>,
}

type NodeName = String;

#[derive(Serialize, Deserialize, Debug, Clone)]
struct GenCommittee {
    committee_name: SmrDkgType,
    bootstrap_node: NodeName,
    node_list: Vec<NodeName>,
    threshold: usize,
}

fn manage_node_name(
    target_path: &Path,
    name: NodeName,
    bootstrap: Option<&NodeName>,
) -> NodeDefinition {
    let secret = SecretKey::generate();
    let elgamal = ElGamalPrivateKey::generate();
    write_node_file(target_path, &name, &secret, &elgamal, bootstrap).unwrap();
    let publickey = PublicKey::try_from(&secret).unwrap();
    let elgamal_pubkey = ElGamalPubKey::try_from(&elgamal).unwrap();
    NodeDefinition {
        publickey: format!("{}", publickey),
        elgamal_pubkey: hex::encode(elgamal_pubkey.into_bytes()),
    }
}

fn write_node_file(
    target_path: &Path,
    name: &NodeName,
    secret: &SecretKey,
    elgamal: &ElGamalPrivateKey,
    bootstrap: Option<&NodeName>,
) -> Result<(), String> {
    let p = target_path.join(name);
    let mut file = OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(true)
        .open(p)
        .map_err(|err| format!("node:{name} write file error:{}", err))?;

    writeln!(&mut file, "---").unwrap();
    writeln!(
        &mut file,
        "node_private_key: \"{}\"",
        hex::encode(&secret.0[..])
    )
    .unwrap();
    writeln!(
        &mut file,
        "node_elgamal_private_key: \"{}\"",
        hex::encode(elgamal.into_bytes())
    )
    .unwrap();
    if let Some(bootstrap) = bootstrap {
        writeln!(
            &mut file,
            "bootstrap_node: \"{{{{ hostvars['{bootstrap}'].ansible_host }}}}\""
        )
        .unwrap();
    }
    Ok(())
}

fn read_committee_file(path: &str) -> Result<GenCommitteeList, String> {
    let text = std::fs::read_to_string(path)
        .map_err(|err| format!("read_dkg_definition file error:{}", err))?;
    serde_json::from_str::<GenCommitteeList>(&text)
        .map_err(|err| format!("read_dkg_definition parse json content error:{}", err))
}
