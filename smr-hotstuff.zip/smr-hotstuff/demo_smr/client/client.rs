// to run: RUST_BACKTRACE=1 RUST_LOG=info cargo run --release --bin client
use env_logger::Env;
use log::{info, warn};
use sha3::{Digest as Sha3Digest, Keccak256};
use socrypto::Digest;
use socrypto::Hash;
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::BlsSignature;
use sodkg::BLS_SIGNATURE_LEN;
use sosmr::oracle::CoherentCluster;
use sosmr::oracle::Origin;
use sosmr::oracle::SignedCoherentCluster;
use sosmr::SmrBlock;
use sosmr::{SmrTransaction, SmrTransactionProtocol};
use std::collections::HashSet;
use std::net::Ipv4Addr;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::sync::mpsc;
use tokio::sync::Mutex;
use tokio::time::{interval, Duration}; //Instant

#[tokio::main]
async fn main() -> Result<(), String> {
    env_logger::Builder::from_env(Env::default().default_filter_or("info"))
        .format_timestamp_millis()
        .init();

    // Start the benchmark.
    start_send().await
}

pub async fn start_send() -> Result<(), String> {
    const PRECISION: u64 = 20; // Sample precision.
    const BURST_DURATION: u64 = 1000 / PRECISION;
    const BURST_RATE: u64 = 100;

    let sender_private_key = SecretKey::generate();

    // The transaction size must be at least 16 bytes to ensure all txs are different.
    //connect to bootstrap node
    let tx_address = SocketAddr::from((Ipv4Addr::new(127, 0, 0, 1), 25_000));
    //let tx_address = SocketAddr::from((Ipv4Addr::new(50, 19, 131, 37), 28_000));

    // Submit all transactions.
    let burst = BURST_RATE / PRECISION;
    //let mut counter = 0;

    let ts_create_list = Arc::new(Mutex::new(HashSet::new()));

    // let _r: u64 = rand::thread_rng().gen();
    //    let mut transport = Framed::new(stream, LengthDelimitedCodec::new());
    let interval = interval(Duration::from_millis(BURST_DURATION));
    tokio::pin!(interval);

    info!("Start RPC ws listening");
    let loop_ts_create_list = ts_create_list.clone();

    tokio::spawn(async move {
        const NB_RECEIVE_BLOCK: i32 = 10;

        loop {
            let rpcclient = rpc::client::RPCClient::new(tx_address);
            let (batch_tx, mut batch_rx) = mpsc::channel(100);
            let wsclient = rpc::client::WsClient::subscribe(tx_address, move |block| async move {
                batch_tx.send(block).await
            })
            .await;

            //manage input blocks

            let input_fut = async {
                let mut counter = 0; //reopen the connection every 20 block. for test
                loop {
                    read_one_block(&mut batch_rx, &rpcclient, &loop_ts_create_list).await;
                    counter += 1;
                    if counter == NB_RECEIVE_BLOCK {
                        break;
                    }
                }
            };

            input_fut.await;
            log::info!("ICIIIIIII Before Close connection and reconnect BLOCK");

            wsclient.close_subscription().await;
            log::info!("ICIIIIIII Close connection and reconnect BLOCK");
        }
    });

    // NOTE: This log entry is used to compute performance.
    info!("Start sending transactions");
    let client = rpc::client::RPCClient::new(tx_address);

    let sub_type = 0;
    //let protocol = SmrTransactionProtocol::OracleCommittee(11);
    let protocol = SmrTransactionProtocol::OracleTribe;

    'main: loop {
        interval.as_mut().tick().await;
        //let now = Instant::now();

        for _x in 0..burst {
            let (payload, ts) = create_oracle_payload();
            ts_create_list.lock().await.insert(ts);
            let new_tx =
                SmrTransaction::sign(&sender_private_key, sub_type, protocol, payload.to_vec())
                    .unwrap();
            if let Err(e) = client.send_tx(new_tx).await {
                warn!("Failed to send transaction: {}", e);
                break 'main;
            }
            tokio::time::sleep(tokio::time::Duration::from_millis(200)).await;
        }
        // if now.elapsed().as_millis() > BURST_DURATION as u128 {
        //     // NOTE: This log entry is used to compute performance.
        //     warn!("Transaction rate too high for this client");
        // }
        // counter += 1;
        // if counter == 1000 {
        //     break;
        // }
    }
    tokio::time::sleep(tokio::time::Duration::from_millis(20000)).await;
    Ok(())
}

async fn read_one_block(
    batch_rx: &mut mpsc::Receiver<SmrBlock>,
    rpcclient: &rpc::client::RPCClient,
    loop_ts_create_list: &Arc<Mutex<HashSet<u128>>>,
) {
    match batch_rx.recv().await {
        Some(block) => {
            log::info!("received block with batch len():{}", block.payload.len());
            log::info!("received block digest:{}", block.digest());
            if !block.payload.is_empty() {
                log::info!("received block with nb batch:{}", block.payload.len());
                //get block Batches
                for (proto, key) in block.payload {
                    match rpcclient.get_batch(key.0.to_vec()).await {
                        Ok(Some(batch)) => {
                            log::info!(
                                "received batch proto:{:?} nb tx:{} digest:{}",
                                proto,
                                batch.get_nb_tx(),
                                hex::encode(key),
                            );
                            for (status, tx) in batch.into_iter_tx() {
                                let sc: SignedCoherentCluster =
                                    bincode::deserialize(&tx.payload).unwrap();

                                info!("receive Tx TS:{} status:{}", sc.cc.timestamp[0], status);
                                if !loop_ts_create_list.lock().await.remove(&sc.cc.timestamp[0]) {
                                    if status == sosmr::TxExecutionStatus::Success {
                                        warn!(
                                            "See Tx TS:{} Twice or more sign:{}",
                                            sc.cc.timestamp[0], tx.signature
                                        );
                                    } else {
                                        info!(
                                            "Replay Tx TS:{} detected sign:{}",
                                            sc.cc.timestamp[0], tx.signature
                                        );
                                    }
                                }
                            }
                        }
                        val => log::error!("receive batch error:{:?}", val),
                    }
                }
            }
        }
        None => {
            log::error!("Ws receive block channel closed");
        }
    }
}

fn create_oracle_payload() -> (Vec<u8>, u128) {
    let timestamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_millis();
    info!("Create TX with TS:{timestamp}");
    let cc: CoherentCluster = CoherentCluster {
        data_hash: create_hash("abc".as_bytes()),
        pair: vec![1],
        prices: vec![12345],
        timestamp: vec![timestamp],
        decimals: vec![5],
    };
    let b: &[u8] = &[0_u8; BLS_SIGNATURE_LEN];
    let qc = BlsSignature::try_from(b).unwrap();

    let origin = Origin {
        id: PublicKey([1; 32]),
        member_index: 2,
        committee_index: 3,
    };

    let signed_cluster = SignedCoherentCluster {
        cc,
        qc,
        round: 4,
        origin,
    };
    (bincode::serialize(&signed_cluster).unwrap(), timestamp)
}

fn create_hash(data: &[u8]) -> Hash {
    let mut hasher = Keccak256::new();
    hasher.update(data);
    Hash(<[u8; 32]>::from(hasher.finalize()))
}
