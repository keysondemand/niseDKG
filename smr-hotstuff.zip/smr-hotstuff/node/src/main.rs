//example of start
//RUST_BACKTRACE=1 RUST_LOG=node,sodkg,soruntime=trace SMRNODE_BIND_ADDR="127.0.0.1:25100" NUMBER_OF_SMRNODE="4" B64_NODE_PRIVATE_KEY="/aNKoCcFDA2EdrpRsA7eBVyrluiy9iD/zNFs91CqXLU5EKQ04TEzIqRImNGP95P99zMlXf6mLluNSDexC0j88A==" B64_NODE_ELGAMAL_PRIVATE_KEY="AAAAAAAAAAAAAAAAAAAAAASCEGCPwHAkrHCdVbYhLZZDNDzSE86BcoYNb6t2CfeaLSph/jXzqpYwvLD3cNwJKdHzHgGv7kGmQM4gD/FI4/M=" RPC_ACCESS_ADDR="127.0.0.1:25000" cargo run --release
//Start with no AuthSc when enable by default use --no-default-features
use log::{error, info};
use node::bftnode::BftNode;
use serde::{Deserialize, Serialize};
use socrypto::PublicKey;
use socrypto::SecretKey;
use sodkg::ElGamalPrivateKey;
use sodkg::ElGamalPubKey;
use sop2p::PeerInfo;
use std::collections::HashSet;
use std::env;
use std::env::VarError;
use std::net::Ipv4Addr;
use std::net::SocketAddr;

const STORE_DB_PATH: &str = "smr_storage";
const LEDGER_DB_PATH: &str = "ledger_storage";

#[cfg(feature = "memory_profile")]
mod profile {
    use alloc_track::{AllocTrack, BacktraceMode};
    use std::alloc::System;
    #[global_allocator]
    static GLOBAL_ALLOC: AllocTrack<System> = AllocTrack::new(System, BacktraceMode::Short);
}

#[derive(Serialize, Deserialize, Debug)]
struct InputNode {
    addr: String,
    pubkey: String,
}

#[tokio::main]
async fn main() {
    //    let mut builder = env_logger::Builder::from_default_env();
    //    builder.format_timestamp_millis().init();

    env_logger::init();

    //trace memory allocation
    #[cfg(feature = "memory_profile")]
    tokio::spawn(async move {
        //use profile;
        console_subscriber::init();

        tokio::task::spawn_blocking(move || loop {
            std::thread::sleep(std::time::Duration::from_millis(10000));
            log::info!("Memeory report start");
            //let report = alloc_track::backtrace_report(|_, _| true);
            //println!("BACKTRACES\n{report}");
            let report = alloc_track::thread_report();
            println!("THREADS\n{report}");
            log::info!("Memeory report end");
        })
        .await
        .unwrap();
    });

    //get config
    //node bind address
    let node_bind_addr = env::var("SMRNODE_BIND_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map_err(|_| {
                log::warn!(
                    "Provided SMRNODE_BIND_ADDR:{} not recognized. use default 127.0.0.1:25100",
                    s
                );
                VarError::NotPresent
            })
        })
        .unwrap_or_else(|_| SocketAddr::from((Ipv4Addr::new(127, 0, 0, 1), 25_100)));

    //node public address
    let node_public_addr = env::var("SMRNODE_PUBLIC_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map_err(|_| {
                log::warn!(
                    "Provided SMRNODE_PUBLIC_ADDR:{} not recognized. use default bind address",
                    s
                );
                VarError::NotPresent
            })
        })
        .unwrap_or(node_bind_addr);

    //Bootstrap node address Optional
    let bootstrap_addr = env::var("SMRBOOTSTRAP_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map_err(|_| {
                log::warn!(
                    "Provided SMRBOOTSTRAP_ADDR:{} not recognized. Start with no bootstrap",
                    s
                );
                VarError::NotPresent
            })
        })
        .ok();

    //Bootstrap node address Optional
    // let number_of_smrnode = env::var("NUMBER_OF_SMRNODE")
    //     .and_then(|s| {
    //         s.parse::<usize>().map_err(|_| {
    //             log::warn!(
    //                 "Provided NUMBER_OF_SMRNODE:{} not recognized. Wait for 5 nodes",
    //                 s
    //             );
    //             VarError::NotPresent
    //         })
    //     })
    //     .unwrap_or_else(|_| 5);

    //log::info!("number_of_smrnode:{}", number_of_smrnode);

    //Node private Key
    let node_secret_key = env::var("B64_NODE_PRIVATE_KEY")
        .and_then(|encoded_priv| {
            SecretKey::decode_base64(&encoded_priv).map_err(|_| VarError::NotPresent)
        })
        .or_else(|_| {
            env::var("NODE_PRIVATE_KEY").and_then(|encoded_priv| {
                let bytes: &[u8] = &hex::decode(encoded_priv).unwrap();
                SecretKey::try_from(bytes).map_err(|_| VarError::NotPresent)
            })
        })
        .unwrap_or_else(|_| {
            //TODO remove and return an error. Only for test
            let key = SecretKey::generate();
            let node_public_key = PublicKey::try_from(&key).unwrap(); //should not panic other the node should stop.

            log::info!(
                "B64_NODE_PRIVCATE_KEY var not defined. Generate a new one:{}",
                key.encode_base64()
            );
            log::info!("Generated public key:{}", node_public_key.encode_base64());
            key
        });

    let node_elgamal_secret_key = env::var("B64_NODE_ELGAMAL_PRIVATE_KEY")
        .and_then(|encoded_priv| {
            ElGamalPrivateKey::decode_base64(&encoded_priv).map_err(|_| VarError::NotPresent)
        })
        .or_else(|_| {
            env::var("NODE_ELGAMAL_PRIVATE_KEY").and_then(|encoded_priv| {
                ElGamalPrivateKey::try_from(hex::decode(encoded_priv).unwrap())
                    .map_err(|_| VarError::NotPresent)
            })
        })
        .unwrap_or_else(|_| {
            let key = ElGamalPrivateKey::generate();
            log::info!(
                "B64_NODE_ELGAMAL_PRIVATE_KEY var not defined. Generate a new one:{}",
                key.encode_base64()
            );
            key
        });

    //Bootstrap node address Optional
    let number_of_smrnode = env::var("NUMBER_OF_SMRNODE")
        .and_then(|s| {
            s.parse::<usize>().map_err(|_| {
                log::warn!(
                    "Provided NUMBER_OF_SMRNODE:{} not recognized. Wait for 5 nodes",
                    s
                );
                VarError::NotPresent
            })
        })
        .expect("NUMBER_OF_SMRNODE not set exit.");

    //node public address
    let rpc_binding_addr = env::var("RPC_ACCESS_ADDR")
        .and_then(|s| {
            s.parse::<SocketAddr>().map_err(|_| {
                log::warn!("Provided RPC_ACCESS_ADDR:{} parse error. exit", s);
                VarError::NotPresent
            })
        })
        .expect("Provided RPC_ACCESS_ADDR not provided. exit");

    //Bootstrap node address Optional
    let prune_block_max_time = env::var("PRUNE_BLOCK_MAX_TIME")
        .and_then(|s| {
            s.parse::<u128>().map_err(|_| {
                log::warn!(
                    "Provided PRUNE_BLOCK_MAX_TIME:{} not recognized. No block pruning done",
                    s
                );
                VarError::NotPresent
            })
        })
        .ok();

    //SMR Storage
    let smr_storage = env::var("SMR_STORAGE").unwrap_or_else(|_| STORE_DB_PATH.to_string());
    let ledger_storage = env::var("LEDGER_STORAGE").unwrap_or_else(|_| LEDGER_DB_PATH.to_string());

    #[cfg(feature = "use_auth")]
    let smr_node_network_manager = {
        let auth_maker =
            auth_sc_connector::p2p::SmrAuthManager::new(auth_sc_connector::AuthScNetwork::SMR);
        sop2p::new_async_with_auth(
            node_bind_addr,
            node_public_addr,
            node_secret_key.clone(),
            bootstrap_addr,
            auth_maker,
        )
        .await
        .unwrap()
    };
    #[cfg(not(feature = "use_auth"))]
    let smr_node_network_manager = sop2p::new_async(
        node_bind_addr,
        node_public_addr,
        node_secret_key.clone(),
        bootstrap_addr,
    )
    .await
    .unwrap();

    let handler = {
        let mut start_receiver = smr_node_network_manager.subscribe_to_event();
        tokio::spawn(async move {
            let mut peers_list = HashSet::new();
            loop {
                match start_receiver.recv().await {
                    Ok(msg) => {
                        match msg {
                            sop2p::PeerEvent::NewPeerConnected(peer) => {
                                info!("bootstrap node receive connection from peer:{peer} peer_counter:{}", peers_list.len());
                                peers_list.insert(peer.pubkey);
                                //wait when all peer connections are done.
                                if peers_list.len() == number_of_smrnode - 1 {
                                    break;
                                }
                            }
                            sop2p::PeerEvent::MessageReceived(_, _) => (),
                            sop2p::PeerEvent::PeerConnectionError(addr) => {
                                log::warn!("Error in p2p connection for peer:{}", addr)
                            }
                            sop2p::PeerEvent::PeerUnreachable(addr) => {
                                log::warn!("Error in p2p peer unreachable:{}", addr)
                            }
                        }
                    }
                    Err(err) => {
                        error!("Main Node error during receiving message:{:?}", err);
                        break;
                    }
                }
            }
        })
    };

    let mut dkgconfig = sodkg::load_dkg_config();
    //for dkg nb node to be the same as SR
    dkgconfig.min_number_of_node = number_of_smrnode;

    let elgamal_publickey = ElGamalPubKey::try_from(&node_elgamal_secret_key).unwrap();
    log::debug!(
        "Node {} starting with elgamal key:{} number_of_smrnode:{} dkg_config:{:?}",
        PublicKey::try_from(&node_secret_key).unwrap(),
        hex::encode(elgamal_publickey.into_bytes()),
        number_of_smrnode,
        dkgconfig
    );

    let concensus_receiver = smr_node_network_manager.subscribe_to_event();
    let proposerack_receiver = smr_node_network_manager.subscribe_to_event();
    let mempool_receiver = smr_node_network_manager.subscribe_to_event();
    let quorumwaiter_receiver = smr_node_network_manager.subscribe_to_event();

    handler.await.unwrap();

    let p2p_sender = smr_node_network_manager.get_command_sender();
    let mut committee = match p2p_sender.get_peers().await {
        Ok(peers) => peers,
        Err(err) => {
            log::error!("Can't get connected peer from p2p, exit. Cause :{}", err);
            return;
        }
    };
    //add current node
    committee.push(PeerInfo {
        ip: node_public_addr,
        pubkey: PublicKey::try_from(&node_secret_key).unwrap(),
    });

    info!(
        "Node {} receive enough connection start SMR",
        PublicKey::try_from(&node_secret_key).unwrap(),
    );

    //read the config from file. TODO update get it from Auth sc
    let committee_definition = smrcommon::dkg::read_dkg_definition().unwrap();
    //build committee config from definition
    let committee_config = committee_definition
        .try_into()
        .expect("error during conversion of DKG definition in the config:{}");

    log::debug!(
        "Start Smr node with committee definition:{:?}",
        committee_config
    );

    //start the smr
    let handle = tokio::spawn(async move {
        match BftNode::new(
            committee,
            committee_config,
            &smr_storage,
            None,
            smr_node_network_manager,
            concensus_receiver,
            proposerack_receiver,
            mempool_receiver,
            quorumwaiter_receiver,
            rpc_binding_addr,
            node_secret_key,
            node_elgamal_secret_key,
            dkgconfig,
            &ledger_storage,
            prune_block_max_time,
        )
        .await
        {
            Ok(node) => {
                node.rpc_task_handle.await.unwrap();
            }
            Err(e) => error!("{}", e),
        }
    });
    handle.await.unwrap();
}
