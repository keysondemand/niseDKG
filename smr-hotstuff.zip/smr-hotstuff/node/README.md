#SMR Node

## Run a SMR node

Start a SMR node. To start define the following env var:
* `SMRNODE_BIND_ADDR`: the node bind ip address. On AWS machine the now can have to bind on the 0.0.0.0 address and use the machine address as public one.
* `SMRNODE_PUBLIC_ADDR`: Optional. if the bind ip address is different from the public one. Define the public one here otherwise it use the bind address.
* `SMRBOOTSTRAP_ADDR`: Optional. public ip address of the first bootstrap node. If not provide mean that it's a bootstrap node.
* `NUMBER_OF_SMRNODE`: number of node in the SMR. If not define, set to 5.
* `B64_NODE_PRIVATE_KEY`: ed25519 node private key, base64 encoded. If you start the node without this parameters, it will generate a new one and print it with the public address associated. It's a convenient way to get new private and public key.
* `NODE_PRIVATE_KEY`: ed25519 node private key, Hex encoded. If you start the node without this parameters, it will generate a new one and print it with the public address associated. It's a convenient way to get new private and public key.
* `B64_NODE_ELGAMAL_PRIVATE_KEY`: Elgamal node private key, base64 encoded. If you start the node without this parameters, it will generate a new one and print it. It's a convenient way to get new private key.
* `NODE_ELGAMAL_PRIVATE_KEY`: Elgamal node private key, Hex encoded. If you start the node without this parameters, it will generate a new one and print it. It's a convenient way to get new private key.
* `RPC_ACCESS_ADDR`: bind address of the SMR node RPC access
* `SMR_STORAGE`: Optional filename of the rocksdb, default is 'smr_stoarege'
* `PRUNE_BLOCK_MAX_TIME`: the time a block is stored before being pruned (removed from db) in milli second. If not set, disable pruning.

For SMR DKG optinoal parameters:
* `THRESHOLD_NUMBER`: f+1 value, default 3.
* `NB_DEALERS`: number of node that are dealer, default 3.
* `DEALER_THRESHOLD`: g+1 value, default 2

The `MIN_NUMBER_OF_NODE` is set to the SMR `NUMBER_OF_SMRNODE`

Smart contract Auth
* `AUTHSC_ADDRESS`: Eth address of the auth smart contract. Ex:"0x5FbDB2315678afecb367f032d93F642f64180aa3" 
* `AUTHSC_CLIENT_URL` URL of the Eth RPC access ex: http://127.0.0.1:8545

By default "use_auth" feature for authentication is activated. Use the --no-default-features flag to remove it.

Example of start commands:

To start the first node of a SMR with 4 nodes with bind is:0.0.0.0 and public address: 127.0.0.1:25100;

First build the node: cargo build --release

Then start the exe: `RUST_BACKTRACE=1 RUST_LOG=node,sodkg,soruntime=trace SMRNODE_BIND_ADDR="127.0.0.1:25101" SMRBOOTSTRAP_ADDR="127.0.0.1:25100" NUMBER_OF_SMRNODE="4" RPC_ACCESS_ADDR="127.0.0.1:25001" B64_NODE_PRIVATE_KEY="gjDXUA7TGWSXZR5YK8CIdRu+y670ezhsLxfqEToy9kRdeaV7jSMnIWSde3JNR6aKD+bR2DSEPQhTYrk70okMlw==" B64_NODE_ELGAMAL_PRIVATE_KEY="AAAAAAAAAAAAAAAAAAAAAFLew5G+fgQT+y4lxFPuwVQGn/uAgmLkPQicl0kZPr84AMGpbq2JSbNjpqlcTv6tbExkuPPq2y+VU39os5skr5M=" ./target/release/smrnode`

# DKG integration.

## Definitions
A DKG must have an id call SmrDkgType. For each id, the DKG data are stored on SRM database call ledger.

Currently the ledger and the block/batch db is the same but it can change in the future.

A DKG is use to define a committee. A committee is a set of node that agree using the DKG to share a public key call Committee threshold public Key.

THis key is use to verify all data signed by the committee.

To execute a DKG on the SMR, its committee must be defined in the SmrDkgCommitteeDefinition structure that is loaded from the file `dkgs_definition.json` located at the root directory of each SMR nodes.

This file must contains the definition of the DKG that has to be run.

To run a DKG, the smrcommon lib contains the function `bottstrap_dkg` that extract the DKG state and finish or return the last finished state.

After its execution, return action must be executed and corresponding event notified to the return `EventProcessor`.

## SMR FDK file definition
This file is a json file containing an array of `SmrDkgCommitteeDefinition`

For each node the file contains:
 * Node public key
 * Node Elgamal public key

For the committee, the f+1 threshold number is indicated.

### Example for VRF DKG
A committee with 4 nodes with id: SmrDkgType::Vrf

    {
        "dkg_type": "Vrf",
        "committee":
        [
            {
                "publickey": "3910a434e1313322a44898d18ff793fdf733255dfea62e5b8d4837b10b48fcf0",
                "elgamal_pubkey": "021380d4d4de6021f5bd8fbba009ec27efcbcf8d86115b75f0727b2ad3c6d61ac94b50be439fd7c221f720fbaa0a029bb4030f8b9f119ae546c1beb4494bef22b50ca2a5ff55137bdcc5956607976c387f1a735d4d89fe5f1c6fd4b208577d11e3a50000000000000000000000000000000035b0fdf3a960f3857ff806ad5e9f5fd26f8818440bfcd0e01e148b3695f9f09500000000000000000000000000000000699fdbbf6276b366f25b8b84687b429ccac040f952ef133bcc377023f27449110205264ef445dbf4538828f0490b4017592c56e514e3df0fd97ab7eb87c5f2f781030a35da16cc98beb50a7dc0ff46ce1ee52e6a8364b0cf9560a229b5c9a2a596b8012512dd5eff23cf8e14a720c55394d857b815ad1f5816fff3f395a94706b3ca089783b86742b3b2ffe0c0cecf8a2e9ffd0eb8255a45878e2604386696c6255a"
            },
            {
                "publickey": "5d79a57b8d232721649d7b724d47a68a0fe6d1d834843d085362b93bd2890c97",
                "elgamal_pubkey": "021273b2f70905532715569fd66a21e610c3c7683f1a3723601992b93918565755e4175bf40696e16767ff96357ae884be0202d8d453f3d791af15917a0c5deb9a6e5b0121a541e2f6b10c040d0ba1699e871fa8ef13d66d403ad98abd798270f574000000000000000000000000000000004b6864d92dc03bc512cf240dcfaa2bbc4dea8cc69d8ea792a2099b41a02ac81a00000000000000000000000000000000062dea91b1d2ca0b6679d15d69b2fec516f626fff4b4ac6c535cdd720512e46603236820aeda6d20975c477cde3a682828380fc8c80a02c0378f2c1c281fbeaac7022b99e9627dfedf17c9ea9e2a0cee4c5fe0745bf1d1c7a888925ec3d54bba30051836f1f0c73a7567c66d72c14807661065eaaaa9c86e3a7fcef5e8af6bd2a0d310cbbd6d4c191d735136dedeb806eb65afdd464309e5ece73671083856ca23b9"
            },
            {
                "publickey": "417ec4627e882981a8a865bda654350515067fe4b5c93cfe5accb39e74e17fe6",
                "elgamal_pubkey": "020038a8b65f0e36b0248f9b969eee195b8a9af831480dce3a39a257720d8afe78f83b7b894e48b57d8400d2a78af47cc103065fc76e6eac68e4702c1a7c6a116df684bce72052ef2f5849eeb4efea9543aba12936c0175e69e9a954e5b46b0eed15000000000000000000000000000000006a389ca287df4928fd227b7e1f6ef7a523d2040b26db8d26a34c6a14b2417cb9000000000000000000000000000000003b2e43936b61c0e660556727b94546eb5cc42499843d3de5f8d699f6adf8f024031a1bdafbf8c15b4767f8e92b90c223c43a018a81831a7443bb390d83041c5f4a0326096245405be8b44b2dfee91771bee1e576aebb7412b8e440fabbfe701bfcac1686b9724cc72b96c082e44123ad8c823a12b6894ec72f267097c1205cd156e51c161a1cef04e5d6733354228e03dc42d6f3009e7e8ab72ec0dd9d67a5c00d86"
            },
            {
                "publickey": "19cf2cf5e6b9676aeb5a8605dcfe610aaa9e5bfb4c80d007d16d716a31a10559",
                "elgamal_pubkey": "0308877dd800cbc1b1b449cee0df848a6e6f7de8d38da90bcabd390e00710e9225586571a75b748bff28c40f77e9ec4dfc031436829d8057c4dc2bc85adccc30e2bfbfab9ccc8bbc67912f94e8d76e4c93d5a7f1f9b301eba455111a8f805db7793400000000000000000000000000000000097689f8bb09f0e607b1c71239fd099fced9160ac4e8f7e7034c22927b26e33e000000000000000000000000000000007252507ef3df09aa6053d1c81a7d30268cbe0c05dc21be4243d208a1885997780307692cc8610bd31a6042327722419fa39f5d3a3e26a263a7414a09e3fd4101fc030bfe52471d670fe7a8f24766628cbf2e4a9e8bd496d8282298a00bf5650d4d3c1dea9efe74e546f658a9a7621c3c74fd91245728e244e869dc3e709d2ce034f71954584e77357f51947bacccfaa37357dc319eb8368ba4ea83b424e0e33f92e4"
            }
        ],
        "threshold_f": 3
    }


## Start a test committee
To start the SMR with a default number of node, in demo_smr, nodes, a mains program start in memory all the node of a running smr.

To use it add you DKG definition in the `dkgs_definition.json` file. then run the command:

`RUST_BACKTRACE=1 RUST_LOG=info cargo run --release`

## Start one node
To start one node, update the `dkgs_definition.json` file with your committees, in the node folder run the command:

`RUST_BACKTRACE=1 RUST_LOG=info AUTHSC_CLIENT_URL="http://127.0.0.1:854" AUTHSC_ADDRESS="5FbDB2315678afecb367f032d93F642f64180aa3" B64_NODE_PRIVATE_KEY=/aNKoCcFDA2EdrpRsA7eBVyrluiy9iD/zNFs91CqXLU5EKQ04TEzIqRImNGP95P99zMlXf6mLluNSDexC0j88A== COMMITTEE_INFO='[{"addr":"127.0.0.1:25100","pubkey":"ORCkNOExMyKkSJjRj/eT/fczJV3+pi5bjUg3sQtI/PA="},{"addr":"127.0.0.1:25101","pubkey":"NFtUiqJSuzTbTHNGlYiiCzBIccY0BQem9DjAVzyx0NM="}]' RPC_ACCESS_ADDR="127.0.0.1:25000" cargo run --release`

Update the parameters as needed.

## SMR DB files
Each smr node creates 3 db files:
 * smr_storage.persy : contains the block/batch produced. It can be removed before each start because currently the SRM restart from genesis. Always open can't be copied when the SMR is running.
 * ledger_storage.persy: contains the ledger data. Currently it's all the DKG committee done with the SMR. Always open can't be copied.
 * ledger_backup.persy: a backup of the ledger_storage.persy. The backup is done automatically after one minute of ledger db inactivity. It can be copied when no DKG is running. Wait one minute to be sure to have the last DBK. This backup allow to restore the ledger db to avoid to lost the DKG committee. To restore stop the SMR, rename the file to ledger_storage.persy and restart the SMR. This file should be archived when all application VRF, Oracle has been started to keep all DKG data.

 
